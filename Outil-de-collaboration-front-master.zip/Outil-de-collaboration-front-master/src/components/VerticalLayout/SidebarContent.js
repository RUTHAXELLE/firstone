import PropTypes from "prop-types"
import React, { Component, Fragment } from "react"
//Simple bar
import SimpleBar from "simplebar-react"
// MetisMenu
import MetisMenu from "metismenujs"
import { Link, withRouter } from "react-router-dom"
//i18n
import { withTranslation } from "react-i18next"
import {
  ROUTE_CAMPAIGN,
  ROUTE_SETTINGS_DOMAIN,
  ROUTE_SETTINGS_DOMAIN_TYPE,
  ROUTE_EXPERIENCE,
  ROUTE_SETTINGS_CAMPAIGN, ROUTE_SETTINGS_USER,
  ROUTE_SETTINGS_PROFILE
} from "../../helpers/route_helper"
import { isGranted, isValidToken, loggedUser } from "../../helpers/jwt_helpers"
import { BASE_URL } from "../../helpers/url_helper"
import { PERMISSION_SETTINGS } from "helpers/permission_helper"

class SidebarContent extends Component {
  constructor(props) {
    super(props)
    this.refDiv = React.createRef()
    this.state = {
      user: {  },
    }
  }

  componentDidMount() {
    this.initMenu()
  }

  // eslint-disable-next-line no-unused-vars
  componentDidUpdate(prevProps, prevState, ss) {
    if (this.props.type !== prevProps.type) {
      this.initMenu()
    }
  }

  initMenu() {
    new MetisMenu("#side-menu")

    let matchingMenuItem = null
    const ul = document.getElementById("side-menu")
    const items = ul.getElementsByTagName("a")
    for (let i = 0; i < items.length; ++i) {
      if (this.props.location.pathname === items[i].pathname) {
        matchingMenuItem = items[i]
        break
      }
    }
    if (matchingMenuItem) {
      this.activateParentDropdown(matchingMenuItem)
    }
    const token = isValidToken()
    let user = token.user
    if (!user) {
      user = loggedUser()
    }
    this.setState({ user })
  }

  // componentDidUpdate() {}

  scrollElement = item => {
    setTimeout(() => {
      if (this.refDiv.current !== null) {
        if (item) {
          const currentPosition = item.offsetTop
          if (currentPosition > window.innerHeight) {
            if (this.refDiv.current)
              this.refDiv.current.getScrollElement().scrollTop =
                currentPosition - 300
          }
        }
      }
    }, 300)
  }

  activateParentDropdown = item => {
    item.classList.add("active")
    const parent = item.parentElement

    const parent2El = parent.childNodes[1]
    if (parent2El && parent2El.id !== "side-menu") {
      parent2El.classList.add("mm-show")
    }

    if (parent) {
      parent.classList.add("mm-active")
      const parent2 = parent.parentElement

      if (parent2) {
        parent2.classList.add("mm-show") // ul tag

        const parent3 = parent2.parentElement // li tag

        if (parent3) {
          parent3.classList.add("mm-active") // li
          parent3.childNodes[0].classList.add("mm-active") //a
          const parent4 = parent3.parentElement // ul
          if (parent4) {
            parent4.classList.add("mm-show") // ul
            const parent5 = parent4.parentElement
            if (parent5) {
              parent5.classList.add("mm-show") // li
              parent5.childNodes[0].classList.add("mm-active") // a tag
            }
          }
        }
      }
      this.scrollElement(item)
      return false
    }
    this.scrollElement(item)
    return false
  }

  render() {
    const { user } = this.state
    return (
      <React.Fragment>
        <SimpleBar style={{ maxHeight: "100%" }} ref={this.refDiv}>
          <div id="sidebar-menu">
            <ul className="metismenu list-unstyled" id="side-menu">
              {/*<li className="menu-title">{this.props.t("Menu")}</li>
              <li>
                <Link to="/#" className="waves-effect">
                  <i className="bx bx-home-circle" />
                  <span className="badge badge-pill badge-info float-right">
                    04
                  </span>
                  <span>{this.props.t("Dashboards")}</span>
                </Link>
                <ul className="sub-menu" aria-expanded="false">
                  <li>
                    <Link to="/dashboard">{this.props.t("Default")}</Link>
                  </li>
                  <li>
                    <Link to="/dashboard-saas">{this.props.t("Saas")}</Link>
                  </li>
                  <li>
                    <Link to="/dashboard-crypto">{this.props.t("Crypto")}</Link>
                  </li>
                  <li>
                    <Link to="/dashboard-blog">{this.props.t("Blog")}</Link>
                  </li>
                </ul>
              </li>*/}


              <li className="menu-title">{this.props.t("Navigation")}</li>

              <li>
                <Link to={ROUTE_CAMPAIGN} className=" waves-effect">
                  <i className="bx bx-calendar"/>
                  <span>{this.props.t("Campaigns")}</span>
                </Link>
              </li>

              

              {isGranted( PERMISSION_SETTINGS ) ? (
                <Fragment>
                  <li className="menu-title">{this.props.t("Settings")}</li>

                  <li>
                    <Link to={ROUTE_SETTINGS_DOMAIN} className=" waves-effect">
                      <i className="bx bx-sitemap"/>
                      <span>{this.props.t("Domains")}</span>
                    </Link>
                  </li>
                  <li>
                    <Link to={ROUTE_SETTINGS_DOMAIN_TYPE} className=" waves-effect">
                      <i className="bx bx-columns"/>
                      <span>{this.props.t("Domain types")}</span>
                    </Link>
                  </li>
                  <li>
                    <Link to={ROUTE_SETTINGS_CAMPAIGN} className=" waves-effect">
                      <i className="bx bx-calendar"/>
                      <span>{this.props.t("Campaigns")}</span>
                    </Link>
                  </li>
                  <li>
                    <Link to={ROUTE_SETTINGS_PROFILE} className=" waves-effect">
                      <i className="fas fa-user-cog"/>
                      <span>{this.props.t("Profiles")}</span>
                    </Link>
                  </li>

                  <li>
                    <Link to = { "#" } className=" waves-effect">
                      <i className="bx bx-check-shield"/>
                      <span>{ this.props.t( "Permissions" ) }</span>
                    </Link>
                  </li>
                  <li>
                    <Link to={ROUTE_SETTINGS_USER} className=" waves-effect">
                      <i className="bx bx-user-circle"/>
                      <span>{this.props.t("Users")}</span>
                    </Link>
                  </li>
                </Fragment>
              ) : ''}
            </ul>
          </div>
        </SimpleBar>
      </React.Fragment>
    )
  }
}

SidebarContent.propTypes = {
  location: PropTypes.object,
  t: PropTypes.any,
  type: PropTypes.string,
}

export default withRouter(withTranslation()(SidebarContent))
