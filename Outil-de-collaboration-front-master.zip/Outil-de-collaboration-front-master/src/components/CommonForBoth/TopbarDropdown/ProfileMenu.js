import React, { Component } from "react"
import PropTypes from "prop-types"
import { Dropdown, DropdownItem, DropdownMenu, DropdownToggle } from "reactstrap"
import { Link, withRouter } from "react-router-dom"
import { get } from "../../../helpers/api_helper"
import Avatar from "react-avatar"

//i18n
import { withTranslation } from "react-i18next"

// users
import { isValidToken, loggedUser } from "../../../helpers/jwt_helpers"
import { BASE_URL, USER } from "../../../helpers/url_helper"
import { connect } from "react-redux"
import { checkToken, logoutUser } from "../../../store/auth/login/actions"
import { ROUTE_LOGIN } from "helpers/route_helper"
import { MAIL_ADDRESS, STORAGE_TOKEN } from "helpers/localStorage_helper"

class ProfileMenu extends Component {
  constructor(props) {
    super(props)
    this.state = {
      menu: false,
      name: "Admin",
      photo: BASE_URL
    }
    this.toggle = this.toggle.bind(this)
  }

  toggle() {
    this.setState(prevState => ({
      menu: !prevState.menu
    }))
  }

  setPhoto(picture) {
    this.setState(prevState => ({
      photo: { ...prevState.photo, picture }
    }))
  }

  getPhoto(userId) {
    get(`${USER}/${userId}`).then(response => {
        this.setPhoto(response.picture)
      }
    )
  }

  componentDidMount() {
    this.props.checkToken()
    const token = isValidToken()
    let user = token.user

    if (!user) {
      user = loggedUser()
    }

    this.setState({ name: `${user.firstname} ${user.lastname}` })

    //this.getPhoto(user.id)
  }

  render() {
    return (
      <React.Fragment>
        <Dropdown
          isOpen={this.state.menu}
          toggle={this.toggle}
          className="d-inline-block"
        >
          <DropdownToggle
            className="btn header-item waves-effect"
            id="page-header-user-dropdown"
            tag="button"
          >
            <Avatar
              className="rounded-circle"
              name={this.state.name}
              src={ isValidToken()?.user?.picture || this.state.photo }
              alt="Header Avatar"
              size="36" />
            <span className="d-none d-xl-inline-block ml-2 mr-1">
              {this.state.name}
            </span>
            <i className="mdi mdi-chevron-down d-none d-xl-inline-block" />
          </DropdownToggle>
          <DropdownMenu right>
            <DropdownItem tag="a" href="/profile">
              <i className="bx bx-user font-size-16 align-middle mr-1" />
              {this.props.t("Profile")}
            </DropdownItem>
            {/*<DropdownItem tag="a" href="/crypto-wallet">
              <i className="bx bx-wallet font-size-16 align-middle mr-1"/>
              {this.props.t("My Wallet")}
            </DropdownItem>*/}
            <DropdownItem tag="a" href="#">
              <span className="badge badge-success float-right mt-1">5</span>
              <i className="bx bx-wrench font-size-17 align-middle mr-1" />
              {this.props.t("Settings")}
            </DropdownItem>
            <DropdownItem tag="a" href="auth-lock-screen">
              <i className="bx bx-lock-open font-size-16 align-middle mr-1" />
              {this.props.t("Lock screen")}
            </DropdownItem>
            <div className="dropdown-divider" />
            <Link to={ "#" } className="dropdown-item">
              <i className="bx bx-power-off font-size-16 align-middle mr-1 text-danger" />
              <span onClick = { () => { 
                localStorage.removeItem( STORAGE_TOKEN )
                localStorage.removeItem( MAIL_ADDRESS )
                this.props.logoutUser( this.props.history ) 
                } }>{this.props.t("Logout")}</span>
            </Link>
          </DropdownMenu>
        </Dropdown>
      </React.Fragment>
    )
  }
}

ProfileMenu.propTypes = {
  t: PropTypes.any,
  checkToken: PropTypes.func,
}

const mapStateToProps = state => {
  const { isValidToken } = state.Login
  return { isValidToken }
}

export default withRouter(
  connect(mapStateToProps, { checkToken, logoutUser })(withTranslation()(ProfileMenu))
)
