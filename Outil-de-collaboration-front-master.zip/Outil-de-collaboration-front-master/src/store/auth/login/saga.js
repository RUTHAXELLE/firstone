import { call, put, takeEvery } from "redux-saga/effects"
// Login Redux States
import { CHECK_TOKEN, LOGIN_USER, LOGOUT_USER } from "./actionTypes"
import { apiError, loginSuccess, validToken } from "./actions"
//Include Both Helper File with needed methods
import { postLogin } from "../../../helpers/backend_helper"
import { ROUTE_DASHBOARD, ROUTE_LOGIN } from "../../../helpers/route_helper"
import { STORAGE_TOKEN } from "../../../helpers/localStorage_helper"
import { isValidToken } from "../../../helpers/jwt_helpers"

function* loginUser( { payload: { user, history } } ) {
  try {
    let response = null // Ajout d'une vérification
    if (process.env.REACT_APP_DEFAULTAUTH === "jwt") {
      response = yield call( postLogin, {
        email: user.email,
        password: user.password,
        rememberMe: user.rememberMe
      })
      
      localStorage.setItem( STORAGE_TOKEN, response.access_token )
      yield put( loginSuccess( response ) ) // Sinon il peut y avoir accès
    }
    if ( history ) history.push( ROUTE_DASHBOARD )
  } catch (error) {
    yield put( apiError( error ) )
  }
}

function* logoutUser({ payload: { history } }) {
  try {
    localStorage.removeItem(STORAGE_TOKEN)
    history.push(ROUTE_LOGIN)
  } catch (error) {
    yield put(apiError(error))
  }
}

function* checkToken() {
  try {
    const token = isValidToken()
    yield put(validToken(token.isValid))
  } catch (error) {
    yield put(validToken(false))
  }
}

function* authSaga() {
  yield takeEvery(LOGIN_USER, loginUser)
  yield takeEvery(LOGOUT_USER, logoutUser)
  yield takeEvery(CHECK_TOKEN, checkToken)
}

export default authSaga
