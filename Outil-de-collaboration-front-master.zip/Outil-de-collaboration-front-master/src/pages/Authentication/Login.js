import React, { Component } from "react"
import PropTypes from "prop-types"

import { Alert, Card, CardBody, Col, Container, Row } from "reactstrap"
// Redux
import { connect } from "react-redux"
import { Link, withRouter } from "react-router-dom"
// availity-reactstrap-validation
import { AvField, AvForm, AvInput } from "availity-reactstrap-validation"
// actions
import { apiError, loginUser, socialLogin } from "../../store/actions"
// import images
import profile from "../../assets/images/profile-img.png"
import logo from "../../assets/images/logo-s.png"
import { withTranslation } from "react-i18next"
import { ROUTE_DASHBOARD, ROUTE_FORGET_PASSWORD } from "helpers/route_helper"
import { post } from "helpers/api_helper"
import { POST_LOGIN } from "helpers/url_helper"
import { STORAGE_TOKEN } from "helpers/localStorage_helper"

class Login extends Component {
  constructor(props) {
    super(props)
    this.state = {}

    // handleValidSubmit
    this.handleValidSubmit = this.handleValidSubmit.bind(this)
  }

  componentDidMount() {
    this.props.apiError("")
  }

  // handleValidSubmit
  handleValidSubmit(event, values) {
    this.props.loginUser(values, this.props.history)
  }

  /**
   * Gestion des inputs du formulaire
   *
   * @param target
   */
  handleChangeInput = ({target}) => {
    //const value = (target.name === 'rememberMe') ? target.checked : target.value
    /*this.setState({
      //[target.name]: value,
      loading: false,
      errorMessage: null
    })*/
  }

  render() {
    return (
      <React.Fragment>
        <div className="account-pages my-3 pt-sm-3">
          <Container>
            <Row className="justify-content-center">
              <Col md={8} lg={6} xl={5}>
                <Card className="overflow-hidden">
                  <div className="bg-soft-primary">
                    <Row>
                      <Col className="col-7">
                        <div className="text-primary p-4">
                          <h5 className="text-primary">{this.props.t("Welcome Back !")}</h5>
                          <p>{this.props.t("Sign in to continue to Mindset BU.")}</p>
                        </div>
                      </Col>
                      <Col className="col-5 align-self-end">
                        <img src={profile} alt="" className="img-fluid" />
                      </Col>
                    </Row>
                  </div>
                  <CardBody className="pt-0">
                    <div>
                      <Link to="/">
                        <div className="avatar-md profile-user-wid mb-4">
                          <span className="avatar-title rounded-circle bg-light">
                            <img
                              src={logo}
                              alt=""
                              height="34"
                            />
                          </span>
                        </div>
                      </Link>
                    </div>
                    <div className="p-2">
                      <AvForm
                        className="form-horizontal"
                        onValidSubmit={this.handleValidSubmit}>
                        {this.props.error && this.props.error ? (
                          <Alert color="danger">{this.props.error}</Alert>
                        ) : null}

                        <div className="form-group">
                          <AvField
                            name="email"
                            label={this.props.t("Email or username")}
                            onChange={this.handleChangeInput}
                            className="form-control"
                            placeholder={this.props.t("Enter email")}
                            type="text"
                            validate={{
                              required: {value: true, errorMessage: this.props.t("This field is required")},
                              email: {value: true, errorMessage: this.props.t("This email field is invalid")},
                            }}
                          />
                        </div>

                        <div className="form-group">
                          <AvField
                            name="password"
                            label={this.props.t("Password")}
                            onChange={this.handleChangeInput}
                            type="password"
                            validate={{
                              required: {value: true, errorMessage: this.props.t("This field is required")},
                              minLength: {value: 2, errorMessage: this.props.t("Your password must contain at least 2 characters")},
                            }}
                            placeholder={this.props.t("Enter Password")}
                          />
                        </div>

                        <div className="custom-control custom-checkbox">
                            <AvInput
                            type="checkbox"
                            className="custom-control-input"
                            id="rememberMe"
                            name="rememberMe"
                            onChange={this.handleChangeInput}
                          />
                          <label
                            className="custom-control-label"
                            htmlFor="rememberMe">
                            {this.props.t("Remember me")}
                          </label>
                        </div>

                        <div className="mt-3">
                          <button
                            className="btn btn-primary btn-block waves-effect waves-light"
                            type="submit">
                            {this.props.t("Log In")}{" "}
                            {this.props.loading ? ( <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2" /> ) : ( "" )}
                          </button>
                        </div>

                        <div className="mt-4 text-center">
                          <Link to = { ROUTE_FORGET_PASSWORD } className="text-muted">
                            <i className="mdi mdi-lock mr-1" />
                            {this.props.t("Forgot your password?")}
                          </Link>
                        </div>
                      </AvForm>
                    </div>
                  </CardBody>
                </Card>
              </Col>
            </Row>
          </Container>
        </div>
      </React.Fragment>
    )
  }
}

Login.propTypes = {
  apiError: PropTypes.any,
  error: PropTypes.any,
  history: PropTypes.object,
  loginUser: PropTypes.func,
  socialLogin: PropTypes.func
}

const mapStateToProps = state => {
  const { error, loading } = state.Login
  return { error, loading }
}

export default withRouter(
  connect(mapStateToProps, { loginUser, apiError, socialLogin })(withTranslation()(Login))
)
