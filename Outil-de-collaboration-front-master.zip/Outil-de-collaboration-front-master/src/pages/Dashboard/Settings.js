import React, { Component } from "react"
import { Link } from "react-router-dom"
import {
  Card,
  CardBody,
  Col,
  Dropdown,
  UncontrolledDropdown,
  DropdownMenu,
  DropdownToggle,
  Row, Nav, NavItem, NavLink, TabContent, TabPane, FormGroup, Label, InputGroup, InputGroupAddon, Input, Button, Alert
} from "reactstrap"

import avatar from "../../assets/images/users/avatar-1.jpg"
import profileImg from "../../assets/images/profile-img.png"
import Avatar from "react-avatar"
import { isGranted, isValidToken, loggedUser } from "../../helpers/jwt_helpers"
import { BASE_URL, DOMAIN } from "../../helpers/url_helper"
import { withTranslation } from "react-i18next"
import classnames from "classnames"
import { AvField, AvForm } from "availity-reactstrap-validation"
import { get } from "../../helpers/api_helper"

class Settings extends Component {
  constructor(props) {
    super(props)
    this.state = {
      user: null,
      name: "Admin",
      photo: BASE_URL,
      loading: false,
      recipient: true,
      domains: [],
      statsDto: props?.statsDto ?? {
        issuingDomainId: undefined,
        receivingDomainId: loggedUser()?.domain?.id,
        compaignId: undefined,
        status: undefined,
        year: new Date().getFullYear()
      }
    }

    this.user = loggedUser()

    this.getDomains()

    // handleValidSubmit
    this.handleValidSubmit = this.handleValidSubmit.bind(this)
  }

  componentDidMount() {
    const token = isValidToken()
    let user = token.user

    if (!user) {
      user = loggedUser()
    }

    this.setState({ user: user, name: `${user.firstname} ${user.lastname}` })
  }

  toggle = () => {
    this.setState({recipient: !this.state.recipient})
  }

  handleChangeInput = ({target}) => {
    this.setState({
      statsDto: {
        ...this.state.statsDto,
        [target.name]: target.value
      }
    })
  }

  // handleValidSubmit
  handleValidSubmit(event, values) {
    this.props.onSubmit(values)
  }

  getDomains = () => {
    get(DOMAIN).then(
      response => {
        this.setState({ domains: response })
      }
    ).catch(error => {
        console.log(error)
      }
    )
  }

  buttonStyle = {
    '&::before': {
      content: `{${this.props.t("OR")}}`,
      backgroundColor: "#1c3ce7"
    }
  }

  render() {
    const { t } = this.props
    const { loading, statsDto, recipient } = this.state
    return (
      <React.Fragment>
        <Col xl={4}>
          <Card className="overflow-hidden">
            <div className="bg-soft-primary">
              <Row>
                <Col xs="7">
                  <div className="text-primary p-3">
                    <h5 className="text-primary">{this.props.t("Welcome Back !")}</h5>
                    <p>{this.props.t("Mindset BU.")}</p>
                  </div>
                </Col>
                <Col xs="5" className="align-self-end">
                  <img src={profileImg} alt="" className="img-fluid"/>
                </Col>
              </Row>
            </div>
            <CardBody className="pt-0">
              <Row>
                <Col sm="4">
                  <div className="avatar-md profile-user-wid mb-4">
                    <Avatar
                      className="rounded-circle"
                      name={this.state.name}
                      src={isValidToken()?.user?.picture || this.state.photo}
                      alt={this.state.name}
                      size="54"/>
                  </div>
                  <h5 className="font-size-15 text-truncate">{this.state.name}</h5>
                  <p className="text-muted mb-0 text-truncate">{this.state.user?.domain?.name ?? ""}</p>
                </Col>

                <Col sm="8">
                  <div className="pt-4">
                    <Row>
                      <Col xs="6">
                        <h5 className="font-size-15">125</h5>
                        <p className="text-muted mb-0">Projects</p>
                      </Col>
                      <Col xs="6">
                        <h5 className="font-size-15">$1245</h5>
                        <p className="text-muted mb-0">Revenue</p>
                      </Col>
                    </Row>
                    {/*<div className="mt-4">
                    <Link
                      to=""
                      className="btn btn-primary waves-effect waves-light btn-sm"
                    >
                      View Profile <i className="mdi mdi-arrow-right ml-1"/>
                    </Link>
                  </div>*/}
                  </div>
                </Col>
              </Row>
            </CardBody>
          </Card>

          <Card>
            <CardBody>
              <h4 className="card-title mb-4">{t('Filter')}</h4>

              <AvForm
                className="form-horizontal"
                onValidSubmit={this.handleValidSubmit}>

                <FormGroup className="mb-3">
                  <AvField
                    name="year"
                    label={t("Year")}
                    className="form-control"
                    onChange={this.handleChangeInput}
                    value={statsDto?.year}
                    type="text"
                    validate={{
                      required: {value: true, errorMessage: this.props.t("This field is required")},
                    }}
                  />
                </FormGroup>

                <FormGroup className="mb-3">
                  <AvField
                    name={(recipient) ? "receivingDomainId" : "issuingDomainId"}
                    label={t("Domain")}
                    className="form-control"
                    onChange={this.handleChangeInput}
                    value={statsDto?.receivingDomainId}
                    type="select"
                    disabled={!isGranted("Administrateur")}
                    validate={{
                      required: { value: true, errorMessage: this.props.t("This field is required") }
                    }}>
                    <option value="">{this.props.t("Select a domain")}</option>
                    {this.state.domains.map((item, i) =>
                      <option value={item.id}>{item.name}</option>
                    )}
                  </AvField>
                </FormGroup>

                <FormGroup>
                  <div
                    className="btn-group btn-group-example mb-3"
                    role="group"
                  >
                    <button
                      type="button"
                      className="btn btn-primary w-xs"
                      onClick={() => this.toggle()}
                      disabled={(recipient)}
                    >
                      {t('Recipient')}
                      <i className="mdi mdi-transfer-down mx-2"/>
                    </button>
                    <button
                      type="button"
                      className="btn btn-danger w-xs pl-3"
                      onClick={() => this.toggle()}
                      disabled={!recipient}
                      style={this.buttonStyle}
                    >
                      {t('Sender')}
                      <i className="mdi mdi-transfer-up ml-2"/>
                    </button>
                  </div>
                </FormGroup>

                <div className="text-center">
                  <button
                    className="btn btn-primary btn-block waves-effect waves-light"
                    type="submit">
                    {t("Submit")}{" "}
                    {loading ? ( <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2" /> ) : ( "" )}
                  </button>
                </div>
              </AvForm>
            </CardBody>
          </Card>
        </Col>
      </React.Fragment>
    )
  }
}

export default withTranslation()(Settings)
