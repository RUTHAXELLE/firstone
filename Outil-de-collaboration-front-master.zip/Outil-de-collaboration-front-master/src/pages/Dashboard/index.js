import React, { Component } from "react"
import { Col, Container, Row } from "reactstrap"
//Import Breadcrumb
import Breadcrumbs from "../../components/Common/Breadcrumb"
import CardUser from "./CardUser"
import Settings from "./Settings"
import { withTranslation } from "react-i18next"
import { EXPERIENCE_ISSUING_DOMAIN, STATS } from "../../helpers/url_helper"
import { get, post } from "../../helpers/api_helper"
import { loggedUser } from "../../helpers/jwt_helpers"
import * as moment from "moment"

class Dashboard extends Component {
  constructor(props) {
    super(props)
    this.state = {
      stats: {
        positive: {
          datas: [],
          total: undefined
        },
        perfectible: {
          datas: [],
          total: undefined
        }
      },
      cardreport: {
        options: this.options,
        series: []
      },
      statsDto: {
        issuingDomainId: undefined,
        receivingDomainId: loggedUser()?.domain?.id,
        compaignId: undefined,
        status: undefined,
        year: new Date().getFullYear()
      }
    }

    this.user = loggedUser()

    this.statsDto = this.statsDto.bind(this)

    this.getStats()
  }

  options = {
    chart: {
      height: 350,
      type: "area",
      toolbar: {
        show: false
      }
    },
    colors: ["#80fa47", "#fc8d38"],
    dataLabels: {
      enabled: false
    },
    stroke: {
      curve: "smooth",
      width: 2
    },
    fill: {
      type: "gradient",
      gradient: {
        shadeIntensity: 1,
        inverseColors: false,
        opacityFrom: 0.45,
        opacityTo: 0.05,
        stops: [20, 100, 100, 100]
      }
    },
    xaxis: {
      categories: [
        this.props.t("March"),
        this.props.t("June"),
        this.props.t("September"),
        this.props.t("December")
      ]
    },
    markers: {
      size: 3,
      strokeWidth: 3,

      hover: {
        size: 4,
        sizeOffset: 2
      }
    },
    legend: {
      position: "top",
      horizontalAlign: "right"
    }
  }

  getStats = () => {
    const { statsDto } = this.state
    console.log(statsDto)
    const stats = {
      year: parseInt(statsDto?.year),
      receivingDomainId: (statsDto?.receivingDomainId !== undefined)
        ? statsDto?.receivingDomainId
        : (statsDto.issuingDomainId !== undefined)
          ? undefined
          : this.user?.domain?.id ?? "",
      issuingDomainId: statsDto?.issuingDomainId ?? undefined
    }
    post(STATS, stats).then(
      response => {
        console.log(response)
        this.setState({ stats: response }, this.createCardreport)
      }
    ).catch(error => {
        console.log(error)
      }
    )
  }

  createCardreport = () => {
    console.log("createCardreport")
    let series = [{
      name: "Positive",
      data: [0, 0, 0, 0]
    },
      {
        name: "Perfectible",
        data: [0, 0, 0, 0]
      }]
    const { positive, perfectible } = this?.state?.stats

    positive?.datas?.forEach(data => {
      const i = moment(data?.campaign_end_at).utc().quarter() - 1
      series[0].data[i] = data?.campaign_experience_total
    })

    perfectible?.datas?.forEach(data => {
      const i = moment(data?.campaign_end_at).utc().quarter() - 1
      series[1].data[i] = data?.campaign_experience_total
    })

    this.setState({ cardreport: { ...this.state.cardreport, series } })
  }

  statsDto = (statsDto) => {
    console.log(statsDto)
    this.setState({statsDto}, () => this.getStats())
  }

  render() {
    const { stats, cardreport, statsDto } = this.state
    return (
      <React.Fragment>
        <div className="page-content">
          <Container fluid>
            {/* Render Breadcrumb */}
            <Breadcrumbs title="Dashboards" breadcrumbItem="Blog"/>
            <Row>
              {/* card user */}
              <CardUser
                stats={stats}
                cardreport={cardreport}
              />
              <Settings
                statsDto={statsDto}
                onSubmit={this.statsDto}
              />
            </Row>
          </Container>
        </div>
      </React.Fragment>
    )
  }
}

export default withTranslation()(Dashboard)