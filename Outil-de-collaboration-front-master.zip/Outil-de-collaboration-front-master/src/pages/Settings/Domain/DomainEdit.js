import React, { Component, Fragment } from "react"
import { Alert, Button, Card, CardBody, CardHeader, CardTitle, Col, Container, Row } from "reactstrap"
import Breadcrumbs from "../../../components/Common/Breadcrumb"
import { Breadcrumbs as Bs } from "../../../common/data/breadcrumbs"
import { withTranslation } from "react-i18next"
import { AvField, AvForm } from "availity-reactstrap-validation"
import { del, get, post, put } from "../../../helpers/api_helper"
import toastr from "toastr"
import "toastr/build/toastr.min.css"
import { DOMAIN, DOMAIN_TYPE, USER } from "../../../helpers/url_helper"
import { ROUTE_SETTINGS_DOMAIN } from "../../../helpers/route_helper"
import SweetAlert from "react-bootstrap-sweetalert/dist"

class DomainEdit extends Component {

  constructor(props) {
    super(props)

    this.state = {
      loading: false,
      delete: false,
      domain: (props.history.location.state !== undefined && props.history.location.state.domain !== null)
        ? props.history.location.state.domain : {
          id: null,
          name: null,
          manager_id: null,
          domain_type_id: null
        },
      domainTypes: [],
      managers: []
    }

    this.getDomainTypes()
    this.getManagers()

    // handleValidSubmit
    this.handleValidSubmit = this.handleValidSubmit.bind(this)
  }

  getDomainTypes = () => {
    get(DOMAIN_TYPE).then(
      response => {
        this.setState({domainTypes: response})
      }
    ).catch(error => {
        console.log(error)
      }
    )
  }

  getManagers = () => {
    get(USER).then(
      response => {
        this.setState({managers: response})
      }
    ).catch(error => {
        console.log(error)
      }
    )
  }

  setStatus = (status) => {
    this.setState({ status })
  }

  toggleLoader = () => {
    this.setState(prevState => ({
      loading: !prevState.loading
    }))
  }

  // handleValidSubmit
  handleValidSubmit(event, values) {
    this.toggleLoader()

    if (this.state.domain.id !== null) {
      const url = `${DOMAIN}/${this.state.domain.id}`
      const data = { ...values, id: this.state.domain.id }

      put(url, values).then(
        response => {
          console.log(response)
          this.setState({ domain: response })
          this.toggleLoader()
          this.props.history.push(ROUTE_SETTINGS_DOMAIN)
          toastr.success("Domaine mis à jour avec succès.")
        }
      ).catch(error => {
          console.log(error)
        this.toggleLoader()
          toastr.error("Erreur lors de la mise à jour, veuillez reessayer plus tard.")
        }
      )
    } else {
      post(DOMAIN, values).then(
        response => {
          this.setState({ domain: response })
          this.toggleLoader()
          this.props.history.push(ROUTE_SETTINGS_DOMAIN)
          toastr.success("Domaine créé avec succès")
        }
      ).catch(error => {
          console.log(error)
          toastr.error("Erreur lors de la création, veuillez reessayer plus tard.")
          this.toggleLoader()
        }
      )
    }
  }

  handleChangeData = ({ target }) => {
    this.setState({ domain: { ...this.state.domain, [target.name]: target.value } })
  }

  displayHeader = () => {
    if (this.state.domain.id !== null) {
      return (
        <CardHeader className="bg-white">
          <CardTitle tag="h5" className="mt-2">
            {`${this.props.t('Edit the domain')}: ${this.state.domain.name}`}
          </CardTitle>
        </CardHeader>
      )
    } else {
      return (
        <CardHeader className="bg-white">
          <CardTitle tag="h5" className="mt-2">
            {this.props.t('Add domain')}
          </CardTitle>
        </CardHeader>
      )
    }
  }

  displayDeleteButton = () => {
    const { t } = this.props
    if (this.state.domain.id !== null) {
      return (
        <Fragment>
          <button
            className="btn btn-danger waves-effect waves-light ml-3"
            type="button"
            onClick={() => this.setState({ delete: true })}
          >
            {this.props.loading ? <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2"/> :
              <i className="fas fa-trash mr-2"/>}
            {this.props.t('Delete')}
          </button>
          {this.state.delete ? (
            <SweetAlert
              title={t("Deletion") + " " + this.state.domain.name}
              warning
              showCancel
              confirmBtnText={t("Delete")}
              cancelBtnText={t("Cancel")}
              confirmBtnBsStyle="danger"
              cancelBtnBsStyle="primary"
              onConfirm={() => this.deleteAction()}
              onCancel={() => this.setState({ delete: false })}
            >
              Souhaitez-vous supprimer ce domaine ?
            </SweetAlert>
          ) : null}
        </Fragment>
      )
    }
  }

  deleteAction() {
    const url = `${DOMAIN}/${this.state.domain.id}`

    del(url).then(
      response => {
        console.log(response)
        this.setState({ domain: response })
        this.toggleLoader()
        this.props.history.push(ROUTE_SETTINGS_DOMAIN)
        toastr.success("Domaine supprimé avec succès.")
      }
    ).catch(error => {
        console.log(error)
        this.toggleLoader()
        toastr.error("Erreur lors de la suppression, veuillez reessayer plus tard.")
      }
    )
  }

  render() {
    const { domain } = this.state
    const { t } = this.props
    return (
      <Fragment>
        <div className="page-content">
          <Container fluid>
            <Breadcrumbs breadcrumbItems={Bs.DOMAIN_EDIT}/>

            <Card>
              {this.displayHeader()}
              <CardBody>
                <Row>
                  <Col>
                    <AvForm
                      className="form-horizontal"
                      onValidSubmit={this.handleValidSubmit}
                    >
                      {this.props.error && this.props.error ? (
                        <Alert color="danger">{this.props.error}</Alert>
                      ) : null}

                      <Row>
                        <Col className="mb-3" md={12}>
                          <b>{t('Name')}</b>
                        </Col>
                        <Col>
                          <AvField
                            name="name"
                            className="form-control"
                            placeholder={t('Name')}
                            onChange={this.handleChangeData}
                            value={domain.name}
                            type="test"
                            validate={{
                              required: { value: true, errorMessage: t("This field is required") }
                            }}/>
                        </Col>
                      </Row>

                      <Row>
                        <Col className="mb-3" md={12}>
                          <b>{this.props.t('Domain type')}</b>
                        </Col>
                        <Col>
                          <AvField
                            name="domainTypeId"
                            onChange={this.handleChangeData}
                            value={domain.domainTypeId}
                            type="select"
                            validate={{
                              required: { value: true, errorMessage: t("This field is required") }
                            }}>
                            <option value="">{t('Select a domain type')}</option>
                            {this.state.domainTypes.map((item, i) =>
                              <option value={item.id}>{item.name}</option>
                            )}
                          </AvField>
                        </Col>
                      </Row>

                      <Row>
                        <Col className="mb-3" md={12}>
                          <b>{this.props.t('Manager')}</b>
                        </Col>
                        <Col>
                          <AvField
                            name="managerId"
                            onChange={this.handleChangeData}
                            value={domain.managerId}
                            type="select"
                            validate={{
                              required: { value: true, errorMessage: t("This field is required") }
                            }}>
                            <option value="">{t('Select a user')}</option>
                            {this.state.managers.map((item, i) =>
                              <option value={item.id}>{`${item.firstname} ${item.lastname}`}</option>
                            )}
                          </AvField>
                        </Col>
                      </Row>

                      <Row className="mt-3">
                        <Col>
                          <button
                            className="btn btn-primary waves-effect waves-light"
                            type="submit"
                          >
                            {this.props.loading ? <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2"/> :
                              <i className="fas fa-save mr-2"/>}
                            {t('Send')}
                          </button>
                          {this.displayDeleteButton()}
                        </Col>
                      </Row>
                      <Button
                        color="secondary"
                        className="mt-3"
                        onClick={() => {
                          this.props.history.goBack()
                        }}
                      >
                        <i className="fas fa-angle-left mr-2" aria-hidden="true"/>
                        {this.props.t("Back")}
                      </Button>
                    </AvForm>
                  </Col>
                </Row>
              </CardBody>
            </Card>
          </Container>
        </div>
      </Fragment>
    )
  }
}

export default withTranslation()(DomainEdit)
