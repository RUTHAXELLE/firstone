import React, { Component, Fragment } from "react"
import { Alert, Button, Card, CardBody, CardHeader, CardTitle, Col, Container, CustomInput, Row } from "reactstrap"
import Breadcrumbs from "../../../components/Common/Breadcrumb"
import { Breadcrumbs as Bs } from "../../../common/data/breadcrumbs"
import { withTranslation } from "react-i18next"
import { AvField, AvForm, AvInput } from "availity-reactstrap-validation"
import { del, post, put } from "../../../helpers/api_helper"
import toastr from "toastr"
import "toastr/build/toastr.min.css"
import { CAMPAIGN } from "../../../helpers/url_helper"
import SweetAlert from "react-bootstrap-sweetalert/dist"
import { ROUTE_SETTINGS_CAMPAIGN } from "../../../helpers/route_helper"

class ScampaignEdit extends Component {

  constructor(props) {
    super(props)

    this.state = {
      loading: false,
      delete: false,
      toggleSwitch: false,
      campaign: (props.history.location.state !== undefined && props.history.location.state.campaign !== null)
        ? props.history.location.state.campaign : {
          id: null,
          name: null,
          startAt: null,
          endAt: null,
          status: null
        }
    }

    // handleValidSubmit
    this.handleValidSubmit = this.handleValidSubmit.bind(this)
  }

  setStatus = (status) => {
    this.setState({ status })
  }

  toggleLoader = () => {
    this.setState(prevState => ({
      loading: !prevState.loading
    }))
  }

  // handleValidSubmit
  handleValidSubmit(event, values) {
    console.log(values)
    this.toggleLoader()

    if (this.state.campaign.id !== null) {
      const url = `${CAMPAIGN}/${this.state.campaign.id}`
      const data = { ...values, id: this.state.campaign.id }

      put(url, data).then(
        response => {
          console.log(response)
          this.setState({ campaign: response })
          this.toggleLoader()
          this.props.history.push(ROUTE_SETTINGS_CAMPAIGN)
          toastr.success("Campaigne mise à jour avec succès.")
        }
      ).catch(error => {
          console.log(error)
        this.toggleLoader()
          toastr.error("Erreur lors de la mise à jour, veuillez reessayer plus tard.")
        }
      )
    } else {
      post(CAMPAIGN, values).then(
        response => {
          this.setState({ campaign: response })
          this.toggleLoader()
          this.props.history.push(ROUTE_SETTINGS_CAMPAIGN)
          toastr.success("campaigne créé avec succès")
        }
      ).catch(error => {
          console.log(error)
          toastr.error("Erreur lors de la création, veuillez reessayer plus tard.")
          this.toggleLoader()
        }
      )
    }
  }

  handleChangeData = ({ target }) => {
    this.setState({ campaign: { ...this.state.campaign, [target.name]: target.value } })
  }

  displayHeader = () => {
    if (this.state.campaign.id !== null) {
      return (
        <CardHeader className="bg-white">
          <CardTitle tag="h5" className="mt-2">
            {`${this.props.t('Edit the campaign')}: ${this.state.campaign.name}`}
          </CardTitle>
        </CardHeader>
      )
    } else {
      return (
        <CardHeader className="bg-white">
          <CardTitle tag="h5" className="mt-2">
            {this.props.t('Add campaign')}
          </CardTitle>
        </CardHeader>
      )
    }
  }

  displayDeleteButton = () => {
    const { t } = this.props
    if (this.state.campaign.id !== null) {
      return (
        <Fragment>
          <button
            className="btn btn-danger waves-effect waves-light ml-3"
            type="button"
            onClick={() => this.setState({ delete: true })}
          >
            {this.props.loading ? <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2"/> :
              <i className="fas fa-trash mr-2"/>}
            {this.props.t('Delete')}
          </button>
          {this.state.delete ? (
            <SweetAlert
              title={t("Deletion") + " " + this.state.campaign.name}
              warning
              showCancel
              confirmBtnText={t("Delete")}
              cancelBtnText={t("Cancel")}
              confirmBtnBsStyle="danger"
              cancelBtnBsStyle="primary"
              onConfirm={() => this.deleteAction()}
              onCancel={() => this.setState({ delete: false })}
            >
              Souhaitez-vous supprimer cette campaigne ?
            </SweetAlert>
          ) : null}
        </Fragment>
      )
    }
  }

  deleteAction() {
    const url = `${CAMPAIGN}/${this.state.campaign.id}`

    del(url).then(
      response => {
        console.log(response)
        this.setState({ campaign: response })
        this.toggleLoader()
        this.props.history.push(ROUTE_SETTINGS_CAMPAIGN)
        toastr.success("Campaigne supprimée avec succès.")
      }
    ).catch(error => {
        console.log(error)
        this.toggleLoader()
        toastr.error("Erreur lors de la suppression, veuillez reessayer plus tard.")
      }
    )
  }

  render() {
    const { campaign } = this.state
    return (
      <Fragment>
        <div className="page-content">
          <Container fluid>
            <Breadcrumbs breadcrumbItems={Bs.SCAMPAIGN_EDIT}/>

            <Card>
              {this.displayHeader()}
              <CardBody>
                <Row>
                  <Col>
                    <AvForm
                      className="form-horizontal"
                      onValidSubmit={this.handleValidSubmit}
                    >
                      {this.props.error && this.props.error ? (
                        <Alert color="danger">{this.props.error}</Alert>
                      ) : null}

                      <Row>
                        <Col className="mb-3" md={12}>
                          <b>{this.props.t('Name')}</b>
                        </Col>
                        <Col>
                          <AvField
                            name="name"
                            className="form-control"
                            placeholder={this.props.t('Name')}
                            onChange={this.handleChangeData}
                            value={campaign.name}
                            validate={{
                              required: { value: true, errorMessage: this.props.t("This field is required") }
                            }}/>
                        </Col>
                      </Row>

                      <Row>
                        <Col>
                          <Row>
                            <Col md={12}>
                              <label htmlFor="startAt"><b>{this.props.t('Start')}</b></label>
                            </Col>
                            <Col>
                              <AvField
                                name="startAt"
                                className="form-control"
                                placeholder={this.props.t('Start')}
                                type="date"
                                onChange={this.handleChangeData}
                                value={campaign.startAt}
                                validate={{
                                  required: { value: true, errorMessage: this.props.t("This field is required") }
                                }}/>
                            </Col>
                          </Row>
                        </Col>
                        <Col>
                          <Row>
                            <Col md={12}>
                              <label htmlFor="endAt"><b>{this.props.t('End')}</b></label>
                            </Col>
                            <Col>
                              <AvField
                                name="endAt"
                                className="form-control"
                                placeholder={this.props.t('End')}
                                type="date"
                                id="endAt"
                                onChange={this.handleChangeData}
                                value={campaign.endAt}
                                validate={{
                                  required: { value: true, errorMessage: this.props.t("This field is required") }
                                }}/>
                            </Col>
                          </Row>
                        </Col>
                      </Row>

                      <Row>
                        <Col className="custom-control custom-switch custom-switch-lg" style={{paddingLeft: "4.75rem"}}>
                          <AvInput
                            name="status"
                            type="checkbox"
                            className="custom-control-input"
                            id="customSwitchStatus"
                            onChange={this.handleChangeData}
                            value={campaign.status}
                          />
                          <label
                            className="custom-control-label"
                            htmlFor="customSwitchStatus"
                          >
                            <b>{this.props.t('Status')}</b>
                          </label>
                        </Col>
                      </Row>

                      <Row className="mt-3">
                        <Col>
                          <button
                            className="btn btn-primary waves-effect waves-light"
                            type="submit"
                          >
                            {this.state.loading ? <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2"/> :
                              <i className="fas fa-save mr-2"/>}
                            {this.props.t('Send')}
                          </button>
                          {this.displayDeleteButton()}
                        </Col>
                      </Row>
                      <Button
                        color="secondary"
                        className="mt-3"
                        onClick={() => {
                          this.props.history.goBack()
                        }}
                      >
                        <i className="fas fa-angle-left mr-2" aria-hidden="true"/>
                        {this.props.t("Back")}
                      </Button>
                    </AvForm>
                  </Col>
                </Row>
              </CardBody>
            </Card>
          </Container>
        </div>
      </Fragment>
    )
  }
}

export default withTranslation()(ScampaignEdit)
