import React, { Component } from "react"
import { Button, Card, CardBody, CardHeader, CardTitle, Col, Container, Row } from "reactstrap"
import { withTranslation } from "react-i18next"
import { get } from "../../../helpers/api_helper"
import datasColumns from "../../../common/data/DomainTypeColumns"
import paginationFactory from "react-bootstrap-table2-paginator"
import BootstrapTable from "react-bootstrap-table-next"
import { withRouter } from "react-router-dom"
import { ROUTE_SETTINGS_DOMAIN_TYPE_EDIT } from "../../../helpers/route_helper"
import { DOMAIN_TYPE } from "../../../helpers/url_helper"
import Breadcrumbs from "../../../components/Common/Breadcrumb"
import { Breadcrumbs as Bs } from "../../../common/data/breadcrumbs"

class DomainType extends Component {
  constructor(props) {
    super(props)
    this.state = {
      domainTypes: []
    }

    this.getDomainTypes()
  }

  getDomainTypes = () => {
    get(DOMAIN_TYPE).then(
      response => {
        this.setState({domainTypes: response})
      }
    ).catch(error => {
        console.log(error)
      }
    )
  }

  editDomainType = () => {
    this.props.history.push(ROUTE_SETTINGS_DOMAIN_TYPE_EDIT)
  }

  render() {
    const rowEvents = {
      onClick: (e, row, rowIndex) => {

      },
      onDoubleClick: (e, row, rowIndex) => {
        console.log(row)
        this.props.history.push({
          pathname: ROUTE_SETTINGS_DOMAIN_TYPE_EDIT,
          state: { domainType: row }
        })
      }
    }

    return (
      <React.Fragment>
        <div className="page-content">
          <Container fluid>
            <Breadcrumbs breadcrumbItems={Bs.DOMAIN_TYPE}/>

            <Card>
              <CardHeader className="bg-white">
                <div className="float-right">
                  <Button
                    color="primary"
                    size="sm"
                    onClick={this.editDomainType}>
                    <i className="fas fa-plus mr-2"/> {this.props.t("Add")}
                  </Button>
                </div>
                <CardTitle tag="h5">{this.props.t("Domain type list")}</CardTitle>
              </CardHeader>
              <CardBody>
                <Row>
                  <Col>
                    <BootstrapTable
                      keyField="id"
                      data={this.state.domainTypes}
                      columns={datasColumns}
                      bootstrap4
                      bordered={false}
                      rowEvents={rowEvents}
                      pagination={paginationFactory({
                        currentPage: 0,
                        sizePerPage: 5,
                        sizePerPageList: [5, 10, 25, 50]
                      })}
                      noDataIndication={() => (
                        <div className=" text-center">{this.props.t("No data found")}</div>
                      )}
                      className={"cf"}
                    />
                  </Col>
                </Row>
              </CardBody>
            </Card>
          </Container>
        </div>
      </React.Fragment>
    )
  }
}

export default withRouter(withTranslation()(DomainType))
