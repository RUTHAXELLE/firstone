import React, { Component, Fragment } from "react"
import { Alert, Button, Card, CardBody, CardHeader, CardTitle, Col, Container, Row } from "reactstrap"
import Breadcrumbs from "../../../components/Common/Breadcrumb"
import { Breadcrumbs as Bs } from "../../../common/data/breadcrumbs"
import { withTranslation } from "react-i18next"
import { AvField, AvForm } from "availity-reactstrap-validation"
import { del, post, put } from "../../../helpers/api_helper"
import toastr from "toastr"
import "toastr/build/toastr.min.css"
import { DOMAIN_TYPE } from "../../../helpers/url_helper"
import { ROUTE_SETTINGS_DOMAIN_TYPE } from "../../../helpers/route_helper"
import SweetAlert from "react-bootstrap-sweetalert/dist"

class DomainTypeEdit extends Component {

  constructor(props) {
    super(props)

    this.state = {
      loading: false,
      delete: false,
      domainType: (props.history.location.state !== undefined && props.history.location.state.domainType !== null)
        ? props.history.location.state.domainType : {
          id: null,
          name: null
        }
    }

    // handleValidSubmit
    this.handleValidSubmit = this.handleValidSubmit.bind(this)
  }

  setStatus = (status) => {
    this.setState({ status })
  }

  toggleLoader = () => {
    this.setState(prevState => ({
      loading: !prevState.loading
    }))
  }

  // handleValidSubmit
  handleValidSubmit(event, values) {
    this.toggleLoader()

    if (this.state.domainType.id !== null) {
      const url = `${DOMAIN_TYPE}/${this.state.domainType.id}`
      const data = { ...values, id: this.state.domainType.id }

      put(url, values).then(
        response => {
          console.log(response)
          this.setState({ domainType: response })
          this.toggleLoader()
          this.props.history.push(ROUTE_SETTINGS_DOMAIN_TYPE)
          toastr.success("Type de domaine mis à jour avec succès.")
        }
      ).catch(error => {
          console.log(error)
        this.toggleLoader()
          toastr.error("Erreur lors de la mise à jour, veuillez reessayer plus tard.")
        }
      )
    } else {
      post(DOMAIN_TYPE, values).then(
        response => {
          this.setState({ domainType: response })
          this.toggleLoader()
          this.props.history.push(ROUTE_SETTINGS_DOMAIN_TYPE)
          toastr.success("Type de domaine créé avec succès")
        }
      ).catch(error => {
          console.log(error)
          toastr.error("Erreur lors de la création, veuillez reessayer plus tard.")
          this.toggleLoader()
        }
      )
    }
  }

  handleChangeData = ({ target }) => {
    this.setState({ domainType: { ...this.state.domainType, [target.name]: target.value } })
  }

  displayHeader = () => {
    if (this.state.domainType.id !== null) {
      return (
        <CardHeader className="bg-white">
          <CardTitle tag="h5" className="mt-2">
            {`${this.props.t('Edit the domain type')}: ${this.state.domainType.name}`}
          </CardTitle>
        </CardHeader>
      )
    } else {
      return (
        <CardHeader className="bg-white">
          <CardTitle tag="h5" className="mt-2">
            {this.props.t('Add domain type')}
          </CardTitle>
        </CardHeader>
      )
    }
  }

  displayDeleteButton = () => {
    const { t } = this.props
    if (this.state.domainType.id !== null) {
      return (
        <Fragment>
          <button
            className="btn btn-danger waves-effect waves-light ml-3"
            type="button"
            onClick={() => this.setState({ delete: true })}
          >
            {this.props.loading ? <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2"/> :
              <i className="fas fa-trash mr-2"/>}
            {this.props.t('Delete')}
          </button>
          {this.state.delete ? (
            <SweetAlert
              title={t("Deletion") + " " + this.state.domainType.name}
              warning
              showCancel
              confirmBtnText={t("Delete")}
              cancelBtnText={t("Cancel")}
              confirmBtnBsStyle="danger"
              cancelBtnBsStyle="primary"
              onConfirm={() => this.deleteAction()}
              onCancel={() => this.setState({ delete: false })}
            >
              Souhaitez-vous supprimer ce type de domaine ?
            </SweetAlert>
          ) : null}
        </Fragment>
      )
    }
  }

  deleteAction() {
    const url = `${DOMAIN_TYPE}/${this.state.domainType.id}`

    del(url).then(
      response => {
        console.log(response)
        this.setState({ domainType: response })
        this.toggleLoader()
        this.props.history.push(ROUTE_SETTINGS_DOMAIN_TYPE)
        toastr.success("Type de domaine supprimé avec succès.")
      }
    ).catch(error => {
        console.log(error)
        this.toggleLoader()
        toastr.error("Erreur lors de la suppression, veuillez reessayer plus tard.")
      }
    )
  }

  render() {
    const { domainType } = this.state
    return (
      <Fragment>
        <div className="page-content">
          <Container fluid>
            <Breadcrumbs breadcrumbItems={Bs.DOMAIN_TYPE_EDIT}/>

            <Card>
              {this.displayHeader()}
              <CardBody>
                <Row>
                  <Col>
                    <AvForm
                      className="form-horizontal"
                      onValidSubmit={this.handleValidSubmit}
                    >
                      {this.props.error && this.props.error ? (
                        <Alert color="danger">{this.props.error}</Alert>
                      ) : null}

                      <Row>
                        <Col className="mb-3" md={12}>
                          <b>{this.props.t('Name')}</b>
                        </Col>
                        <Col>
                          <AvField
                            name="name"
                            className="form-control"
                            placeholder={this.props.t('Name')}
                            onChange={this.handleChangeData}
                            value={domainType.name}
                            type="test"
                            validate={{
                              required: { value: true, errorMessage: this.props.t("This field is required") }
                            }}/>
                        </Col>
                      </Row>

                      <Row className="mt-3">
                        <Col>
                          <button
                            className="btn btn-primary waves-effect waves-light"
                            type="submit"
                          >
                            {this.props.loading ? <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2"/> :
                              <i className="fas fa-save mr-2"/>}
                            {this.props.t('Send')}
                          </button>
                          {this.displayDeleteButton()}
                        </Col>
                      </Row>
                      <Button
                        color="secondary"
                        className="mt-3"
                        onClick={() => {
                          this.props.history.goBack()
                        }}
                      >
                        <i className="fas fa-angle-left mr-2" aria-hidden="true"/>
                        {this.props.t("Back")}
                      </Button>
                    </AvForm>
                  </Col>
                </Row>
              </CardBody>
            </Card>
          </Container>
        </div>
      </Fragment>
    )
  }
}

export default withTranslation()(DomainTypeEdit)
