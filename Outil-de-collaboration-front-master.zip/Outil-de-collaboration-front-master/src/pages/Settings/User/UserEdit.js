import React, { Component, Fragment } from "react"
import { Alert, Button, Card, CardBody, CardHeader, CardTitle, Col, Container, Row } from "reactstrap"
import Breadcrumbs from "../../../components/Common/Breadcrumb"
import { Breadcrumbs as Bs } from "../../../common/data/breadcrumbs"
import { withTranslation } from "react-i18next"
import { AvField, AvForm } from "availity-reactstrap-validation"
import { del, get,post, put } from "../../../helpers/api_helper"
import toastr from "toastr"
import "toastr/build/toastr.min.css"
import { PROFILE,USER} from "../../../helpers/url_helper"
import { ROUTE_SETTINGS_USER } from "../../../helpers/route_helper"
import SweetAlert from "react-bootstrap-sweetalert/dist"

class UserEdit extends Component {

  constructor(props) {
    super(props)

    this.state = {
      loading: false,
      delete: false,
      user: (props.history.location.state !== undefined && props.history.location.state.user !== null)
        ? props.history.location.state.user : {
          id: null,
          name: null
        },
        profiles: []
    }

    this.getProfiles()

    // handleValidSubmit
    this.handleValidSubmit = this.handleValidSubmit.bind(this)
  }

  setStatus = (status) => {
    this.setState({ status })
  }

  getProfiles = () => {
    get(PROFILE).then(
      response => {
        this.setState({profiles: response})
      }
    ).catch(error => {
        console.log(error)
      }
    )
  }




  toggleLoader = () => {
    this.setState(prevState => ({
      loading: !prevState.loading
    }))
  }

  // handleValidSubmit
  handleValidSubmit(event, values) {
    this.toggleLoader()

    if (this.state.user.id !== null) {
      const url = `${USER}/${this.state.user.id}`
      const data = { ...values, id: this.state.user.id }

      put(url, values).then(
        response => {
          console.log(response)
          this.setState({ user: response })
          this.toggleLoader()
          this.props.history.push(ROUTE_SETTINGS_USER)
          toastr.success("Utilisateur mis à jour avec succès.")
        }
      ).catch(error => {
          console.log(error)
        this.toggleLoader()
          toastr.error("Erreur lors de la mise à jour, veuillez reessayer plus tard.")
        }
      )
    } else {
      post(USER, values).then(
        response => {
          this.setState({ user: response })
          this.toggleLoader()
          this.props.history.push(ROUTE_SETTINGS_USER)
          toastr.success("Utilisateur créé avec succès")
        }
      ).catch(error => {
          console.log(error)
          toastr.error("Erreur lors de la création, veuillez reessayer plus tard.")
          this.toggleLoader()
        }
      )
    }
  }

  handleChangeData = ({ target }) => {
    this.setState({ user: { ...this.state.user, [target.name]: target.value } })
  }

  displayHeader = () => {
    if (this.state.user.id !== null) {
      return (
        <CardHeader className="bg-white">
          <CardTitle tag="h5" className="mt-2">
            {`${this.props.t('Edit the user')}: ${this.state.user.firstname} ${this.state.user.lastname}`}
          </CardTitle>
        </CardHeader>
      )
    } else {
      return (
        <CardHeader className="bg-white">
          <CardTitle tag="h5" className="mt-2">
            {this.props.t('Add user')}
          </CardTitle>
        </CardHeader>
      )
    }
  }

  displayPassword = () => {
    const { user } = this.state
    if (user.id === null) {
      return (
        <Fragment>
          <Row>
            <Col className="mb-3" md={12}>
              <b>{this.props.t('Password')}</b>
            </Col>
            <Col>
              <AvField
                name="password"
                className="form-control"
                placeholder={this.props.t('Password')}
                onChange={this.handleChangeData}
                type="password"
                validate={{
                  required: { value: true, errorMessage: this.props.t("This field is required") }
                }}/>
            </Col>
          </Row>

          <Row>
            <Col className="mb-3" md={12}>
              <b>{this.props.t('Confirm your password')}</b>
            </Col>
            <Col>
              <AvField
                name="confirmPassword"
                className="form-control"
                type="password"
                placeholder={this.props.t('Confirm your password')}
                onChange={this.handleChangeData}
                validate={{
                  required: { value: true, errorMessage: this.props.t("This field is required") },
                  match: { value: 'password', errorMessage: this.props.t("Password doesn't match") }
                }}/>
            </Col>
          </Row>
        </Fragment>
      )
    }
  }

  displayDeleteButton = () => {
    const { t } = this.props
    if (this.state.user.id !== null) {
      return (
        <Fragment>
          <button
            className="btn btn-danger waves-effect waves-light ml-3"
            type="button"
            onClick={() => this.setState({ delete: true })}
          >
            {this.props.loading ? <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2"/> :
              <i className="fas fa-trash mr-2"/>}
            {this.props.t('Delete')}
          </button>
          {this.state.delete ? (
            <SweetAlert
              title={`${t("Deletion")} ${this.state.user.firstname} ${this.state.user.lastname}`}
              warning
              showCancel
              confirmBtnText={t("Delete")}
              cancelBtnText={t("Cancel")}
              confirmBtnBsStyle="danger"
              cancelBtnBsStyle="primary"
              onConfirm={() => this.deleteAction()}
              onCancel={() => this.setState({ delete: false })}
            >
              Souhaitez-vous supprimer cet utilisateur ?
            </SweetAlert>
          ) : null}
        </Fragment>
      )
    }
  }

  deleteAction() {
    const url = `${USER}/${this.state.user.id}`

    del(url).then(
      response => {
        console.log(response)
        this.setState({ user: response })
        this.toggleLoader()
        this.props.history.push(ROUTE_SETTINGS_USER)
        toastr.success("Utilisateur supprimé avec succès.")
      }
    ).catch(error => {
        console.log(error)
        this.toggleLoader()
        toastr.error("Erreur lors de la suppression, veuillez reessayer plus tard.")
      }
    )
  }

  render() {
    const { user } = this.state
    return (
      <Fragment>
        <div className="page-content">
          <Container fluid>
            <Breadcrumbs breadcrumbItems={Bs.USER_EDIT}/>

            <Card>
              {this.displayHeader()}
              <CardBody>
                <Row>
                  <Col>
                    <AvForm
                      className="form-horizontal"
                      onValidSubmit={this.handleValidSubmit}
                    >
                      {this.props.error && this.props.error ? (
                        <Alert color="danger">{this.props.error}</Alert>
                      ) : null}

                      <Row>
                        <Col className="mb-3" md={12}>
                          <b>{this.props.t('Firstname')}</b>
                        </Col>
                        <Col>
                          <AvField
                            name="firstname"
                            className="form-control"
                            placeholder={this.props.t('Firstname')}
                            onChange={this.handleChangeData}
                            value={user.firstname}
                            validate={{
                              required: { value: true, errorMessage: this.props.t("This field is required") }
                            }}/>
                        </Col>
                      </Row>

                      <Row>
                        <Col className="mb-3" md={12}>
                          <b>{this.props.t('Lastname')}</b>
                        </Col>
                        <Col>
                          <AvField
                            name="lastname"
                            className="form-control"
                            placeholder={this.props.t('Lastname')}
                            onChange={this.handleChangeData}
                            value={user.lastname}
                            validate={{
                              required: { value: true, errorMessage: this.props.t("This field is required") }
                            }}/>
                        </Col>
                      </Row>

                      <Row>
                        <Col className="mb-3" md={12}>
                          <b>{this.props.t('Email')}</b>
                        </Col>
                        <Col>
                          <AvField
                            name="email"
                            className="form-control"
                            placeholder={this.props.t('Email')}
                            onChange={this.handleChangeData}
                            value={user.email}
                            validate={{
                              required: { value: true, errorMessage: this.props.t("This field is required") }
                            }}/>
                        </Col>
                      </Row>

                      <Row>
                        <Col className="mb-3" md={12}>
                          <b>{this.props.t('Registration number')}</b>
                        </Col>
                        <Col>
                          <AvField
                            name="registrationNumber"
                            className="form-control"
                            placeholder={this.props.t('Registration number')}
                            onChange={this.handleChangeData}
                            value={user.registrationNumber}
                            validate={{
                              required: { value: true, errorMessage: this.props.t("This field is required") }
                            }}/>
                        </Col>
                      </Row>

                      <Row>
                        <Col className="mb-3" md={12}>
                          <b>{this.props.t('Profile')}</b>
                        </Col>
                        <Col>
                          <AvField
                            name="profileId"
                            onChange={this.handleChangeData}
                            value={user.profileId}
                            type="select"
                            validate={{
                              required: { value: true, errorMessage: this.props.t("This field is required") }
                            }}>
                            <option value="">{this.props.t('Select a profile')}</option>
                            {this.state.profiles.map((item, i) =>
                              <option value={item.id}>{item.name}</option>
                            )}
                          </AvField>
                        </Col>
                      </Row>                      

                      {this.displayPassword()}

                      <Row className="mt-3">
                        <Col>
                          <button
                            className="btn btn-primary waves-effect waves-light"
                            type="submit"
                          >
                            {this.props.loading ? <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2"/> :
                              <i className="fas fa-save mr-2"/>}
                            {this.props.t('Send')}
                          </button>
                          {this.displayDeleteButton()}
                        </Col>
                      </Row>
                      <Button
                        color="secondary"
                        className="mt-3"
                        onClick={() => {
                          this.props.history.goBack()
                        }}
                      >
                        <i className="fas fa-angle-left mr-2" aria-hidden="true"/>
                        {this.props.t("Back")}
                      </Button>
                    </AvForm>
                  </Col>
                </Row>
              </CardBody>
            </Card>
          </Container>
        </div>
      </Fragment>
    )
  }
}

export default withTranslation()(UserEdit)
