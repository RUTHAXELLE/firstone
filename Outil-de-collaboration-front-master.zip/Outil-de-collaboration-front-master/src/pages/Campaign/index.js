import React, { Component, Fragment } from "react"
import { Badge, Button, Card, CardBody, CardHeader, CardTitle, Container, UncontrolledTooltip } from "reactstrap"
import BootstrapTable from "react-bootstrap-table-next"
import paginationFactory from "react-bootstrap-table2-paginator"
//Import Breadcrumb
import Breadcrumbs from "../../components/Common/Breadcrumb"
import { Breadcrumbs as Bs } from "../../common/data/breadcrumbs"
import { Trans, withTranslation } from "react-i18next"
import {
  ROUTE_CAMPAIGN_APPRAISAL,
  ROUTE_CAMPAIGN_CAPTURES,
  ROUTE_CAMPAIGN_DETAILS,
  ROUTE_CAMPAIGN_REPLIES, ROUTE_CAMPAIGN_REPLY
} from "../../helpers/route_helper"
import { withRouter } from "react-router-dom"
import { get } from "../../helpers/api_helper"
import { CAMPAIGN } from "../../helpers/url_helper"
import moment from "moment"

class Campaign extends Component {
  constructor(props) {
    super(props)
    this.state = {
      compaigns: []
    }

    this.getCompaigns()
  }

  transFormatter = (column, colIndex, components) => {
    return (<Trans>{column.text}</Trans>)
  }

  dateFormatter = (cell, row, rowIndex, formatExtraData) => {
    return (<span>{moment(cell).format("MMMM YYYY")}</span>)
  }

  statusFormatter = (column, colIndex, components) => {
    if (column === true) {
      return (
        <Badge
          className="font-size-12 badge-soft-success"
          color="success"
          pill
        >
          <Trans>
            In progress
          </Trans>
        </Badge>
      )
    } else {
      return (
        <Badge
          className="font-size-12 badge-soft-warning"
          color="warning"
          pill
        >
          <Trans>
            Expired
          </Trans>
        </Badge>
      )
    }
  }

  actionsFormatter = (column, row, components) => {
    return (
      <Fragment>
        <Fragment>
          <Button
            id="action-see"
            color="primary"
            size="sm"
            className="mr-3"
            onClick={() => {
              this.props.history.push({
                pathname: ROUTE_CAMPAIGN_DETAILS,
                state: { campaign: row }
              })
            }}>
            <i className="fas fa-eye mr-2"/> {this.props.t("See")}
          </Button>
          <UncontrolledTooltip
            placement="top"
            target={"action-see"}
          >
            Visualiser la campagne
          </UncontrolledTooltip>
        </Fragment>
        {row.status === true ? (
          <Fragment>
            <Fragment>
              <Button
                id="action-entering"
                color="primary"
                size="sm"
                onClick={() => {
                  this.props.history.push({
                    pathname: ROUTE_CAMPAIGN_CAPTURES,
                    state: { campaign: row }
                  })
                }}>
                <i className="fas fa-pen mr-2"/> {this.props.t("Entering")}
              </Button>
              <UncontrolledTooltip
                placement="top"
                target={"action-entering"}
              >
                Saisissez vos expériences de collaboration
              </UncontrolledTooltip>
            </Fragment>
            {/*<Fragment>
              <Button
                id="action-replies"
                color="primary"
                size="sm"
                className="mx-3"
                onClick={() => {
                  this.props.history.push({
                    pathname: ROUTE_CAMPAIGN_REPLIES,
                    state: { campaign: row }
                  })
                }}>
                <i className="fas fa-exchange-alt mr-2"/> {this.props.t("Replies")}
              </Button>
              <UncontrolledTooltip
                placement="top"
                target={"action-replies"}
              >
                Visualisez les réponses de vos saisies d'expérience de collaboration
              </UncontrolledTooltip>
            </Fragment>*/}
            <Fragment>
              <Button
                id="action-reply"
                color="primary"
                size="sm"
                className="mx-3"
                onClick={() => {
                  this.props.history.push({
                    pathname: ROUTE_CAMPAIGN_REPLY,
                    state: { campaign: row }
                  })
                }}>
                <i className="fas fa-reply mr-2"/> {this.props.t("Reply")}
              </Button>
              <UncontrolledTooltip
                placement="top"
                target={"action-reply"}
              >
                Répondez aux saisies d'expérience de collaboration
              </UncontrolledTooltip>
            </Fragment>
            <Fragment>
              <Button
                id="action-appraisal"
                color="primary"
                size="sm"
                onClick={() => {
                  this.props.history.push({
                    pathname: ROUTE_CAMPAIGN_APPRAISAL,
                    state: { campaign: row }
                  })
                }}>
                <i className="far fa-file mr-2"/> {this.props.t("Bilan")}
              </Button>
              <UncontrolledTooltip
                placement="top"
                target={"action-appraisal"}
              >
                Saisissez votre bilan pour la campagne
              </UncontrolledTooltip>
            </Fragment>
          </Fragment>
        ) : null}
      </Fragment>
    )
  }

  datasColumns = [
    {
      text: "id",
      dataField: "id",
      sort: true,
      hidden: true,
      headerFormatter: this.transFormatter

    },
    {
      text: "Status",
      dataField: "status",
      sort: true,
      headerFormatter: this.transFormatter,
      formatter: this.statusFormatter
    },
    {
      text: "Name",
      dataField: "name",
      sort: true,
      headerFormatter: this.transFormatter

    },
    {
      text: "Start",
      dataField: "startAt",
      sort: true,
      headerFormatter: this.transFormatter,
      formatter: this.dateFormatter
    },
    {
      text: "End",
      dataField: "endAt",
      sort: true,
      headerFormatter: this.transFormatter,
      formatter: this.dateFormatter
    },
    {
      text: "Actions",
      dataField: "id",
      sort: true,
      headerFormatter: this.transFormatter,
      formatter: this.actionsFormatter
    }
  ]

  getCompaigns = () => {
    get(CAMPAIGN).then(
      response => {
        this.setState({ compaigns: response })
      }
    ).catch(error => {
        console.log(error)
      }
    )
  }

  render() {
    return (
      <React.Fragment>
        <div className="page-content">
          <Container fluid>
            <Breadcrumbs breadcrumbItems={Bs.CAMPAIGN}/>

            <Card>
              <CardHeader className="bg-white">
                <CardTitle tag="h5">{this.props.t("Campaign")}</CardTitle>
              </CardHeader>
              <CardBody>
                <BootstrapTable
                  keyField="id"
                  data={this.state.compaigns}
                  columns={this.datasColumns}
                  bootstrap4
                  bordered={false}
                  pagination={paginationFactory({
                    currentPage: 0,
                    sizePerPage: 4,
                    sizePerPageList: [4, 8, 12, 16, 20, 24]
                  })}
                  noDataIndication={() => (
                    <div className=" text-center">{this.props.t("No data found")}</div>
                  )}
                  className={"cf"}
                />
              </CardBody>
            </Card>
          </Container>
        </div>
      </React.Fragment>
    )
  }
}

export default withRouter(withTranslation()(Campaign))
