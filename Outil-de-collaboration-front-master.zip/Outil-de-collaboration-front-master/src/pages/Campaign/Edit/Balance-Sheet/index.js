import React, { Component } from "react"
import { Alert, Button, Card, CardBody, CardHeader, CardTitle, Col, Container, Row } from "reactstrap"
import Breadcrumbs from "../../../../components/Common/Breadcrumb"
import { Breadcrumbs as Bs } from "../../../../common/data/breadcrumbs"
import { withTranslation } from "react-i18next"
import { get, post, put } from "../../../../helpers/api_helper"
import compaignsDatas from "../../../../common/data/campaigns"
import Experience from "../Capture/Experience"
import ExperienceTypes from "../../../../helpers/ExperienceTypes"
import { EXPERIENCE } from "../../../../helpers/url_helper"
import { AvField, AvForm } from "availity-reactstrap-validation"
import { withRouter } from "react-router-dom"
import toastr from "toastr"

class BalanceExperience extends Component {
  constructor(props) {
    super(props)
    this.state = {
      campaign: (props.history.location.state !== undefined && props.history.location.state.campaign !== null)
        ? props.history.location.state.campaign : {
          id: null,
          name: null,
          startAt: null,
          endAt: null,
          status: null
        },
      display: (props.display !== undefined) ? props.display : false,
      compaignId: 1,
      toggleSendExperience: false,
      status: 0,
    }

    this.compaigns = compaignsDatas
    this.getExperiences()

    // handleValidSubmit
    this.handleValidSubmit = this.handleValidSubmit.bind(this)
  }

  setStatus = (status) => {
    this.setState({ status })
  }

  toggleSendExperience = () => {
    this.setState(prevState => ({
      toggleSendExperience: !prevState.toggleSendExperience
    }))
  }

  handleChange = ({target}) => {
    this.setState({[target.name]: target.value});
  }

  getExperiences = () => {
    get(EXPERIENCE).then(
      response => {
        console.log(response)
      }
    ).catch(error => {
        console.log(error)
      }
    )
  }

  // handleValidSubmit
  handleValidSubmit(event, values) {
    //this.props.loginUser(values, this.props.history)
    const datas = {
      ...values,
      rank: this.props.rank,
      type: this.type.value,
      file: this.state.experience.file,
      status: this.state.status,
      compaignId: this.props.campaignId,
      issuingDomainId: this.props.user.domain.id,
      receivingDomainId: parseInt(values.receivingDomainId)
    }
    console.log(datas)
    this.loaderToggle(datas.status, true)

    if (this.state.experience.id !== undefined) {
      const url = `${EXPERIENCE}/${this.state.experience.id}`
      const data = { ...datas, id: this.state.experience.id }
      put(url, data).then(
        response => {
          console.log(response)
          this.setState({ experience: response })
          toastr.success("Expérience mise à jour avec succès.")
          this.loaderToggle(datas.status, false)
        }
      ).catch(error => {
          console.log(error)
          this.loaderToggle(datas.status, false)
          toastr.error("Erreur lors de la mise à jour, veuillez reessayer plus tard.")
        }
      )
    } else {
      post(EXPERIENCE, datas).then(
        response => {
          this.setState({ experience: response })
          toastr.success("Expérience ajoutée avec succès")
          console.log(response)
          this.loaderToggle(datas.status, false)
        }
      ).catch(error => {
          console.log(error)
          this.loaderToggle(datas.status, false)
          toastr.error("Erreur lors de l'ajout', veuillez reessayer plus tard.")
        }
      )
    }
  }

  render() {
    return (
      <Card>
        <CardHeader className="bg-white">
          <CardTitle tag="h5">{this.props.t("Donnez votre appréhension globale sur cette campagne")}</CardTitle>
        </CardHeader>
        <CardBody>
          <Row>
            <Col>
              <AvForm
                className="form-horizontal"
                onValidSubmit={this.handleValidSubmit}
              >
                {this.props.error && this.props.error ? (
                  <Alert color="danger">{this.props.error}</Alert>
                ) : null}

                <Row>
                  <Col>
                    <AvField
                      name="description"
                      className="form-control"
                      placeholder="Descrivez votre bilan sur la compagne"
                      type="textarea"
                      maxlength="600"
                      rows="7"
                      disabled={this.state.display}
                      validate={{
                        required: { value: true, errorMessage: this.props.t("This field is required") },
                        maxLength: {value: 600}
                      }}/>
                  </Col>
                </Row>

                {(!this.state.display) ? (
                <div className="mt-3">
                  <button
                    className="btn btn-primary waves-effect waves-light"
                    type="submit"
                    onClick={() => this.setStatus(0)}
                  >
                    {this.props.saveLoading ? <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2"/>: <i className="fas fa-save mr-2"/>}
                    Enregistrer
                  </button>

                  <button
                    className="btn btn-primary waves-effect waves-light ml-3"
                    type="submit"
                    onClick={() => this.setStatus(1)}
                  >
                    {this.props.sendLoading ? <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2"/>: <i className="mdi mdi-send mr-2"/>}
                    Envoyer
                  </button>
                </div>
                ) : null}
              </AvForm>
            </Col>
          </Row>
          <Button
            color="secondary"
            className="mt-3"
            onClick={() => { this.props.history.goBack() }}
          >
            <i className="fas fa-angle-left mr-2" aria-hidden="true"/>
            {this.props.t('Back')}
          </Button>
        </CardBody>
      </Card>
    )
  }
}

export default withRouter(withTranslation()(BalanceExperience))
