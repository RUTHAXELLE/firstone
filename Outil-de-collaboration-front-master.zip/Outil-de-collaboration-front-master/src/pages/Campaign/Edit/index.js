import React, { Component, Fragment } from "react"
import { Container, Nav, NavItem, NavLink, TabContent, TabPane } from "reactstrap"
import Breadcrumbs from "../../../components/Common/Breadcrumb"
import { Breadcrumbs as Bs } from "../../../common/data/breadcrumbs"
import classnames from "classnames"
import ToolTip from "../../../components/Common/Tooltip"
import { withTranslation } from "react-i18next"
import ReplyExperience from "./Reply"
import CaptureExperience from "./Capture"
import BalanceExperience from "./Balance-Sheet"
import { withRouter } from "react-router-dom"
import RepliesExperience from "./Replies"

class CampaignDetail extends Component {

  constructor(props) {
    super(props)

    this.state = {
      activeTab: "1",
      campaign: (props.history.location.state !== undefined && props.history.location.state.campaign !== null)
        ? props.history.location.state.campaign : {
          id: null,
          name: null,
          startAt: null,
          endAt: null,
          status: null
        }
    }
  }

  toggle(tab) {
    if (this.state.activeTab !== tab) {
      this.setState({
        activeTab: tab
      })
    }
  }

  render() {
    return (
      <Fragment>
        <div className="page-content">
          <Container fluid>
            <Breadcrumbs breadcrumbItems={Bs.CAMPAIGN_DETAILS}/>
            <Nav tabs>
              <NavItem>
                <NavLink
                  style={{ cursor: "pointer" }}
                  className={classnames({ active: this.state.activeTab === "1" })}
                  onClick={() => {
                    this.toggle("1")
                  }}>
                  {this.props.t("My experiences")}
                  {/*<ToolTip
                    targetId="expeditionListe"
                    classname="mb-0"
                    tooltipContent={this.props.t("Saisie d'expériences")}
                    orientation="right"
                    htmlContent={
                      <i className="fas fa-bars" />
                    } />*/}
                </NavLink>
              </NavItem>
              {/*<NavItem>
                <NavLink
                  id="nav-replies"
                  style={{ cursor: "pointer" }}
                  className={classnames({ active: this.state.activeTab === "2" })}
                  onClick={() => {
                    this.toggle("2")
                  }}>
                  {this.props.t("Réponses")}
                  <ToolTip
                    targetId="nav-replies"
                    classname="mb-0"
                    tooltipContent={this.props.t("Les réponses de vos saisies d'expérience de collaboration")}
                    orientation="top" />
                </NavLink>
              </NavItem>*/}
              <NavItem>
                <NavLink
                  id="nav-reply"
                  style={{ cursor: "pointer" }}
                  className={classnames({ active: this.state.activeTab === "3" })}
                  onClick={() => {
                    this.toggle("3")
                  }}>
                  {this.props.t("Répondre")}
                  <ToolTip
                    targetId="nav-reply"
                    classname="mb-0"
                    tooltipContent={this.props.t("Vos réponses aux saisies d'expérience de collaboration")}
                    orientation="top"/>
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink
                  style={{ cursor: "pointer" }}
                  className={classnames({ active: this.state.activeTab === "4" })}
                  onClick={() => {
                    this.toggle("4")
                  }}>
                  {this.props.t("Appraisal")}
                  {/*<ToolTip
                    targetId="advancedFilter"
                    classname="mb-0"
                    tooltipContent={this.props.t("Bilan")}
                    orientation="right"
                    htmlContent={
                      <i className="fas fa-filter" />
                    } />*/}
                </NavLink>
              </NavItem>
            </Nav>

            <TabContent activeTab={this.state.activeTab}>
              <TabPane tabId="1">
                <CaptureExperience
                  campaign={this.state.campaign}
                  display={true}
                />
              </TabPane>
              <TabPane tabId="2">
                <RepliesExperience
                  campaign={this.state.campaign}
                  display={true}/>
              </TabPane>
              <TabPane tabId="3">
                <ReplyExperience
                  campaign={this.state.campaign}
                  display={true}/>
              </TabPane>
              <TabPane tabId="4">
                <BalanceExperience
                  campaign={this.state.campaign}
                  display={true}/>
              </TabPane>
            </TabContent>
          </Container>
        </div>
      </Fragment>
    )
  }
}

export default withRouter(withTranslation()(CampaignDetail))
