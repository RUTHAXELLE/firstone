import React, { Component, Fragment } from "react"
import { Alert, Button, Card, CardBody, CardHeader, CardTitle, Col, Container, Row } from "reactstrap"
import Breadcrumbs from "../../../../components/Common/Breadcrumb"
import { Breadcrumbs as Bs } from "../../../../common/data/breadcrumbs"
import { withTranslation } from "react-i18next"
import picto from "../../../../assets/images/picto.png"
import { AvField, AvForm } from "availity-reactstrap-validation"
import ExperienceTypes from "../../../../helpers/ExperienceTypes"
import { REPLY } from "../../../../helpers/url_helper"
import { post, put, upload } from "../../../../helpers/api_helper"
import toastr from "toastr"
import "toastr/build/toastr.min.css"

class Reply extends Component {

  constructor(props) {
    super(props)

    this.state = {
      status: 0,
      experience: (props.history.location.state !== undefined && props.history.location.state.experience !== null)
        ? props.history.location.state.experience : {
          id: null,
          shortDescription: null,
          description: null,
          issuingDomainId: null,
          type: null,
          status: null,
          rank: null,
          compaignId: null,
          file: null,
          issuingDomain: {
            name: null
          }
        },
      active: (props.history.location.state !== undefined && props.history.location.state.active !== null)
        ? props.history.location.state.active : true,
      receiving: (props.history.location.state !== undefined && props.history.location.state.receiving !== null)
        ? props.history.location.state.receiving : false,
      response: (
        props.history.location.state !== undefined
        && props.history.location.state.experience !== null
        && props.history.location.state.experience.replies !== undefined
        && props.history.location.state.experience.replies !== null
        && props.history.location.state.experience.replies.length > 0)
        ? props.history.location.state.experience.replies[0] : {
          message: null,
          status: 0,
          file: null
        }
    }

    // handleValidSubmit
    this.handleValidSubmit = this.handleValidSubmit.bind(this)
    this.updates = this.updates.bind(this)
    this.setFile = this.setFile.bind(this)
  }

  setStatus = (status) => {
    this.setState({ status })
  }

  loaderToggle = (status, loader) => {
    switch (status) {
      case 0:
        this.setState({ saveLoading: loader })
        break
      case 1:
        this.setState({ sendLoading: loader })
        break
      default:
        break
    }
  }

  updates = () => {
    //Récupération du fichier sélectionné par l'utilisateur
    let toUpload = document.getElementById("updateFile").files[0]

    let dataForm = new FormData()
    dataForm.append("image", toUpload)

    upload(dataForm).then(r => {
      this.setFile(r.data.url)
    })
  }

  setFile = (url) => {
    this.setState(
      { response: { ...this.state.response, file: "http://" + url } },
      () => {
        console.log(this.state)
      }
    )
  }

  // handleValidSubmit
  handleValidSubmit(event, values) {
    const datas = {
      ...values,
      experienceId: this.state.experience.id,
      file: this.state.response.file,
      status: this.state.status
    }
    this.loaderToggle(datas.status, true)

    if (this.state.response.id !== undefined) {
      const url = `${REPLY}/${this.state.response.id}`
      const data = { ...datas, id: this.state.response.id }
      put(url, data).then(
        response => {
          console.log(response)
          this.setState({ response: data })
          toastr.success("Réponse mise à jour avec succès.")
          this.loaderToggle(datas.status, false)
        }
      ).catch(error => {
          console.log(error)
          this.loaderToggle(datas.status, false)
          toastr.error("Erreur lors de la mise à jour, veuillez reessayer plus tard.")
        }
      )
    } else {
      post(REPLY, datas).then(
        response => {
          this.setState({ response: response })
          toastr.success("Réponse créé avec succès")
          console.log(response)
          this.loaderToggle(datas.status, false)
        }
      ).catch(error => {
          console.log(error)
          this.loaderToggle(datas.status, false)
          toastr.error("Erreur lors de la création', veuillez reessayer plus tard.")
        }
      )
    }
  }

  displayButtons = () => {
    if (this.state.response.status !== undefined && this.state.response.status !== 1 && this.state.active === true) {
      return (
        <div className="mt-3">
          <button
            className="btn btn-primary waves-effect waves-light"
            type="submit"
            onClick={() => this.setStatus(0)}
          >

            {this.props.saveLoading ? <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2"/> :
              <i className="fas fa-save mr-2"/>}
            Enregistrer
          </button>

          <button
            className="btn btn-primary waves-effect waves-light ml-3"
            type="submit"
            onClick={() => this.setStatus(1)}
          >
            {this.props.sendLoading ? <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2"/> :
              <i className="mdi mdi-send mr-2"/>}
            Envoyer
          </button>
        </div>
      )
    }
  }

  handleChangeData = ({ target }) => {
    this.setState({ response: { ...this.state.response, [target.name]: target.value } })
  }

  render() {
    const { experience, response, active } = this.state
    const disabled = response.status || active === false
    return (
      <Fragment>
        <div className="page-content">
          <Container fluid>
            <Breadcrumbs breadcrumbItems={Bs.CAMPAIGN_DETAILS}/>

            <Card>
              <CardHeader className="bg-white">
                <CardTitle tag="h5" className="mt-2">
                  <span style={{
                    padding: "5px",
                    marginRight: "10px",
                    textAlign: "center",
                    backgroundColor: (experience.type === ExperienceTypes.POSITIVE) ? "#c4f8b8" : "#f5edc1"
                  }}>
                    <img src={picto} alt="" style={{ width: "20px" }}/>
                  </span>
                  {experience.shortDescription}
                </CardTitle>
              </CardHeader>
              <CardBody>
                <Row>
                  <Col>
                    <p>Domaine: <b>{
                      (this.state.receiving)
                        ? experience?.receivingDomain?.name ?? ""
                        : experience?.issuingDomain?.name ?? ""
                    }</b></p>
                    <p>{experience.description}</p>

                    <div className="mb-2">
                      <a href={experience.file} target="_blank">{experience.file}</a>
                    </div>

                    <AvForm
                      className="form-horizontal"
                      onValidSubmit={this.handleValidSubmit}
                    >
                      {this.props.error && this.props.error ? (
                        <Alert color="danger">{this.props.error}</Alert>
                      ) : null}

                      <Row className="mt-5">
                        <Col className="mb-3" md={12}>
                          <b>{
                            (this.state.receiving)
                              ? "Réponse"
                              : "Votre réponse"
                          }</b>
                        </Col>
                        <Col>
                          <AvField
                            name="message"
                            className="form-control"
                            placeholder="Descrivez votre réponse ici"
                            onChange={this.handleChangeData}
                            value={response.message}
                            disabled={disabled}
                            type="textarea"
                            maxlength="600"
                            rows="7"
                            validate={{
                              required: { value: true, errorMessage: this.props.t("This field is required") },
                              maxLength: { value: 600 }
                            }}/>

                          <div className="mb-2">
                            <a href={response.file} target="_blank">{response.file}</a>
                          </div>

                          {response.status !== 1 && this.state.active === true ? (
                            <div className="mt-6">
                              <input
                                type="file"
                                id="updateFile"
                                style={{
                                  display: "none"
                                }}
                                onChange={() => {
                                  this.updates()
                                }}
                              />
                              <Button
                                color="primary"
                                id={"updateFile"}
                                onClick={() => {
                                  document.getElementById("updateFile").click() //Doesn't work on Safari
                                }}
                              >
                                <i className="fa fa-upload mr-2" aria-hidden="true"/>
                                Charger
                              </Button>
                            </div>
                          ) : (<span/>)}
                        </Col>
                      </Row>

                      {this.displayButtons()}

                      <Button
                        color="secondary"
                        className="mt-3"
                        onClick={() => { this.props.history.goBack() }}
                      >
                        <i className="fas fa-angle-left mr-2" aria-hidden="true"/>
                        {this.props.t('Back')}
                      </Button>
                    </AvForm>
                  </Col>
                </Row>
              </CardBody>
            </Card>
          </Container>
        </div>
      </Fragment>
    )
  }
}

export default withTranslation()(Reply)
