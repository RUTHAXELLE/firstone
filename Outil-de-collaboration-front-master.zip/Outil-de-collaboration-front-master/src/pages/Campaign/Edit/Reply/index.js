import React, { Component } from "react"
import { Button, Card, CardBody, CardHeader, CardTitle, Col, Row } from "reactstrap"
import { withTranslation } from "react-i18next"
import { get } from "../../../../helpers/api_helper"
import compaignsDatas from "../../../../common/data/campaigns"
import { EXPERIENCE_RECEIVING_DOMAIN } from "../../../../helpers/url_helper"
import datasColumns from "../../../../common/data/ReplyDatasColumns"
import paginationFactory from "react-bootstrap-table2-paginator"
import BootstrapTable from "react-bootstrap-table-next"
import { ROUTE_CAMPAIGN_DETAILS_REPLY } from "../../../../helpers/route_helper"
import { withRouter } from "react-router-dom"
import { loggedUser } from "../../../../helpers/jwt_helpers"

class ReplyExperience extends Component {
  constructor(props) {
    super(props)
    this.state = {
      campaign: (props.history.location.state !== undefined && props.history.location.state.campaign !== null)
        ? props.history.location.state.campaign : {
          id: null,
          name: null,
          startAt: null,
          endAt: null,
          status: null
        },
      display: (props.display !== undefined) ? props.display : false,
      experiences: [],
      toggleSendExperience: false,
    }

    this.user = loggedUser()

    this.compaigns = compaignsDatas
    this.getExperiences()
  }

  toggleSendExperience = () => {
    this.setState(prevState => ({
      toggleSendExperience: !prevState.toggleSendExperience
    }))
  }

  handleChange = ({ target }) => {
    this.setState({ [target.name]: target.value })
  }

  getExperiences = () => {
    const url = `${EXPERIENCE_RECEIVING_DOMAIN}/${this.state.campaign.id}/${this.user.domain.id}`
    get(url).then(
      response => {
        this.setState({experiences: response})
        console.log(response)
      }
    ).catch(error => {
        console.log(error)
      }
    )
  }

  render() {
    const rowEvents = {
      onClick: (e, row, rowIndex) => {

      },
      onDoubleClick: (e, row, rowIndex) => {
        console.log(row)
        this.props.history.push({
          pathname: ROUTE_CAMPAIGN_DETAILS_REPLY,
          state: { experience: row, active: !this.state.display }
        })
      }
    }

    return (
      <Card>
        <CardHeader className="bg-white">
          <CardTitle tag="h5">{this.props.t("Saisie d'expérience de collabartion qui vous sont adressées")}</CardTitle>
        </CardHeader>
        <CardBody>
          <Row>
            <Col>
              <BootstrapTable
                keyField="id"
                data={this.state.experiences}
                columns={datasColumns}
                bootstrap4
                bordered={false}
                rowEvents={rowEvents}
                pagination={paginationFactory({
                  currentPage: 0,
                  sizePerPage: 5,
                  sizePerPageList: [5, 10, 25, 50]
                })}
                noDataIndication={() => (
                  <div className=" text-center">{this.props.t("No data found")}</div>
                )}
                className={"cf"}
              />
            </Col>
          </Row>
          <Button
            color="secondary"
            className="mt-3"
            onClick={() => { this.props.history.goBack() }}
          >
            <i className="fas fa-angle-left mr-2" aria-hidden="true"/>
            {this.props.t('Back')}
          </Button>
        </CardBody>
      </Card>
    )
  }
}

export default withRouter(withTranslation()(ReplyExperience))
