import React, { Component, Fragment } from "react"
import { Container } from "reactstrap"
import Breadcrumbs from "../../../../components/Common/Breadcrumb"
import { Breadcrumbs as Bs } from "../../../../common/data/breadcrumbs"
import { withTranslation } from "react-i18next"
import ReplyExperience from "./index"
import { withRouter } from "react-router-dom"

class ReplyPage extends Component {

  constructor(props) {
    super(props)

    this.state = {
      loading: false,
      campaign: (props.history.location.state !== undefined && props.history.location.state.campaign !== null)
        ? props.history.location.state.campaign : {
          id: null,
          name: null,
          startAt: null,
          endAt: null,
          status: null
        }
    }
  }

  setStatus = (status) => {
    this.setState({ status })
  }

  render() {
    return (
      <Fragment>
        <div className="page-content">
          <Container fluid>
            <Breadcrumbs breadcrumbItems={Bs.CAMPAIGN_REPLIES}/>

            <ReplyExperience
              campaign={this.state.campaign}/>
          </Container>
        </div>
      </Fragment>
    )
  }
}

export default withRouter(withTranslation()(ReplyPage))
