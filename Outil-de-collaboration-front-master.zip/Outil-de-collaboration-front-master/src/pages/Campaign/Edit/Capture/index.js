import React, { Component } from "react"
import { Button, Card, CardBody, CardHeader, CardTitle, Col, Container, Row } from "reactstrap"
import { withTranslation } from "react-i18next"
import { get } from "../../../../helpers/api_helper"
import compaignsDatas from "../../../../common/data/campaigns"
import Experience from "./Experience"
import ExperienceTypes from "../../../../helpers/ExperienceTypes"
import { CAMPAIGN, CAMPAIGN_ACTIVE, EXPERIENCE, EXPERIENCE_ISSUING_DOMAIN } from "../../../../helpers/url_helper"
import { loggedUser } from "../../../../helpers/jwt_helpers"
import { withRouter } from "react-router-dom"

class CaptureExperience extends Component {
  constructor(props) {
    super(props)
    this.state = {
      campaign: (props.history.location.state !== undefined && props.history.location.state.campaign !== null)
        ? props.history.location.state.campaign : {
          id: null,
          name: null,
          startAt: null,
          endAt: null,
          status: null
        },
      display: (props.display !== undefined) ? props.display : false,
      toggleSendExperience: false,
      exp1: {
        shortDescription: null,
        description: null,
        issuingDomainId: 1,
        receivingDomainId: null,
        type: 1,
        status: 0,
        rank: 0,
        campaignId: null
      },
      exp2: {
        shortDescription: null,
        description: null,
        issuingDomainId: 1,
        receivingDomainId: null,
        type: 1,
        status: 0,
        rank: 1,
        campaignId: null
      },
      exp3: {
        shortDescription: null,
        description: null,
        issuingDomainId: 1,
        receivingDomainId: null,
        type: 2,
        status: 0,
        rank: 2,
        campaignId: null
      }
    }

    this.user = loggedUser()

    this.compaigns = compaignsDatas
    this.getActiveCompaign()
    this.getExperiences()
  }

  toggleSendExperience = () => {
    this.setState(prevState => ({
      toggleSendExperience: !prevState.toggleSendExperience
    }))
  }

  handleChange = ({ target }) => {
    this.setState({ [target.name]: target.value })
  }

  getActiveCompaign = () => {
    if (this.state.campaign.id === null) {
      get(CAMPAIGN_ACTIVE).then(
        response => {
          this.setState(prevState => ({
            compaign: response,
            exp1: { ...prevState.exp1, campaignId: response.id },
            exp2: { ...prevState.exp2, campaignId: response.id },
            exp3: { ...prevState.exp3, campaignId: response.id }
          }))
        }
      ).catch(error => {
          console.log(error)
        }
      )
    } else {
      this.setState(prevState => ({
        exp1: { ...prevState.exp1, campaignId: prevState.campaign.id },
        exp2: { ...prevState.exp2, campaignId: prevState.campaign.id },
        exp3: { ...prevState.exp3, campaignId: prevState.campaign.id }
      }))
    }
  }

  getExperiences = () => {
    const url = `${EXPERIENCE_ISSUING_DOMAIN}/${this.state.campaign.id}/${this.user.domain.id}`
    get(url).then(
      response => {
        //console.log(response)
        response.map((item, i) => {
          switch (item.rank) {
            case 0:
              this.setState({ exp1: item })
              break
            case 1:
              this.setState({ exp2: item })
              break
            case 2:
              this.setState({ exp3: item })
              break
          }
        })
      }
    ).catch(error => {
        console.log(error)
      }
    )
  }

  render() {
    const active = (this.state.display) ? false : this.state.campaign.status
    return (
      <Card>
        <CardHeader className="bg-white">
          <CardTitle tag="h5">{this.props.t("Info")}</CardTitle>
        </CardHeader>
        <CardBody>
          <Row>
            <Col>
              <p>
                {this.props.t("Cet écran vous permet de saisir les expériences de la compagne courante") + ": " + this.state.campaign.name}
              </p>
            </Col>
          </Row>

          <Experience
            type={ExperienceTypes.POSITIVE}
            campaignId={this.state.campaign.id}
            rank={0}
            experience={this.state.exp1}
            user={this.user}
            active={active}
          />
          <Experience
            type={ExperienceTypes.POSITIVE}
            campaignId={this.state.campaign.id}
            rank={1}
            experience={this.state.exp2}
            user={this.user}
            active={active}
          />
          <Experience
            type={ExperienceTypes.PERFECTIBLE}
            campaignId={this.state.campaign.id}
            rank={2}
            experience={this.state.exp3}
            user={this.user}
            active={active}
          />

          <Button
            color="secondary"
            className="mt-3"
            onClick={() => {
              this.props.history.goBack()
            }}
          >
            <i className="fas fa-angle-left mr-2" aria-hidden="true"/>
            {this.props.t("Back")}
          </Button>
        </CardBody>
      </Card>
    )
  }
}

export default withRouter(withTranslation()(CaptureExperience))
