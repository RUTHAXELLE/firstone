import React, { Component } from "react"
import { Alert, Button, Card, CardBody, CardHeader, CardTitle, Col, Row } from "reactstrap"
import { withTranslation } from "react-i18next"
import { AvField, AvForm } from "availity-reactstrap-validation"
import compaignsDatas from "../../../../common/data/campaigns"
import entitiesDatas from "../../../../common/data/entities"
import ExperienceTypes from "../../../../helpers/ExperienceTypes"
import { get, post, put, upload } from "../../../../helpers/api_helper"
import { DOMAIN, EXPERIENCE } from "../../../../helpers/url_helper"
import picto from "../../../../assets/images/picto.png"
import toastr from "toastr"
import "toastr/build/toastr.min.css"
import { loggedUser } from "../../../../helpers/jwt_helpers"

class Experience extends Component {

  constructor(props) {
    super(props)
    this.state = {
      toggleSendExperience: false,
      status: 0,
      domains: [],
      experience: (props.experience !== null) ? props.experience : {
        id: null,
        shortDescription: null,
        description: null,
        issuingDomainId: null,
        receivingDomainId: null,
        type: null,
        status: null,
        rank: null,
        campaignId: null,
        file: null
      },

      /**
       * Boolean spinner "Enregistrer"
       */
      saveLoading: false,

      /**
       * Boolean spinner "Envoyer"
       */
      sendLoading: false
    }

    this.type = {
      className: (this.props.type === ExperienceTypes.POSITIVE) ? "experience-positive" : "experience-perfectible",
      title: (this.props.type === ExperienceTypes.POSITIVE)
        ? "Saisissez une expérience de collaboration positive"
        : "Saisissez une expérience de collaboration perfectible",
      bg: (this.props.type === ExperienceTypes.POSITIVE) ? "#c4f8b8" : "#f5edc1",
      value: (this.props.type === ExperienceTypes.POSITIVE) ? 1 : 2
    }

    this.getDomains()

    // handleValidSubmit
    this.handleValidSubmit = this.handleValidSubmit.bind(this)
    this.updates = this.updates.bind(this)
    this.setFile = this.setFile.bind(this)
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      domains: [],
      experience: (nextProps.experience !== null) ? nextProps.experience : {
        id: null,
        shortDescription: null,
        description: null,
        issuingDomainId: null,
        receivingDomainId: null,
        type: null,
        status: null,
        rank: null,
        campaignId: null,
        file: null
      }
    })
  }

  getDomains = () => {
    get(DOMAIN).then(
      response => {
        this.setState({ domains: response })
        console.log(response)
      }
    ).catch(error => {
        console.log(error)
      }
    )
  }

  setStatus = (status) => {
    this.setState({ status })
  }

  setFile = (url) => {
    this.setState(
      { experience: { ...this.state.experience, file: "http://" + url } },
      () => {
        console.log(this.state)
      }
    )
  }

  toggleSendExperience = () => {
    this.setState(prevState => ({
      toggleSendExperience: !prevState.toggleSendExperience
    }))
  }

  // handleValidSubmit
  handleValidSubmit(event, values) {
    //this.props.loginUser(values, this.props.history)
    const datas = {
      ...values,
      rank: this.props.rank,
      type: this.type.value,
      file: this.state.experience.file,
      status: this.state.status,
      compaignId: this.props.campaignId,
      issuingDomainId: this.props.user.domain.id,
      receivingDomainId: parseInt(values.receivingDomainId)
    }
    console.log(datas)
    this.loaderToggle(datas.status, true)

    if (this.state.experience.id !== undefined) {
      const url = `${EXPERIENCE}/${this.state.experience.id}`
      const data = { ...datas, id: this.state.experience.id }
      put(url, data).then(
        response => {
          console.log(response)
          this.setState({ experience: response })
          toastr.success("Expérience mise à jour avec succès.")
          this.loaderToggle(datas.status, false)
        }
      ).catch(error => {
          console.log(error)
          this.loaderToggle(datas.status, false)
          toastr.error("Erreur lors de la mise à jour, veuillez reessayer plus tard.")
        }
      )
    } else {
      post(EXPERIENCE, datas).then(
        response => {
          this.setState({ experience: response })
          toastr.success("Expérience ajoutée avec succès")
          console.log(response)
          this.loaderToggle(datas.status, false)
        }
      ).catch(error => {
          console.log(error)
          this.loaderToggle(datas.status, false)
          toastr.error("Erreur lors de l'ajout', veuillez reessayer plus tard.")
        }
      )
    }
  }

  loaderToggle = (status, loader) => {
    switch (status) {
      case 0:
        this.setState({ saveLoading: loader })
        break
      case 1:
        this.setState({ sendLoading: loader })
        break
      default:
        break
    }
  }

  handleChangeData = ({ target }) => {
    this.setState({ experience: { ...this.state.experience, [target.name]: target.value } })
  }

  updates = () => {
    //Récupération du fichier sélectionné par l'utilisateur
    let files = document.getElementById("updateFile").files
    let toUpload = document.getElementById("updateFile").files[0]

    let dataForm = new FormData()
    dataForm.append("image", toUpload)

    // TODO: MAJ this (objet Experienc)
    upload(dataForm).then(r => {
      this.setFile(r.data.url)
    })
  }

  displayButtons = () => {
    if (this.state.experience.status !== 1 && this.props.active === true) {
      return (
        <div className="mt-3">
          <button
            className="btn btn-primary waves-effect waves-light"
            type="submit"
            onClick={() => this.setStatus(0)}
          >

            {this.props.saveLoading ? <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2"/> :
              <i className="fas fa-save mr-2"/>}
            Enregistrer
          </button>

          <button
            className="btn btn-primary waves-effect waves-light ml-3"
            type="submit"
            onClick={() => this.setStatus(1)}
          >
            {this.props.sendLoading ? <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2"/> :
              <i className="mdi mdi-send mr-2"/>}
            Envoyer
          </button>
        </div>
      )
    }
  }

  displayReplies = () => {
    if (this.state.experience.replies != null && this.state.experience.replies.length > 0) {
      const reply = this.state.experience.replies[0]
      return (
        <Row className="mt-3">
          <Col>
            <h3>Réponse</h3>
            <blockquote>
              {reply.message}
            </blockquote>
            <div className="mb-2">
              <a href={reply.file} target="_blank">{reply.file}</a>
            </div>
          </Col>
        </Row>
      )
    }
  }

  render() {
    const { experience } = this.state
    const disabled = experience.status || this.props.active === false
    return (
      <div className="mt-4">
        <h5>
          <span style={{ padding: "5px", marginRight: "10px", textAlign: "center", backgroundColor: this.type.bg }}>
            <img src={picto} alt="" style={{ width: "20px" }}/>
          </span>
          {this.props.t(this.type.title)}
        </h5>
        <AvForm
          className="form-horizontal mt-4"
          onValidSubmit={this.handleValidSubmit}
        >
          {this.props.error && this.props.error ? (
            <Alert color="danger">{this.props.error}</Alert>
          ) : null}

          <Row>
            <Col>
              <AvField
                name="receivingDomainId"
                className="form-control"
                placeholder="Entité"
                onChange={this.handleChangeData}
                value={experience.receivingDomainId}
                disabled={disabled}
                type="select"
                validate={{
                  required: { value: true, errorMessage: this.props.t("This field is required") }
                }}>
                <option value="">{this.props.t("Select a domain")}</option>
                {this.state.domains.map((item, i) =>
                  <option value={item.id}>{item.name}</option>
                )}
              </AvField>

              <AvField
                name="shortDescription"
                className="form-control"
                placeholder="Donnez un titre à votre expérience"
                onChange={this.handleChangeData}
                value={experience.shortDescription}
                disabled={disabled}
                type="textarea"
                maxlength="200"
                rows="3"
                validate={{
                  required: { value: true, errorMessage: this.props.t("This field is required") },
                  maxLength: { value: 200 }
                }}/>

              <AvField
                name="description"
                className="form-control"
                placeholder="Descrivez votre expérience"
                onChange={this.handleChangeData}
                value={experience.description}
                disabled={disabled}
                type="textarea"
                maxlength="600"
                rows="7"
                validate={{
                  required: { value: true, errorMessage: this.props.t("This field is required") },
                  maxLength: { value: 600 }
                }}/>

              <div className="mb-2">
                <a href={this.state.experience.file} target="_blank">{this.state.experience.file}</a>
              </div>

              {experience.status !== 1 && this.props.active === true ? (
                <div className="mt-6">
                  <input
                    type="file"
                    id="updateFile"
                    style={{
                      display: "none"
                    }}
                    onChange={() => {
                      this.updates()
                    }}
                  />
                  <Button
                    color="primary"
                    id={"updateFile"}
                    onClick={() => {
                      document.getElementById("updateFile").click() //Doesn't work on Safari
                    }}
                  >
                    <i className="fa fa-upload mr-2" aria-hidden="true"/>
                    Joindre un fichier
                  </Button>
                </div>
              ) : (<span/>)}
            </Col>
          </Row>

          {this.displayButtons()}
        </AvForm>

        {this.displayReplies()}
      </div>
    )
  }
}

export default withTranslation()(Experience)
