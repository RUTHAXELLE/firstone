import axios from "axios"
import { STORAGE_TOKEN } from "./localStorage_helper"
import { POST_FILES } from "./url_helper"
import * as url from "./url_helper"

const https = require('https')
const fs = require('fs')
const path = require('path')

const httpsAgent = new https.Agent( {
    rejectUnauthorized : false
    /* cert: certFile,
    key: keyFile */
  } )

//apply base url for axios
const API_URL = "http://localhost:3050"
//const API_URL = "http://192.168.43.179:3050"
//const API_URL = "https://chilly-bear-80.loca.lt"

const axiosApi = axios.create({
  baseURL: API_URL,
  httpsAgent : httpsAgent
})

// Rafraichir le token à chaque appel de service
axiosApi.interceptors.request.use(
  async config => {
    config.headers = {
      'Authorization': `Bearer ${localStorage.getItem(STORAGE_TOKEN)}`
    }
    return config;
  },
  error => {
    Promise.reject(error)
  })

axiosApi.interceptors.response.use(
  response => response,
  error => Promise.reject(error)
)

export async function get(url, config = {}) {
  return await axiosApi.get(url, { ...config })
    .then(response => successProcess(response))
    .catch(err => errorProcess(err))
}

export async function post(url, data, config = {}) {
  return axiosApi
    .post(url, data, { ...config })
    .then(response => successProcess(response))
    .catch(err => errorProcess(err))
}

export async function put(url, data, config = {}) {
  return axiosApi
    .put(url, data, { ...config })
    .then(response => successProcess(response))
    .catch(err => errorProcess(err))
}

export async function del(url, config = {}) {
  return await axiosApi
    .delete(url, { ...config })
    .then(response => successProcess(response))
    .catch(err => errorProcess(err))
}

export async function upload(data, config = {}) {
  return await axiosApi
    .post(POST_FILES, data,
    {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem(STORAGE_TOKEN)}`,
        'Content-Type' :  `multipart/form-data; boundary=${data._boundary}`
      }
    })
    .then(response => successProcess(response))
    .catch(err => errorProcess(err))
}

const successProcess = (response) => {
  console.log(response)
  if (response.status >= 200 || response.status <= 299) return response.data
  throw response.data
}

const errorProcess = (err) => {
  console.log(err)
  let message
  if (err.response && err.response.status) {
    console.log(err.response)
    switch (err.response.status) {
      case 404:
        message = "Désolé! l'API que vous appelez est introuvable"
        break
      case 500:
        message = "Désolé! un problème est survenu, veuillez contacter notre équipe d'assistance"
        break
      case 401:
        message = err.response.data.message
        break
      default:
        message = err.response.data.message
        break
    }
  }
  throw message
}
