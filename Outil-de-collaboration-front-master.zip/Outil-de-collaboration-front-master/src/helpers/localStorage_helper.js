export const STORAGE_TOKEN = "token"
export const MAIL_ADDRESS = "mailaddress"
export const STORAGE_AUTH_USER = "authUser"
export const STORAGE_SHORTCUTS = "shortcuts"
export const OFFER_KEY = "offerKey"
export const getCotation = () => localStorage.getItem( OFFER_KEY )

