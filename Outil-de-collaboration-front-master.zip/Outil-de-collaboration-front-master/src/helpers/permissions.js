import * as PERMISSIONS from "./permission_helper"

const Permissions = [
    {
        label : "Log out",
        value :  PERMISSIONS.PERMISSION_LOGOUT
    },
    {
        label : "Log in",
        value :  PERMISSIONS.PERMISSION_LOGIN
    },
    {
        label : "Settings menu",
        value :  PERMISSIONS.PERMISSION_SETTINGS
    },
    {
        label : "Profile list",
        value :  PERMISSIONS.PERMISSION_PROFILE
    },
    {
        label : "Create a profile",
        value :  PERMISSIONS.PERMISSION_PROFILE_CREATE
    },
    {
        label : "Edit a profile",
        value :  PERMISSIONS.PERMISSION_PROFILE_UPDATE
    },
    {
        label : "Delete a profile",
        value :  PERMISSIONS.PERMISSION_PROFILE_DELETE
    }
]
export default Permissions