const ExperienceTypes = {
  POSITIVE: 1,
  PERFECTIBLE: 2
}

export default ExperienceTypes