//API_URLS
export const BASE_URL = '35.180.211.191:3010';

//REGISTER
export const POST_FAKE_REGISTER = "/post-fake-register"

//LOGIN
export const POST_LOGIN = "/auth/login"
export const POST_FAKE_LOGIN = "/post-fake-login"
export const POST_FAKE_JWT_LOGIN = "/post-jwt-login"
export const POST_FAKE_PASSWORD_FORGET = "/fake-forget-pwd"
export const POST_FAKE_JWT_PASSWORD_FORGET = "/jwt-forget-pwd"
export const SOCIAL_LOGIN = "/social-login"

//EXPERIENCE
export const EXPERIENCE = '/experience'
export const EXPERIENCE_ISSUING_DOMAIN = '/experience/issuingDomain'
export const EXPERIENCE_RECEIVING_DOMAIN = '/experience/receivingDomain'
export const STATS = '/experience/stats'

// REPLY
export const REPLY = '/reply'

// DOMAIN
export const DOMAIN = '/domain'

// DOMAIN_TYPE
export const DOMAIN_TYPE = '/domain-type'

// PROFILE
export const PROFILE = '/profile'

// CAMPAIGN
export const CAMPAIGN = '/campaign'
export const CAMPAIGN_ACTIVE = '/campaign/active'


//Demande de cargaison
export const CONSTRAINT_URL = "/constraintType"
export const REEFERTYPE_URL = "/reeferType"
export const CONNAISSEMENT_URL = "/billoflading"

export const REFRESH_TOKEN = "/token/update"

//USER
export const USER = "/user"

//CHARGEURS
export const TRANSPRQST = "/transpreqst"
export const DELIVERY_CONSTRAINT_URL = "/deliveryconstraints"

// PABLO B.O MENUS
export const GET_AXLES_NB = `/axlesNb`
export const GET_TRAILER_TYPE = `/trailertype`
export const GET_TRUCK_TYPE = `/trucktype`
export const GET_VEHICLE_CLASS_TYPE = `/vehiculeclass`
export const GET_COMPANIES = `/companies`
export const GET_TIME_UNITS = `/timeunit`
export const GET_QTY_UNITS = `/units`
export const GET_PRODUCT_K_TYPE = `/productktype`
export const GET_PRODUCTS_KBB = `/productskbb`
export const GET_PRODUCTS_PACK_KBB = `/prodPackKBB`
export const POST_FILES = `/files`


//Register
export const MAIL_CHECK = `/mails/check/`
export const PHONE_CHECK = `/phones/check/`
export const USERNAME_CHECK = `/user/check/username/`
export const USER_CODE_URL = '/usercode'
export const REGISTER_URL = '/user'
export const USER_CODE_VERIFY = `${USER_CODE_URL}/verify`
export const RESET_CODE_URL = `${ USER_CODE_URL }/sendResetCode`
export const RESET_PASSWORD_URL = '/auth/reset-password'

//PROFILE
export const POST_EDIT_JWT_PROFILE = "/post-jwt-profile"
export const POST_EDIT_PROFILE = "/post-fake-profile"


//PRODUCTS
export const GET_PRODUCTS = "/products"
export const GET_PRODUCTS_DETAIL = "/product"

//CALENDER
export const GET_EVENTS = "/events"
export const ADD_NEW_EVENT = "/add/event"
export const UPDATE_EVENT = "/update/event"
export const DELETE_EVENT = "/delete/event"
export const GET_CATEGORIES = "/categories"

//CHATS
export const GET_CHATS = "/Chats"
export const GET_GROUPS = "/groups"
export const GET_CONTACTS = "/contacts"
export const GET_MESSAGES = "/messages"
export const ADD_MESSAGE = "/add/messages"

//ORDERS
export const GET_ORDERS = "/orders"

//CART DATA
export const GET_CART_DATA = "/cart"

//CUSTOMERS
export const GET_CUSTOMERS = "/customers"

//SHOPS
export const GET_SHOPS = "/shops"

//CRYPTO
export const GET_WALLET = "/wallet"
export const GET_CRYPTO_ORDERS = "/crypto/orders"

//INVOICES
export const GET_INVOICES = "/invoices"
export const GET_INVOICE_DETAIL = "/invoice"

//PROJECTS
export const GET_PROJECTS = "/projects"
export const GET_PROJECT_DETAIL = "/project"

//TASKS
export const GET_TASKS = "/tasks"

//CONTACTS
export const GET_USERS = "/utilisateurs_droits"
export const GET_USER_PROFILE = "/user"

//UNCERTIFIED USERS
export const GET_NOT_CERTIFIED_USER = "/user/uncertified"
export const PUT_CERTIFIED_USER = "/user"

//COMPANY TAGS
export const GET_COMPANY_TAGS = "/companytags"

//ROLES
export const GET_ROLES = "/roles"

//compagnie
export const GET_COMPANIES_DATA = "/companies"

//

//mails
export const GET_MAILS = "/mails"
export const GET_MAILS_USER = "/mails/user"
export const GET_MAIL_TYPE = "/mailtype"
export const GET_MAIL_STATUS = "/statustype"

//Phones
export const GET_PHONES = "/phones"
export const GET_PHONES_USER = GET_PHONES+"/user"
export const GET_PHONES_TYPE = "/phonetype"

//Doc auth
export const GET_DOC_AUTH_USER = "/docauth/user"
export const GET_DOC_AUTH_TYPE = "/docauthtype"
export const GET_DOC_AUTH = "/docauth"

export const GET_COMPANY_TYPE = "/companytype"
export const GET_STATUS_TYPE = "/statustype"

export const GET_COMPANY_ENTITY_TYPE = "/companyentitytype"
export const GET_PROFILE_USER = "/userprofile"

export const GET_COMPANY_ENTITY = "/companyentity"

//Expeditions
export const GET_TRANSPORT_ORDER = "/transportorder"

//localisation
export const GET_LOCALISATIONS = "/localisations"

//cargo type
export const GET_CARGO_TYPE = "/cargotype"

//transport request
export const GET_TRANSPORT_REQUEST = "/transpreqst"

export const GET_TRUCK_TRAILER = "/trucktrailer"

export const GET_TRANSPORT_OFFER = "/transportoffer"

export const GET_LOAD_VEHICULE = "/loadvehicule"

