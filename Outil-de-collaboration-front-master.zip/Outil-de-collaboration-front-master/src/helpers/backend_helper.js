import axios from "axios"
import { del, get, post, put } from "./api_helper"
import * as url from "./url_helper"
import { STORAGE_AUTH_USER, STORAGE_TOKEN } from "./localStorage_helper"
import { TRANSPRQST } from "./url_helper"


//---- Pablo  methods -----
const registerMethods = {

  userCodeVerify: (data, successCallback, errorCallback) => {

    return new Promise((resolve, reject) => {
      post(
        url.USER_CODE_VERIFY, {
          "email": data?.mailAddress || data?.email,
          "code": data?.code || document.getElementById("code_verification").value
        })
        .then(response => resolve(response))
        .catch(error => reject(error))
    })

  },

  register: (data, successCallback, errorCallback) => {

    //Procède à la préinsciption
    return new Promise((resolve, reject) => {
      post(url.REGISTER_URL, data)

        .then(response => resolve(response))
        .catch(err => reject(err))
    })

  },

  userMailVerify: (data, successCallback, errorCallback) => {
    return new Promise((resolve, reject) => {
      get(`${url.MAIL_CHECK}${data?.mailAddress}`)
        .then(response => resolve(response))
        .catch(err => reject(err))
    })
  },

  phoneVerify: (data, successCallback, errorCallback) => {
    return new Promise((resolve, reject) => {

      get(`${url.PHONE_CHECK}${data?.countryCode}/${data?.phoneNr}`)
        .then(response => resolve(response))
        .catch(err => reject(err))
    })
  },

  usernameVerify: (data, successCallback, errorCallback) => {
    return new Promise((resolve, reject) => {

      get(`${url.USERNAME_CHECK}${data?.userName}`)
        .then(response => resolve(response))
        .catch(err => reject(err))

    })

  },

  getProfilTypes: () => {

    /* // TODO décommenter lorsque le service sera prêt
    return new Promise ( ( resolve, reject ) => {
        get( `${ url }protypes_`)
        .then ( response => {
          let profils =  response.map ( profilUtilisation => ( { label : `${ profilUtilisation.title }`, value : `${ profilUtilisation.id }`} ) )
          resolve( profils )

        })
        .catch ( err => {
          toastr.error( "Une erreur est survenue" )
          console.log( "GET /protypes error = ", err )
          resolve( [] )
        } )
      } )
      */

    let response = [{ id: 1, title: "Professionnel", defaultChecked: true },
        { id: 0, title: "Particulier" }],
      profils = response.map(profilUtilisation => ({
        label: `${profilUtilisation.title}`,
        value: `${profilUtilisation.id}`
      }))

    return profils
  },

  sendUserCode: (data) => {
    return new Promise((resolve, reject) => {

      post(`${url.USER_CODE_URL}`,
        {
          username: data?.userName,
          email: data?.mailAddress || localStorage.getItem("mailAddress")
        }
      )
        .then(response => resolve(response))
        .catch(error => reject(error))

    })
  },

  sendResetCode: (data) => {
    return new Promise((resolve, reject) => {
      post(`${url.RESET_CODE_URL}`,
        {
          email: data?.mailAddress || localStorage.getItem("mailAddress")
        }
      )
        .then(response => resolve(response))
        .catch(error => reject(error))

    })

  }

}
export const resetPassword = (data) => post(
  `${url.RESET_PASSWORD_URL}`,
  {
    email: data?.mailAddress || localStorage.getItem("mailAddress"),
    newpassword: data?.newPassword
  }
)


export const requestQuotation = (quotation, successCallack, errorCallack) => {
  let url = TRANSPRQST

  if (quotation.id !== null && quotation.id !== undefined && quotation.id !== "") {
    url = `${TRANSPRQST}/${quotation.id}`
    put(url, quotation).then(response => successCallack(response)).catch(error => errorCallack(error))
  } else {
    post(url, quotation).then(response => successCallack(response)).catch(error => errorCallack(error))
  }
}

export const refreshToken = (token) => post(`${url.REFRESH_TOKEN}`, {
  token: token || localStorage.getItem(STORAGE_TOKEN)
})


const backOfficeMethods = {

  uploadFile: (data, forVehicle = false, vehicleId = undefined) => {
    return new Promise((resolve, reject) => {
      post(url.POST_FILES, data,
        {
          headers: {
            "Authorization": `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": `multipart/form-data; boundary=${data._boundary}`
          }
        })
        .then(response => {
          resolve(response)
        })
        .catch(err => reject(err))

    })
  },

  getQtyUnits: () => {
    return new Promise((resolve, reject) => {
      get(url.GET_QTY_UNITS)
        .then(
          response => {
            response.splice(0, 0, { id: -1, unit: "Veuillez selectionner une unité de produit" })
            let units = response.filter(unit => unit.unitTypeId === 1),
              monn = response.filter(unit => unit.unitTypeId === 5)
            units.splice(0, 0, { id: -1, unit: "Veuillez selectionner une unité de produit" })
            monn.splice(0, 0, { id: -1, unit: "Veuillez selectionner une valeur monétaire" })

            if (response.error) {
              reject(response.message)
            } else {
              resolve({
                units: units,
                monnaies: monn
              })
            }

          }
        ).catch(error => reject(error))
    })
  },


  getProductKTypes: () => {
    return new Promise((resolve, reject) => {
      get(url.GET_PRODUCT_K_TYPE)
        .then(
          response => {
            response.splice(0, 0, { id: -1, title: "Veuillez sélectionner une type de produit" })

            if (response.error) {
              reject(response.message)
            } else {
              resolve(response)
            }

          }
        ).catch(error => reject(error))
    })
  },


  getTimeUnits: () => {
    return new Promise((resolve, reject) => {
      get(url.GET_TIME_UNITS).then(
        response => {
          response.splice(0, 0, { id: -1, title: "Veuillez selectionner une fréquence de facturation" })
          if (response.error) {
            reject(response.message)
          } else {
            resolve(response)
          }

        }
      ).catch(error => reject(error))
    })
  },

  getDurations: () => {
    return new Promise((resolve, reject) => {
      get(parameter).then(
        response => {
          if (response.error) {
            reject(response.message)
          } else {
            resolve(response)
          }

        }
      ).catch(error => reject(error))
    })
  },


  getOwnerKBBs: () => {
    return new Promise((resolve, reject) => {
      get(url.GET_COMPANIES).then(
        response => {
          if (response.error) {
            reject(response.message)
          } else {
            response.splice(0, 0, { id: -1, name: "Veuillez sélectionner une société" })
            resolve(response)
          }
        }
      ).catch(error => reject(error))
    })
  },

  getProducts: () => {
    return new Promise((resolve, reject) => {
      get(url.GET_PRODUCTS_PACK_KBB)
        .then(response => {
          response.splice(0, 0, { id: -1, name: "Veuillez selectionner un produit" })
          resolve(response)
        })
        .catch(err => reject(err))
    })
  },

  getProductsKbb: () => {

    return new Promise((resolve, reject) => {
      get(url.GET_PRODUCTS_KBB)
        .then(s => {
          s.splice(0, 0, { id: -1, name: "Veuillez selectionner un produit" })
          resolve(s)
        }).catch(err => reject(err))
    })
  },


  getCategorys: () => {
    return new Promise((resolve, reject) => {
      get(url.GET_VEHICLE_CLASS_TYPE).then(
        response => {
          if (response.error) {
            reject(response.message)
          } else {
            response.splice(0, 0, { id: -1, title: "Veuillez séléctionner la catégorie générale" })
            resolve(response)
          }

        }
      ).catch(error => reject(error))
    })
  },


  getTruckCategory: () => {
    return new Promise((resolve, reject) => {
      get(url.GET_TRUCK_TYPE)
        .then(
          response => {
            if (response.error) {
              reject(response.message)
            } else {
              response.splice(0, 0, { id: -1, title: "Veuillez séléctionner la catégorie tracteur" })
              resolve(response)
            }

          }).catch(error => reject(error))
    })
  },


  getTrailerCategory: () => {
    return new Promise((resolve, reject) => {
      get(url.GET_TRAILER_TYPE).then(
        response => {
          if (response.error) {
            reject(response.message)
          } else {
            response.splice(0, 0, { id: -1, title: "Veuillez séléctionner la catégorie remorque" })
            resolve(response)
          }

        }
      ).catch(error => reject(error))
    })
  },


  getAxlesNb: () => {
    return new Promise((resolve, reject) => {
      get(url.GET_AXLES_NB).then(
        response => {
          if (response.error) {
            reject(response.message)
          } else {
            resolve(response)

          }

        }
      ).catch(error => reject(error))
    })
  }


}

export const getConstraints = () => get(url.CONSTRAINT_URL)
export const getDeliveryConstraints = () => get(url.DELIVERY_CONSTRAINT_URL)

export const getOTSamePOD = (podId) => {

  return new Promise((resolve, reject) => {
    get(url.GET_TRANSPORT_ORDER)
      .then(transpOrders => {
        getStatusType()
          .then(statusTypes => {
            let transportOrdersStatusDeliverd = statusTypes.filter(status => status.target === "transportOrders" && status.title === "Livré"),
              transportOrdersDelivered = transpOrders.filter(transportOrder => {
                transportOrder.statusId === transportOrdersStatusDeliverd[0].id
              }),

              samePod = transportOrdersDelivered.filter(ot => ot.podId === podId)
            resolve(samePod)
          })
          .catch(err => this.setState({ statusTypes: [] }))
      })
      .catch(err => reject(err))

  })

}
//---------------------------

// Get local session token
const getToken = () => {
  const token = localStorage.getItem(STORAGE_TOKEN)
  if (token) return token
  return null
}

// Gets the logged in user data from local session
const getLoggedInUser = () => {
  const user = localStorage.getItem(STORAGE_AUTH_USER)
  if (user) return JSON.parse(user)
  return null
}

//is user is logged in
const isUserAuthenticated = () => {
  return getLoggedInUser() !== null
}

//is user is granted in
const isUserGranted = (roles) => {
  // TODO: définir les droits d'accès aux pages et menus
  return true
}

// Login Method
const postLogin = data => post(url.POST_LOGIN, data, {
  //"User-Agent" : "PostmanRuntime/7.26.8"
})

// Register Method
const postRegister = data => {
  return axios
    .post(url.POST_FAKE_REGISTER, data)
    .then(response => {
      if (response.status >= 200 || response.status <= 299) return response.data
      throw response.data
    })
    .catch(err => {
      let message
      if (err.response && err.response.status) {
        switch (err.response.status) {
          case 404:
            message = "Sorry! the page you are looking for could not be found"
            break
          case 500:
            message =
              "Sorry! something went wrong, please contact our support team"
            break
          case 401:
            message = "Invalid credentials"
            break
          default:
            message = err[1]
            break
        }
      }
      throw message
    })
}

// postForgetPwd
const postFakeForgetPwd = data => post(url.POST_FAKE_PASSWORD_FORGET, data)

// Edit profile
const postJwtProfile = data => post(url.POST_EDIT_JWT_PROFILE, data)

// Register Method
const postJwtRegister = (url, data) => {
  return axios
    .post(url, data)
    .then(response => {
      if (response.status >= 200 || response.status <= 299) return response.data
      throw response.data
    })
    .catch(err => {
      var message
      if (err.response && err.response.status) {
        switch (err.response.status) {
          case 404:
            message = "Sorry! the page you are looking for could not be found"
            break
          case 500:
            message =
              "Sorry! something went wrong, please contact our support team"
            break
          case 401:
            message = "Invalid credentials"
            break
          default:
            message = err[1]
            break
        }
      }
      throw message
    })
}

// postSocialLogin
export const postSocialLogin = data => post(url.SOCIAL_LOGIN, data)

// get AmarisData
export const getAmarisDatas = url => get(url)
export const persistsAmarisDatas = (url, datas, method) => {
  switch (method) {
    case "POST":
      post(url, datas)
      break
    case "PUT":
      put(url, datas)
      break
    case "DELETE":
      del(url, datas)
      break
  }
}

// get Products
export const getProducts = () => get(url.GET_PRODUCTS)

// get Events
export const getEvents = () => get(url.GET_EVENTS)

// update Event
export const updateEvent = event => put(url.UPDATE_EVENT, event)

// delete Event
export const deleteEvent = event =>
  del(url.DELETE_EVENT, { headers: { event } })

// get Chats
export const getChats = () => get(url.GET_CHATS)

// get groups
export const getGroups = () => get(url.GET_GROUPS)

// get Contacts
export const getContacts = () => get(url.GET_CONTACTS)

// get messages
export const getMessages = (roomId = "") =>
  get(`${url.GET_MESSAGES}/${roomId}`, { params: { roomId } })

// post messages
export const addMessage = message => post(url.ADD_MESSAGE, message)

// get orders
export const getOrders = () => get(url.GET_ORDERS)

// get cart data
export const getCartData = () => get(url.GET_CART_DATA)

// get crypto order
export const getCryptoOrder = () => get(url.GET_CRYPTO_ORDERS)

// get invoices
export const getInvoices = () => get(url.GET_INVOICES)

// get project
export const getProjects = () => get(url.GET_PROJECTS)

export const getUserProfile = () => get(url.GET_USER_PROFILE)

// get uncertified utilisateurs_droits
export const getNotCertifiedUser = () => get(url.GET_NOT_CERTIFIED_USER)
export const addNotCertifiedUser = (id, user) => put(`${url.PUT_CERTIFIED_USER}/${id}`, user)

//Company tags
export const getCompanytags = () => get(url.GET_COMPANY_TAGS)

//Roles
export const getAllRoles = () => get(url.GET_ROLES)
export const updateRole = (id, role) => put(`${url.GET_ROLES}/${id}`, role)
export const deleteRole = id => del(`${url.GET_ROLES}/${id}`)
export const addRole = role => post(url.GET_ROLES, role)

//Compagnie
export const getAllCompagnies = () => get(url.GET_COMPANIES_DATA)
export const getAllCompaniesByStatus = (id) => get(url.GET_COMPANIES_DATA + `/status/${id}`)
export const updateCompany = (id, dataCompany) => put(`${url.GET_COMPANIES_DATA}/${id}`, dataCompany)
export const addCompany = companies => post(`${url.GET_COMPANIES_DATA}`, companies)

//Mails
export const getMailsForUser = id => get(`${url.GET_MAILS_USER}/${id}`)
export const getMailsType = () => get(url.GET_MAIL_TYPE)
export const getMailsStatus = () => get(url.GET_MAIL_STATUS)
export const addNewMail = mail => post(url.GET_MAILS, mail)
export const updateMail = (id, mail) => put(`${url.GET_MAILS}/${id}`, mail)
export const deleteMail = id => del(`${url.GET_MAILS}/${id}`)

//Phones
export const getPhonesForUser = id => get(`${url.GET_PHONES_USER}/${id}`)
export const getPhonesTypes = () => get(url.GET_PHONES_TYPE)
export const addNewPhone = phone => post(url.GET_PHONES, phone)
export const updatePhone = (id, phone) => put(`${url.GET_PHONES}/${id}`, phone)
export const deletePhone = id => del(`${url.GET_PHONES}/${id}`)
export const getPhoneById = id => get(`${url.GET_PHONES}/${id}`)
export const isPhoneExist = (ind, number) => get(`${url.GET_PHONES}/check/${ind}/${number}`)

//Docauth
export const getDocAuthForUser = id => get(`${url.GET_DOC_AUTH_USER}/${id}`)
export const getAuthDocType = () => get(url.GET_DOC_AUTH_TYPE)
export const addDocAuth = docauth => post(url.GET_DOC_AUTH, docauth)
export const updateDocAuth = (id, docAuth) => put(`${url.GET_DOC_AUTH}/${id}`, docAuth)

//Users
export const addUser = user => post(url.GET_USER_PROFILE, user)
export const getAllUsers = () => get(url.USER)
//export const getUserProfile = () => get(url.GET_PROFILE)

//Companytype
export const getCompanyType = () => get(url.GET_COMPANY_TYPE)

//statustypr
export const getStatusType = () => get(url.GET_STATUS_TYPE)

export const getCompanyEntityType = () => get(url.GET_COMPANY_ENTITY_TYPE)

//countries
export const getAllCountries = () => get("http://35.180.211.191:3536/api/v1")
export const getCountryByCallingCode = (cc) => get(`http://35.180.211.191:3536/api/v1/callingcode/${parseInt(cc)}`)

export const getProfileUser = () => get(url.GET_PROFILE_USER)

//Docauth
export const deleteDocAuth = id => del(`${url.GET_DOC_AUTH}/${id}`)

//update company entity
export const updateCompanyEntity = (id, companyentity) => put(`${url.GET_COMPANY_ENTITY}/${id}`, companyentity)

//Etablissement
export const createCompanyEntity = companyentity => post(url.GET_COMPANY_ENTITY, companyentity)

//localisation
export const updateLocation = (id, localisations) => put(`${url.GET_LOCALISATIONS}/${id}`, localisations)
export const addLocation = location => post(`${url.GET_LOCALISATIONS}`, location)

//crgotype
export const getCargoType = () => get(url.GET_CARGO_TYPE)

//Demande de cargaison
export const getReeferTypes = () => get(url.REEFERTYPE_URL)

//Transport Request
export const getTransportRequest = () => get(`${url.GET_TRANSPORT_REQUEST}`)

//Get all region
export const getRegions = () => get("http://kubeba.co:3000/data.json")

//Truck Trailer
export const getTruckTrailer = () => get(`${url.GET_TRUCK_TRAILER}`)

//Transport offer
export const getAllTransportOffer = () => get(`${url.GET_TRANSPORT_OFFER}`)

export const addTransportOffer = transportoffer => post(`${url.GET_TRANSPORT_OFFER}`, transportoffer)
export const updateTransportOffer = transportoffer => put(`${url.GET_TRANSPORT_OFFER}`, transportoffer)
export const updateNewTransportOffer = (id, transportoffer) => put(`${url.GET_TRANSPORT_OFFER}/${id}`, transportoffer)

export const getLoadVehicle = () => get(url.GET_LOAD_VEHICULE)

export {
  getToken,
  getLoggedInUser,
  isUserAuthenticated,
  isUserGranted,
  postLogin,
  postFakeForgetPwd,
  postJwtRegister,
  postJwtProfile,
  registerMethods,
  backOfficeMethods
}
