import { Trans } from "react-i18next"
import React from "react"
import moment from "moment"
import { EXPERIENCE } from "../../helpers/url_helper"

const transFormatter = (column, colIndex, components) => {
  return (<Trans>{column.text}</Trans>)
}

const emailFormatter = (cell, row, rowIndex, formatExtraData) => {
  return (<a href={`mailto:/${cell}`}>{cell}</a>)
}

const datasColumns = [
  {
    text: "id",
    dataField: "id",
    sort: true,
    hidden: true,
    headerFormatter: transFormatter

  },
  {
    text: "Firstname",
    dataField: "firstname",
    sort: true,
    headerFormatter: transFormatter

  },
  {
    text: "Lastname",
    dataField: "lastname",
    sort: true,
    headerFormatter: transFormatter,
  },
  {
    text: "Email",
    dataField: "email",
    sort: true,
    headerFormatter: transFormatter,
    formatter: emailFormatter
  },
  {
    text: "Registration number",
    dataField: "registrationNumber",
    sort: true,
    headerFormatter: transFormatter,
  },
  {
    text: "Profile",
    dataField: "profile.name",
    sort: true,
    headerFormatter: transFormatter,
  }
]

export default datasColumns
