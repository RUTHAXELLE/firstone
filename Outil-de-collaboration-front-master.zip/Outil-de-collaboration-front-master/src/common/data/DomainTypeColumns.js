import { Trans } from "react-i18next"
import React from "react"

const transFormatter = (column, colIndex, components) => {
  return (<Trans>{column.text}</Trans>)
}

const datasColumns = [
  {
    text: "id",
    dataField: "id",
    sort: true,
    hidden: true,
    headerFormatter: transFormatter

  },
  {
    text: "Name",
    dataField: "name",
    sort: true,
    headerFormatter: transFormatter

  }
]

export default datasColumns
