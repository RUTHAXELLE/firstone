const datas = [
  { "id": 1, "name": "Domaine", "created_at": "24/1/2021" },
  { "id": 2, "name": "Fonction support", "created_at": "24/9/2020" }
]

export default datas