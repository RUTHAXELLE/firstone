const datas = [
  { "id": 1, "type": 1, "shortDescription": "Franche collaboration", "issuingDomain": { "id": 2, "name": "DIFA" }, "response": { } },
  { "id": 2, "type": 1, "shortDescription": "Disponible", "issuingDomain": { "id": 3, "name": "SIC" }, "response": { "id": 1, "status": 1 } },
  { "id": 2, "type": 2, "shortDescription": "Pas reactif", "issuingDomain": { "id": 4, "name": "CBS" }, "response": { "id": 4, "status": 2 } },
  { "id": 2, "type": 1, "shortDescription": "A l'écoute", "issuingDomain": { "id": 5, "name": "PAI" }, "response": {  } },
]

export default datas