import {
  ROUTE_CAMPAIGN,
  ROUTE_CAMPAIGN_DETAILS,
  ROUTE_SETTINGS_DOMAIN,
  ROUTE_SETTINGS_DOMAIN_EDIT,
  ROUTE_SETTINGS_DOMAIN_TYPE,
  ROUTE_SETTINGS_DOMAIN_TYPE_EDIT,
  ROUTE_EXPERIENCE,
  ROUTE_EXPERIENCE_EDIT,
  ROUTE_SETTINGS_CAMPAIGN,
  ROUTE_SETTINGS_CAMPAIGN_EDIT,
  ROUTE_SETTINGS_USER,
  ROUTE_SETTINGS_USER_EDIT,
  ROUTE_CAMPAIGN_CAPTURES, ROUTE_CAMPAIGN_REPLIES, ROUTE_CAMPAIGN_APPRAISAL,
  ROUTE_SETTINGS_PROFILE,
  ROUTE_SETTINGS_PROFILE_EDIT

} from "../../helpers/route_helper"

export const Breadcrumbs = {
  CAMPAIGN: [
    {
      "link": ROUTE_CAMPAIGN,
      "title": "Campaign",
      "short_title": "Campaign",
      "active": true
    }
  ],
  CAMPAIGN_DETAILS: [
    {
      "link": ROUTE_CAMPAIGN,
      "title": "Campaign",
      "short_title": "Campaign",
      "active": false
    },
    {
      "link": ROUTE_CAMPAIGN_DETAILS,
      "title": "Détails campagne",
      "short_title": "Saisie",
      "active": true
    }
  ],
  CAMPAIGN_CAPTURES: [
    {
      "link": ROUTE_CAMPAIGN,
      "title": "Campaign",
      "short_title": "Campaign",
      "active": false
    },
    {
      "link": ROUTE_CAMPAIGN_CAPTURES,
      "title": "Entering experiences",
      "short_title": "Saisie",
      "active": true
    }
  ],
  CAMPAIGN_REPLIES: [
    {
      "link": ROUTE_CAMPAIGN,
      "title": "Campaign",
      "short_title": "Campaign",
      "active": false
    },
    {
      "link": ROUTE_CAMPAIGN_REPLIES,
      "title": "Experience replies",
      "short_title": "Replies",
      "active": true
    }
  ],
  CAMPAIGN_APPRAISAL: [
    {
      "link": ROUTE_CAMPAIGN,
      "title": "Campaign",
      "short_title": "Campaign",
      "active": false
    },
    {
      "link": ROUTE_CAMPAIGN_APPRAISAL,
      "title": "Appraisal",
      "short_title": "Appraisal",
      "active": true
    }
  ],
  EXPERIENCE: [
    {
      "link": "#",//ROUTE_EXPERIENCE,
      "title": "Experience",
      "short_title": "Experience",
      "active": true
    }
  ],
  EXPERIENCE_EDIT: [
    {
      "link": "#",//ROUTE_EXPERIENCE_EDIT,
      "title": "Experience",
      "short_title": "Experience",
      "active": false
    },
    {
      "link": "#",//ROUTE_EXPERIENCE_EDIT,
      "title": "Saisie d'expériences",
      "short_title": "Saisie",
      "active": true
    }
  ],
  DOMAIN: [
    {
      "link": ROUTE_SETTINGS_DOMAIN,
      "title": "Domains",
      "short_title": "Domains",
      "active": true
    }
  ],
  DOMAIN_EDIT: [
    {
      "link": ROUTE_SETTINGS_DOMAIN,
      "title": "Domains",
      "short_title": "Domains",
      "active": false
    },
    {
      "link": ROUTE_SETTINGS_DOMAIN_EDIT,
      "title": "Domain edit",
      "short_title": "Edit",
      "active": true
    }
  ],
  DOMAIN_TYPE: [
    {
      "link": ROUTE_SETTINGS_DOMAIN_TYPE,
      "title": "Domain types",
      "short_title": "Domain types",
      "active": true
    }
  ],
  DOMAIN_TYPE_EDIT: [
    {
      "link": ROUTE_SETTINGS_DOMAIN_TYPE,
      "title": "Domain types",
      "short_title": "Domain types",
      "active": false
    },
    {
      "link": ROUTE_SETTINGS_DOMAIN_TYPE_EDIT,
      "title": "Edit domain type",
      "short_title": "Edit",
      "active": true
    }
  ],
  SCAMPAIGN: [
    {
      "link": ROUTE_SETTINGS_CAMPAIGN,
      "title": "Campaign",
      "short_title": "Campaign",
      "active": true
    }
  ],
  SCAMPAIGN_EDIT: [
    {
      "link": ROUTE_SETTINGS_CAMPAIGN,
      "title": "Campaign",
      "short_title": "Campaign",
      "active": false
    },
    {
      "link": ROUTE_SETTINGS_CAMPAIGN_EDIT,
      "title": "Edit campaign",
      "short_title": "Edit",
      "active": true
    }
  ],
  USER: [
    {
      "link": ROUTE_SETTINGS_USER,
      "title": "Users",
      "short_title": "Users",
      "active": true
    }
  ],
  USER_EDIT: [
    {
      "link": ROUTE_SETTINGS_USER,
      "title": "Users",
      "short_title": "Users",
      "active": false
    },
    {
      "link": ROUTE_SETTINGS_USER_EDIT,
      "title": "Edit user",
      "short_title": "Edit",
      "active": true
    }
  ],
  PROFILE: [
    {
      "link": ROUTE_SETTINGS_PROFILE,
      "title": "Profiles",
      "short_title": "Profiles",
      "active": true
    }
  ],
  PROFILE_EDIT: [
    {
      "link": ROUTE_SETTINGS_PROFILE,
      "title": "Profiles",
      "short_title": "Profiles",
      "active": false
    },
    {
      "link": ROUTE_SETTINGS_PROFILE_EDIT,
      "title": "Edit profile",
      "short_title": "Edit",
      "active": true
    }
  ],
}
