import { Trans } from "react-i18next"
import React from "react"
import picto from "../../assets/images/picto.png"

const transFormatter = (column, colIndex, components) => {
  return (<Trans>{column.text}</Trans>)
}

const managerFormatter = (column, colIndex, components) => {
  return (
    <span>{`${column.firstname} ${column.lastname}`}</span>
  )
}

const datasColumns = [
  {
    text: "id",
    dataField: "id",
    sort: true,
    hidden: true,
    headerFormatter: transFormatter

  },
  {
    text: "Domain",
    dataField: "name",
    sort: true,
    headerFormatter: transFormatter

  },
  {
    text: "Domain type",
    dataField: "domainType.name",
    sort: true,
    headerFormatter: transFormatter

  },
  {
    text: "Manager",
    dataField: "manager",
    sort: true,
    headerFormatter: transFormatter,
    formatter: managerFormatter

  }
]

export default datasColumns
