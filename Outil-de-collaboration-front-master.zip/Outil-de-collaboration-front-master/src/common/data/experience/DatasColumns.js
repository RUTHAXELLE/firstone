import { Trans } from "react-i18next"

const transFormatter = (column, colIndex, components) => {
    return (<Trans>{column.text}</Trans>)
}

const datasColumns = [
    {
        text: "id",
        dataField: "id",
        sort: true,
        hidden: true,
        headerFormatter: transFormatter

    },
    {
        text: "Statut",
        dataField: "statut",
        sort: true,
        headerFormatter: transFormatter

    },
    {
        text: "Campgane",
        dataField: "status",
        sort: true,
        headerFormatter: transFormatter

    },
    {
        text: "Entité",
        dataField: "entite",
        sort: true,
        headerFormatter: transFormatter

    }
]

export default datasColumns
