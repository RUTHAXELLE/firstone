const datas = [
  {
    "id": 1,
    "firstname": "Lacina",
    "lastname": "TRAORE",
    "registration": "9492",
    "password": "1234",
    "email": "lacina.traore@socgen.com",
    "entityId": 1,
    "entity": { "id": 1, "name": "GS", "type": 1, "manager": "DOAHI Potey", "created_at": "24/1/2021" },
    "profileId": 1,
    "profile":  {"id": 1, "title": "Administrateur", "created_at": "24/1/2021" },
    "created_at": "24/1/2021"
  },
  {
    "id": 2,
    "firstname": "John",
    "lastname": "DOE",
    "registration": "9491",
    "password": "4321",
    "email": "john.doe@socgen.com",
    "entityId": 2,
    "entity": { "id": 2, "name": "DIFA", "type": 1, "manager": "JOHN Doe", "created_at": "24/9/2020" },
    "profileId": 2,
    "profile":  { "id": 2, "title": "Support", "created_at": "24/4/2021" },
    "created_at": "24/1/2021"
  }
]

export default datas