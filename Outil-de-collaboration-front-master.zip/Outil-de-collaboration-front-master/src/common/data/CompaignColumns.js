import { Trans } from "react-i18next"
import React from "react"
import moment from "moment"
import { Badge } from "reactstrap"

const transFormatter = (column, colIndex, components) => {
  return (<Trans>{column.text}</Trans>)
}

const dateFormatter = (cell, row, rowIndex, formatExtraData) => {
  return (<span>{moment(cell).format("DD/MM/YYYY")}</span>)
}

const statusFormatter = (column, colIndex, components) => {
  if (column === true) {
    return (
      <Badge
        className="font-size-12 badge-soft-success"
        color="success"
        pill
      >
        <Trans>
          In progress
        </Trans>
      </Badge>
    )
  } else {
    return (
      <Badge
        className="font-size-12 badge-soft-warning"
        color="warning"
        pill
      >
        <Trans>
          Expired
        </Trans>
      </Badge>
    )
  }
}

const datasColumns = [
  {
    text: "id",
    dataField: "id",
    sort: true,
    hidden: true,
    headerFormatter: transFormatter

  },
  {
    text: "Name",
    dataField: "name",
    sort: true,
    headerFormatter: transFormatter

  },
  {
    text: "Start",
    dataField: "startAt",
    sort: true,
    headerFormatter: transFormatter,
    formatter: dateFormatter
  },
  {
    text: "End",
    dataField: "endAt",
    sort: true,
    headerFormatter: transFormatter,
    formatter: dateFormatter
  },
  {
    text: "Status",
    dataField: "status",
    sort: true,
    headerFormatter: transFormatter,
    formatter: statusFormatter
  }
]

export default datasColumns
