const datas = [
  { "id": "", "name": "Sélectionner un domaine ou support fonctionnel ...", "type": 1, "manager": "DOAHI Potey", "created_at": "24/1/2021" },
  { "id": 1, "name": "GS", "type": 1, "manager": "DOAHI Potey", "created_at": "24/1/2021" },
  { "id": 2, "name": "DIFA", "type": 1, "manager": "JOHN Doe", "created_at": "24/9/2020" },
  { "id": 3, "name": "SIC", "type": 1, "manager": "JOHN Doe", "created_at": "24/9/2020" },
  { "id": 4, "name": "CBS", "type": 1, "manager": "JOHN Doe", "created_at": "24/9/2020" },
  { "id": 5, "name": "PAI", "type": 1, "manager": "JOHN Doe", "created_at": "24/9/2020" }
]

export default datas