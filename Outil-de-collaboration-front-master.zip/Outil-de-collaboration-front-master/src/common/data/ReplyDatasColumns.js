import { Trans } from "react-i18next"
import picto from "../../assets/images/picto.png"
import React from "react"
import { Badge } from "reactstrap"

const transFormatter = (column, colIndex, components) => {
  return (<Trans>{column.text}</Trans>)
}

const typeFormatter = (column, colIndex, components) => {
  const bg = (column === 1) ? "#c4f8b8" : "#f5edc1"
  return (
    <span style={{ padding: "5px", textAlign: "center", backgroundColor: bg }}>
      <img src={picto} alt="" style={{ width: "20px" }}/>
    </span>
  )
}

const replyFormatter = (column, colIndex, components) => {
  console.log(column)
  if (column.length > 0) {
    const reply = column[0]
    const text = (reply.status === 0) ? "Brouillon" : "Saisi"
    const color = (reply.status === 0) ? "warning" : "success"
    return (
      <Badge
        className={"font-size-12 badge-soft-" + color}
        color={color}
        pill
      >
        <Trans>
          {text}
        </Trans>
      </Badge>
    )
  } else {
    return (
      <Badge
        className="font-size-12 badge-soft-danger"
        color="danger"
        pill
      >
        <Trans>
          Non saisi
        </Trans>
      </Badge>
    )
  }
}

const datasColumns = [
  {
    text: "id",
    dataField: "id",
    sort: true,
    hidden: true,
    headerFormatter: transFormatter

  },
  {
    text: " ",
    dataField: "type",
    sort: true,
    headerFormatter: transFormatter,
    formatter: typeFormatter
  },
  {
    text: "Domaine",
    dataField: "issuingDomain.name",
    sort: true,
    headerFormatter: transFormatter

  },
  {
    text: "Titre",
    dataField: "shortDescription",
    sort: true,
    headerFormatter: transFormatter

  },
  {
    text: "Réponse",
    dataField: "replies",
    sort: true,
    headerFormatter: transFormatter,
    formatter: replyFormatter

  }
]

export default datasColumns
