import React from "react"
import { Redirect } from "react-router-dom"
// User profile
import UserProfile from "../pages/Authentication/UserProfile"
// Authentication related pages
import Login from "../pages/Authentication/Login"
import Logout from "../pages/Authentication/Logout"
import ForgetPwd from "../pages/Authentication/ForgetPassword"
//Pages
import Pages404 from "../pages/Utility/pages-404"
import Pages500 from "../pages/Utility/pages-500"
import {
  ROUTE_CAMPAIGN, ROUTE_CAMPAIGN_APPRAISAL, ROUTE_CAMPAIGN_CAPTURES,
  ROUTE_CAMPAIGN_DETAILS,
  ROUTE_CAMPAIGN_DETAILS_REPLY, ROUTE_CAMPAIGN_REPLIES, ROUTE_CAMPAIGN_REPLY,
  ROUTE_DASHBOARD,
  ROUTE_FORGET_PASSWORD,
  ROUTE_LOGIN,
  ROUTE_LOGOUT,
  ROUTE_SETTINGS_CAMPAIGN,
  ROUTE_SETTINGS_CAMPAIGN_EDIT,
  ROUTE_SETTINGS_DOMAIN,
  ROUTE_SETTINGS_DOMAIN_EDIT,
  ROUTE_SETTINGS_DOMAIN_TYPE,
  ROUTE_SETTINGS_DOMAIN_TYPE_EDIT, ROUTE_SETTINGS_USER, ROUTE_SETTINGS_USER_EDIT,
  ROUTE_SETTINGS_PROFILE,
  ROUTE_SETTINGS_PROFILE_EDIT
} from "../helpers/route_helper"
import Campaign from "../pages/Campaign"
import CampaignDetail from "../pages/Campaign/Edit"
import Reply from "../pages/Campaign/Edit/Reply/Reply"
import Domain from "../pages/Settings/Domain"
import DomainType from "../pages/Settings/Domain-type"
import DomainTypeEdit from "../pages/Settings/Domain-type/DomainTypeEdit"
import DomainEdit from "../pages/Settings/Domain/DomainEdit"
import SCompaign from "../pages/Settings/Compaign"
import SCompaignEdit from "../pages/Settings/Compaign/SCompaignEdit"
import User from "../pages/Settings/User"
import UserEdit from "../pages/Settings/User/UserEdit"
import CapturePage from "../pages/Campaign/Edit/Capture/Page"
import ReplyPage from "../pages/Campaign/Edit/Reply/Page"
import RepliesPage from "../pages/Campaign/Edit/Replies/Page"
import AppraisalPage from "../pages/Campaign/Edit/Balance-Sheet/Page"
import Dashboard from "../pages/Dashboard"
import Profile from "../pages/Settings/Profile"
import ProfileEdit from "../pages/Settings/Profile/ProfileEdit"
import { PERMISSION_PROFILE, PERMISSION_PROFILE_CREATE } from "helpers/permission_helper"

const authProtectedRoutes = [
  { path: ROUTE_DASHBOARD, component: Dashboard },

  { path: ROUTE_CAMPAIGN, component: Campaign},
  { path: ROUTE_CAMPAIGN_DETAILS, component: CampaignDetail },
  { path: ROUTE_CAMPAIGN_CAPTURES, component: CapturePage },
  { path: ROUTE_CAMPAIGN_REPLY, component: ReplyPage },
  { path: ROUTE_CAMPAIGN_REPLIES, component: RepliesPage },
  { path: ROUTE_CAMPAIGN_DETAILS_REPLY, component: Reply },
  { path: ROUTE_CAMPAIGN_APPRAISAL, component: AppraisalPage },
  { path: ROUTE_SETTINGS_DOMAIN, component: Domain, role: "Administrateur" },
  { path: ROUTE_SETTINGS_DOMAIN_EDIT, component: DomainEdit, role: "Administrateur" },
  { path: ROUTE_SETTINGS_DOMAIN_TYPE, component: DomainType, role: "Administrateur" },
  { path: ROUTE_SETTINGS_DOMAIN_TYPE_EDIT, component: DomainTypeEdit, role: "Administrateur" },
  { path: ROUTE_SETTINGS_CAMPAIGN, component: SCompaign, role: "Administrateur" },
  { path: ROUTE_SETTINGS_CAMPAIGN_EDIT, component: SCompaignEdit, role: "Administrateur" },
  { path: ROUTE_SETTINGS_USER, component: User, role: "Administrateur" },
  { path: ROUTE_SETTINGS_USER_EDIT, component: UserEdit, role: "Administrateur" },
  { path: ROUTE_SETTINGS_PROFILE, component: Profile, role: PERMISSION_PROFILE },
  { path: ROUTE_SETTINGS_PROFILE_EDIT, component: ProfileEdit, role: PERMISSION_PROFILE_CREATE },


  //profile
  { path: "/profile", component: UserProfile },

  // this route should be at the end of all other routes
  { path: "/", exact: true, component: () => <Redirect to={ROUTE_DASHBOARD} /> },
]

const publicRoutes = [
  { path: ROUTE_LOGOUT, component: Logout },
  { path: ROUTE_LOGIN, component: Login },
  { path: ROUTE_FORGET_PASSWORD, component: ForgetPwd },
  /*{ path: "/register", component: Register },*/

  { path: "/pages-404", component: Pages404 },
  { path: "/pages-500", component: Pages500 },
]

export { authProtectedRoutes, publicRoutes }
