import React from "react"
import PropTypes from "prop-types"
import { Redirect, Route } from "react-router-dom"
import { ROUTE_LOGIN } from "../helpers/route_helper"
import { STORAGE_TOKEN } from "../helpers/localStorage_helper"
import { isGranted } from "../helpers/jwt_helpers"

const AppRoute = ({
                    component: Component,
                    layout: Layout,
                    isAuthProtected,
                    role,
                    ...rest
                  }) => (
  <Route
    {...rest}
    render={props => {
      if (isAuthProtected && !localStorage.getItem(STORAGE_TOKEN)) {
        return (
          <Redirect
            to={{ pathname: ROUTE_LOGIN, state: { from: props.location } }}
          />
        )
      }

      if (role && !isGranted(role)) {
        return (
          <Redirect
            to={{ pathname: "/pages-500", state: { from: props.location } }}
          />
        )
      }

      return (
        <Layout>
          <Component {...props} />
        </Layout>
      )
    }}
  />
)

AppRoute.propTypes = {
  isAuthProtected: PropTypes.bool,
  component: PropTypes.any,
  location: PropTypes.object,
  layout: PropTypes.any
}

export default AppRoute
