import React from "react"
import PropTypes from "prop-types"
import { Navigate } from "react-router-dom"
import { ROUTE_LOGIN } from "../helpers/route_helper"
import ErrorBoundary from "components/Common/ErrorBoundary"
import { connect } from "react-redux"
import Granted from "components/Common/Granted"
import { withRouter } from "common/hoc/withRouter"

const AppRoute = ({
  component: Component,
  layout: Layout,
  isAuthProtected,
  role,
  ...props
}) => {
  if (isAuthProtected && !props.user) {
    return (
      <Navigate
        to={ROUTE_LOGIN}
        replace={true}
        state={ {from: props.location} }
      />
    )
  }

  return (
    <Granted
      permission={role}
      errorComponent={
        <Navigate
          to="/pages-403"
          replace={true}
          state={{ from: props.location }}
        />
      }
    >
      <Layout>
        <ErrorBoundary>
          <Component {...props} />
        </ErrorBoundary>
      </Layout>
    </Granted>
  )
}

AppRoute.propTypes = {
  isAuthProtected: PropTypes.bool,
  component: PropTypes.any,
  location: PropTypes.object,
  layout: PropTypes.any
}

const mapStateToProps = (state) => {
  return {
    user: state.user.data
  }
}

export default withRouter(connect(mapStateToProps)(AppRoute));
