import { createProfile, deleteProfile, editProfile, getAllProfiles, getFeatures, searchProfiles } from "helpers/backend_helper";
import { useRequest } from "./useHttp";

const sortFields = {
    
}

export const useAllProfiles = (paginate = true) => {
    const {call, response, loading, error} = useRequest([], {
        hasCount: paginate
    });

    const get = (index, size, criteria) => {
        if (criteria) {
            if (criteria?.orderField) {
                criteria.orderField = sortFields[criteria?.orderField] ?? criteria?.orderField;
            }

            if (criteria?.searchField) {
                const field = criteria?.searchField;
                const value = criteria?.searchValue;
                delete criteria?.searchField;
                delete criteria?.searchValue;
                criteria[field] = value;
            }

            return call(searchProfiles(criteria, {index, size}));
        }
        return call(getAllProfiles({index, size}));
    }

    return {get, response, loading, error};
}

export const useGetProfileFeatures = (paginate = false) => {
    const {call, response, loading, error} = useRequest([], {
        hasCount: paginate
    });

    const get = (criteria, index, size) => {
        return call(getFeatures(criteria, {index, size}));
    }

    return {get, response, loading, error};
}

export const useCreateProfile = () => {
    const {call, response, loading, error} = useRequest();

    const create = (data) => {
        return call(createProfile(data));
    }

    return {create, response, loading, error};
}

export const useSearchProfile = () => {
    const {call, response, loading, error} = useRequest([]);

    const search = (criteria) => {
        return call(searchProfiles(criteria));
    }

    return {search, response: response ? response[0] : null, loading, error};
}

export const useEditProfile = () => {
    const {call, response, loading, error} = useRequest();

    const edit = (data) => {
        return call(editProfile(data));
    }

    return {edit, response, loading, error};
}

export const useDeleteProfile = () => {
    const {call, response, loading, error} = useRequest();

    const del = (data) => {
        return call(deleteProfile(data));
    }

    return {del, response, loading, error};
}