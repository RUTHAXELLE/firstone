import { request_Incoherent, request_InProgress, request_Invalid, request_Valid } from "common/data/requestStatus";
import { createRequest, deleteRequest, editRequest, getAllRequests, getInvalidRequests, getValidRequests, makeControl, searchRequests, validateRequests } from "helpers/backend_helper";
import { useUserVisibility } from "./useCurrentUser";
import { useRequest } from "./useHttp";

const sortFields = {
}

export const useAllRequests = (paginate = true) => {
    const {call, response, loading, error} = useRequest([], {
        hasCount: paginate
    });

    const visibility = useUserVisibility();

    const get = (index, size, criteria = {}) => {
        //return call(getAllRequests({index, size}));
        if (criteria?.orderField) {
            criteria.orderField = sortFields[criteria?.orderField] ?? criteria?.orderField;
        }

        if (criteria?.searchField) {
            const field = criteria?.searchField;
            const value = criteria?.searchValue;
            delete criteria?.searchField;
            delete criteria?.searchValue;
            criteria[field] = value;
            
        }
        return call(searchRequests({
            ...criteria,
            ...visibility,
            statusId: request_InProgress,
        }, {index, size}));
    }

    return {get, response, loading, error};
}

export const useUnValidatedRequest = (paginate = true) => {
    const {call, response, loading, error} = useRequest([], {
        hasCount: paginate
    });

    const get = (index, size) => {
        return call(searchRequests({
            statusId: 5,
            statusIdParam: {
                operator: "<>"
            }
        }, {index, size}));
    }

    return { get, response, loading, error };
}


export const useValidRequests = (paginate = true) => {
    const {call, response, loading, error} = useRequest([], {
        hasCount: paginate
    });
    const visibility = useUserVisibility();

    const get = (index, size, criteria = {}) => {
        //return call(getValidRequests({index, size}));
        if (criteria?.orderField) {
            criteria.orderField = sortFields[criteria?.orderField] ?? criteria?.orderField;
        }

        if (criteria?.searchField) {
            const field = criteria?.searchField;
            const value = criteria?.searchValue;
            delete criteria?.searchField;
            delete criteria?.searchValue;
            criteria[field] = value;
            
        }
        return call(searchRequests({
            ...criteria,
            ...visibility,
            statusId: request_Valid,
        }, {index, size}));
    }

    return {get, response, loading, error};
}

export const useInvalidRequests = (paginate = true) => {
    const {call, response, loading, error} = useRequest([], {
        hasCount: paginate
    });
    const visibility = useUserVisibility();

    const get = (index, size, criteria = {}) => {
        //return call(getInvalidRequests({index, size}));
        if (criteria?.orderField) {
            criteria.orderField = sortFields[criteria?.orderField] ?? criteria?.orderField;
        }

        if (criteria?.searchField) {
            const field = criteria?.searchField;
            const value = criteria?.searchValue;
            delete criteria?.searchField;
            delete criteria?.searchValue;
            criteria[field] = value;
            
        }
        return call(searchRequests({
            ...criteria,
            ...visibility,
            statusId: request_Invalid,
        }, {index, size}));
    }

    return {get, response, loading, error};
}

export const useIncoherentRequests = (paginate = true) => {
    const {call, response, loading, error} = useRequest([], {
        hasCount: paginate
    });
    const visibility = useUserVisibility();

    const get = (index, size, criteria = {}) => {
        //return call(getInvalidRequests({index, size}));
        if (criteria?.orderField) {
            criteria.orderField = sortFields[criteria?.orderField] ?? criteria?.orderField;
        }

        if (criteria?.searchField) {
            const field = criteria?.searchField;
            const value = criteria?.searchValue;
            delete criteria?.searchField;
            delete criteria?.searchValue;
            criteria[field] = value;
            
        }
        return call(searchRequests({
            ...criteria,
            ...visibility,
            statusId: request_Incoherent,
        }, {index, size}));
    }

    return {get, response, loading, error};
}

export const useCreateRequest = () => {
    const {call, response, loading, error} = useRequest();

    const create = (data) => {
        const plafond = data?.plafond;

        if (plafond == 1)
            data["isPlafondHaut"] = true;
        else
            data["isPlafondHaut"] = false;

        if (plafond == 2)
            data["isPlafondMoyen"] = true;
        else
            data["isPlafondMoyen"] = false;

        if (plafond == 3)
            data["isPlafondBas"] = true;
        else
            data["isPlafondBas"] = false;

        delete data?.plafond;

        return call(createRequest({
            ...data,
            matricule: "0000"
        }));
    }

    return {create, response, loading, error};
}

export const useSearchRequest = () => {
    const {call, response, loading, error} = useRequest([], {
        mustExist: true
    });

    const search = (criteria) => {
        return call(searchRequests(criteria));
    }

    return {search, response: response ? response[0] : null, loading, error};
}

export const useEditRequest = () => {
    const {call, response, loading, error} = useRequest();

    const edit = (data) => {
        return call(editRequest(data));
    }

    return {edit, response, loading, error};
}

export const useDeleteRequest = () => {
    const {call, response, loading, error} = useRequest();

    const del = (data) => {
        return call(deleteRequest(data));
    }

    return {del, response, loading, error};
}

export const useValidateRequest = () => {
    const {call, response, loading, error} = useRequest();

    const validate = (data) => {
        return call(validateRequests(data));
    }

    return {validate, response, loading, error};
}

export const useMakeControl = () => {
    const {call, response, loading, error} = useRequest();

    const control = () => {
        return call(makeControl());
    }

    return {control, response, loading, error};
}