import { changeUserPassword, createUser, editUser, getAllUsers, postLogin, searchUsers } from "helpers/backend_helper";
import { useRequest } from "./useHttp";

const sortFields = {
    agenceAddress: "agence.address",
    login: "login",
    nomPrenoms: "nom",
    roleLibelle: "role.libelle",
    createdAt: "createdAt"
}


export const useAllUsers = (paginate = true) => {
    const {call, response, loading, error} = useRequest([], {
        hasCount: paginate
    });

    const get = (index, size, criteria) => {
        if (criteria) {
            if (criteria?.orderField) {
                criteria.orderField = sortFields[criteria?.orderField] ?? criteria?.orderField;
            }

            if (criteria?.searchField) {
                const field = criteria?.searchField;
                const value = criteria?.searchValue;
                delete criteria?.searchField;
                delete criteria?.searchValue;
                criteria[field] = value;
                
            }
            return call(searchUsers(criteria, {index, size}));
        }
        return call(getAllUsers({index, size}));
    }

    return {get, response, loading, error};
}

export const useCreateUser = () => {
    const {call, response, loading, error} = useRequest();

    const create = (data) => {
        return call(createUser(data));
    }

    return {create, response, loading, error};
}

export const useSearchUser = () => {
    const {call, response, loading, error} = useRequest([]);

    const search = (criteria) => {
        return call(searchUsers(criteria));
    }

    return {search, response: response ? response[0] : null, loading, error};
}

export const useEditUser = () => {
    const {call, response, loading, error} = useRequest();

    const edit = (data) => {
        return call(editUser(data));
    }

    return {edit, response, loading, error};
}

export const useLogin = () => {
    const {call, response, loading, error} = useRequest();

    const login = (data) => {
        return call(postLogin(data));
    }

    return {login, response, loading, error};
}

export const useChangePassword = () => {
    const {call, response, loading, error} = useRequest();

    const change = (data) => {
        return call(changeUserPassword(data));
    }

    return {change, response, loading, error};
}