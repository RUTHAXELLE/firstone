import { createAgence, deleteAgence, editAgence, getAllAgences, searchAgences } from "helpers/backend_helper";
import { useEffect } from "react";
import { useRequest } from "./useHttp";


export const useAllAgences = (paginate = true) => {
    const {call, response, loading, error} = useRequest([], {
        hasCount: paginate
    });

    const get = (index, size) => {
        return call(getAllAgences({index, size}));
    }

    return {get, response, loading, error};
}

export const useCreateAgence = () => {
    const {call, response, loading, error} = useRequest();

    const create = (data) => {
        return call(createAgence(data));
    }

    return {create, response, loading, error};
}

export const useSearchAgence = () => {
    const {call, response, loading, error} = useRequest([]);

    const search = (criteria) => {
        return call(searchAgences(criteria));
    }

    return {search, response: response ? response[0] : null, loading, error};
}

export const useEditAgence = () => {
    const {call, response, loading, error} = useRequest();

    const edit = (data) => {
        return call(editAgence(data));
    }

    return {edit, response, loading, error};
}

export const useDeleteAgence = () => {
    const searchQuery = useSearchAgence();
    const {call, response, loading, error} = useRequest();

    const del = (data) => {
        searchQuery.search(data);
    }

    useEffect(() => {
        if (searchQuery.response) {
            call(deleteAgence(searchQuery.response));
        }
    }, [searchQuery.response]);

    return {del, response, loading: loading || searchQuery.loading, error: error ?? searchQuery.error};
}