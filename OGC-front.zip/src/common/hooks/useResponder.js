import { INVALID_TOKEN_ERROR } from "helpers/api_helper";
import { useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useDispatch } from "react-redux";
import { logout } from "store/auth/user/userReducer";
import toastr from "toastr"

// Send notification when a response or an error got
const useResponder = ({
    response, error, successMessage, errorMessage, successAction = () => { }, errorAction = () => { }
}) => {
    const dispatch = useDispatch();
    const {t} = useTranslation();

    useEffect(() => {
        if (error) {
            if (error === INVALID_TOKEN_ERROR) {
                dispatch(logout());
                errorResponse(t("Your session has expired"));
            } else {
                if (errorMessage)
                    errorResponse(
                        errorMessage?.message ? errorMessage?.message : errorMessage
                    )
                errorAction();
            }
        }
    }, [error])

    useEffect(() => {
        if (response) {
            if (successMessage)
                successResponse(successMessage);
            successAction();
        }
    }, [response]);

    return { response, error, successMessage, errorMessage };
}

export const errorResponse = (message) => {
    toastr.error(
        message
    )
}

export const successResponse = (message) => {
    toastr.success(message);
}

export default useResponder;