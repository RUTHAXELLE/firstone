import { isEmpty } from "lodash";
import { useState } from "react"
import useLoading from "./useLoading";

// Extract the mainful information from response depending to options
const responseFormatter = (response, options = {
    hasCount: false,
    mustExist: false
}) => {
    let data = null;
    if (response.items)
        data = response.items;
    else if (response.item)
        data = response.item;
    else {
        data = []
    }

    if (options?.mustExist && isEmpty(data))
        throw "Response is empty"

    if (options?.hasCount)
        data = {
            count: response.count,
            items: data
        }

    return data;
}

export const useRequest = (initialValue, options = {
    hasCount: false,
    mustExist: false
}) => {
    const [error, setError] = useState(null);
    const [loading, toggleLoader] = useLoading();
    const [response, setResponse] = useState(initialValue ?? null);

    const call = (request) => {
        toggleLoader(true);
        setError(null);
        return request?.then((response) => {
            // Format the response
            const data = responseFormatter(response, options)
            setResponse(data)

        }).catch((err) => {
            setError(err);
            //setResponse(initialValue ?? null);
        }).finally(() => {
            toggleLoader(false);
        });
    }

    return {call, response, loading, error};
}