import { SYS_ADMIN_LOGIN } from "config";
import { isGranted, PERMISSION_REQUEST_CHECK, PERMISSION_USER_CREATE } from "helpers/permission_helper";
import { useSelector } from "react-redux";


const useCurrentUser = () => {
    const user = useSelector((state) => state.user);

    return user;
}


export const useUserVisibility = () => {
    const visibility = useSelector((state) => state.user.visibility);

    return visibility;
}

export default useCurrentUser;