import { request_InProgress } from "common/data/requestStatus";
import { cancelCard, deleteMaintenance, editPricing, getCustomMaintenances, getMaintenances, searchCard, updateAccount } from "helpers/backend_helper";
import { useUserVisibility } from "./useCurrentUser";
import { useRequest } from "./useHttp"

const sortFields = {
    fullname: "noms",
    codeTypeOperation: "typeOperation.code",
    numberCard: "carte.code"
}

const searchField = {
    fullname: "noms",
}

export const useAllMaintenanceRequest = (paginate = true) => {
    const {call, response, loading, error} = useRequest([], {
        hasCount: paginate
    });
    const visibility = useUserVisibility();

    const get = (index, size, criteria) => {
        if (criteria) {
            if (criteria?.orderField) {
                criteria.orderField = sortFields[criteria?.orderField] ?? criteria?.orderField;
            }

            if (criteria?.searchField) {
                const field = searchField[criteria?.searchField] ?? criteria?.searchField;
                const value = criteria?.searchValue;
                delete criteria?.searchField;
                delete criteria?.searchValue;
                criteria[field] = value;
            }
        }
        return call(getCustomMaintenances({
            ...criteria,
            ...visibility,
            statusId: request_InProgress
        }, {index, size}));
    }

    return {get, response, loading, error};
}

export const useGetMaintenances = (paginate = true) => {
    const {call, response, loading, error} = useRequest([], {
        hasCount: paginate
    });

    const get = (criteria, index, size) => {
        return call(getCustomMaintenances({
            ...criteria
        }, {index, size}))
    }

    return {get, response, loading, error}
}

export const useSearchCard = (paginate = true) => {
    const {call, response, loading, error} = useRequest(null, {
        mustExist: true,
        hasCount: paginate
    });

    const search = (criteria, index, size) => {
        if (criteria?.orderField) {
            criteria.orderField = sortFields[criteria?.orderField] ?? criteria?.orderField;
        }

        if (criteria?.searchField) {
            const field = searchField[criteria?.searchField] ?? criteria?.searchField;
            const value = criteria?.searchValue;
            delete criteria?.searchField;
            delete criteria?.searchValue;
            criteria[field] = value;
        }
        return call(searchCard(criteria, {index, size}))
    }

    return {search, response: response, loading, error}
}

export const useCancelCard = () => {
    const {call, response, loading, error} = useRequest()

    const cancel = (criteria) => {
        return call(cancelCard(criteria))
    }

    return {cancel, response, loading, error};
}

export const useEditPricing = () => {
    const {call, response, loading, error} = useRequest();

    const edit = (criteria) => {
        return call(editPricing(criteria))
    }

    return {edit, response, loading, error}
}

export const useEditAccount = () => {
    const {call, response, loading, error} = useRequest();

    const edit = (data) => {
        return call(updateAccount(data))
    }

    return {edit, response, loading, error}
}

export const useDeleteOperation = () => {
    const {call, response, loading, error} = useRequest();

    const del = (criteria) => {
        return call(deleteMaintenance(criteria))
    }

    return {del, response, loading, error}
}