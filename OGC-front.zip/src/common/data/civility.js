
const civility = [
    {
        value: "M",
        label: "form.civility_sir"
    },
    {
        value: "Mme",
        label: "form.civility_madame"
    },
    {
        value: "Mlle",
        label: "form.civility_miss"
    }
]

export default civility;