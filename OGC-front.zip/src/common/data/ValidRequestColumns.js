import { camelCaseFormatter, columnClasses, fullnameFormatter, surnameFormatter, transFormatter } from "./Formatter"

const datasColumns = [
  {
    text: "form.registration_number",
    dataField: "id",
    sort: true,
    hidden: true,
    headerFormatter: transFormatter
  },
  {
    text: "form.account",
    dataField: "numeroCompte",
    classes: columnClasses,
    title: true,
    sort: true,
    headerFormatter: transFormatter,
    searchable: true
  },
  {
    text: "form.agence",
    dataField: "agence",
    classes: columnClasses,
    title: true,
    sort: true,
    formatter: camelCaseFormatter,
    headerFormatter: transFormatter,
    searchable: true
  },
  {
    text: "Cardholder Surname",
    dataField: "noms",
    sort: true,
    classes: columnClasses,
    headerFormatter: transFormatter,
    formatter: surnameFormatter
  },
  {
    text: "Cardholder Firstname",
    dataField: "prenom",
    sort: true,
    classes: columnClasses,
    headerFormatter: transFormatter,
  },
  {
    text: "form.product",
    dataField: "produit",
    classes: columnClasses,
    title: true,
    sort: true,
    headerFormatter: transFormatter,
    searchable: true
  },
  {
    text: "form.phone",
    dataField: "telephone",
    sort: true,
    classes: columnClasses,
    title: true,
    headerFormatter: transFormatter,
  },
  {
    text: "form.created_at",
    dataField: "createdAt",
    classes: columnClasses,
    title: true,
    sort: true,
    headerFormatter: transFormatter,
  },
  {
    text: "form.created_by",
    classes: columnClasses,
    title: true,
    dataField: "login",
    sort: true,
    headerFormatter: transFormatter,
  },
]

export default datasColumns
