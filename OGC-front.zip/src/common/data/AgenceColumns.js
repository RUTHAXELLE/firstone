import { Trans } from "react-i18next"
import React from "react"

const transFormatter = (column, colIndex, components) => {
  return (<Trans>{column.text}</Trans>)
}

const datasColumns = [
  {
    text: "id",
    dataField: "id",
    sort: true,
    hidden: true,
    headerFormatter: transFormatter

  },
  {
    text: "form.code",
    dataField: "code",
    sort: true,
    headerFormatter: transFormatter

  },
  {
    text: "form.address",
    dataField: "address",
    sort: true,
    headerFormatter: transFormatter

  }
]

export default datasColumns
