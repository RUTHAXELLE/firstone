import { camelCaseFormatter, columnClasses, fullnameFormatter, plafondFormatter, surnameFormatter, transFormatter } from "./Formatter"

const datasColumns = [
  {
    text: "form.registration_number",
    dataField: "id",
    sort: true,
    hidden: true,
    headerFormatter: transFormatter

  },
  {
    text: "Cardholder Surname",
    dataField: "noms",
    sort: true,
    classes: columnClasses,
    headerFormatter: transFormatter,
    formatter: surnameFormatter
  },
  {
    text: "Cardholder Firstname",
    dataField: "prenom",
    sort: true,
    classes: columnClasses,
    headerFormatter: transFormatter,
  },
  {
    text: "form.account",
    dataField: "numeroCompte",
    classes: columnClasses,
    title: true,
    sort: true,
    headerFormatter: transFormatter,
    searchable: true
  },
  {
    text: "form.phone",
    dataField: "telephone",
    classes: columnClasses,
    title: true,
    sort: true,
    headerFormatter: transFormatter,
  },
  {
    text: "form.product",
    dataField: "produit",
    classes: columnClasses,
    title: true,
    sort: true,
    headerFormatter: transFormatter,
    searchable: true
  },
  {
    text: "form.plafond",
    dataField: "plafond",
    sort: true,
    headerFormatter: transFormatter,
    formatter: plafondFormatter
  },
  {
    text: "form.agence",
    dataField: "agence",
    classes: columnClasses,
    title: true,
    formatter: camelCaseFormatter,
    sort: true,
    headerFormatter: transFormatter,
    searchable: true
  },
  {
    text: "form.created_at",
    dataField: "createdAt",
    classes: columnClasses,
    title: true,
    sort: true,
    headerFormatter: transFormatter,
  },
  {
    text: "form.created_by",
    dataField: "login",
    sort: true,
    classes: columnClasses,
    title: true,
    headerFormatter: transFormatter,
  },
  /* {
    text: "form.contrat",
    dataField: "contrat",
    sort: true,
    headerFormatter: transFormatter,
  } */
]

export default datasColumns
