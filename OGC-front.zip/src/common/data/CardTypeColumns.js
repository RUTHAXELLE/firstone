import { columnClasses, transFormatter } from "./Formatter"

const datasColumns = [
  {
    text: "id",
    dataField: "id",
    sort: true,
    hidden: true,
    classes: columnClasses,
    title: true,
    headerFormatter: transFormatter

  },
  /* {
    text: "form.code",
    dataField: "code",
    sort: true,
    headerFormatter: transFormatter

  }, */
  {
    text: "form.type_card",
    dataField: "typeCarte",
    sort: true,
    classes: columnClasses,
    title: true,
    headerFormatter: transFormatter,
    searchable: true
  },
  {
    text: "form.type_gen",
    dataField: "typeGen",
    sort: true,
    classes: columnClasses,
    title: true,
    headerFormatter: transFormatter,
    searchable: true
  },
  /* {
    text: "form.product",
    dataField: "produit",
    sort: true,
    headerFormatter: transFormatter,
  }, */
  {
    text: "form.code_bank",
    dataField: "codeBanque",
    sort: true,
    classes: columnClasses,
    title: true,
    headerFormatter: transFormatter,
  },
  /* {
    text: "form.id_product",
    dataField: "identifiantProduit",
    sort: true,
    headerFormatter: transFormatter,
  }, */
  /* {
    text: "form.id_institution",
    dataField: "identifiantInstitution",
    sort: true,
    headerFormatter: transFormatter,
  }, */
  /* {
    text: "form.id_group",
    dataField: "identifiantGroupe",
    sort: true,
    headerFormatter: transFormatter,
  }, */
  /* {
    text: "form.business",
    dataField: "business",
    sort: true,
    headerFormatter: transFormatter,
  }, */
  {
    text: "form.code_product",
    dataField: "codeProduit",
    sort: true,
    classes: columnClasses,
    title: true,
    headerFormatter: transFormatter,
  },
  {
    text: "form.code_tarif",
    dataField: "codeTarif",
    sort: true,
    classes: columnClasses,
    title: true,
    headerFormatter: transFormatter,
  },
  /* {
    text: "form.devise",
    dataField: "devise",
    sort: true,
    headerFormatter: transFormatter,
  }, */
  /* {
    text: "form.acc_country",
    dataField: "accCountry",
    sort: true,
    headerFormatter: transFormatter,
  }, */
  {
    text: "form.country",
    dataField: "pays",
    sort: true,
    classes: columnClasses,
    title: true,
    headerFormatter: transFormatter,
  },
  {
    text: "form.bin",
    dataField: "bin",
    classes: columnClasses,
    title: true,
    sort: true,
    headerFormatter: transFormatter,
    searchable: true
  },
  {
    text: "form.type",
    dataField: "type",
    sort: true,
    classes: columnClasses,
    title: true,
    headerFormatter: transFormatter,
  }
]

export default datasColumns
