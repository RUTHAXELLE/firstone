import { camelCaseFormatter, columnClasses, fullnameUserFormatter, statusFormatter, transFormatter } from "./Formatter"
import { textFilter } from 'react-bootstrap-table2-filter';

const datasColumns = [
  {
    text: "id",
    dataField: "id",
    sort: true,
    hidden: true,
    headerFormatter: transFormatter

  },
  {
    text: "form.agence",
    dataField: "agenceAddress",
    sort: true,
    classes: columnClasses,
    formatter: camelCaseFormatter,
    title: true,
    headerFormatter: transFormatter,
    searchable: true
  },
  {
    text: "form.login",
    dataField: "login",
    sort: true,
    classes: columnClasses,
    title: true,
    headerFormatter: transFormatter,
    searchable: true
  },
  {
    text: "form.fullname",
    dataField: "nomPrenoms",
    classes: columnClasses,
    sort: true,
    formatter: fullnameUserFormatter,
    headerFormatter: transFormatter,
  },
  {
    text: "form.profile",
    dataField: "roleLibelle",
    sort: true,
    classes: columnClasses,
    title: true,
    headerFormatter: transFormatter,
    searchable: true
  },
  {
    text: "form.status",
    dataField: "isActif",
    classes: columnClasses,
    sort: true,
    formatter: statusFormatter,
    headerFormatter: transFormatter,
  },
  {
    text: "form.created_at",
    dataField: "createdAt",
    sort: true,
    classes: columnClasses,
    title: true,
    headerFormatter: transFormatter,
  }
]

export default datasColumns
