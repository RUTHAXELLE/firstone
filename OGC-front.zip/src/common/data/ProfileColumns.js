import { columnClasses, transFormatter } from "./Formatter"

const datasColumns = [
  {
    text: "id",
    dataField: "id",
    sort: true,
    hidden: true,
    headerFormatter: transFormatter
  },
  {
    text: "form.code",
    dataField: "code",
    hidden: true,
    sort: true,
    classes: columnClasses,
    title: true,
    headerFormatter: transFormatter

  },
  {
    text: "form.label",
    dataField: "libelle",
    sort: true,
    classes: columnClasses,
    title: true,
    headerFormatter: transFormatter,
    searchable: true

  }
]

export default datasColumns
