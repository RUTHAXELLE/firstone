import { columnClasses, transFormatter } from "./Formatter"


const datasColumns = [
  {
    text: "id",
    dataField: "id",
    sort: true,
    hidden: true,
    headerFormatter: transFormatter,
    classes: columnClasses,
    title: true,
  },
  {
    text: "form.code",
    dataField: "code",
    sort: true,
    headerFormatter: transFormatter,
    classes: columnClasses,
    title: true,
    hidden: true,
  },
  {
    text: "form.label",
    dataField: "libelle",
    sort: true,
    headerFormatter: transFormatter,
    classes: columnClasses,
    title: true,
  }
]

export default datasColumns
