const Plafonds = [
    {
        id: 1,
        name: "Plafond Haut"
    },
    {
        id: 2,
        name: "Plafond Moyen"
    },
    {
        id: 3,
        name: "Plafond Bas"
    }
]

export default Plafonds;