export const STORAGE_TOKEN = "token"
export const MAIL_ADDRESS = "mailaddress"
export const STORAGE_AUTH_USER = "authUser"
export const STORAGE_AUTH_ROLE = "authRole"
export const STORAGE_SHORTCUTS = "shortcuts"
export const OFFER_KEY = "offerKey"
export const getCotation = () => localStorage.getItem(OFFER_KEY)

export const storeData = (name, data) => {
    const token = getToken();
    if (token) {
        if (data) {
            localStorage.setItem(name, JSON.stringify(data));
        }
    }
}

export const restoreData = (name, onUpdate) => {
    const token = getToken();
    let value = null;
    if (token) {
        value = localStorage.getItem(name);
        if (value) {
            value = JSON.parse(value);
        }
    }
    onUpdate(value)
    localStorage.removeItem(name)
}

export const deleteToken = () => {
    sessionStorage.removeItem(STORAGE_TOKEN);
}
export const storeToken = (token) => {
    sessionStorage.setItem(STORAGE_TOKEN, token);
}
export const getToken = () => {
    return sessionStorage.getItem(STORAGE_TOKEN);
}