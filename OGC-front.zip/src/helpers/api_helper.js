import axios from "axios"
import { isArray } from "lodash"
import { getToken } from "./localStorage_helper"

const https = require('https')
const fs = require('fs')
const path = require('path')


export const INVALID_TOKEN_ERROR = "902;Donnee inexistante: Token invalide";

const httpsAgent = new https.Agent({
  rejectUnauthorized: false
  /* cert: certFile,
  key: keyFile */
})

//apply base url for axios
const API_URL = "http://localhost:8080"

const axiosApi = axios.create({
  baseURL: API_URL,
  httpsAgent: httpsAgent,
})

// Rafraichir le token à chaque appel de service
axiosApi.interceptors.request.use(
  config => {
    // Auth token added to all queries
    const token = getToken();
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`
    }
    return config;
  },
  error => {
    Promise.reject(error)
  })

axiosApi.interceptors.response.use(
  response => response,
  error => Promise.reject(error)
)

export async function get(url, criteria, options = {
  format: true,
  index: 0,
  size: 5
}, config = {}) {
  const data = formatData(criteria, {
    format: true,
    ...options,
    array: false
  });
  return axiosApi
    .post(url, data, { ...config })
    .then(response => successProcess(response))
    .catch(err => errorProcess(err))
}

export async function post(url, data, options = {
  format: true,
  array: true
}, config = {}) {
  return axiosApi
    .post(url, formatData(data, { format: true, array: true, ...options }), { ...config })
    .then(response => successProcess(response))
    .catch(err => errorProcess(err))
}

export async function put(url, data, options = {
  format: true
}, config = {}) {
  return axiosApi
    .put(url, formatData(data, { ...options, array: true }), { ...config })
    .then(response => successProcess(response))
    .catch(err => errorProcess(err))
}

export async function del(url, data, options = {
  format: true
}, config = {}) {
  return await axiosApi
    .delete(url, { ...config, data: formatData(data, { ...options, array: true }) })
    .then(response => successProcess(response))
    .catch(err => errorProcess(err))
}

/* export async function upload(data, config = {}) {
  return await axiosApi
    .post(POST_FILES, data,
    {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem(STORAGE_TOKEN)}`,
        'Content-Type' :  `multipart/form-data; boundary=${data._boundary}`
      }
    })
    .then(response => successProcess(response))
    .catch(err => errorProcess(err))
} */

const successProcess = (response) => {
  console.log(response)
  if ((response.status >= 200 || response.status <= 299) && !response.data?.hasError) {
    return response.data;
  }
  throw response.data;
}

const errorProcess = (err) => {
  console.log(err)
  let message
  if (err.response && err.response.status) {
    console.log(err.response)
    switch (err.response.status) {
      case 404:
        message = "Désolé! l'API que vous appelez est introuvable"
        break
      case 500:
        if (err.response.data.message === INVALID_TOKEN_ERROR) {
          message = INVALID_TOKEN_ERROR;
        } else {
          message = "Désolé! un problème est survenu, veuillez contacter notre équipe d'assistance"
        }
        break
      case 401:
        message = err.response.data.message
        break
      default:
        message = err.response.data.message
        break
    }
  }
  if (err.status) {
    console.log(err.status)
    message = err.status
  }
  throw message ?? err
}

const formatData = (data, options = {
  array: true,
  format: true,
  index: 0,
  size: 5
}) => {
  return options.format ? isArray(data) ? {
    datas: data
  } : options.array ? {
    datas: [data]
  } : {
    data: data,
    index: options?.index,
    size: options?.size
  } : data;
}
