import * as PERMISSIONS from "./permission_helper"
import { 
    ROUTE_CARD_TYPE,
    ROUTE_CARD_TYPE_CREATE,
    ROUTE_MAINTENANCE,
    ROUTE_MAINTENANCE_ACCOUNT_EDIT,
    ROUTE_MAINTENANCE_CANCEL_CARD,
    ROUTE_MAINTENANCE_PRICING_EDIT,
    ROUTE_PROCESSING_GENERATE_APBATCH_COMMAND,
    ROUTE_PROCESSING_GENERATE_APBATCH_MAINTENANCE,
    ROUTE_PROCESSING_LAST_INFO,
    ROUTE_PROCESSING_VALIDATE_APBATCH_COMMAND,
    ROUTE_PROCESSING_VALIDATE_APBATCH_MAINTENANCE,
    ROUTE_PROFILE,
    ROUTE_PROFILE_CREATE,
    ROUTE_REQUEST,
    ROUTE_REQUEST_CREATE, 
    ROUTE_REQUEST_STATE, 
    ROUTE_USER, 
    ROUTE_USER_CREATE,
} from "./route_helper"

const Permissions = [
    {
        label: 'Card requests',
        value: PERMISSIONS.PERMISSION_REQUEST,
        children: [
            {
                link: ROUTE_REQUEST,
                icon: "bx bx-search-alt-2",
                label: 'Search',
                value: PERMISSIONS.PERMISSION_REQUEST_LIST
            },
            {
                link: ROUTE_REQUEST_CREATE,
                icon: "bx bx-plus",
                label: 'Create a request',
                value: PERMISSIONS.PERMISSION_REQUEST_CREATE
            },
            {
                link: ROUTE_REQUEST_STATE,
                icon: "bx bx-check-circle",
                label: 'menu.state_request',
                value: PERMISSIONS.PERMISSION_VALID_REQUEST_LIST
            },
        ]
    },
    {
        label: 'Card maintenances',
        value: PERMISSIONS.PERMISSION_MAINTENANCE,
        children: [
            {
                link: ROUTE_MAINTENANCE,
                icon: "bx bx-search-alt-2",
                label: 'Search',
                value: PERMISSIONS.PERMISSION_OPERATION_LIST
            },
            {
                link: ROUTE_MAINTENANCE_CANCEL_CARD,
                icon: "bx bx-x",
                label: 'menu.cancel_card',
                value: PERMISSIONS.PERMISSION_OPERATION_CREATE
            },
            {
                link: ROUTE_MAINTENANCE_PRICING_EDIT,
                icon: "bx bx-money",
                label: 'menu.pricing_edit',
                value: PERMISSIONS.PERMISSION_OPERATION_CREATE
            },
            {
                link: ROUTE_MAINTENANCE_ACCOUNT_EDIT,
                icon: "bx bx-edit",
                label: 'menu.account_update',
                value: PERMISSIONS.PERMISSION_OPERATION_CREATE
            },
        ]
    },
    {
        label: 'Card types',
        value: PERMISSIONS.PERMISSION_CARD_TYPE,
        children: [
            {
                link: ROUTE_CARD_TYPE,
                icon: "bx bx-search-alt-2",
                label: 'Search',
                value: PERMISSIONS.PERMISSION_CARD_TYPE_LIST
            },
            {
                link: ROUTE_CARD_TYPE_CREATE,
                icon: "bx bx-plus",
                label: 'menu.create_card_type',
                value: PERMISSIONS.PERMISSION_CARD_TYPE_CREATE
            },
        ]
    },
    {
        label: 'Exchange files',
        value: PERMISSIONS.PERMISSION_PROCESSING,
        children: [
            /* {
                link: ROUTE_PROCESSING_LAST_INFO,
                icon: "bx bx-info-circle",
                label: 'menu.last_generation',
                value: PERMISSIONS.PERMISSION_LAST_GENERATION
            }, */
            {
                link: ROUTE_PROCESSING_GENERATE_APBATCH_COMMAND,
                icon: "bx bx-download",
                label: 'menu.commande_apbatch_generation',
                value: PERMISSIONS.PERMISSION_COMMAND_APBATCH_GENERATION
            },
            {
                link: ROUTE_PROCESSING_GENERATE_APBATCH_MAINTENANCE,
                icon: "bx bx-download",
                label: 'menu.maintenance_apbatch_generation',
                value: PERMISSIONS.PERMISSION_MAINTENANCE_APBATCH_GENERATION
            },
            {
                link: ROUTE_PROCESSING_VALIDATE_APBATCH_COMMAND,
                icon: "bx bx-check",
                label: 'menu.commande_apbatch_validation',
                value: PERMISSIONS.PERMISSION_COMMAND_APBATCH_VALIDATION
            },
            {
                link: ROUTE_PROCESSING_VALIDATE_APBATCH_MAINTENANCE,
                icon: "bx bx-check",
                label: 'menu.maintenance_apbatch_validation',
                value: PERMISSIONS.PERMISSION_MAINTENANCE_APBATCH_VALIDATION
            },
        ]
    },
    {
        label: 'Users',
        value: PERMISSIONS.PERMISSION_USER,
        children: [
            {
                link: ROUTE_USER,
                icon: "bx bx-search-alt-2",
                label: 'Search',
                value: PERMISSIONS.PERMISSION_USER_LIST
            },
            {
                link: ROUTE_USER_CREATE,
                icon: "bx bx-user-plus",
                label: 'menu.create_user',
                value: PERMISSIONS.PERMISSION_USER_CREATE
            },
            
        ]
    },
    {
        label: 'Profiles',
        value: PERMISSIONS.PERMISSION_PROFILE,
        children: [
            {
                link: ROUTE_PROFILE,
                icon: "bx bx-search-alt-2",
                label: 'Search',
                value: PERMISSIONS.PERMISSION_PROFILE
            },
            {
                link: ROUTE_PROFILE_CREATE,
                icon: "bx bx-user-plus",
                label: 'menu.create_profile',
                value: PERMISSIONS.PERMISSION_PROFILE_CREATE
            },
        ]
    },
    /* {
        label: 'menu.feature_management',
        value: PERMISSIONS.PERMISSION_FEATURE,
        children: [
            {
                link: ROUTE_FEATURE,
                icon: "bx bx-list-ul",
                label: 'menu.list_feature',
                value: PERMISSIONS.PERMISSION_FEATURE_LIST
            },
            {
                link: ROUTE_FEATURE_CREATE,
                icon: "bx bx-user-plus",
                label: 'menu.create_feature',
                value: PERMISSIONS.PERMISSION_FEATURE_CREATE
            },
        ]
    }, */
]
export default Permissions