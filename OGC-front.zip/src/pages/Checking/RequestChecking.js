import React, { useEffect } from "react"
import Breadcrumbs from "../../components/Common/Breadcrumb"
import { Breadcrumbs as Bs } from "../../common/data/breadcrumbs"
import { Card, CardBody, CardHeader, CardTitle, Col, Container, Row } from "reactstrap"
import { withTranslation } from "react-i18next"
import { useMakeControl } from "common/hooks/useRequest"
import useResponder from "common/hooks/useResponder"

const RequestChecking = ({ navigate, params, location, ...props }) => {
    const query = useMakeControl();
    useResponder({
        response: query.response, 
        error: query.error, 
        successMessage: "Contrôle effectué avec succès", 
        errorMessage: "Erreur lors du contrôle, veuillez reessayer plus tard."
    })

    const onCheck = () => {
        query.control();
    }

    const displayHeader = () => {
        return (
            <CardHeader className="bg-white">
                <CardTitle tag="h5" className="mt-2">
                    {props.t("card.control_requests")}
                </CardTitle>
            </CardHeader>
        )
    }

    return (
        <>
            <div className="page-content">
                <Container fluid>
                    <Breadcrumbs breadcrumbItems={Bs.REQUEST_CHECKING} />

                    <Card>
                        {displayHeader()}
                        <CardBody>
                            <Row>
                                <Col>
                                    <button
                                        className="btn btn-primary waves-effect waves-light"
                                        onClick={onCheck}
                                    >
                                        {query.loading ? (
                                            <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2" />
                                        ) : (
                                            <i className="bx bx-comment-error mr-2" />
                                        )}
                                        {props.t("form.start_control")}
                                    </button>
                                </Col>
                            </Row>
                        </CardBody>
                    </Card>
                </Container>
            </div>
        </>
    )
}

RequestChecking.propTypes = {
}

export default withTranslation()(RequestChecking);
