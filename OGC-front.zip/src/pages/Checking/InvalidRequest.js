
import React from "react"
import { Container } from "reactstrap"
import { withTranslation } from "react-i18next"
import { Breadcrumbs as Bs } from "common/data/breadcrumbs"
import Breadcrumbs from "components/Common/Breadcrumb"
import datasColumns from "common/data/InvalidRequestColumns"
import { EntityList } from "components/Common/EntityManger"
import { useInvalidRequests } from "common/hooks/useRequest"
import useResponder from "common/hooks/useResponder"

const InvalidRequest = ({ ...props }) => {
    const query = useInvalidRequests();
    useResponder({
        error: query.error,
        errorMessage: "Une erreur est survenue lors du chargement des données"
    })

    const rowEvents = {
        onClick: (e, row, rowIndex) => {

        },
        onDoubleClick: (e, row, rowIndex) => {
            console.log(row)
        }
    }

    return (
        <>
            <div className="page-content">
                <Container fluid>
                    <Breadcrumbs breadcrumbItems={Bs.REQUEST_INVALID} />

                    <EntityList data={query.response} dataColumns={datasColumns} rowEvents={rowEvents} title={"card.invalid_request"} onLoad={query.get} {...props} />
                </Container>
            </div>
        </>
    )
}

export default withTranslation()(InvalidRequest)
