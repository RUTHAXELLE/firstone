import Breadcrumbs from "components/Common/Breadcrumb"
import { withTranslation } from "react-i18next"
import { Card, CardBody, CardHeader, CardTitle, Col, Container, Nav, NavItem, NavLink, Row, TabContent, TabPane } from "reactstrap";
import { Breadcrumbs as Bs } from "common/data/breadcrumbs"
import { useIncoherentRequests, useInvalidRequests, useMakeControl, useValidateRequest, useValidRequests } from "common/hooks/useRequest";
import useResponder from "common/hooks/useResponder";
import { EntityList } from "components/Common/EntityManger";
import { PERMISSION_INVALID_REQUEST_VALIDATE, PERMISSION_REQUEST_CHECK } from "helpers/permission_helper";
import Granted from "components/Common/Granted";
import { useEffect, useState } from "react";
import valid_datasColumns from "common/data/ValidRequestColumns"
import invalid_datasColumns from "common/data/InvalidRequestColumns"
import waited_datasColumns from "common/data/WaitedRequestColumns"
import { createRowEvent } from "components/Common/SearchTable";

const VALID_TAB = "1";
const INVALID_TAB = "2";
const WAITED_TAB = "3";

const StatePage = ({ ...props }) => {
    const query = useMakeControl();
    useResponder({
        response: query.response,
        error: query.error,
        successMessage: "Contrôle effectué avec succès",
        errorMessage: "Erreur lors du contrôle, veuillez reessayer plus tard.",
        successAction: () => {
            setReload(!reload)
        }
    })

    const [activeTab, setActiveTab] = useState(VALID_TAB);
    const [reload, setReload] = useState(false);

    const tabs = [
        {
            index: VALID_TAB,
            Component: ValidStateList,
            title: "valid_request",
            label: "Valid requests list"
        },
        {
            index: INVALID_TAB,
            Component: InvalidStateList,
            title: "invalid_request",
            label: "Invalid requests list"
        },
        {
            index: WAITED_TAB,
            Component: WaitedStateList,
            title: "waited_request",
            label: "Waited requests list"
        }
    ]

    const toggle = (tab) => {
        if (activeTab != tab) {
            //setReload(!reload);
            setActiveTab(tab)
        }
    }

    const handleCheck = () => {
        query.control();
    }

    return (
        <div className="page-content">
            <Container fluid>
                <Breadcrumbs breadcrumbItems={Bs.REQUEST_STATE} />

                <Card>
                    <CardHeader className="bg-white">
                        <div className="d-flex justify-content-between">
                            <CardTitle tag="h5">{props.t("card.state_request")}</CardTitle>
                            <Granted permission={PERMISSION_REQUEST_CHECK}>
                                <button
                                    className="btn btn-primary waves-effect waves-light"
                                    onClick={handleCheck}
                                >
                                    {query.loading ? (
                                        <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2" />
                                    ) : (
                                        <i className="bx bx-comment-error mr-2" />
                                    )}
                                    {props.t("form.start_control")}
                                </button>
                            </Granted>
                        </div>
                    </CardHeader>
                    <CardBody>
                        <Nav
                            tabs
                        >
                            {
                                tabs.map((tab) => (
                                    <NavItem key={tab.index}>
                                        <NavLink
                                            active={activeTab === tab.index}
                                            onClick={() => toggle(tab.index)}
                                        >
                                            {props.t(tab.title)}
                                        </NavLink>
                                    </NavItem>
                                ))
                            }
                        </Nav>
                        <TabContent activeTab={activeTab}>
                            {
                                tabs.map((tab) => (
                                    <TabPane key={tab.index} tabId={tab.index}>
                                        <tab.Component title={tab.label} mustReload={reload} updateView={() => setReload(!reload)} />
                                    </TabPane>
                                ))
                            }
                        </TabContent>
                    </CardBody>
                </Card>
            </Container>
        </div>
    )
}

const ValidStateList = withTranslation()(({ mustReload, updateView, title, ...props }) => {
    const query = useValidRequests();
    useResponder({
        error: query.error,
        errorMessage: "Une erreur est survenue lors du chargement des données"
    })

    const rowEvents = {
        onClick: (e, row, rowIndex) => {

        },
        onDoubleClick: (e, row, rowIndex) => {
            console.log(row)
        }
    }

    return (
        <div className="mt-3">
            <CardTitle tag="h5" className="mb-3">{props.t(title)}</CardTitle>
            <EntityList inCard={false} data={query.response} mustUpdate={mustReload} dataColumns={valid_datasColumns} rowEvents={rowEvents} title={"card.valid_request"} onLoad={query.get} {...props} />
        </div>
    )
})

const InvalidStateList = withTranslation()(({ mustReload, updateView, title, ...props }) => {
    const query = useInvalidRequests();
    useResponder({
        error: query.error,
        errorMessage: "Une erreur est survenue lors du chargement des données"
    })

    const rowEvents = {
        onClick: (e, row, rowIndex) => {

        },
        onDoubleClick: (e, row, rowIndex) => {
            console.log(row)
        }
    }

    return (
        <div className="mt-3">
            <CardTitle tag="h5" className="mb-3">{props.t(title)}</CardTitle>
            <EntityList inCard={false} data={query.response} mustUpdate={mustReload} dataColumns={invalid_datasColumns} rowEvents={rowEvents} title={"card.invalid_request"} onLoad={query.get} {...props} />
        </div>
    )
})

const WaitedStateList = withTranslation()(({ mustReload, updateView, title, ...props }) => {
    const [selected, setSelected] = useState([]);
    const [reload, setReload] = useState(false);

    const invalidQuery = useIncoherentRequests();
    useResponder({
        error: invalidQuery.error,
        errorMessage: "Une erreur est survenue lors du chargement des données"
    })

    const validateQuery = useValidateRequest({ ...props });
    useResponder({
        response: validateQuery.response,
        error: validateQuery.error,
        successMessage: "Validation effectuée avec succès",
        errorMessage: "Erreur lors de la validation, veuillez reessayer plus tard.",
        successAction: () => {
            setReload(!reload);
            updateView();
        }
    })

    useEffect(() => {
        setReload(!reload);
    }, [mustReload])

    const keyField = "id"
    const rowEvents = createRowEvent(selected, setSelected, keyField);

    const validateRequests = () => {
        validateQuery.validate(selected.map((value) => {
            return {
                id: value
            };
        }))
    }
    return (
        <div className="mt-3">
            <CardTitle tag="h5" className="mb-3">{props.t(title)}</CardTitle>
            <Granted
                permission={PERMISSION_INVALID_REQUEST_VALIDATE}
                errorComponent={
                    <EntityList
                        inCard={false}
                        data={invalidQuery.response}
                        dataColumns={waited_datasColumns}
                        rowEvents={rowEvents}
                        title={"card.waited_request"}
                        onLoad={invalidQuery.get}
                        mustUpdate={reload}
                        {...props}
                    />
                }
            >
                <EntityList
                    inCard={false}
                    data={invalidQuery.response}
                    dataColumns={waited_datasColumns}
                    rowEvents={rowEvents}
                    title={"card.waited_request"}
                    onLoad={invalidQuery.get}
                    isRowSelectable={true}
                    selectColumnTitle={"form.isValid"}
                    mustUpdate={reload}
                    selected={selected}
                    {...props}
                />

                <Row className="mt-3">
                    <Col>
                        <button
                            className="btn btn-primary waves-effect waves-light"
                            onClick={validateRequests}
                        >
                            {validateQuery.loading ? (
                                <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2" />
                            ) : (
                                <i className="fas fa-save mr-2" />
                            )}
                            {props.t("form.save")}
                        </button>
                    </Col>
                </Row>
            </Granted>
        </div>
    )
})


export default withTranslation()(StatePage);