import React, { useEffect } from "react"
import { withTranslation } from "react-i18next"
import datasColumns from "../../common/data/UserColumns"
import { withRouter } from "common/hoc/withRouter"
import { useAllUsers } from "common/hooks/useUsers"
import { EntityList, EntityPage } from "components/Common/EntityManger"
import useResponder from "common/hooks/useResponder"
import { PERMISSION_USER_CREATE, PERMISSION_USER_UPDATE } from "helpers/permission_helper"
import { ROUTE_USER_CREATE, ROUTE_USER_EDIT } from "helpers/route_helper"
import { useNavigate } from "react-router-dom"
import { optionsFormatter, transFormatter } from "common/data/Formatter"
import Granted from "components/Common/Granted"
import { SYS_ADMIN_LOGIN } from "config"

const UserList = ({ breadCrumb, ...props }) => {
  const query = useAllUsers();
  const navigate = useNavigate();

  useResponder({
    error: query.error,
    errorMessage: "Une erreur est survenue lors du chargement des données"
  })

  const handleAdd = () => {
    navigate(ROUTE_USER_CREATE);
  }

  const handleEdit = (row) => {
    navigate(ROUTE_USER_EDIT + "/" + row?.id);
  }

  const rowEvents = {
    onClick: (e, row, rowIndex) => {

    },
    onDoubleClick: (e, row, rowIndex) => {
      console.log(row)
    }
  }

  const addActions = () => {
    return [
      ...datasColumns,
      {
        text: "actions",
        dataField: "action",
        formatter: optionsFormatter,
        headerFormatter: transFormatter,
        formatExtraData: {
          id: "id",
          onEdit: handleEdit,
          editPermission: PERMISSION_USER_UPDATE,
        }
      }
    ];
  }

  const filterResponse = () => {
    return {
      items: query.response?.items?.filter((value) => {
        return value?.login !== SYS_ADMIN_LOGIN;
      }),
      count: query.response?.count
    }
  }

  const filterOptions = (type, {filters}) => {
    let criteria = {};

    for (const dataField in filters) {
      const { filterVal, filterType, comparator } = filters[dataField];
      console.log(filters[dataField]);
    }
  }

  return (
    <EntityPage
      breadCrumb={breadCrumb}
    >
      <Granted
        permission={PERMISSION_USER_UPDATE}
        errorComponent={
          <EntityList
            data={filterResponse()}
            dataColumns={datasColumns}
            rowEvents={rowEvents}
            title={"Users list"}
            onLoad={query.get}
            mustUpdate={true}
            onAdd={handleAdd}
            addPermission={PERMISSION_USER_CREATE}
            filterOptions={filterOptions}
            {...props}
          />
        }
      >
        <EntityList
          data={filterResponse()}
          dataColumns={addActions()}
          rowEvents={rowEvents}
          title={"Users list"}
          onLoad={query.get}
          mustUpdate={true}
          onAdd={handleAdd}
          addPermission={PERMISSION_USER_CREATE}
          filterOptions={filterOptions}
          {...props}
        />
      </Granted>
    </EntityPage>
  )
}

export default withRouter(withTranslation()(UserList))
