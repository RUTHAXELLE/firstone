import React, { useEffect, useState } from "react"
import {
    CardHeader,
    CardTitle,
    Col,
    FormGroup,
    Label,
    Row,
    Input as RInput
} from "reactstrap"
import { withTranslation } from "react-i18next"
import "toastr/build/toastr.min.css"
import { withRouter } from "common/hoc/withRouter"
import PropTypes from "prop-types"
import civility from "common/data/civility"
import { useAllAgences } from "common/hooks/useAgence"
import Plafonds from "common/data/Plafonds"
import { useAllCardTypes } from "common/hooks/useCardType"
import { EntityForm, FormEntity } from "components/Common/EntityManger"
import { ONLY_LETTERS_SPACE_PATTERN, ONLY_NUMBERS_PATTERN } from "common/regex/pattern"
import Select, { createOption } from "components/Common/forms/Select"
import Input from "components/Common/forms/Input"

const RequestForm = ({ add = true, data = null, onSubmit, ...props }) => {
    //const [loadAgences, agences, ,] = useAllAgences();
    const query = useAllCardTypes(false);
    const [Isdisabled, setIsDisabled] = useState(true)

    const [initData, setInitData] = useState({});

    useEffect(() => {
        //loadAgences();
        query.get();
    }, [])

    useEffect(() => {
        if (data) {
            setInitData({
                intitule: data?.civiliteClient ?? data?.intitule ?? "",
                noms: data?.noms ?? "",
                prenom: data?.prenom ?? "",
                numeroCompte: data?.numeroCompte ?? "",
                telephone: data?.telephone ?? "",
                typeCarteId: data?.typeCarteId,
                plafond: data?.isPlafondHaut ? 1 : data?.isPlafondMoyen ? 2 : data?.isPlafondBas ? 3 : 0
            })
        }
    }, [data])

    const handleCheck = ({target}) => {
        console.log(target.checked)
        setIsDisabled(!target.checked);
    }

    return (
        <>
            <FormEntity
                header={() => {
                    if (!add) {
                        return (
                            <CardHeader className="bg-white">
                                <CardTitle tag="h5" className="mt-2">
                                    {`${props.t("card.edit_request")}`}
                                </CardTitle>
                            </CardHeader>
                        )
                    } else {
                        return (
                            <CardHeader className="bg-white">
                                <CardTitle tag="h5" className="mt-2">
                                    {props.t("card.create_request")}
                                </CardTitle>
                            </CardHeader>
                        )
                    }
                }}
                {...props}
                onSubmit={onSubmit}
                initialData={initData}
                render={(control) => (
                    <>
                        <Row>
                            <Col>
                                <Col className="mb-3 px-0" md={12}>
                                    <b>{props.t("form.civility")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Select
                                        name="intitule"
                                        control={control}
                                        disabled={Isdisabled}
                                        placeholder={props.t("form.select_civility")}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                        }}
                                        options={civility.map((item, index) => {
                                            return createOption(props.t(item.label), item.value)
                                        })}
                                    />
                                </Col>
                            </Col>
                            <Col>
                                <Col className="mb-3" md={12}>
                                    <b>{props.t('form.lastname')}</b>
                                </Col>
                                <Col>
                                    <Input
                                        name="noms"
                                        control={control}
                                        className="form-control"
                                        placeholder={props.t('form.lastname')}
                                        disabled={Isdisabled}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                            pattern: {
                                                value: ONLY_LETTERS_SPACE_PATTERN,
                                                message: props.t("messages.error.only_letter_space")
                                            }
                                        }}
                                    />
                                </Col>
                            </Col>
                            <Col>
                                <Col className="mb-3" md={12}>
                                    <b>{props.t('form.firstname')}</b>
                                </Col>
                                <Col>
                                    <Input
                                        name="prenom"
                                        control={control}
                                        className="form-control"
                                        placeholder={props.t('form.firstname')}
                                        disabled={Isdisabled}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                            pattern: {
                                                value: ONLY_LETTERS_SPACE_PATTERN,
                                                message: props.t("messages.error.only_letter_space")
                                            }
                                        }}
                                    />
                                </Col>
                            </Col>
                        </Row>

                        <Row>
                            <Col className="mb-3">
                                <FormGroup check>
                                    <Label check>
                                        <RInput type="checkbox" name="isBeneficiary" onChange={handleCheck} /> {props.t("form.change_benef")}
                                    </Label>
                                </FormGroup>
                            </Col>
                        </Row>

                        <Row className="mb-3">
                            <Col>
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t("form.account_number")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Input
                                        name="numeroCompte"
                                        className="form-control"
                                        placeholder={props.t("form.account_number")}
                                        control={control}
                                        disabled={true}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                            pattern: {
                                                value: ONLY_NUMBERS_PATTERN,
                                                message: props.t("messages.error.only_number")
                                            }
                                        }}
                                    />
                                </Col>
                            </Col>
                            <Col>
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t("form.phone")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Input
                                        name="telephone"
                                        className="form-control"
                                        placeholder={props.t("form.phone")}
                                        control={control}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                            pattern: {
                                                value: ONLY_NUMBERS_PATTERN,
                                                message: props.t("messages.error.only_number")
                                            }
                                        }}
                                    />
                                </Col>
                            </Col>
                            {/* <Col>
                                        <Col className="mb-3 px-0" md={12}>
                                            <b>{props.t("form.agence")}</b>
                                        </Col>
                                        <Col className="px-0">
                                            <AvField
                                                name="agence"
                                                onChange={handleChangeData}
                                                value={request?.profileId}
                                                type="select"
                                                validate={{
                                                    required: {
                                                        value: true,
                                                        errorMessage: props.t("This field is required"),
                                                    },
                                                }}
                                            >
                                                <option value="">
                                                    {props.t("form.select_agence")}
                                                </option>
                                                {agences?.map((item, i) => (
                                                    <option key={i} value={item.id}>{item.code}</option>
                                                ))}
                                            </AvField>
                                        </Col>
                                    </Col> */}
                            {/* <Col>
                                <Col className="mb-3 px-0" md={12}>
                                    <b>{props.t("form.matricule")}</b>
                                </Col>
                                <Col className="px-0">
                                    <AvField
                                        name="matricule"
                                        className="form-control"
                                        placeholder={props.t("form.matricule")}
                                        onChange={handleChangeData}
                                        value={request?.matricule ?? ""}
                                        validate={{
                                            required: {
                                                value: true,
                                                errorMessage: props.t("This field is required"),
                                            },
                                        }}
                                    />
                                </Col>
                            </Col> */}
                        </Row>

                        <Row className="mb-3">
                            <Col>
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t("form.type_card")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Select
                                        name="typeCarteId"
                                        control={control}
                                        placeholder={props.t("form.select_type_card")}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                        }}
                                        options={query.response?.map((item, i) => {
                                            return createOption(item.typeCarte, item.id)
                                        })}
                                    />
                                </Col>
                            </Col>
                            <Col>
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t("form.plafond")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Select
                                        name="plafond"
                                        control={control}
                                        placeholder={props.t("form.select_plafond")}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                        }}
                                        options={Plafonds.map((item, i) => {
                                            return createOption(item.name, item.id)
                                        })}
                                    />
                                </Col>
                            </Col>
                        </Row>

                        <Row className="mt-3">
                            <Col>
                                <button
                                    className="btn btn-primary waves-effect waves-light"
                                    type="submit"
                                >
                                    {props.loading ? (
                                        <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2" />
                                    ) : (
                                        <i className="fas fa-save mr-2" />
                                    )}
                                    {props.t("form.save")}
                                </button>
                            </Col>
                        </Row>
                    </>
                )}
            />
        </>
    )
}

RequestForm.propTypes = {
    navigate: PropTypes.func,
    location: PropTypes.object,
    params: PropTypes.object,
    add: PropTypes.bool,
    request: PropTypes.object
}

export default withRouter(withTranslation()(RequestForm))
