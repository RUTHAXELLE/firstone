import React, { useEffect, useState } from "react"
import { withTranslation } from "react-i18next"
import datasColumns from "../../common/data/RequestColumns"
import { withRouter } from "common/hoc/withRouter"
import { useAllRequests, useDeleteRequest, useUnValidatedRequest } from "common/hooks/useRequest"
import { EntityList, EntityPage } from "components/Common/EntityManger"
import useResponder from "common/hooks/useResponder"
import { useNavigate } from "react-router-dom"
import { ROUTE_REQUEST_CREATE, ROUTE_REQUEST_EDIT } from "helpers/route_helper"
import { optionsFormatter, transFormatter } from "common/data/Formatter"
import { PERMISSION_REQUEST_CREATE, PERMISSION_REQUEST_DELETE, PERMISSION_REQUEST_UPDATE } from "helpers/permission_helper"
import Granted from "components/Common/Granted"

const RequestList = ({ query = useAllRequests(), breadCrumb, ...props }) => {
  const deleteQuery = useDeleteRequest();
  const [mustUpdate, setMustUpdate] = useState();
  const navigate = useNavigate();

  useResponder({
    error: query.error,
    errorMessage: "Une erreur est survenue lors du chargement des données"
  })

  useResponder({
    response: deleteQuery.response,
    error: deleteQuery.error,
    errorMessage: "Une erreur est survenue lors de la suppression",
    successMessage: "La suppression a été effectuée avec succès",
    successAction: () => {
      setMustUpdate(!mustUpdate);
    }
  });

  const handleAdd = () => {
    navigate(ROUTE_REQUEST_CREATE);
  }

  const handleEdit = (row) => {
    navigate(ROUTE_REQUEST_EDIT + "/" + row?.id);
  }

  const rowEvents = {
    onClick: (e, row, rowIndex) => {

    },
    onDoubleClick: (e, row, rowIndex) => {
      console.log(row)
    }
  }

  const addActions = () => {
    return [
      ...datasColumns,
      {
        text: "actions",
        dataField: "action",
        sort: true,
        formatter: optionsFormatter,
        headerFormatter: transFormatter,
        formatExtraData: {
          onDelete: deleteQuery.del,
          id: "id",
          deletePermission: PERMISSION_REQUEST_DELETE,
          onEdit: handleEdit,
          editPermission: PERMISSION_REQUEST_UPDATE,
        }
      }
    ];
  }

  return (
    <EntityPage
      breadCrumb={breadCrumb}
    >
      <Granted
        permission={[PERMISSION_REQUEST_DELETE, PERMISSION_REQUEST_UPDATE]}
        errorComponent={
          <EntityList
            data={query.response}
            dataColumns={datasColumns}
            rowEvents={rowEvents}
            title={"card.request_list"}
            onLoad={query.get}
            mustUpdate={mustUpdate}
            onAdd={handleAdd}
            addPermission={PERMISSION_REQUEST_CREATE}
            {...props}
          />
        }
      >
        <EntityList
          data={query.response}
          dataColumns={addActions()}
          rowEvents={rowEvents}
          title={"card.request_list"}
          onLoad={query.get}
          mustUpdate={mustUpdate}
          onAdd={handleAdd}
          addPermission={PERMISSION_REQUEST_CREATE}
          {...props}
        />
      </Granted>
    </EntityPage>
  )
}

export default withRouter(withTranslation()(RequestList))

export const AllRequestList = ({ ...props }) => {
  const query = useAllRequests();

  return (
    <RequestList {...props} query={query} />
  )
}
