import { AvField } from "availity-reactstrap-validation"
import { EntityForm, FormEntity } from "components/Common/EntityManger"
import Input from "components/Common/forms/Input"
import { useEffect, useState } from "react"
import { withTranslation } from "react-i18next"
import { CardHeader, CardTitle, Col, Row } from "reactstrap"

const CancelCardForm = ({ onSubmit, data = null, ...props }) => {

    const [initData, setInitData] = useState({});

    useEffect(() => {
        if (data) {
            setInitData({
                card_number: data?.card_number ?? "",
                card_label: data?.card_label ?? "",
                tarification: data?.tarification ?? ""
            });
        }
    }, [data])

    return (
        <FormEntity
            onSubmit={onSubmit}
            initialData={initData}
            {...props}
            header={() => {
                return (
                    <CardHeader className="bg-white">
                        <CardTitle tag="h5" className="mt-2">
                            {`${props.t("card.cancel_card")}`}
                        </CardTitle>
                    </CardHeader>
                )
            }}
            render={(control) => (
                <>
                    <Row>
                        <Col>
                            <Col className="mb-3" md={12}>
                                <b>{props.t('form.card_number')}</b>
                            </Col>
                            <Col>
                                <Input
                                    name="card_number"
                                    className="form-control"
                                    placeholder={props.t('form.card_number')}
                                    control={control}
                                    disabled={true}
                                    rules={{
                                        required: {
                                            value: true,
                                            message: props.t("This field is required"),
                                        },
                                    }}
                                />
                            </Col>
                        </Col>
                        <Col>
                            <Col className="mb-3" md={12}>
                                <b>{props.t('form.card_label')}</b>
                            </Col>
                            <Col>
                                <Input
                                    name="card_label"
                                    className="form-control"
                                    placeholder={props.t('form.card_label')}
                                    control={control}
                                    disabled={true}
                                    rules={{
                                        required: {
                                            value: true,
                                            message: props.t("This field is required"),
                                        },
                                    }}
                                />
                            </Col>
                        </Col>
                        <Col>
                            <Col className="mb-3" md={12}>
                                <b>{props.t('form.tarification')}</b>
                            </Col>
                            <Col>
                                <Input
                                    name="tarification"
                                    className="form-control"
                                    placeholder={props.t('form.tarification')}
                                    control={control}
                                    disabled={true}
                                    rules={{
                                        required: {
                                            value: true,
                                            message: props.t("This field is required"),
                                        },
                                    }}
                                />
                            </Col>
                        </Col>
                    </Row>
                    <Row className="mt-3">
                        <Col>
                            <button
                                className="btn btn-primary waves-effect waves-light"
                                type="submit"
                            >
                                {props.loading ? (
                                    <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2" />
                                ) : (
                                    <i className="fas fa-save mr-2" />
                                )}
                                {props.t("form.save")}
                            </button>
                        </Col>
                    </Row>
                </>
            )}
        />
    )
}

export default withTranslation()(CancelCardForm)