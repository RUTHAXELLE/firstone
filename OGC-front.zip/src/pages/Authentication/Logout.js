import { withRouter } from "common/hoc/withRouter"
import React, { Component, useEffect } from "react"
import { connect } from "react-redux"

import { logoutUser } from "../../store/actions"

const Logout = ({...props}) => {
  /**
   * Redirect to login
   */
  useEffect(() => {
    props.logoutUser(props.location)
  }, []);

  return <React.Fragment></React.Fragment>
}

export default withRouter(connect(null, { logoutUser })(Logout))
