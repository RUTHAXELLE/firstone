import React, { useEffect, useState } from "react"
import {
    CardHeader,
    CardTitle,
    Col,
    Row,
} from "reactstrap"
import { withTranslation } from "react-i18next"
import "toastr/build/toastr.min.css"
import { withRouter } from "common/hoc/withRouter"
import PropTypes from "prop-types"
import { Types_CardType } from "common/data/CardTypeType"
import { FormEntity } from "components/Common/EntityManger"
import { ONLY_LETTERS_NUMBERS_PATTERN, ONLY_LETTERS_NUMBERS_SPACE_PATTERN, ONLY_NUMBERS_PATTERN } from "common/regex/pattern"
import Input from "components/Common/forms/Input"
import Select, { createOption } from "components/Common/forms/Select"

const CardTypeForm = ({ add = true, data = null, loading, onSubmit, onRemove, ...props }) => {

    const [initData, setInitData] = useState({
        code: "",
        typeCarte: "",
        typeGen: "",
        produit: "",
        codeProduit: "",
        codeBanque: "",
        identifiantProduit: "",
        identifiantInstitution: "",
        identifiantGroupe: "",
        business: "",
        codeTarif: "",
        devise: "",
        accCountry: "",
        pays: "",
        bin: "",
        type: ""
    });

    useEffect(() => {
        if (data) {
            setInitData({
                code: data?.code ?? "",
                typeCarte: data?.typeCarte,
                typeGen: data?.typeGen,
                produit: data?.produit,
                codeProduit: data?.codeProduit,
                codeBanque: data?.codeBanque,
                identifiantProduit: data?.identifiantProduit,
                identifiantInstitution: data?.identifiantInstitution,
                identifiantGroupe: data?.identifiantGroupe,
                business: data?.business,
                codeTarif: data?.codeTarif,
                devise: data?.devise,
                accCountry: data?.accCountry,
                pays: data?.pays,
                bin: data?.bin,
                type: data?.type
            });
        }
    }, [data])

    return (
        <>
            <FormEntity
                {...props}
                header={(cardType) => {
                    if (!add) {
                        return (
                            <CardHeader className="bg-white">
                                <CardTitle tag="h5" className="mt-2">
                                    {cardType ? `${props.t("card.edit_card_type")}: ${cardType?.typeCarte}` : `${props.t("card.edit_card_type")}`}
                                </CardTitle>
                            </CardHeader>
                        )
                    } else {
                        return (
                            <CardHeader className="bg-white">
                                <CardTitle tag="h5" className="mt-2">
                                    {props.t("card.create_card_type")}
                                </CardTitle>
                            </CardHeader>
                        )
                    }
                }}
                initialData={initData}
                onSubmit={onSubmit}
                render={(control) => (
                    <>
                        <Row>
                            <Col className="mb-3">
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t("form.code")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Input
                                        name="code"
                                        className="form-control"
                                        placeholder={props.t("form.code")}
                                        control={control}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                            pattern: {
                                                value: ONLY_NUMBERS_PATTERN,
                                                message: props.t("messages.error.only_number")
                                            }
                                        }}
                                    />
                                </Col>
                            </Col>
                            <Col className="mb-3">
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t("form.type_card")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Input
                                        name="typeCarte"
                                        control={control}
                                        className="form-control"
                                        placeholder={props.t("form.type_card")}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                            pattern: {
                                                value: ONLY_LETTERS_NUMBERS_SPACE_PATTERN,
                                                message: props.t("messages.error.only_letter_number_space")
                                            }
                                        }}
                                    />
                                </Col>
                            </Col>
                        </Row>

                        <Row>
                            <Col className="mb-3">
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t("form.type_gen")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Input
                                        name="typeGen"
                                        className="form-control"
                                        placeholder={props.t("form.type_gen")}
                                        control={control}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                            pattern: {
                                                value: ONLY_LETTERS_NUMBERS_SPACE_PATTERN,
                                                message: props.t("messages.error.only_letter_number_space")
                                            }
                                        }}
                                    />
                                </Col>
                            </Col>
                            <Col className="mb-3">
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t("form.product")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Input
                                        name="produit"
                                        control={control}
                                        className="form-control"
                                        placeholder={props.t("form.product")}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                            pattern: {
                                                value: ONLY_LETTERS_NUMBERS_SPACE_PATTERN,
                                                message: props.t("messages.error.only_letter_number_space")
                                            }
                                        }}
                                    />
                                </Col>
                            </Col>
                        </Row>

                        <Row>
                            <Col className="mb-3">
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t("form.code_product")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Input
                                        name="codeProduit"
                                        className="form-control"
                                        placeholder={props.t("form.code_product")}
                                        control={control}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                            pattern: {
                                                value: ONLY_NUMBERS_PATTERN,
                                                message: props.t("messages.error.only_number")
                                            }
                                        }}
                                    />
                                </Col>
                            </Col>
                            <Col className="mb-3">
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t("form.code_bank")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Input
                                        name="codeBanque"
                                        control={control}
                                        className="form-control"
                                        placeholder={props.t("form.code_bank")}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                            pattern: {
                                                value: ONLY_NUMBERS_PATTERN,
                                                message: props.t("messages.error.only_number")
                                            }
                                        }}
                                    />
                                </Col>
                            </Col>
                        </Row>

                        <Row>
                            <Col className="mb-3">
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t("form.id_product")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Input
                                        name="identifiantProduit"
                                        className="form-control"
                                        placeholder={props.t("form.id_product")}
                                        control={control}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                            pattern: {
                                                value: ONLY_NUMBERS_PATTERN,
                                                message: props.t("messages.error.only_number")
                                            }
                                        }}
                                    />
                                </Col>
                            </Col>
                            <Col className="mb-3">
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t("form.id_institution")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Input
                                        name="identifiantInstitution"
                                        control={control}
                                        className="form-control"
                                        placeholder={props.t("form.id_institution")}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                            pattern: {
                                                value: ONLY_NUMBERS_PATTERN,
                                                message: props.t("messages.error.only_number")
                                            }
                                        }}
                                    />
                                </Col>
                            </Col>
                        </Row>

                        <Row>
                            <Col className="mb-3">
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t("form.id_group")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Input
                                        name="identifiantGroupe"
                                        className="form-control"
                                        placeholder={props.t("form.id_group")}
                                        control={control}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                            pattern: {
                                                value: ONLY_LETTERS_NUMBERS_PATTERN,
                                                message: props.t("messages.error.only_letter_number")
                                            }
                                        }}
                                    />
                                </Col>
                            </Col>
                            <Col className="mb-3">
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t("form.business")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Input
                                        name="business"
                                        control={control}
                                        className="form-control"
                                        placeholder={props.t("form.business")}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                            pattern: {
                                                value: ONLY_LETTERS_NUMBERS_SPACE_PATTERN,
                                                message: props.t("messages.error.only_letter_number_space")
                                            }
                                        }}
                                    />
                                </Col>
                            </Col>
                        </Row>

                        <Row>
                            <Col className="mb-3">
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t("form.code_tarif")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Input
                                        name="codeTarif"
                                        className="form-control"
                                        placeholder={props.t("form.code_tarif")}
                                        control={control}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                            pattern: {
                                                value: ONLY_LETTERS_NUMBERS_PATTERN,
                                                message: props.t("messages.error.only_letter_number")
                                            }
                                        }}
                                    />
                                </Col>
                            </Col>
                            <Col className="mb-3">
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t("form.devise")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Input
                                        name="devise"
                                        control={control}
                                        className="form-control"
                                        placeholder={props.t("form.devise")}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                        }}
                                    />
                                </Col>
                            </Col>
                        </Row>

                        <Row>
                            <Col className="mb-3">
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t("form.acc_country")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Input
                                        name="accCountry"
                                        className="form-control"
                                        placeholder={props.t("form.acc_country")}
                                        control={control}
                                        rules={{}}
                                    />
                                </Col>
                            </Col>
                            <Col className="mb-3">
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t("form.country")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Input
                                        name="pays"
                                        control={control}
                                        className="form-control"
                                        placeholder={props.t("form.country")}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                        }}
                                    />
                                </Col>
                            </Col>
                        </Row>

                        <Row>
                            <Col className="mb-3">
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t("form.bin")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Input
                                        name="bin"
                                        className="form-control"
                                        placeholder={props.t("form.bin")}
                                        control={control}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                        }}
                                    />
                                </Col>
                            </Col>
                            <Col className="mb-3">
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t("form.type")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Select
                                        name="type"
                                        control={control}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                        }}
                                        placeholder={props.t("form.select_type")}
                                        options={Types_CardType.map((item, i) => {
                                            return createOption(item.value, item.value)
                                        })}
                                    />
                                </Col>
                            </Col>
                        </Row>

                        <Row className="mt-3">
                            <Col>
                                <button
                                    className="btn btn-primary waves-effect waves-light"
                                    type="submit"
                                >
                                    {loading ? (
                                        <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2" />
                                    ) : (
                                        <i className="fas fa-save mr-2" />
                                    )}
                                    {props.t("form.save")}
                                </button>
                            </Col>
                            {
                                (!add && onRemove) && (
                                    <Col md={11}>
                                        <button
                                            className="btn btn-danger waves-effect waves-light"
                                            type="button"
                                            onClick={onRemove}
                                        >
                                            {props.loading ? (
                                                <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2" />
                                            ) : (
                                                <i className="fas fa-trash mr-2" />
                                            )}
                                            {props.t("form.delete")}
                                        </button>
                                    </Col>
                                )
                            }
                        </Row>
                    </>
                )}
            />
        </>
    )
}

CardTypeForm.propTypes = {
    navigate: PropTypes.func,
    location: PropTypes.object,
    params: PropTypes.object,
    add: PropTypes.bool,
    cardType: PropTypes.object
}

export default withRouter(withTranslation()(CardTypeForm))
