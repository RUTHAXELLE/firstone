import { Breadcrumbs } from "common/data/breadcrumbs"
import { useCreateCardType, useDeleteCardType, useEditCardType, useSearchCardType } from "common/hooks/useCardType"
import { AddEntity, EditEntity } from "components/Common/EntityManger"
import { ROUTE_CARD_TYPE } from "helpers/route_helper"
import { useEffect, useState } from "react"
import { useNavigate, useParams } from "react-router-dom"
import CardTypeForm from "./CardTypeForm"
import CardTypeList from "./CardTypeList"


const props = {
    Form: CardTypeForm,
    List: CardTypeList,
    onCreate: useCreateCardType,
    onSearch: useSearchCardType,
    onEdit: useEditCardType,
    onDelete: useDeleteCardType
}

export const AddCardTypePage = () => {
    const navigate = useNavigate();

    const handleSuccessCreate = () => {
        navigate(ROUTE_CARD_TYPE);
    }
    return (
        <AddEntity breadCrumb={Breadcrumbs.CARD_TYPE_ADD} onSuccessCreate={handleSuccessCreate} {...props} />
    )
}

export const EditCardTypePage = () => {
    const navigate = useNavigate();
    const { id } = useParams();
    const [mustSearch, setMustSearch] = useState(true);

    const handleSuccessEdit = () => {
        navigate(ROUTE_CARD_TYPE);
    }

    useEffect(() => {
        setMustSearch(!mustSearch);
    }, [id]);

    return (
        <EditEntity breadCrumb={Breadcrumbs.CARD_TYPE_EDIT} id={{ id: id }} mustSearch={mustSearch} onSuccessEdit={handleSuccessEdit} {...props} />
    )
}

export const ListCardTypePage = () => {
    return (
        <CardTypeList breadCrumb={Breadcrumbs.CARD_TYPE} {...props} />
    )
}