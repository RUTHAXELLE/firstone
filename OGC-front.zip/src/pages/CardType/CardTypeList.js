import React, { useEffect, useState } from "react"
import { withTranslation } from "react-i18next"
import datasColumns from "../../common/data/CardTypeColumns"
import { withRouter } from "common/hoc/withRouter"
import { EntityList, EntityPage } from "components/Common/EntityManger"
import { useAllCardTypes, useDeleteCardType } from "common/hooks/useCardType"
import useResponder from "common/hooks/useResponder"
import { PERMISSION_CARD_TYPE_CREATE, PERMISSION_CARD_TYPE_DELETE, PERMISSION_CARD_TYPE_UPDATE } from "helpers/permission_helper"
import { optionsFormatter, transFormatter } from "common/data/Formatter"
import { ROUTE_CARD_TYPE_CREATE, ROUTE_CARD_TYPE_EDIT } from "helpers/route_helper"
import { useNavigate } from "react-router-dom"
import Granted from "components/Common/Granted"

const CardTypeList = ({ breadCrumb, ...props }) => {
  const query = useAllCardTypes();
  const navigate = useNavigate();
  const deleteQuery = useDeleteCardType();
  const [mustUpdate, setMustUpdate] = useState();

  useResponder({
    error: query.error,
    errorMessage: "Une erreur est survenue lors du chargement des données"
  })

  useResponder({
    response: deleteQuery.response,
    error: deleteQuery.error,
    errorMessage: "Une erreur est survenue lors de la suppression",
    successMessage: "La suppression a été effectuée avec succès",
    successAction: () => {
      setMustUpdate(!mustUpdate);
    }
  });

  const handleAdd = () => {
    navigate(ROUTE_CARD_TYPE_CREATE);
  }

  const handleEdit = (row) => {
    navigate(ROUTE_CARD_TYPE_EDIT + "/" + row?.id);
  }

  const rowEvents = {
    onClick: (e, row, rowIndex) => {

    },
    onDoubleClick: (e, row, rowIndex) => {
      console.log(row)
    }
  }

  const addActions = () => {
    return [
      ...datasColumns,
      {
        text: "actions",
        dataField: "action",
        sort: true,
        formatter: optionsFormatter,
        headerFormatter: transFormatter,
        formatExtraData: {
          onEdit: handleEdit,
          editPermission: PERMISSION_CARD_TYPE_UPDATE,
          id: "id",
          onDelete: deleteQuery.del,
          deletePermission: PERMISSION_CARD_TYPE_DELETE,
        }
      }
    ];
  }

  return (
    <EntityPage
      breadCrumb={breadCrumb}
    >
      <Granted
        permission={[PERMISSION_CARD_TYPE_UPDATE, PERMISSION_CARD_TYPE_DELETE]}
        errorComponent={
          <EntityList
            data={query.response}
            dataColumns={datasColumns}
            rowEvents={rowEvents}
            title={"card.card_type_list"}
            onLoad={query.get}
            mustUpdate={mustUpdate}
            onAdd={handleAdd}
            addPermission={PERMISSION_CARD_TYPE_CREATE}
            {...props}
          />
        }
      >
        <EntityList
          data={query.response}
          dataColumns={addActions()}
          rowEvents={rowEvents}
          title={"card.card_type_list"}
          onLoad={query.get}
          mustUpdate={mustUpdate}
          onAdd={handleAdd}
          addPermission={PERMISSION_CARD_TYPE_CREATE}
          {...props}
        />
      </Granted>
    </EntityPage>
  )
}

export default withRouter(withTranslation()(CardTypeList))
