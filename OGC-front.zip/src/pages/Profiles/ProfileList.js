import React, { useEffect, useState } from "react"
import { withTranslation } from "react-i18next"
import { withRouter } from "common/hoc/withRouter"
import { useAllProfiles, useDeleteProfile } from "common/hooks/useProfiles"
import datasColumns from "common/data/ProfileColumns"
import { EntityList, EntityPage } from "components/Common/EntityManger"
import useResponder from "common/hooks/useResponder"
import { useNavigate } from "react-router-dom"
import { ROUTE_PROFILE_CREATE, ROUTE_PROFILE_EDIT } from "helpers/route_helper"
import { optionsFormatter, transFormatter } from "common/data/Formatter"
import { PERMISSION_PROFILE_CREATE, PERMISSION_PROFILE_DELETE, PERMISSION_PROFILE_UPDATE } from "helpers/permission_helper"
import Granted from "components/Common/Granted"

const ProfileList = ({ breadCrumb, ...props }) => {
  const query = useAllProfiles();
  const deleteQuery = useDeleteProfile();
  const [mustUpdate, setMustUpdate] = useState();
  const navigate = useNavigate();

  useResponder({
    error: query.error,
    errorMessage: "Une erreur est survenue lors du chargement des données"
  })

  useResponder({
    response: deleteQuery.response,
    error: deleteQuery.error,
    errorMessage: "Une erreur est survenue lors de la suppression",
    successMessage: "La suppression a été effectuée avec succès",
    successAction: () => {
      setMustUpdate(!mustUpdate);
    }
  });

  const handleAdd = () => {
    navigate(ROUTE_PROFILE_CREATE);
  }

  const handleEdit = (row) => {
    navigate(ROUTE_PROFILE_EDIT + "/" + row?.id);
  }

  const handleDuplicate = (row) => {
    navigate(ROUTE_PROFILE_CREATE + "/" + row?.id);
  }

  const rowEvents = {
    onClick: (e, row, rowIndex) => {

    },
    onDoubleClick: (e, row, rowIndex) => {
      console.log(row)
    }
  }

  const addActions = () => {
    return [
      ...datasColumns,
      {
        text: "actions",
        dataField: "action",
        formatter: optionsFormatter,
        headerFormatter: transFormatter,
        formatExtraData: {
          onDelete: deleteQuery.del,
          id: "id",
          deletePermission: PERMISSION_PROFILE_DELETE,
          onEdit: handleEdit,
          editPermission: PERMISSION_PROFILE_UPDATE,
          onDuplicate: handleDuplicate,
          duplicatePermission: PERMISSION_PROFILE_CREATE
        }
      }
    ];
  }

  return (
    <EntityPage
      breadCrumb={breadCrumb}
    >
      <Granted
      permission={[PERMISSION_PROFILE_DELETE, PERMISSION_PROFILE_UPDATE]}
        errorComponent={
          <EntityList
            data={query.response}
            dataColumns={datasColumns}
            rowEvents={rowEvents}
            title={"card.profile_list"}
            onLoad={query.get}
            mustUpdate={mustUpdate}
            onAdd={handleAdd}
            addPermission={PERMISSION_PROFILE_CREATE}
            {...props}
          />
        }
      >
        <EntityList
          data={query.response}
          dataColumns={addActions()}
          rowEvents={rowEvents}
          title={"card.profile_list"}
          onLoad={query.get}
          mustUpdate={mustUpdate}
          onAdd={handleAdd}
          addPermission={PERMISSION_PROFILE_CREATE}
          {...props}
        />
      </Granted>
    </EntityPage>
  )
}

export default withRouter(withTranslation()(ProfileList))
