import { Breadcrumbs } from "common/data/breadcrumbs"
import { useCreateProfile, useDeleteProfile, useEditProfile, useSearchProfile } from "common/hooks/useProfiles"
import useResponder from "common/hooks/useResponder"
import { AddEntity, EditEntity } from "components/Common/EntityManger"
import { default as SearchItem } from "components/Common/SearchItem"
import { ROUTE_PROFILE } from "helpers/route_helper"
import { useEffect, useState } from "react"
import { withTranslation } from "react-i18next"
import { useNavigate, useParams } from "react-router-dom"
import ProfileForm from "./ProfileForm"
import ProfileList from "./ProfileList"


const SearchProfile = withTranslation()(({ onSearch, ...props }) => {
    return (
        <SearchItem label={props.t("form.code")} onSearch={onSearch} name="code" />
    )
})

const props = {
    Form: ProfileForm,
    Search: SearchProfile,
    onCreate: useCreateProfile,
    onSearch: useSearchProfile,
    onEdit: useEditProfile,
    onDelete: useDeleteProfile
}

export const AddProfilePage = () => {
    const navigate = useNavigate();
    const {id} = useParams();
    const query = useSearchProfile();
    const [duplicatedData, setDuplicatedData] = useState();

    const handleSuccessCreate = () => {
        navigate(ROUTE_PROFILE);
    }

    useEffect(() => {
        if (id)
            query.search({id: id})
    }, [id]);

    useResponder({
        response: query.response,
        error: query.error,
        errorMessage: "Aucun élément n'a pas été trouvé",
        successAction: () => {
            setDuplicatedData(query.response)
        }
    });

    return (
        <AddEntity breadCrumb={Breadcrumbs.PROFILE_ADD} onSuccessCreate={handleSuccessCreate} {...props} data={duplicatedData} />
    )
}

export const EditProfilePage = () => {
    const navigate = useNavigate();
    const {id} = useParams();
    const [mustSearch, setMustSearch] = useState(true);

    const handleSuccessEdit = () => {
        navigate(ROUTE_PROFILE);
    }

    useEffect(() => {
        setMustSearch(!mustSearch);
    }, [id]);

    return (
        <EditEntity breadCrumb={Breadcrumbs.PROFILE_EDIT} id={{id: id}} mustSearch={mustSearch} onSuccessEdit={handleSuccessEdit} {...props} />
    )
}

export const ListProfilePage = () => {
    return (
        <ProfileList breadCrumb={Breadcrumbs.PROFILE} />
    )
}