import { withTranslation } from "react-i18next"
import { Card, CardBody, CardHeader, CardTitle, Col, Row } from "reactstrap";

const Generate = ({ title, onSubmit, ...props }) => {

    return (
        <Card>
            <CardHeader className="bg-white">
                <CardTitle tag="h5">{props.t(title)}</CardTitle>
            </CardHeader>
            <CardBody>
                <Row className="mt-3">
                    <Col>
                        <button
                            className="btn btn-primary waves-effect waves-light"
                            onClick={onSubmit}
                        >
                            {props.loading ? (
                                <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2" />
                            ) : (
                                <i className="fas fa-save mr-2" />
                            )}
                            {props.t("form.start_generation")}
                        </button>
                    </Col>
                </Row>
            </CardBody>
        </Card>
    )
}

export default withTranslation()(Generate);