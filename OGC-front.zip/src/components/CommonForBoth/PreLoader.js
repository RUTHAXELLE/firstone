
const PreLoader = ({ display = true }) => {

    if (!display)
        return null;

    return (
        <div id="preloader" style={{
            display: "block"
        }}>
            <div id="status">
                <div className="spinner-chase">
                    <div className="chase-dot"></div>
                    <div className="chase-dot"></div>
                    <div className="chase-dot"></div>
                    <div className="chase-dot"></div>
                    <div className="chase-dot"></div>
                    <div className="chase-dot"></div>
                </div>
            </div>
        </div>
    )
}

export default PreLoader;