import PropTypes from "prop-types"
import React, { useEffect, useRef, useState } from "react"
//Simple bar
import SimpleBar from "simplebar-react"
// MetisMenu
import MetisMenu from "metismenujs"
import { Link } from "react-router-dom"
//i18n
import { withTranslation } from "react-i18next"
import { isValidToken, loggedUser } from "../../helpers/jwt_helpers"
import { withRouter } from "common/hoc/withRouter"
import Permissions from "helpers/permissions"
import { connect } from "react-redux"
import Granted from "components/Common/Granted"

const SidebarContent = ({ ...props }) => {
  const [user, setUser] = useState({});
  const refDiv = useRef();
  const [activeMenu, setActiveMenu] = useState(null);

  // Init menu every time url path changes
  useEffect(() => {
    //initMenu()
    setActiveMenu(props.location.pathname)
  }, [props.location.pathname])

  // Init user every time page loaded
  useEffect(() => {
    new MetisMenu("#side-menu")
    initUser();
  }, []);

  /**
   * Reset menus and select active menu
   */
  const initMenu = () => {
    new MetisMenu("#side-menu")
    disableAllMenus();

    // Looking for a menu which match with current url path
    let matchingMenuItem = null
    const ul = document.getElementById("side-menu")
    const items = ul.getElementsByTagName("a")
    for (let i = 0; i < items.length; ++i) {
      if (props.location.pathname === items[i].pathname) {
        matchingMenuItem = items[i]
        break
      }
    }

    // If a menu match with the current url path
    // expand matched menu parent
    if (matchingMenuItem) {
      activateParentDropdown(matchingMenuItem)
    }

  }

  const initUser = () => {
    const token = isValidToken()
    let user = token.user
    if (!user) {
      user = loggedUser()
    }
    setUser(user)
  }

  const scrollElement = item => {
    setTimeout(() => {
      if (refDiv.current !== null) {
        if (item) {
          const currentPosition = item.offsetTop
          if (currentPosition > window.innerHeight) {
            if (refDiv.current)
              refDiv.current.getScrollElement().scrollTop =
                currentPosition - 300
          }
        }
      }
    }, 300)
  }


  /**
   * Make all menus inactive
   */
  const disableAllMenus = () => {
    const ul = document.getElementById("side-menu")

    const items = ul.getElementsByClassName("mm-active");
    for (let i = 0; i < items.length; ++i) {
      items[i]?.classList?.remove("mm-active");
    }

    const activeLink = ul.getElementsByClassName("active");
    for (let index = 0; index < activeLink.length; index++) {
      const element = activeLink[index];
      element.classList.remove("active")
    }
  }


  /**
   * Active given menu
   * @param {HTMLElement} item The menu to active
   * @returns 
   */
  const activateParentDropdown = item => {
    item.classList.add("active")
    const parent = item.parentElement

    // I don't know
    /* const parent2El = parent.childNodes[1]
    if (parent2El && parent2El.id !== "side-menu") {
      parent2El.classList.add("mm-show")
    } */

    if (parent) {
      parent.classList.add("mm-active")
      const parent2 = parent.parentElement

      if (parent2) {
        parent2.classList.add("mm-show") // ul tag

        const parent3 = parent2.parentElement // li tag

        if (parent3) {
          parent3.classList.add("mm-active") // li
          parent3.childNodes[0].classList.add("mm-active") //a

          const parent4 = parent3.parentElement // ul
          if (parent4  && parent4.id !== "side-menu") {
            parent4.classList.add("mm-show") // ul
            const parent5 = parent4.parentElement
            if (parent5) {
              parent5.classList.add("mm-show") // li
              parent5.childNodes[0].classList.add("mm-active") // a tag
            }
          }
        }
      }
      scrollElement(item)
      return false
    }
    scrollElement(item)
    return false
  }


  const handleClickHeader = (link) => {
    props.navigate(link)
  }

  return (
    <React.Fragment>
      <SimpleBar style={{ maxHeight: "100%" }} ref={refDiv}>
        <div id="sidebar-menu">
          <ul className="metismenu list-unstyled" id="side-menu">

            {
              Permissions.map((permission) => {
                if (permission.value) {
                  return (
                    <Granted permission={permission.value} key={permission.value}>
                      <li>
                        <Link to={"/#"} className="waves-effect has-arrow" onClick={() => handleClickHeader(permission.children[0].link)}>
                          {props.t(permission.label)}
                        </Link>
                        <ul className="sub-menu">
                          {
                            permission.children.map((menu) => {
                              if (menu.value) {
                                return (
                                  <Granted permission={menu.value} key={menu.label}>
                                    <li>
                                      <Link to={menu.link} className={`waves-effect ${menu.link === activeMenu ? "active" : ""}`} aria-expanded={menu.link === activeMenu}>
                                        <i className={menu.icon} />
                                        <span>{props.t(menu.label)}</span>
                                      </Link>
                                    </li>
                                  </Granted>
                                )
                              }

                              return null;
                            })
                          }
                        </ul>
                      </li>
                    </Granted>
                  )
                }

                return null;
              })
            }

          </ul>
        </div>
      </SimpleBar>
    </React.Fragment>
  )
}

SidebarContent.propTypes = {
  location: PropTypes.object,
  t: PropTypes.any,
  type: PropTypes.string,
}

const mapStateToProps = (state) => {
  return {
    features: state.role.features
  }
}

export default withRouter(withTranslation()(connect(mapStateToProps)(SidebarContent)))
