import PropTypes from 'prop-types'
import React, { Component, useState } from "react"

import { connect } from "react-redux"

import { Link } from "react-router-dom"

// Import menuDropdown
import LanguageDropdown from "../CommonForBoth/TopbarDropdown/LanguageDropdown"
import ProfileMenu from "../CommonForBoth/TopbarDropdown/ProfileMenu"

import logoL from "../../assets/images/logo-l.png"
import logoS from "../../assets/images/logo-s.png"

//i18n
import { withTranslation } from "react-i18next"

// Redux Store
import { toggleRightSidebar } from "../../store/actions"
import { ROUTE_DASHBOARD } from "../../helpers/route_helper"
import { Col, Row } from 'reactstrap'

const Header = ({ ...props }) => {
  const [isSearch, setIsSearch] = useState(false)

  /**
   * Toggle sidebar
   */
  const toggleMenu = () => {
    props.toggleMenuCallback()
  }

  return (
    <React.Fragment>
      <header id="page-topbar">
        <div className="navbar-header">
          <div className="d-flex">

            <div className="navbar-brand-box">
              {/* <Link to={ROUTE_DASHBOARD} className="logo logo-dark">
                <span className="logo-sm">
                  <img src={logoS} alt="" height="22" />
                </span>
                <span className="logo-lg">
                  <img src={logoL} alt="" height="34" />
                </span>
              </Link>

              <Link to={ROUTE_DASHBOARD} className="logo logo-light">
                <span className="logo-sm">
                  <img src={logoS} alt="" height="22" />
                </span>
                <span className="logo-lg">
                  <img src={logoL} alt="" height="34" />
                </span>
              </Link> */}

              {props.type !== "condensed" && (
                <Row className='justify-content-end align-items-center'>
                  <Col className='align-middle'>
                    <span className="fs-1 text-uppercase text-white">{props.t("Menu")}</span>
                  </Col>
                  <Col md={3}>
                    <button
                      type="button"
                      className="btn btn-sm px-3 font-size-16 header-item waves-effect text-white"
                      onClick={toggleMenu}
                      id="vertical-menu-btn"
                    >
                      <i className="fas fa-angle-left" />
                    </button>
                  </Col>
                </Row>
              )}
            </div>

            {props.type === "condensed" && (
              <button
                type="button"
                className="btn btn-sm px-3 font-size-16 header-item waves-effect"
                onClick={toggleMenu}
                id="vertical-menu-btn"
              >
                <i className="fa fa-fw fa-bars" />
              </button>
            )}
          </div>
          <div className="d-flex">
            {/* <div className="dropdown d-inline-block d-lg-none ml-2">
              <button
                onClick={() => {
                  setIsSearch(!isSearch);
                }}
                type="button"
                className="btn header-item noti-icon waves-effect"
                id="page-header-search-dropdown"
              >
                <i className="mdi mdi-magnify" />
              </button>
            </div> */}

            <LanguageDropdown />

            <ProfileMenu />
          </div>
        </div>
      </header>
    </React.Fragment>
  )
}

const mapStatetoProps = state => {
  const { layoutType } = state.Layout
  return { layoutType }
}

export default connect(mapStatetoProps, { toggleRightSidebar })(
  withTranslation()(Header)
)

Header.propTypes = {
  t: PropTypes.any,
  toggleMenuCallback: PropTypes.any,
  toggleRightSidebar: PropTypes.func
}