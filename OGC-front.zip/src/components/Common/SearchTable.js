import BootstrapTable from "react-bootstrap-table-next";
import paginationFactory from "react-bootstrap-table2-paginator";
import ToolkitProvider from "react-bootstrap-table2-toolkit";
import { useTranslation } from "react-i18next"
import { Col, Row } from "reactstrap";
import PropTypes from "prop-types"

export const createRowEvent = (selected, setSelected, keyField, multiselect = true) => {

    if (multiselect)
        return {
            onClick: (e, row, rowIndex) => {

            },
            onDoubleClick: (e, row, rowIndex) => {
                console.log(row)
            },
            onSelect: (row, isSelected) => {
                if (isSelected) {
                    setSelected([...selected, row[keyField]])
                } else {
                    setSelected(selected.filter((r) => r !== row[keyField]))
                }
            },
            onSelectAll: (rows, isSelected) => {
                if (isSelected) {
                    setSelected([...selected, ...rows.map((row) => row[keyField])])
                } else {
                    const rs = rows.map(row => row[keyField])
                    setSelected(selected.filter(r => !rs.includes(r)))
                }
            }
        }
    else
        return {
            onClick: (e, row, rowIndex) => {
                setSelected(row)
            },
            onDoubleClick: (e, row, rowIndex) => {
                console.log(row)
            },
            onSelect: (row, isSelected) => {
                if (isSelected) {
                    setSelected(row)
                } else {
                    setSelected(null)
                }
            },
        }
}

const SearchTable = ({
    data,
    datasColumns,
    keyField = "id",
    rowEvents,
    isRowSelectable = false,
    showSelectColumn = true,
    multiselect = true,
    selectColumnTitle,
    selected = [],
    paginationOpt,
    onTableChange,
    renderSearch,
    ...props
}) => {

    const { t } = useTranslation();

    const selectRow = {
        mode: multiselect ? 'checkbox' : "radio",
        clickToSelect: true,
        selected: selected,
        hideSelectColumn: !showSelectColumn,
        selectColumnPosition: 'right',
        headerColumnStyle: (status) => {
            return multiselect ? {
                width: "auto"
            } : {};
        },
        onSelect: (row, isSelected, rowIndex, e) => {
            rowEvents?.onSelect(row, isSelected);
        },
        onSelectAll: (isSelected, rows, e) => {
            rowEvents?.onSelectAll(rows, isSelected);
        },
    };

    const events = {
        onClick: rowEvents?.onClick,
        onDoubleClick: rowEvents?.onDoubleClick,
    }

    const renderSelectionHeader = () => {
        return <span>{t(selectColumnTitle)}</span>
    }

    const paginationOptions = {
        ...paginationOpt
    }

    const handleTableChange = (type, newState) => {
        onTableChange(type, newState);
    }

    return (
        <ToolkitProvider
            keyField={keyField}
            data={data}
            columns={datasColumns}
            search={{
                customMatchFunc: true,
            }}
            bootstrap4
        >
            {
                props => (
                    <Row>
                        <Col>
                            {
                                renderSearch()
                            }
                            <BootstrapTable
                                responsive
                                remote
                                {...props.baseProps}
                                bordered={false}
                                striped={false}
                                rowEvents={events}
                                pagination={paginationFactory(paginationOptions)}
                                classes={"table table-centered table-nowrap"}
                                headerWrapperClasses={"thead-light"}
                                onTableChange={handleTableChange}
                                {...(
                                    isRowSelectable ? {
                                        selectRow: selectColumnTitle ? { ...selectRow, selectionHeaderRenderer: renderSelectionHeader } : selectRow
                                    } : {}
                                )}
                                noDataIndication={() => (
                                    <div className=" text-center">{t("No data found")}</div>
                                )}
                                className={"cf"} />
                        </Col>
                    </Row>
                )
            }
        </ToolkitProvider>
    )
}

SearchTable.propTypes = {
    data: PropTypes.array,
    datasColumns: PropTypes.array,
    keyField: PropTypes.string,
    rowEvents: PropTypes.object
}

export default SearchTable;