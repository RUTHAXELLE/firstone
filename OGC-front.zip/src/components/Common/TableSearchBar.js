const { useState, useEffect } = require("react");
const { Search } = require("react-bootstrap-table2-toolkit");
const { useTranslation } = require("react-i18next");
const { Row, Col, FormGroup, Input } = require("reactstrap")
const { SearchBar } = Search;

const TableSearchBar = ({dataColumns, onSearch, searchProps}) => {
    const {t} = useTranslation();

    const [searchProperties, setSearchProperties] = useState([]);
    const [searchProperty, setSearchProperty] = useState("");
    const [searchText, setSearchText] = useState("");

    useEffect(() => {
        const searchable = dataColumns.filter((value) => {
            return value?.searchable;
        })
        setSearchProperties([...searchable]);

        if (!searchProperty)
            setSearchProperty(searchable?.[0]?.dataField);
    }, [dataColumns]);

    const handleSearchTextChange = (text) => {
        setSearchText(text);
        onSearch(text, searchProperty)
    }

    const handleSearchPropertyChange = ({ target: { value } }) => {
        setSearchProperty(value)
        onSearch(searchText, value)
    }

    return (
        <Row>
            <Col md={"auto"}>
                <SearchBar
                    {...searchProps}
                    placeholder={t("form.search")}
                    onSearch={handleSearchTextChange}
                    searchText={searchText}
                />
            </Col>
            <Col md={"auto"}>
                <FormGroup>
                    <Input
                        onChange={handleSearchPropertyChange}
                        name="searchBy"
                        type="select"
                        value={searchProperty}
                        className="border border-0"
                    >
                        {
                            searchProperties.map((column) => (
                                <option key={column?.dataField} value={column?.dataField}>
                                    {t("by")} {t(column?.text)}
                                </option>
                            ))
                        }
                    </Input>
                </FormGroup>
            </Col>
        </Row>
    )
}

export default TableSearchBar;