import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Col, Row } from "reactstrap";


const ColumnHeader = ({ text, sortElement, filterElement, ...props }) => {
    const { t } = useTranslation();

    return (
        <>
            <Row className="px-1 justify-content-between">
                <Col className="text-truncate">
                    <span >{t(text)}</span>
                </Col>
                <Col md={2}>
                    {sortElement}
                </Col>
            </Row>
        </>
    )
}

export default ColumnHeader;