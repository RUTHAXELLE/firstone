import { useTranslation } from "react-i18next";
import { Button, Modal, ModalBody, ModalFooter, ModalHeader } from "reactstrap";


const ConfirmationModal = ({ onConfirm, opened, onClose, message }) => {
    const { t } = useTranslation();

    const handleConfirm = () => {
        onConfirm();
        onClose();
    }

    return (
        <Modal isOpen={opened} toggle={onClose}>
            <ModalHeader toggle={onClose}>{t("confirmation")}</ModalHeader>
            <ModalBody>
                <p>{t(message)}</p>
            </ModalBody>
            <ModalFooter>
                <Button color="danger" onClick={handleConfirm}>
                    {t("confirm")}
                </Button>
                <Button color="secondary" onClick={onClose}>
                    {t("Cancel")}
                </Button>
            </ModalFooter>
        </Modal>
    )
}

export default ConfirmationModal;