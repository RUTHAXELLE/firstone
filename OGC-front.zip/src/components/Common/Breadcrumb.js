import React,  { Component }  from "react"
import PropTypes from "prop-types"
import { Link }  from "react-router-dom"
import { Breadcrumb, BreadcrumbItem, Col, Row }  from "reactstrap"
import { withTranslation }  from "react-i18next"
import { ROUTE_DASHBOARD }  from "../../helpers/route_helper"

const Breadcrumbs = ({...props}) => { 
   
    return (
      <React.Fragment>
        <Row>
          <Col xs = "12">
            <div className = "page-title-box d-flex align-items-center justify-content-between">
              <h4 className = "mb-0 font-size-18">
                { props.t( props.breadcrumbItems?.filter( breadcrumbItem   =>  breadcrumbItem.active)[ 0 ]?.title ) } 
              </h4>
              <div className = "page-title-right">
                <Breadcrumb listClassName = "m-0">
                  <BreadcrumbItem>
                    <Link to =  { ROUTE_DASHBOARD } > { props.t("Dashboard") } </Link>
                  </BreadcrumbItem>
                   { props.breadcrumbItems?.map( (breadcrumbItem, index)  =>  (
                    <BreadcrumbItem key={index} active =  { breadcrumbItem.active } >
                      <Link to =  { breadcrumbItem.link } > { props.t( breadcrumbItem.short_title ) } </Link>
                    </BreadcrumbItem>
                  )) } 
                </Breadcrumb>
              </div>
            </div>
          </Col>
        </Row>
      </React.Fragment>
    )
} 

Breadcrumbs.propTypes = { 
  breadcrumbItems : PropTypes.any,
  title: PropTypes.string
} 

export default withTranslation()(Breadcrumbs)
