import { useState } from "react";
import { Button, ButtonGroup } from "reactstrap";
import ConfirmationModal from "./ConfirmationModal";
import Granted from "./Granted";


const RowOptions = ({
    key,
    onEdit,
    editPermission,
    onDelete,
    deletePermission,
    confimationMessage = "Would you like to really make this action",
    data,
    row,
    ...props
}) => {
    const [openConfirm, setOpenConfirm] = useState(false);

    const handleEdit = () => {
        onEdit(row)
    }

    const handleDelete = () => {
        onDelete(data)
    }

    const handleOpenModal = () => {
        setOpenConfirm(true)
    }

    const handleCloseModal = () => {
        setOpenConfirm(false)
    }

    return (
        <div key={key}>
            <ButtonGroup>
                {
                    (props?.onDuplicate) && (
                        <Granted permission={props?.duplicatePermission}>
                            <Button color="success" onClick={() => props?.onDuplicate(row)}>
                                <i className="bx bx-duplicate" />
                            </Button>
                        </Granted>
                    )
                }
                {
                    (onEdit) && (
                        <Granted permission={editPermission}>
                            <Button color="primary" onClick={handleEdit}>
                                <i className="bx bx-edit" />
                            </Button>
                        </Granted>
                    )
                }
                {
                    (onDelete) && (
                        <Granted permission={deletePermission}>
                            <Button color="danger" onClick={handleOpenModal}>
                                <i className="bx bx-trash" />
                            </Button>
                        </Granted>
                    )
                }
                <ConfirmationModal
                    opened={openConfirm}
                    onClose={handleCloseModal}
                    onConfirm={handleDelete}
                    message={confimationMessage}
                />
            </ButtonGroup>
        </div>
    )
}


export default RowOptions;