
import { any, array, object, string } from "prop-types";
import { useEffect, useState } from "react";
import { Controller } from "react-hook-form";
import ReactSelect from "react-select"

/**
 * Crée une option de Select
 * @param {string} label Texte à afficher
 * @param {any} value Valeur à attribuer à l'option
 * @returns Objet représentant d'une option
 */
export const createOption = (label, value) => {
    return {
        label: label,
        value: value
    };
}

/**
 * @component
 * Abtraction du component react-select qui uniformise son utilisation
 */
const SelectComponent = ({value, options, innerRef, ...props}) => {
    const [selected, setSelected] = useState();

    useEffect(() => {
        if (value) {
            const opt = options?.find((option, index) => {
                return option?.value === value
            });
            
            setSelected(opt);
        }
    }, [value]);

    const handleChange = (option) => {
        props.onChange(option?.value)
    }

    return (
        <ReactSelect
            ref={innerRef}
            {...props}
            onChange={handleChange}
            value={selected}
            options={options}
            maxMenuHeight={150}
        />
    )
}


/**
 * @component
 * Représente un select qui intègre un controleur compatible avec la librairie de validation react-hook-form
 * 
 * @example
 * const {control} = useForm();
 * 
 * const options = [
 *  {
 *      label: "Monsieur",
 *      value: "M"
 *  },
 *  {
 *      label: "Madame",
 *      value: "Mme"
 *  },
 *  {
 *      label: "Mademoiselle",
 *      value: "Mlle"
 *  },
 * ]
 * 
 * return (
 *  <Select
 *      control={control}
 *      name={"civility"}
 *      rules={{
 *          required : true
 *      }}
 *      options={options}
 *  />
 * )
 */
const Select = ({ control, name, options, rules, disabled, ...props }) => {

    return (
        <Controller
            name={name}
            control={control}
            rules={rules}
            render={({ field: {ref, ...field}, fieldState: { error } }) => (
                <>
                    <SelectComponent
                        innerRef={ref}
                        {...props}
                        {...field}
                        isDisabled={disabled}
                        options={options}
                        className={error ? "border border-danger" : ""}
                    />
                    {
                        error && (
                            <span className="invalid-feedback" style={{
                                display: "block"
                            }}>
                                {error?.message}
                            </span>
                        )
                    }
                </>
            )}
        />
    )
}

Select.propTypes = {
    name: string.isRequired,
    control: any.isRequired,
    options: array.isRequired,
    rules: object,
    defaultValue: any
}

export default Select;