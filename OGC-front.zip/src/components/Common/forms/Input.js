import { Controller } from "react-hook-form";
import { FormFeedback, Input as RInput } from "reactstrap"
import { any, object, string } from "prop-types";

/**
 * @component
 * Représente un input qui intègre un controleur compatible avec la librairie de validation react-hook-form
 * 
 * @example
 * const {control} = useForm();
 * 
 * return (
 *  <Input 
 *      control={control}
 *      name={"firstname"}
 *      rules={{
 *          required : true
 *      }}
 *  />
 * )
 */
const Input = ({ control, name, rules, ...props }) => {

    return (
        <Controller
            control={control}
            name={name}
            rules={rules}
            render={({field, fieldState: {error, invalid}}) => (
                <>
                    <RInput invalid={invalid} {...props} {...field} />
                    <FormFeedback>
                        {error?.message}
                    </FormFeedback>
                </>
            )}
        />
    )
}

Input.propTypes = {
    control: any.isRequired,
    name: string.isRequired,
    rules: object,
}

export default Input;