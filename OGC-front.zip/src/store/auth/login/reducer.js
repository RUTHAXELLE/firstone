import {
  LOGIN_USER,
  LOGIN_SUCCESS,
  LOGOUT_USER,
  LOGOUT_USER_SUCCESS,
  API_ERROR, VALID_TOKEN
} from "./actionTypes"

const initialState = {
  error: "",
  loading: false,
  connected: false,
  isValidToken: true,
}

const login = (state = initialState, action) => {
  switch (action.type) {
    case LOGIN_USER:
      state = {
        ...state,
        loading: true,
        connected: false,
      }
      break
    case LOGIN_SUCCESS:
      state = {
        ...state,
        loading: false,
        connected: true,
      }
      break
    case LOGOUT_USER:
      state = { ...state }
      break
    case LOGOUT_USER_SUCCESS:
      state = { ...state }
      break
    case API_ERROR:
      state = {
        ...state,
        error: action.payload,
        loading: false,
        connected: false,
      }
      break
    case VALID_TOKEN:
      state = {
        ...state,
        isValidToken: action.payload,
        connected: false,
      }
      break
    default:
      state = { ...state }
      break
  }
  return state
}

export default login
