# Simple Add TO Cart In React Js

> Specific product quantity increment or decrement 

> Quantity increment or decrement without using `hooks` and `context api`

![add to cart in react](https://github.com/kalidas120799/react-shooping-cart/blob/master/src/assets/img/addtocart1.png?raw=true)
![add to cart in react](https://github.com/kalidas120799/react-shooping-cart/blob/master/src/assets/img/addtocart2.png?raw=true)
