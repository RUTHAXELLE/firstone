import React, { Component } from 'react'
import './App.css';
import Mycart from './pages/Mycart';
export default class App extends Component {
  render() {
    return (
      <div className="App">

        <Mycart />

      </div>
    )
  }
}
