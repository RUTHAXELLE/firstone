
// The top user login
export const SYS_ADMIN_LOGIN = "SYSADMIN";
// The top user profil code
export const SYS_ADMIN_PROFILE = "SYS_ADMIN";
