import { applyMiddleware, compose } from "redux"
import createSagaMiddleware from "redux-saga"
import { configureStore } from "@reduxjs/toolkit";

import rootReducer from "./reducers"
import rootSaga from "./sagas"

// Front
import Layout from "./layout/reducer"
import userReducer from "./auth/user/userReducer";
import roleReducer from "./auth/roles/roleReducer";

const sagaMiddleware = createSagaMiddleware()
const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose

const store = configureStore({
  middleware: (getDefaultMiddleware) => getDefaultMiddleware({thunk: false}).concat(sagaMiddleware),
  reducer: {
    user: userReducer,
    role: roleReducer,
    Layout
  }
});

sagaMiddleware.run(rootSaga);

export default store;
