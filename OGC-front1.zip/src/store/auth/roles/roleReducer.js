import { createSlice } from "@reduxjs/toolkit";
import { restoreData, STORAGE_AUTH_ROLE, storeData } from "helpers/localStorage_helper";


const roleSlice = createSlice({
    name: "role",
    initialState: {
        role: null,
        features: [],
        loading: true
    },
    reducers: {
        loadUserRole: (state, data) => {
            state.role = data.payload;
            state.features = data.payload?.features
        },
        storeRole: (state) => {
            storeData(STORAGE_AUTH_ROLE, {...state});
        },
        restoreRole: (state) => {
            if (!state.role && state.loading)
                restoreData(STORAGE_AUTH_ROLE, (data) => {
                    state.role = data?.role ?? null;
                    state.features = data?.features ?? [];
                    state.loading = false;
                });
        }
    }
});

export const { loadUserRole, storeRole, restoreRole } = roleSlice.actions;
export default roleSlice.reducer;