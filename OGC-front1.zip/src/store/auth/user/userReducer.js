import { createSlice } from "@reduxjs/toolkit";
import { SYS_ADMIN_LOGIN } from "config";
import { deleteToken, getToken, restoreData, STORAGE_AUTH_ROLE, STORAGE_AUTH_USER, storeData, storeToken } from "helpers/localStorage_helper";
import { isGranted, PERMISSION_REQUEST_CHECK, PERMISSION_USER_CREATE } from "helpers/permission_helper";


const userSlice = createSlice({
    name: "user",
    initialState: {
        data: null,
        role: null,
        features: [],
        visibility: {},
        loading: true
    },
    reducers: {
        login: (state, data) => {
            storeToken(data.payload?.token)
            state.data = data.payload;
        },
        // set user data
        updateData: (state, data) => {
            state.data = {
                ...data.payload,
                token: getToken()
            };
        },
        logout: (state) => {
            state.data = null;
            deleteToken()
        },
        storeUser: (state) => {
            storeData(STORAGE_AUTH_USER, state);
        },
        restoreUser: (state) => {
            if (state.loading) {
                if (!state.data) {
                    restoreData(STORAGE_AUTH_USER, (user) => {
                        state.data = user?.data;
                        state.role = user?.role ?? null;
                        state.features = user?.features ?? [];
                        state.visibility = user?.visibility ?? {};
                        state.loading = false;
                    });
                }
            }
        },
        // set profile and feature data
        loadUserRole: (state, data) => {
            state.role = data.payload;
            state.features = data.payload?.features

            if (state.data.login === SYS_ADMIN_LOGIN || isGranted(state.features, PERMISSION_USER_CREATE)) {
                state.visibility = {
        
                }
            }
            else if (isGranted(state.features, PERMISSION_REQUEST_CHECK)) {
                state.visibility = {
                    agence : state.data?.agenceCode
                }
            }
            else {
                state.visibility = {
                    login : state.data?.login
                }
            }
        },
    }
});

export const { login, logout, updateData, storeUser, restoreUser, loadUserRole } = userSlice.actions;

export default userSlice.reducer;