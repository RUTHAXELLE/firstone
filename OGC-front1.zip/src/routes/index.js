import React from "react"
import { Navigate, Redirect } from "react-router-dom"
// Authentication related pages
import Login from "../pages/Authentication/Login"
import Logout from "../pages/Authentication/Logout"
//Pages
import Pages404 from "../pages/Utility/pages-404"
import Pages500 from "../pages/Utility/Pages500"
import {
  ROUTE_CARD_TYPE,
  ROUTE_CARD_TYPE_CREATE,
  ROUTE_CARD_TYPE_EDIT,
  ROUTE_DASHBOARD,
  ROUTE_FEATURE,
  ROUTE_FEATURE_CREATE,
  ROUTE_INVALID_REQUEST_STATE,
  ROUTE_LOGIN,
  ROUTE_LOGOUT,
  ROUTE_MAINTENANCE,
  ROUTE_MAINTENANCE_ACCOUNT_EDIT,
  ROUTE_MAINTENANCE_CANCEL_CARD,
  ROUTE_MAINTENANCE_PRICING_EDIT,
  ROUTE_PROCESSING_GENERATE_APBATCH_COMMAND,
  ROUTE_PROCESSING_GENERATE_APBATCH_MAINTENANCE,
  ROUTE_PROCESSING_LAST_INFO,
  ROUTE_PROCESSING_VALIDATE_APBATCH_COMMAND,
  ROUTE_PROCESSING_VALIDATE_APBATCH_MAINTENANCE,
  ROUTE_PROFILE,
  ROUTE_PROFILE_CREATE,
  ROUTE_PROFILE_EDIT,
  ROUTE_REQUEST,
  ROUTE_REQUEST_CHECK,
  ROUTE_REQUEST_CREATE,
  ROUTE_REQUEST_EDIT,
  ROUTE_REQUEST_STATE,
  ROUTE_REQUEST_TOVALIDATE,
  ROUTE_UPDATE_PASSWORD,
  ROUTE_USER,
  ROUTE_USER_CREATE,
  ROUTE_USER_EDIT,
  ROUTE_VALID_REQUEST_STATE
} from "../helpers/route_helper"
import Dashboard from "../pages/Dashboard"
import RequestChecking from "pages/Checking/RequestChecking"
import { AddUserPage, EditUserPage, ListUserPage } from "pages/Users"
import { AddRequestPage, DeleteRequestPage, EditRequestPage, ListRequestPage } from "pages/Request"
import { AddCardTypePage, EditCardTypePage, ListCardTypePage } from "pages/CardType"
import InvalidRequest from "pages/Checking/InvalidRequest"
import ValidRequest from "pages/Checking/ValidRequest"
import WaitedRequest from "pages/Checking/WaitedRequest"
import { GenerateMaintenancePage, GenerateOrderPage, LastGenerationPage, ValidateMaintenancePage, ValidateOrderPage } from "pages/apbatch"
import { AccountUpdatePage, CancelCardPage, ChangeTarificationPage, DeleteOperationPage, ListMaintenancePage } from "pages/Maintenance"
import {
  PERMISSION_CARD_TYPE_CREATE,
  PERMISSION_CARD_TYPE_LIST,
  PERMISSION_CARD_TYPE_UPDATE,
  PERMISSION_COMMAND_APBATCH_GENERATION,
  PERMISSION_COMMAND_APBATCH_VALIDATION,
  PERMISSION_FEATURE_CREATE,
  PERMISSION_FEATURE_LIST,
  PERMISSION_INVALID_REQUEST_LIST,
  PERMISSION_INVALID_REQUEST_VALIDATE,
  PERMISSION_LAST_GENERATION,
  PERMISSION_MAINTENANCE_APBATCH_GENERATION,
  PERMISSION_MAINTENANCE_APBATCH_VALIDATION,
  PERMISSION_OPERATION_CREATE,
  PERMISSION_OPERATION_LIST,
  PERMISSION_PROFILE,
  PERMISSION_PROFILE_CREATE,
  PERMISSION_PROFILE_UPDATE,
  PERMISSION_REQUEST_CHECK,
  PERMISSION_REQUEST_CREATE,
  PERMISSION_REQUEST_LIST,
  PERMISSION_REQUEST_UPDATE,
  PERMISSION_USER_CREATE,
  PERMISSION_USER_LIST,
  PERMISSION_USER_UPDATE,
  PERMISSION_VALID_REQUEST_LIST
} from "helpers/permission_helper"
import { AddProfilePage, EditProfilePage, ListProfilePage } from "pages/Profiles"
import { AddFeaturePage, ListFeaturePage } from "pages/Features"
import Pages403 from "pages/Utility/Pages403"
import ChangePasswordPage from "pages/Authentication/ChangePassword"
import StatePage from "pages/Checking"

const authProtectedRoutes = [
  { path: ROUTE_DASHBOARD, component: Dashboard },

  //users
  { path: ROUTE_USER_CREATE, component: AddUserPage, role: PERMISSION_USER_CREATE },
  { path: ROUTE_USER_EDIT + "/" + ":id", component: EditUserPage, role: PERMISSION_USER_UPDATE },
  { path: ROUTE_USER, component: ListUserPage, role: PERMISSION_USER_LIST },

  /* //agences
  { path: ROUTE_AGENCE_CREATE, component: AddAgencePage},
  { path: ROUTE_AGENCE_EDIT, component: EditAgencePage},
  { path: ROUTE_AGENCE_DELETE, component: DeleteAgencePage}, */

  //profiles
  { path: ROUTE_PROFILE_CREATE + "/" + ":id", component: AddProfilePage, role: PERMISSION_PROFILE_CREATE },
  { path: ROUTE_PROFILE_CREATE, component: AddProfilePage, role: PERMISSION_PROFILE_CREATE },
  { path: ROUTE_PROFILE_EDIT + "/" + ":id", component: EditProfilePage, role: PERMISSION_PROFILE_UPDATE },
  { path: ROUTE_PROFILE, component: ListProfilePage, role: PERMISSION_PROFILE },

  //features
  /* { path: ROUTE_FEATURE_CREATE, component: AddFeaturePage, role: PERMISSION_FEATURE_CREATE },
  { path: ROUTE_FEATURE, component: ListFeaturePage, role: PERMISSION_FEATURE_LIST }, */

  //card type
  { path: ROUTE_CARD_TYPE, component: ListCardTypePage, role: PERMISSION_CARD_TYPE_LIST },
  { path: ROUTE_CARD_TYPE_CREATE, component: AddCardTypePage, role: PERMISSION_CARD_TYPE_CREATE },
  { path: ROUTE_CARD_TYPE_EDIT + "/" + ":id", component: EditCardTypePage, role: PERMISSION_CARD_TYPE_UPDATE },

  //request
  { path: ROUTE_REQUEST, component: ListRequestPage, role: PERMISSION_REQUEST_LIST },
  { path: ROUTE_REQUEST_CREATE, component: AddRequestPage, role: PERMISSION_REQUEST_CREATE },
  { path: ROUTE_REQUEST_EDIT + "/" + ":id", component: EditRequestPage, role: PERMISSION_REQUEST_UPDATE },

  //Checking
  { path: ROUTE_REQUEST_CHECK, component: RequestChecking, role: PERMISSION_REQUEST_CHECK },
  { path: ROUTE_REQUEST_STATE, component: StatePage, role: PERMISSION_VALID_REQUEST_LIST },
  { path: ROUTE_INVALID_REQUEST_STATE, component: InvalidRequest, role: PERMISSION_INVALID_REQUEST_LIST },
  { path: ROUTE_VALID_REQUEST_STATE, component: ValidRequest, role: PERMISSION_VALID_REQUEST_LIST },
  { path: ROUTE_REQUEST_TOVALIDATE, component: WaitedRequest, role: PERMISSION_INVALID_REQUEST_VALIDATE },

  //Apbatch
  { path: ROUTE_PROCESSING_GENERATE_APBATCH_COMMAND, component: GenerateOrderPage, role: PERMISSION_COMMAND_APBATCH_GENERATION },
  { path: ROUTE_PROCESSING_VALIDATE_APBATCH_COMMAND, component: ValidateOrderPage, role: PERMISSION_COMMAND_APBATCH_VALIDATION },
  { path: ROUTE_PROCESSING_GENERATE_APBATCH_MAINTENANCE, component: GenerateMaintenancePage, role: PERMISSION_MAINTENANCE_APBATCH_GENERATION },
  { path: ROUTE_PROCESSING_VALIDATE_APBATCH_MAINTENANCE, component: ValidateMaintenancePage, role: PERMISSION_MAINTENANCE_APBATCH_VALIDATION },
  { path: ROUTE_PROCESSING_LAST_INFO, component: LastGenerationPage, role: PERMISSION_LAST_GENERATION },

  //Maintenance
  { path: ROUTE_MAINTENANCE, component: ListMaintenancePage, role: PERMISSION_OPERATION_LIST },
  { path: ROUTE_MAINTENANCE_CANCEL_CARD, component: CancelCardPage, role: PERMISSION_OPERATION_CREATE },
  { path: ROUTE_MAINTENANCE_PRICING_EDIT, component: ChangeTarificationPage, role: PERMISSION_OPERATION_CREATE },
  { path: ROUTE_MAINTENANCE_ACCOUNT_EDIT, component: AccountUpdatePage, role: PERMISSION_OPERATION_CREATE },

  { path: ROUTE_UPDATE_PASSWORD, component: ChangePasswordPage, noLayout: true },

  // this route should be at the end of all other routes
  { path: "/", exact: true, component: () => <Navigate to={ROUTE_DASHBOARD} replace={true} /> },
]

const publicRoutes = [
  { path: ROUTE_LOGOUT, component: Logout },
  { path: ROUTE_LOGIN, component: Login },

  { path: "/pages-404", component: Pages404 },
  { path: "/pages-500", component: Pages500 },
  { path: "/pages-403", component: Pages403 },
]

export { authProtectedRoutes, publicRoutes }
