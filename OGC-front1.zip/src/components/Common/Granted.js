import { isGranted } from "helpers/permission_helper";
import React from "react";
import { connect } from "react-redux";

const Granted = ({ children, permission, and = false, not = false, features, errorComponent, ...props }) => {
    if (permission) {
        let allowed;
        if (Array.isArray(permission)) {
            if (and) {
                allowed = !permission.find((value) => !isGranted(features, value))
            } else {
                allowed = !!permission.find((value) => isGranted(features, value))
            }
        } else {
            allowed = isGranted(features, permission)
        }
        if ((not && allowed) || (!not && !allowed)) {

            if (errorComponent) {
                return (
                    <>
                        {errorComponent}
                    </>
                )
            }

            return null;
        }

        return (
            <React.Fragment key={props?.key}>
                {children}
            </React.Fragment>
        )
    }

    return (
        <>
            {children}
        </>
    )
}

const mapStateToProps = (state) => {
    return {
        features: state.user.features
    }
}

export default connect(mapStateToProps)(Granted);