import { AvForm } from "availity-reactstrap-validation";
import useResponder from "common/hooks/useResponder";
import { useEffect, useRef, useState } from "react";
import { useTranslation, withTranslation } from "react-i18next"
import { Alert, Button, Card, CardBody, CardHeader, CardTitle, Col, Container, Row } from "reactstrap";
import Breadcrumbs from "./Breadcrumb"
import ConfirmationModal from "./ConfirmationModal";
import Form from "./forms/Form";
import Granted from "./Granted";
import SearchTable from "./SearchTable";
import TableSearchBar from "./TableSearchBar";

export const AddEntity = withTranslation()(({ Form, List, onCreate, onSuccessCreate = () => { }, breadCrumb, top, bottom, ...props }) => {
    const query = onCreate();
    useResponder({
        response: query.response,
        error: query.error,
        errorMessage: "Erreur lors de la création, veuillez reessayer plus tard.",
        successMessage: "Création effectuée avec succès",
        successAction: () => onSuccessCreate()
    });

    const createEntity = (values) => {
        return query?.create(values);
    }

    return (
        <>
            <EntityPage breadCrumb={breadCrumb}>
                {top}
                <Form add={true} loading={query.loading} onSubmit={createEntity} {...props} />
                {bottom}
            </EntityPage>
        </>
    )
})

export const DeleteEntity = withTranslation()(({ Search, List, onDelete, breadCrumb, ...props }) => {
    const query = onDelete();
    const [reload, setReload] = useState();
    useResponder({
        response: query.response,
        error: query.error,
        errorMessage: "Erreur lors de la suppression, veuillez reessayer plus tard.",
        successAction: () => setReload(!reload),
        successMessage: "Suppression effectuée avec succès"
    });

    const deleteEntity = (values) => {
        return query.del(values);
    }

    return (
        <>
            <EntityPage breadCrumb={breadCrumb}>
                <Search onSearch={deleteEntity} loading={query.loading} />
                {/* <List mustUpdate={reload} /> */}
            </EntityPage>
        </>
    )
})

export const EditEntity = withTranslation()(({
    Form,
    List,
    id,
    mustSearch,
    onSearch,
    onEdit,
    onDelete,
    confirmationMessage = "Would you like to really make this action",
    onSuccessEdit = () => { },
    breadCrumb,
    ...props
}) => {
    const [entity, setEntity] = useState(null)
    const searchQuery = onSearch();
    const editQuery = onEdit();
    const deleteQuery = onDelete?.();
    const [openModal, setOpenModal] = useState(false);

    useResponder({
        response: searchQuery.response,
        error: searchQuery.error,
        errorMessage: "Aucun élément n'a pas été trouvé",
        successAction: () => {
            setEntity(searchQuery.response);
        }
    });
    useResponder({
        response: editQuery.response,
        error: editQuery.error,
        errorMessage: "Erreur lors de la mise à jour, veuillez reessayer plus tard.",
        successMessage: "Mise à jour effectuée avec succès.",
        successAction: () => {
            console.log(editQuery.response)
            resetEntity();
            onSuccessEdit();
        }
    });

    useResponder({
        response: deleteQuery?.response,
        error: deleteQuery?.error,
        errorMessage: "Erreur lors de la suppression, veuillez reessayer plus tard.",
        successMessage: "Suppression effectuée avec succès.",
        successAction: () => {
            onSuccessEdit();
        }
    });

    useEffect(() => {
        handleSearch(id);
    }, [mustSearch])

    const handleOpenModal = () => {
        setOpenModal(true);
    }

    const handleCloseModal = () => {
        setOpenModal(false);
    }

    const handleConfirm = () => {
        deleteQuery?.del(id)
    }

    const resetEntity = () => {
        setEntity(null);
    }

    const handleSearch = (pattern) => {
        searchQuery.search(pattern);
    }

    const updateEntity = (values) => {
        //const url = `${USER}/${entity.id}`
        const data = { ...values, id: entity.id }
        return editQuery.edit(data);
    }

    const handleDelete = () => {
        handleOpenModal()
    }

    return (
        <EntityPage breadCrumb={breadCrumb}>
            {/* <Search onSearch={handleSearch} /> */}
            <Form add={false} data={searchQuery.response} loading={editQuery.loading} onSubmit={updateEntity} onRemove={handleDelete} {...props} />
            <ConfirmationModal
                onClose={handleCloseModal}
                opened={openModal}
                onConfirm={handleConfirm}
                message={confirmationMessage}
            />
        </EntityPage>
    )
})

export const EntityList = ({ mustUpdate, onLoad, inCard = true, data, dataColumns, rowEvents, title, onAdd, addPermission, renderAdd, ...props }) => {
    const {t} = useTranslation();
    
    const sizePerPageList = [5, 10, 25, 50]
    const [page, setPage] = useState(0);
    const [sizePerPage, setSizePerPage] = useState(sizePerPageList[2]);

    //// Pagination and sorting logic

    const paginationOptions = {
        currentPage: page,
        sizePerPage: sizePerPage,
        sizePerPageList: sizePerPageList,
        showTotal: true,
        paginationTotalRenderer: (from, to, size) => {
            return (
                <span className="react-bootstrap-table-pagination-total mx-2">
                    {t("showing rows")} {from} {t("to")} {to} {t("on")} {size}
                </span>
            )
        },
        onTableChange: (type, { page, sizePerPage }) => {
            if (type === "pagination") {
                setSizePerPage(sizePerPage);
                setPage(page);
                onLoad(page - 1, sizePerPage);
            }
        }
    }

    const handleTableChange = (type, { page, sizePerPage, filters, sortField, sortOrder, ...newState }) => {
        let criteria = {};

        if (type === "pagination") {
            setSizePerPage(sizePerPage);
            setPage(page);
        }

        if (type === "sort") {
            criteria = {
                ...criteria,
                orderField: sortField,
                orderDirection: sortOrder
            }
        }

        if (type !== "search") {
            onLoad(page - 1, sizePerPage, criteria);
        }
    }

    useEffect(() => {
        onLoad(page > 0 ? page - 1 : page, sizePerPage);
    }, [mustUpdate])


    ////   Search logic

    const handleSearch = (text, searchProperty) => {
        onLoad(page, sizePerPage, {
            "searchField": searchProperty,
            "searchValue": text,
        });
    }

    /// Rendering logic

    const displayHeader = () => {

        return (
            <CardHeader className="bg-white">
                <div className="d-flex justify-content-between">
                    <CardTitle tag="h5">{t(title)}</CardTitle>
                    {
                        (onAdd || renderAdd) && (
                            <Granted permission={addPermission}>
                                {
                                    renderAdd ? renderAdd?.() : (
                                        <Button onClick={onAdd} color="success">{t("add")}</Button>
                                    )
                                }
                            </Granted>
                        )
                    }
                </div>
            </CardHeader>
        )
    }

    const displayTable = () => {

        return (
            <SearchTable
                data={data?.items ?? []}
                datasColumns={dataColumns}
                rowEvents={rowEvents}
                paginationOpt={{ ...paginationOptions, totalSize: data?.count ?? 0 }}
                onTableChange={handleTableChange}
                renderSearch={renderSearch}
                {...props}
            />
        )
    }

    const renderSearch = (searchProps) => {
        return (
            <TableSearchBar 
                searchProps={searchProps}
                onSearch={handleSearch}
                dataColumns={dataColumns}
            />
        )
    }

    return (
        <>
            {
                inCard ? (
                    <EntityCard
                        header={() => displayHeader()}
                    >
                        {displayTable()}
                    </EntityCard>
                ) : displayTable()
            }
        </>
    )
}

export const EntityForm = withTranslation()(({ data, render, header, onSubmit, ...props }) => {
    const formRef = useRef();

    const [model, setModel] = useState(data);

    useEffect(() => {
        setModel(data);
    }, [data]);

    const handleValidSubmit = (event, values) => {
        onSubmit(values)
        formRef.current.reset();
        setModel(null);
    }

    const handleChangeData = ({ target }) => {
        //setModel({ ...model, [target.name]: target.value })
    }

    return (
        <EntityCard
            header={() => header(model)}
        >
            <Row>
                <Col>
                    <AvForm
                        className="form-horizontal"
                        onValidSubmit={handleValidSubmit}
                        ref={formRef}
                    >
                        {props.error && props.error ? (
                            <Alert color="danger">{props.error}</Alert>
                        ) : null}
                        {render(handleChangeData, model)}
                    </AvForm>
                </Col>
            </Row>
        </EntityCard>
    )
})

export const FormEntity = ({ initialData, render, header, onSubmit, ...props }) => {

    return (
        <EntityCard
            header={() => header(initialData)}
        >
            <Form 
                data={initialData}
                render={render}
                onSubmit={onSubmit}
            />
        </EntityCard>
    )
}

export const EntityPage = ({ breadCrumb, children }) => {
    return (
        <div className="page-content">
            <Container fluid>
                <Breadcrumbs breadcrumbItems={breadCrumb} />
                {
                    children
                }
            </Container>
        </div>
    )
}

export const EntityCard = ({ header, children }) => {
    return (
        <Card>
            {
                header?.()
            }
            <CardBody>
                {children}
            </CardBody>
        </Card>
    )
}
