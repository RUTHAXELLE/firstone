import { AvField, AvForm } from "availity-reactstrap-validation";
import { generatePassword } from "helpers/form_helper";
import { useRef } from "react";
import { useTranslation } from "react-i18next";
import { Button, Col, Modal, ModalBody, ModalFooter, ModalHeader, Row } from "reactstrap";


const PasswordModal = ({ opened, onClose }) => {
    const { t } = useTranslation();
    const formRef = useRef();
    const passwordInputRef = useRef();

    const onSubmit = (values) => {
        console.log(values)
    }

    const handleValidSubmit = (event, values) => {
        onSubmit(values)
        formRef.current.reset();
        onClose();
    }

    const handleChange = ({ target }) => {

    }

    return (
        <Modal isOpen={opened} toggle={onClose}>
            <AvForm
                className="form-horizontal"
                onValidSubmit={handleValidSubmit}
                ref={formRef}
            >
                <ModalHeader toggle={onClose}>{t("form.edit_password")}</ModalHeader>
                <ModalBody>
                    <Row className="mt-3">
                        <Col className="">
                            <AvField
                                name="oldpassword"
                                placeholder={t("form.old_password")}
                                onChange={handleChange}
                                type="password"
                                validate={{
                                    required: {
                                        value: true,
                                        errorMessage: t("This field is required"),
                                    },
                                    minLength: {
                                        value: 8,
                                        errorMessage: t("messages.error.min8")
                                    }
                                }}
                            />
                        </Col>
                    </Row>
                    <Row className="mt-3">
                        <Col className="">
                            <AvField
                                innerRef={passwordInputRef}
                                name="password"
                                placeholder={t("form.new_password")}
                                onChange={handleChange}
                                type="text"
                                validate={{
                                    required: {
                                        value: true,
                                        errorMessage: t("This field is required"),
                                    },
                                    minLength: {
                                        value: 8,
                                        errorMessage: t("messages.error.min8")
                                    }
                                }}
                            />
                        </Col>
                        <Col className="align-items-end">
                            <button type="button" className="btn btn-secondary waves-effect waves-light" onClick={() => generatePassword(passwordInputRef)}>
                                {t("form.generate_password")}
                            </button>
                        </Col>
                    </Row>
                </ModalBody>
                <ModalFooter>
                    <Button color="danger" type={"submit"}>
                        {t("form.save")}
                    </Button>
                    <Button color="secondary" onClick={onClose}>
                        {t("Cancel")}
                    </Button>
                </ModalFooter>
            </AvForm>
        </Modal>
    )

}

export default PasswordModal;