import { AvField, AvForm } from "availity-reactstrap-validation"
import PropTypes from "prop-types"
import { useRef, useState } from "react"
import { withTranslation } from "react-i18next"
import { Alert, Card, CardBody, CardHeader, CardTitle, Col, Row } from "reactstrap"

const SearchItem = ({ label, onSearch, actionText, name, validators = {}, ...props }) => {
    const [pattern, setPattern] = useState("");
    const formRef = useRef();

    const handleChangeData = ({ target }) => {
        setPattern(target.value);
    }

    const displayHeader = () => {
        return (
            <CardHeader className="bg-white">
                <CardTitle tag="h5" className="mt-2">
                    {props.t("card.search")}
                </CardTitle>
            </CardHeader>
        )
    }

    const handleSubmit = (event, values) => {
        onSearch(values);
        formRef.current.reset();
    }

    return (

        <Card>
            {displayHeader()}
            <CardBody>
                <Row>
                    <Col>
                        <AvForm
                            className="form-horizontal"
                            onValidSubmit={handleSubmit}
                            ref={formRef}
                        >
                            {props.error && props.error ? (
                                <Alert color="danger">{props.error}</Alert>
                            ) : null}

                            <Row>
                                <Col md={8}>
                                    <Col className="mb-2" md={12}>
                                        <b>{label}</b>
                                    </Col>
                                    <Col>
                                        <AvField
                                            name={name}
                                            className="form-control"
                                            groupAttrs={{
                                                className: "m-0"
                                            }}
                                            placeholder={props.t('form.search')}
                                            onChange={handleChangeData}
                                            value={""}
                                            validate={{
                                                required: {
                                                    value: true,
                                                    errorMessage: props.t("This field is required"),
                                                },
                                                ...validators
                                            }}
                                        />
                                    </Col>
                                </Col>
                                <Col className="align-self-end">
                                    <button
                                        className="btn btn-primary waves-effect waves-light"
                                        type="submit"
                                    >
                                        {props.loading ? (
                                            <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2" />
                                        ) : (
                                            <i className="bx bx-search mr-2" />
                                        )}
                                        {actionText ?? props.t("form.search")}
                                    </button>
                                </Col>
                            </Row>
                        </AvForm>
                    </Col>
                </Row>
            </CardBody>
        </Card>
    )
}

SearchItem.propTypes = {
    label: PropTypes.string,
    handleSubmit: PropTypes.func,
    name: PropTypes.string
}

export default withTranslation()(SearchItem);