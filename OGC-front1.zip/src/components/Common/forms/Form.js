import { useEffect } from "react";

const { object, func } = require("prop-types");
const { useForm } = require("react-hook-form");
const { Row, Col } = require("reactstrap");

/**
 * @component
 * Représente un formulaire configuré avec une librairie de validation (actuellement react-hook-form)
 * 
 * @example
 * const data = {
 *  firstname: "John"
 * };
 * 
 * const handleSubmit = (values) => console.log(values)
 * 
 * return (
 *  <Form 
 *      data={data}
 *      onSubmit={handleSubmit}
 *      render={(control, register) => (
 *          <input type="text" {...register("firstname")} />
 *      )}
 *  />
 * )
 */
const Form = ({ 
    data = {},
    render, 
    onSubmit,  
}) => {
    const { control, register, reset, handleSubmit, formState: {isSubmitSuccessful} } = useForm({
        defaultValues: data
    });

    useEffect(() => {
        if (isSubmitSuccessful) {
            reset(data)
        }
    }, [isSubmitSuccessful, reset]);

    const handleValidSubmit = (values) => {
        onSubmit(values);
    }

    useEffect(() => {
        reset(data)
    }, [data]);

    return (
        <Row>
            <Col>
                <form
                    className="form-horizontal"
                    onSubmit={handleSubmit(handleValidSubmit)}
                >
                    {render(control, register)}
                </form>
            </Col>
        </Row>
    )
};

Form.propTypes = {
    data: object,
    render: func.isRequired,
    onSubmit: func.isRequired
}

export default Form;