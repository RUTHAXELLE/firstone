import { AvField, AvForm } from "availity-reactstrap-validation";
import { useAllAgences } from "common/hooks/useAgence";
import { ONLY_NUMBERS_PATTERN } from "common/regex/pattern";
import { useEffect, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { connect } from "react-redux";
import { Alert, Col, Row } from "reactstrap";
import useResponder from "common/hooks/useResponder";
import Form from "./forms/Form";
import Input from "./forms/Input";
import Select, { createOption } from "./forms/Select";

const isEmpty = (object) => {
    for (const property in object) {
        return false;
    }
    return true;
}

const SearchAccount = ({ onSearch, numberField = "numero", agenceField = "codeAgence", ...props }) => {
    const [isAdmin, setIsAdmin] = useState(false);

    const { t } = useTranslation();
    const agenceQuery = useAllAgences(false)

    const [initData, setInitData] = useState({
        [numberField]: "",
        [agenceField]: ""
    });

    useResponder({
        response: agenceQuery.response,
        successAction: () => {
            if (!isAdmin) {
                setInitData({
                    agency: props.user?.agenceCode
                });
            }
        }
    })

    useEffect(() => {
        agenceQuery.get();
    }, []);

    useEffect(() => {
        setIsAdmin(isEmpty(props.visibility));
    }, [props.visibility])

    const handleSubmit = (values) => {
        onSearch(values);
    }

    return (
        <Form
            data={initData}
            onSubmit={handleSubmit}
            render={(control) => (
                <>
                    <Row>
                        <Col>
                            <Col className="mb-2" md={12}>
                                <b>{t("Account number")}</b>
                            </Col>
                            <Col>
                                <Input
                                    name={numberField}
                                    className="form-control"
                                    placeholder={t('form.search')}
                                    control={control}
                                    rules={{
                                        required: {
                                            value: true,
                                            message: t("This field is required"),
                                        },
                                        pattern: {
                                            value: ONLY_NUMBERS_PATTERN,
                                            message: t("messages.error.only_number")
                                        },
                                    }}
                                />
                            </Col>
                        </Col>
                        {
                            !isAdmin && (
                                <Col>
                                    <Col className="mb-2" md={12}>
                                        <b>{t("Agency")}</b>
                                    </Col>
                                    <Col>
                                        <Select
                                            name={agenceField}
                                            disabled={!isAdmin}
                                            control={control}
                                            options={agenceQuery.response?.map((item) => {
                                                return createOption(item.address, item.code);
                                            })}
                                        />
                                    </Col>
                                </Col>
                            )
                        }
                    </Row>
                    <Row className="mt-2">
                        <Col>
                            <Col>
                                <button
                                    className="btn btn-primary waves-effect waves-light"
                                    type="submit"
                                >
                                    {props.loading ? (
                                        <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2" />
                                    ) : (
                                        <i className="bx bx-search mr-2" />
                                    )}
                                    {t("form.search")}
                                </button>
                            </Col>
                        </Col>
                    </Row>
                </>
            )}
        />
    )
}

const mapStateToProps = (state) => {
    return {
        visibility: state.user.visibility,
        user: state.user.data
    }
}

export default connect(mapStateToProps)(SearchAccount);