import React, { Component, Fragment } from "react"
import { Row, Col } from "reactstrap"
import { withTranslation } from "react-i18next"

class Footer extends Component {
  constructor(props) {
    super(props)
    this.refDiv = React.createRef()
  }

  render() {
    return (
      <Fragment>
        <footer className="footer">
          <div className="container-fluid">
            <Row>
              <Col sm={6}>{new Date().getFullYear()} © SGABS Abidjan.</Col>
              <Col sm={6}>
                <div className="text-sm-right d-none d-sm-block">
                  {this.props.t("Developed by GS - SGABS Abidjan")}
                </div>
              </Col>
            </Row>
          </div>
        </footer>
      </Fragment>
    )
  }
}

export default withTranslation()(Footer)
