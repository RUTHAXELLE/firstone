import React, { Component } from "react"
import PropTypes from "prop-types"
import { connect } from "react-redux"
import { } from "../../store/actions"

//i18n
import { withTranslation } from "react-i18next"
import SidebarContent from "./SidebarContent"
import { withRouter } from "common/hoc/withRouter"

class Sidebar extends Component {
  constructor(props) {
    super(props)
    this.state = {}
  }

  render() {
    return (
      <React.Fragment>
        {this.props.type !== "condensed" && (
          <div className="vertical-menu">
            <div data-simplebar className="h-100">
              <SidebarContent />
            </div>
          </div>
        )}
      </React.Fragment>
    )
  }
}

Sidebar.propTypes = {
  type: PropTypes.string,
}

const mapStateToProps = state => {
  return {
    layout: state.Layout,
  }
}
export default connect(
  mapStateToProps,
  {}
)(withRouter(withTranslation()(Sidebar)))
