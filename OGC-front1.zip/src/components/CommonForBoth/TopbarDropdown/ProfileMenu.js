import React, { useEffect, useState } from "react"
import PropTypes from "prop-types"
import { Dropdown, DropdownItem, DropdownMenu, DropdownToggle } from "reactstrap"
import { Link } from "react-router-dom"
import Avatar from "react-avatar"

//i18n
import { withTranslation } from "react-i18next"

// users
import { connect } from "react-redux"
import { withRouter } from "common/hoc/withRouter"
import { ROUTE_LOGIN, ROUTE_UPDATE_PASSWORD } from "helpers/route_helper"
import { logout } from "store/auth/user/userReducer"
import PasswordModal from "components/Common/PasswordModal"

const ProfileMenu = ({ ...props }) => {
  const [openDropdown, setOpenDropdown] = useState(false);

  const toggle = () => {
    setOpenDropdown(!openDropdown);
  }

  const formatName = () => {
    return `${props.user?.login}`;
  }

  return (
    <React.Fragment>
      <Dropdown
        isOpen={openDropdown}
        toggle={toggle}
        className="d-inline-block"
      >
        <DropdownToggle
          className="btn header-item waves-effect"
          id="page-header-user-dropdown"
          tag="button"
        >
          <Avatar
            className="rounded-circle"
            name={formatName()}
            alt="Header Avatar"
            size="36" />
          <span className="d-none d-xl-inline-block ml-2 mr-1">
            {formatName()}
          </span>
          <i className="mdi mdi-chevron-down d-none d-xl-inline-block" />
        </DropdownToggle>
        <DropdownMenu right>
          <DropdownItem tag="a" href={ROUTE_UPDATE_PASSWORD}>
            <i className="bx bx-user font-size-16 align-middle mr-1" />
            {props.t("Profile")}
          </DropdownItem>
          <div className="dropdown-divider" />
          <Link to={ROUTE_LOGIN} onClick={() => {
            props?.logout();
          }}>
            <i className="bx bx-power-off font-size-16 align-middle mr-1 text-danger" />
            <span >{props.t("Logout")}</span>
          </Link>
        </DropdownMenu>
      </Dropdown>
    </React.Fragment>
  )
}

ProfileMenu.propTypes = {
  t: PropTypes.any,
  checkToken: PropTypes.func,
}

const mapStateToProps = (state) => {
  return {
    user: state.user?.data
  }
}

const mapDispatchToProps = {
  logout: logout
}

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(withTranslation()(ProfileMenu))
)
