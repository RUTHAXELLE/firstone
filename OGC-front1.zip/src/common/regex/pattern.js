
export const ONLY_NUMBERS_PATTERN = "^[0-9]*$"
export const ONLY_LETTERS_SPACE_PATTERN = "^[a-zA-Z ]*$"
export const ONLY_LETTERS_NUMBERS_PATTERN = "^[a-zA-Z0-9]*$"
export const ONLY_LETTERS_NUMBERS_SPACE_PATTERN = "^[a-zA-Z0-9 ]*$"