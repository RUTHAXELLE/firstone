

export const Types_CardType = [
    {
        value: "PUCE"
    },
    {
        value: "PISTE"
    }
]