import {
  ROUTE_CARD_TYPE,
  ROUTE_CARD_TYPE_CREATE,
  ROUTE_CARD_TYPE_EDIT,
  ROUTE_FEATURE,
  ROUTE_FEATURE_CREATE,
  ROUTE_INVALID_REQUEST_STATE,
  ROUTE_MAINTENANCE,
  ROUTE_MAINTENANCE_ACCOUNT_EDIT,
  ROUTE_MAINTENANCE_CANCEL_CARD,
  ROUTE_MAINTENANCE_PRICING_EDIT,
  ROUTE_PROFILE,
  ROUTE_PROFILE_CREATE,
  ROUTE_PROFILE_EDIT,
  ROUTE_REQUEST,
  ROUTE_REQUEST_CHECK,
  ROUTE_REQUEST_CREATE,
  ROUTE_REQUEST_EDIT,
  ROUTE_REQUEST_STATE,
  ROUTE_USER,
  ROUTE_USER_CREATE,
  ROUTE_USER_EDIT,
  ROUTE_VALID_REQUEST_STATE

} from "../../helpers/route_helper"

export const Breadcrumbs = {
  USER: [
    {
      "link": ROUTE_USER,
      "title": "breadcrumbs.users",
      "short_title": "breadcrumbs.users",
      "active": true
    },
  ],
  USER_EDIT: [
    {
      "link": ROUTE_USER,
      "title": "breadcrumbs.users",
      "short_title": "breadcrumbs.users",
      "active": false
    },
    {
      "link": ROUTE_USER_EDIT,
      "title": "breadcrumbs.edit_user",
      "short_title": "breadcrumbs.edit",
      "active": true
    }
  ],
  USER_ADD: [
    {
      "link": ROUTE_USER,
      "title": "breadcrumbs.users",
      "short_title": "breadcrumbs.users",
      "active": false
    },
    {
      "link": ROUTE_USER_CREATE,
      "title": "breadcrumbs.add_user",
      "short_title": "breadcrumbs.create",
      "active": true
    }
  ],
  PROFILE: [
    {
      "link": ROUTE_PROFILE,
      "title": "breadcrumbs.profiles",
      "short_title": "breadcrumbs.profiles",
      "active": true
    }
  ],
  PROFILE_EDIT: [
    {
      "link": ROUTE_PROFILE,
      "title": "breadcrumbs.profiles",
      "short_title": "breadcrumbs.profiles",
      "active": false
    },
    {
      "link": ROUTE_PROFILE_EDIT,
      "title": "breadcrumbs.edit_profile",
      "short_title": "breadcrumbs.edit",
      "active": true
    }
  ],
  PROFILE_ADD: [
    {
      "link": ROUTE_PROFILE,
      "title": "breadcrumbs.profiles",
      "short_title": "breadcrumbs.profiles",
      "active": false
    },
    {
      "link": ROUTE_PROFILE_CREATE,
      "title": "breadcrumbs.add_profile",
      "short_title": "breadcrumbs.create",
      "active": true
    }
  ],
  FEATURE: [
    {
      "link": ROUTE_FEATURE,
      "title": "breadcrumbs.features",
      "short_title": "breadcrumbs.features",
      "active": true
    },
  ],
  FEATURE_ADD: [
    {
      "link": ROUTE_FEATURE,
      "title": "breadcrumbs.features",
      "short_title": "breadcrumbs.features",
      "active": false
    },
    {
      "link": ROUTE_FEATURE_CREATE,
      "title": "breadcrumbs.add_feature",
      "short_title": "breadcrumbs.create",
      "active": true
    }
  ],
  MAINTENANCE: [
    {
      "link": ROUTE_MAINTENANCE,
      "title": "breadcrumbs.maintenances",
      "short_title": "breadcrumbs.maintenances",
      "active": true
    }
  ],
  MAINTENANCE_CANCEL_CARD: [
    {
      "link": ROUTE_MAINTENANCE,
      "title": "breadcrumbs.maintenances",
      "short_title": "breadcrumbs.maintenances",
      "active": false
    },
    {
      "link": ROUTE_MAINTENANCE_CANCEL_CARD,
      "title": "breadcrumbs.maintenance_cancel_card",
      "short_title": "breadcrumbs.maintenance_cancel_card",
      "active": true
    }
  ],
  MAINTENANCE_PRICING_EDIT: [
    {
      "link": ROUTE_MAINTENANCE,
      "title": "breadcrumbs.maintenances",
      "short_title": "breadcrumbs.maintenances",
      "active": false
    },
    {
      "link": ROUTE_MAINTENANCE_PRICING_EDIT,
      "title": "breadcrumbs.maintenance_pricing_edit",
      "short_title": "breadcrumbs.maintenance_pricing_edit",
      "active": true
    }
  ],
  MAINTENANCE_ACCOUNT_EDIT: [
    {
      "link": ROUTE_MAINTENANCE,
      "title": "breadcrumbs.maintenances",
      "short_title": "breadcrumbs.maintenances",
      "active": false
    },
    {
      "link": ROUTE_MAINTENANCE_ACCOUNT_EDIT,
      "title": "breadcrumbs.maintenance_account_edit",
      "short_title": "breadcrumbs.maintenance_account_edit",
      "active": true
    }
  ],
  
  CARD_TYPE: [
    {
      "link": ROUTE_CARD_TYPE,
      "title": "breadcrumbs.card_type",
      "short_title": "breadcrumbs.card_type",
      "active": true
    }
  ],
  CARD_TYPE_EDIT: [
    {
      "link": ROUTE_CARD_TYPE,
      "title": "breadcrumbs.card_type",
      "short_title": "breadcrumbs.card_type",
      "active": false
    },
    {
      "link": ROUTE_CARD_TYPE_EDIT,
      "title": "breadcrumbs.edit_card_type",
      "short_title": "breadcrumbs.edit",
      "active": true
    }
  ],
  CARD_TYPE_ADD: [
    {
      "link": ROUTE_CARD_TYPE,
      "title": "breadcrumbs.card_type",
      "short_title": "breadcrumbs.card_type",
      "active": false
    },
    {
      "link": ROUTE_CARD_TYPE_CREATE,
      "title": "breadcrumbs.add_card_type",
      "short_title": "breadcrumbs.create",
      "active": true
    }
  ],
  REQUEST: [
    {
      "link": ROUTE_REQUEST,
      "title": "breadcrumbs.request",
      "short_title": "breadcrumbs.request",
      "active": true
    }
  ],
  REQUEST_EDIT: [
    {
      "link": ROUTE_REQUEST,
      "title": "breadcrumbs.request",
      "short_title": "breadcrumbs.request",
      "active": false
    },
    {
      "link": ROUTE_REQUEST_EDIT,
      "title": "breadcrumbs.edit_request",
      "short_title": "breadcrumbs.edit",
      "active": true
    }
  ],
  REQUEST_DELETE: [
    {
      "link": ROUTE_REQUEST,
      "title": "breadcrumbs.request",
      "short_title": "breadcrumbs.request",
      "active": false
    },
    {
      "link": ROUTE_REQUEST_EDIT,
      "title": "breadcrumbs.delete_request",
      "short_title": "breadcrumbs.delete",
      "active": true
    }
  ],
  REQUEST_ADD: [
    {
      "link": ROUTE_REQUEST,
      "title": "breadcrumbs.request",
      "short_title": "breadcrumbs.request",
      "active": false
    },
    {
      "link": ROUTE_REQUEST_CREATE,
      "title": "breadcrumbs.add_request",
      "short_title": "breadcrumbs.create",
      "active": true
    }
  ],
  REQUEST_STATE: [
    {
      "link": ROUTE_REQUEST,
      "title": "breadcrumbs.request",
      "short_title": "breadcrumbs.request",
      "active": false
    },
    {
      "link": ROUTE_REQUEST_STATE,
      "title": "breadcrumbs.state_request",
      "short_title": "breadcrumbs.state",
      "active": true
    }
  ],
  REQUEST_CHECKING: [
    {
      "link": ROUTE_REQUEST,
      "title": "breadcrumbs.request",
      "short_title": "breadcrumbs.request",
      "active": false
    },
    {
      "link": ROUTE_REQUEST_CHECK,
      "title": "breadcrumbs.check_request",
      "short_title": "breadcrumbs.check",
      "active": true
    }
  ],
  REQUEST_INVALID: [
    {
      "link": ROUTE_REQUEST,
      "title": "breadcrumbs.request",
      "short_title": "breadcrumbs.request",
      "active": false
    },
    {
      "link": ROUTE_INVALID_REQUEST_STATE,
      "title": "breadcrumbs.invalid_request_state",
      "short_title": "breadcrumbs.state",
      "active": true
    }
  ],
  REQUEST_VALID: [
    {
      "link": ROUTE_REQUEST,
      "title": "breadcrumbs.request",
      "short_title": "breadcrumbs.request",
      "active": false
    },
    {
      "link": ROUTE_VALID_REQUEST_STATE,
      "title": "breadcrumbs.valid_request_state",
      "short_title": "breadcrumbs.state",
      "active": true
    }
  ],
  REQUEST_WAITED: [
    {
      "link": ROUTE_REQUEST,
      "title": "breadcrumbs.request",
      "short_title": "breadcrumbs.request",
      "active": false
    },
    {
      "link": ROUTE_INVALID_REQUEST_STATE,
      "title": "breadcrumbs.waited_request",
      "short_title": "breadcrumbs.validate",
      "active": true
    }
  ],
}
