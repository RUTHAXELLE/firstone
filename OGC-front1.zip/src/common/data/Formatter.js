import ColumnHeader from "components/Common/ColumnHeader"
import RowOptions from "components/Common/RowOptions"
// Full customer name formatter
export const fullnameFormatter = (cell, row, rowIndex, formatExtraData) => {
    return (<span>{`${row.intitule ?? ""} ${row.noms} ${row.prenom}`}</span>)
}

// Customer name and civility formatter
export const surnameFormatter = (cell, row, rowIndex, formatExtraData) => {
    return (<span>{`${row.intitule ? row.intitule + "." : ""} ${row.noms}`}</span>)
}

// Full user name formater
export const fullnameUserFormatter = (cell, row, rowIndex, formatExtraData) => {
    return (<span>{`${row.nom} ${row.prenoms}`}</span>)
}

// Translate the cell
export const transFormatter = (column, colIndex, component) => {
    return (
        <ColumnHeader
            {...column}
            {...component}
        />
    )
}

export const plafondFormatter = (cell, row) => {
    let plafond = "";
    if (row.isPlafondHaut) plafond = "Haut"
    if (row.isPlafondMoyen) plafond = "Moyen"
    if (row.isPlafondBas) plafond = "Bas"
    return (
        <span>{plafond}</span>
    )
}

export const camelCaseFormatter = (cell, row) => {
    return <span className="text-capitalize">{cell}</span>
}

export const statusFormatter = (cell, row, rowIndex, formatExtraData) => {
    return cell ? "Actif" : "Suspendu"
}

// Display edit and delete buttons
export const optionsFormatter = (cell, row, rowIndex, formatExtraData) => {

    return (
        <RowOptions
            key={cell}
            {...formatExtraData}
            data={{ [formatExtraData?.id]: row?.[formatExtraData?.id] }}
            row={row}
        />
    )
}

export const columnClasses = (cell, row, rowIndex, colIndex) => {
    return "text-truncate";
}