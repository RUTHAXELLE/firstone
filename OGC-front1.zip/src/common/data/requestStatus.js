
export const request_InProgress = 1;
export const request_Valid = 2;
export const request_Invalid = 3;
export const request_Incoherent = 4;
export const request_APBATCHValidated = 5;