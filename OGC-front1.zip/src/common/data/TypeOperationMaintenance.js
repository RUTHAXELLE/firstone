
const TypeOperation = {
    cancelCard: "ANNULATIONCARTE",
    changePrice: "CHANGEMENTTARIFICATION",
    updateAccount: "MISEAJOURCOMPTE"
}

export default TypeOperation;