
const userStatus = [
    {
        value: "true",
        label: "form.status_active"
    },
    {
        value: "false",
        label: "form.status_suspend"
    }
]

export default userStatus;