
import { camelCaseFormatter, columnClasses, fullnameFormatter, plafondFormatter, surnameFormatter, transFormatter } from "./Formatter"

const datasColumns = [
  {
    text: "form.registration_number",
    dataField: "id",
    sort: true,
    hidden: true,
    headerFormatter: transFormatter,
  },
  /* {
    text: "Cardholder Name",
    dataField: "fullname",
    sort: true,
    classes: columnClasses,
    headerFormatter: transFormatter,
    formatter: fullnameFormatter,
    searchable: true
  }, */
  {
    text: "Cardholder Surname",
    dataField: "noms",
    sort: true,
    classes: columnClasses,
    headerFormatter: transFormatter,
    formatter: surnameFormatter
  },
  {
    text: "Cardholder Firstname",
    dataField: "prenom",
    sort: true,
    classes: columnClasses,
    headerFormatter: transFormatter,
  },
  {
    text: "form.operation_type",
    dataField: "codeTypeOperation",
    sort: true,
    classes: columnClasses,
    title: true,
    headerFormatter: transFormatter,
    searchable: true
  },
  {
    text: "form.agence",
    dataField: "codeAgence",
    sort: true,
    classes: columnClasses,
    formatter: camelCaseFormatter,
    title: true,
    headerFormatter: transFormatter,
    searchable: true
  },
  {
    text: "form.card_number",
    dataField: "numberCard",
    sort: true,
    classes: columnClasses,
    title: true,
    headerFormatter: transFormatter,
    searchable: true
  },
  {
    text: "form.product",
    dataField: "produit",
    sort: true,
    classes: columnClasses,
    title: true,
    headerFormatter: transFormatter,
    searchable: true
  },
  {
    text: "form.created_at",
    dataField: "createdAt",
    sort: true,
    classes: columnClasses,
    title: true,
    headerFormatter: transFormatter,
  },
  {
    text: "form.agent",
    dataField: "login",
    sort: true,
    classes: columnClasses,
    title: true,
    headerFormatter: transFormatter,
  },
]

export default datasColumns
