import { useEffect, useRef } from "react";

// Used to save and restore data when reloading
export const usePersistData = (onLoad, onUnload) => {

    const cbRef = useRef();
    cbRef.current = {
        unload: onUnload,
        load: onLoad
    }

    useEffect(() => {
        const onUnload = cbRef.current.unload;
        const onLoad = cbRef.current.load;

        window.addEventListener("beforeunload", onUnload);
        window.addEventListener("DOMContentLoaded", onLoad);
    });

    useEffect(() => {
        const onLoad = cbRef.current.load;
        const onUnload = cbRef.current.unload;

        onLoad();

        return () => {
            onUnload();
        }
    }, [])
}