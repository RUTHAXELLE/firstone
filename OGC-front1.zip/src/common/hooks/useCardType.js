import { createCardType, deleteCardType, editCardType, getAllCardTypes, searchCardTypes } from "helpers/backend_helper";
import { useRequest } from "./useHttp";

const sortFields = {
    
}

export const useAllCardTypes = (paginate = true) => {
    const {call, response, loading, error} = useRequest([], {
        hasCount: paginate
    });

    const get = (page, size, criteria) => {
        if (criteria) {
            if (criteria?.orderField) {
                criteria.orderField = sortFields[criteria?.orderField] ?? criteria?.orderField;
            }

            if (criteria?.searchField) {
                const field = criteria?.searchField;
                const value = criteria?.searchValue;
                delete criteria?.searchField;
                delete criteria?.searchValue;
                criteria[field] = value;
            }
            return call(searchCardTypes(criteria, {index: page, size}));
        }
        return call(getAllCardTypes({
            index: page, size
        }));
    }

    return {get, response, loading, error};
}

export const useCreateCardType = () => {
    const {call, response, loading, error} = useRequest();

    const create = (data) => {
        return call(createCardType(data));
    }

    return {create, response, loading, error};
}

export const useSearchCardType = () => {
    const {call, response, loading, error} = useRequest([]);

    const search = (criteria) => {
        return call(searchCardTypes(criteria));
    }

    return {search, response: response ? response[0] : null, loading, error};
}

export const useEditCardType = () => {
    const {call, response, loading, error} = useRequest();

    const edit = (data) => {
        return call(editCardType(data));
    }

    return {edit, response, loading, error};
}

export const useDeleteCardType = () => {
    const {call, response, loading, error} = useRequest();

    const del = (data) => {
        return call(deleteCardType(data));
    }

    return {del, response, loading, error};
}