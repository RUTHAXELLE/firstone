import { createFeature, deleteFeature, getAllFeatures, searchFeatures } from "helpers/backend_helper";
import { useRequest } from "./useHttp";


const sortFields = {
    
}

export const useAllFeatures = (paginate = true) => {
    const {call, response, loading, error} = useRequest([], {
        hasCount: paginate
    });

    const get = (index, size, criteria) => {
        if (criteria) {
            if (criteria?.orderField) {
                criteria.orderField = sortFields[criteria?.orderField] ?? criteria?.orderField;
            }
            return call(searchFeatures(criteria, {index, size}));
        }
        return call(getAllFeatures({index, size}));
    }

    return {get, response, loading, error};
}

export const useCreateFeature = () => {
    const {call, response, loading, error} = useRequest();

    const create = (data) => {
        return call(createFeature(data));
    }

    return {create, response, loading, error};
}

export const useSearchFeature = () => {
    const {call, response, loading, error} = useRequest([]);

    const search = (criteria) => {
        return call(searchFeatures(criteria));
    }

    return {search, response: response ? response[0] : null, loading, error};
}

export const useDeleteFeature = () => {
    const {call, response, loading, error} = useRequest();

    const del = (data) => {
        return call(deleteFeature(data));
    }

    return {del, response, loading, error};
}
