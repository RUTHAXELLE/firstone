import { generateMaintenanceApbatch, generateOrderApbatch, getLastGeneratedMaintenance, getLastOrderApbatch, validateAccountUpdateApbatch, validateMaintenanceApbatch, validateOrderApbatch } from "helpers/backend_helper";
import { useEffect } from "react";
import { useRequest } from "./useHttp"


export const useGenerateOrderAPBATCH = () => {
    const {call, response, loading, error} = useRequest();

    const generate = () => {
        return call(generateOrderApbatch());
    }

    return { generate, response, loading, error }
}

export const useValidateOrderAPBATCH = () => {
    const {call, response, loading, error} = useRequest();
    const lastGeneration = useLastGeneration(true);

    // Get last order's APBATCH generated
    const validate = () => {
        lastGeneration.get();
    }

    // When got it call to validate it
    useEffect(() => {
        if (lastGeneration.response) {
            call(validateOrderApbatch({
                id: lastGeneration.response.id,
                isValidated : true
            }))
        }
    }, [lastGeneration.response])

    return { validate, response, loading : lastGeneration.loading || loading, error : lastGeneration.error ?? error }
}

// Generate maintenance APBATCH
export const useGenerateMaintenanceAPBATCH = () => {
    const {call, response, loading, error} = useRequest();

    const generate = (type) => {
        return call(generateMaintenanceApbatch({
            codeTypeOperation: type
        }));
    }

    return { generate, response, loading, error }
}

// Validate maintenance APBATCH different from account update maintenance
export const useValidateMaintenanceAPBATCH = () => {
    const {call, response, loading, error} = useRequest();
    const query = useLastGeneratedMaintenance(true);

    const validate = (type) => {
        query.get({
            typeOperation: type
        });
    }

    useEffect(() => {
        if (query.response) {
            call(validateMaintenanceApbatch({
                id: query.response.id
            }));
        }
    }, [query.response])

    return { validate, response, loading: query.loading || loading, error: query.error ?? error }
}

// Validate account update maintenance APBATCH 
export const useValidateAccountUpdateMaintenanceAPBATCH = () => {
    const {call, response, loading, error} = useRequest();

    const validate = () => {
        return call(validateAccountUpdateApbatch());
    }

    return { validate, response, loading, error }
}

// Get last order APBATCH generated
export const useLastGeneration = (mustExist = false) => {
    const {call, response, loading, error} = useRequest(null, {
        mustExist: mustExist
    });

    const get = (criteria = {}) => {
        return call(getLastOrderApbatch(criteria))
    }

    return { get, response: response ? response[0] : response, loading, error }
}

// Get last maintenance APBATCH generated
export const useLastGeneratedMaintenance = (mustExist = false) => {
    const {call, response, loading, error} = useRequest(null, {
        mustExist: mustExist
    });

    const get = (criteria = {}) => {
        return call(getLastGeneratedMaintenance(criteria))
    }

    return { get, response: response ? response[0] : response, loading, error }
}