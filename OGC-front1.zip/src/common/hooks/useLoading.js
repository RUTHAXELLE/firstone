import { useState } from "react";

const useLoading = (value = false) => {
    const [loading, setLoading] = useState(value);

    const toggleLoader = (value) => {
        setLoading(value ?? !loading)
    }

    return [loading, toggleLoader];
}

export default useLoading;