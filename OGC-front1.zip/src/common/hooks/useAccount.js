import { searchAccount } from "helpers/backend_helper";
import { useRequest } from "./useHttp";

// Search a customer's account
export const useSearchAccount = () => {
    const {call, response, loading, error} = useRequest([], {
        mustExist: true
    });

    const search = (criteria) => {
        return call(searchAccount(criteria));
    }

    return {search, response: response ? response[0] : null, loading, error};
}