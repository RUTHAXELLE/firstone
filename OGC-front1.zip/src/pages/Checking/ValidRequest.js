
import React, { useEffect } from "react"
import { Container } from "reactstrap"
import { withTranslation } from "react-i18next"
import { withRouter } from "common/hoc/withRouter"
import { Breadcrumbs as Bs } from "common/data/breadcrumbs"
import Breadcrumbs from "components/Common/Breadcrumb"
import datasColumns from "common/data/ValidRequestColumns"
import { EntityList } from "components/Common/EntityManger"
import { useValidRequests } from "common/hooks/useRequest"
import useResponder from "common/hooks/useResponder"

const ValidRequest = ({ ...props }) => {
    const query = useValidRequests();
    useResponder({
        error: query.error,
        errorMessage: "Une erreur est survenue lors du chargement des données"
    })

    const rowEvents = {
        onClick: (e, row, rowIndex) => {

        },
        onDoubleClick: (e, row, rowIndex) => {
            console.log(row)
        }
    }

    return (
        <>
            <div className="page-content">
                <Container fluid>
                    <Breadcrumbs breadcrumbItems={Bs.REQUEST_VALID} />

                    <EntityList data={query.response} dataColumns={datasColumns} rowEvents={rowEvents} title={"card.valid_request"} onLoad={query.get} {...props} />
                </Container>
            </div>
        </>
    )
}

export default withRouter(withTranslation()(ValidRequest))
