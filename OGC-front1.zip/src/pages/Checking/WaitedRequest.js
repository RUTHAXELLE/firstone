
import React, { useEffect, useState } from "react"
import { Col, Container, Row } from "reactstrap"
import { withTranslation } from "react-i18next"
import { Breadcrumbs as Bs } from "common/data/breadcrumbs"
import Breadcrumbs from "components/Common/Breadcrumb"
import { EntityList } from "components/Common/EntityManger"
import datasColumns from "common/data/WaitedRequestColumns"
import { useInvalidRequests, useValidateRequest } from "common/hooks/useRequest"
import useResponder from "common/hooks/useResponder"

const WaitedRequest = ({ ...props }) => {
    const [selected, setSelected] = useState([]);
    const [reload, setReload] = useState();

    const invalidQuery = useInvalidRequests();
    useResponder({
        error: invalidQuery.error,
        errorMessage: "Une erreur est survenue lors du chargement des données"
    })

    const validateQuery = useValidateRequest();
    useResponder({
        response: validateQuery.response,
        error: validateQuery.error,
        successMessage: "Validation effectuée avec succès",
        errorMessage: "Erreur lors de la validation, veuillez reessayer plus tard.",
        successAction: () => setReload(!reload)
    })

    const rowEvents = {
        onClick: (e, row, rowIndex) => {

        },
        onDoubleClick: (e, row, rowIndex) => {
            console.log(row)
        },
        onSelect: (row, isSelected) => {
            const keyField = "id"
            if (isSelected) {
                setSelected([...selected, row])
            } else {
                setSelected(selected.filter((r) => r[keyField] !== row[keyField]))
            }
        }/* ,
        onSelectAll: (rows, isSelected) => {
            setSelected(isSelected ? rows : []);
        } */
    }

    const validateRequests = () => {
        validateQuery.validate(selected.map((value) => {
            return {
                id: value?.id
            };
        }))
    }

    return (
        <>
            <div className="page-content">
                <Container fluid>
                    <Breadcrumbs breadcrumbItems={Bs.REQUEST_WAITED} />

                    <EntityList
                        data={invalidQuery.response}
                        dataColumns={datasColumns}
                        rowEvents={rowEvents}
                        title={"card.waited_request"}
                        onLoad={invalidQuery.get}
                        isRowSelectable={true}
                        selectColumnTitle={"form.isValid"}
                        mustUpdate={reload}
                        {...props}
                    />

                    <Row className="mt-3">
                        <Col>
                            <button
                                className="btn btn-primary waves-effect waves-light"
                                onClick={validateRequests}
                            >
                                {validateQuery.loading ? (
                                    <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2" />
                                ) : (
                                    <i className="fas fa-save mr-2" />
                                )}
                                {props.t("form.save")}
                            </button>
                        </Col>
                    </Row>
                </Container>
            </div>
        </>
    )
}

export default withTranslation()(WaitedRequest)
