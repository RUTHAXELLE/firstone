import { Link, useLocation, useNavigate } from "react-router-dom";
import { Button, Card, CardBody, Col, Container, Row } from "reactstrap";
import profile from "../../assets/images/profile-img.png"
import logo from "../../assets/images/logo-s.png"
import { AvField, AvForm } from "availity-reactstrap-validation";
import Avatar from "react-avatar";
import { useTranslation } from "react-i18next";
import { connect } from "react-redux";
import { useChangePassword } from "common/hooks/useUsers";
import useResponder from "common/hooks/useResponder";
import { updateData } from "store/auth/user/userReducer";
import { ROUTE_DASHBOARD } from "helpers/route_helper";
import Form from "components/Common/forms/Form";
import Input from "components/Common/forms/Input";

const firstConnectionNumber = 0;

const ChangePasswordPage = ({ user, setUser, ...props }) => {
    const { t } = useTranslation();
    const navigate = useNavigate();
    const location = useLocation();
    const query = useChangePassword();

    const handleCancel = () => {
        navigate(-1);
    }

    useResponder({
        response: query.response,
        error: query.error,
        errorMessage: query.error,
        successMessage: "Votre mot de passe à été modifier avec succès",
        successAction: () => {
            setUser(query.response);
            if (user?.numberOfConnections > 1) {
                handleCancel();
            } else {
                navigate(ROUTE_DASHBOARD, { replace: true })
            }
        }
    })

    const handleSubmit = (event, values) => {
        query.change({
            id: user?.id,
            oldPassWord: location.state?.password,
            ...values
        });
    }

    return (
        <>
            <div className="home-btn d-none d-sm-block">
                <Link to={"/"} className="text-dark">
                    <i className="fas fa-home h2" />
                </Link>
            </div>
            <div className="account-pages my-5 pt-sm-5">
                <Container>
                    <Row className="justify-content-center">
                        <Col md={8} lg={6} xl={5}>
                            <Card className="overflow-hidden">
                                <div className="bg-soft-primary">
                                    <Row>
                                        <Col xs={7}>
                                            <div className="text-primary p-4">
                                                <h5 className="text-primary">{t("Reset Password")}</h5>
                                                <p>{t("Re-set password")}</p>
                                            </div>
                                        </Col>
                                        <Col xs="5" className="align-self-end">
                                            <img src={profile} alt="" className="img-fluid" />
                                        </Col>
                                    </Row>
                                </div>
                                <CardBody className="pt-0">
                                    <div>
                                        <Link to={"/"}>
                                            <div className="avatar-md profile-user-wid mb-4">
                                                <span className="avatar-title rounded-circle bg-light">
                                                    <img
                                                        src={logo}
                                                        className="rounded-circle"
                                                        alt=""
                                                        height={"34"}
                                                    />
                                                </span>
                                            </div>
                                        </Link>
                                    </div>
                                    <div className="p-2">
                                        <Form
                                            onSubmit={handleSubmit}
                                            data={{}}
                                            render={(control) => (
                                                <>
                                                    <div className="user-thumb text-center mb-4">
                                                        <Avatar
                                                            className="rounded-circle"
                                                            name={user?.login}
                                                            alt="Header Avatar"
                                                            size="36" />
                                                        <h5 className="font-size-15 mt-3">{user?.login}</h5>
                                                    </div>

                                                    {
                                                        (user?.numberOfConnections > firstConnectionNumber) && (
                                                            <div className="form-group">
                                                                <Input
                                                                    control={control}
                                                                    name="oldPassWord"
                                                                    label={t("form.old_password")}
                                                                    type="password"
                                                                    rules={{
                                                                        required: { value: true, message: t("This field is required") },
                                                                    }}
                                                                    placeholder={t("Enter Password")}
                                                                />
                                                            </div>
                                                        )
                                                    }

                                                    <div className="form-group">
                                                        <Input
                                                            control={control}
                                                            name="newPassWord"
                                                            label={t("form.new_password")}
                                                            type="password"
                                                            rules={{
                                                                required: { value: true, message: t("This field is required") },
                                                            }}
                                                            placeholder={t("form.enter_password")}
                                                        />
                                                    </div>

                                                    <div className="form-group row mb-0">
                                                        <Col xs={12} className="text-right">
                                                            {
                                                                (user?.numberOfConnections > firstConnectionNumber) && (
                                                                    <Button
                                                                        color="danger"
                                                                        className="w-md waves-effect waves-light mr-1"
                                                                        type="button"
                                                                        onClick={handleCancel}
                                                                    >
                                                                        {t("Cancel")}
                                                                    </Button>
                                                                )
                                                            }
                                                            <Button
                                                                color="primary"
                                                                className="w-md waves-effect waves-light"
                                                                type="submit"
                                                            >
                                                                {t("Update")}
                                                            </Button>
                                                        </Col>
                                                    </div>
                                                </>
                                            )}
                                        />
                                    </div>
                                </CardBody>
                            </Card>
                        </Col>
                    </Row>
                </Container>
            </div>
        </>
    )
}

const mapStateToProps = (state) => {
    return {
        user: state.user.data
    }
}

const mapDispatchToProps = {
    setUser: updateData
}

export default connect(mapStateToProps, mapDispatchToProps)(ChangePasswordPage);