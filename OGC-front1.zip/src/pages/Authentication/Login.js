import React, { Component, useEffect, useState } from "react"
import PropTypes from "prop-types"

import { Alert, Card, CardBody, Col, Container, Label, Row } from "reactstrap"
// Redux
import { connect } from "react-redux"
import { Link } from "react-router-dom"
// availity-reactstrap-validation
import { AvField, AvForm, AvInput } from "availity-reactstrap-validation"
// import images
import profile from "../../assets/images/profile-img.png"
import logo from "../../assets/images/logo-s.png"

import { withTranslation } from "react-i18next"
import { ROUTE_DASHBOARD, ROUTE_FORGET_PASSWORD, ROUTE_UPDATE_PASSWORD } from "helpers/route_helper"
import { withRouter } from "common/hoc/withRouter"
import { useLogin } from "common/hooks/useUsers"
import useResponder from "common/hooks/useResponder"
import { loadUserRole, login, logout } from "store/auth/user/userReducer"
import { useGetProfileFeatures } from "common/hooks/useProfiles"
import { CODE_DATA_NOT_EXIST } from "helpers/status_code_helper"
import Form from "components/Common/forms/Form"
import Input from "components/Common/forms/Input"

const MediaPage = () => {
  return (
    <>
      <Col xl={4}>
        <div className="auth-full-bg pt-lg-5 p-4">
          <div className="w-100">
            <div className="bg-overlay"></div>
            <div className="d-flex h-100 flex-column">
              <div className="py-5 px-4 mt-auto">
                <div className="row justify-content-center">
                  <div className="col-lg-7">

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Col>
    </>
  )
}

const Login = ({ ...props }) => {
  const service = useLogin();
  const roleService = useGetProfileFeatures();
  const [password, setPassword] = useState("");

  // handle login query response
  useResponder({
    response: service.response,
    error: service.error,
    successMessage: "Authentification effectuée avec succes",
    errorMessage: service.error?.code === CODE_DATA_NOT_EXIST ? "Login ou mot de passe incorrect. Si le problème persiste, merci de vous rapprocher de l'administrateur s'il vous plaît" : service.error,
    successAction: () => {
      props.login(service.response);
      // After logged user, load his roles
      roleService.get({
        code: service.response?.roleCode
      });
    },
  })

  // handle role query response
  useResponder({
    response: roleService.response.length,
    error: service.error,
    successAction: () => {

      props.setRole({
        role: {
          code: service.response?.roleCode,
          libelle: service.response?.roleLibelle
        },
        features: roleService.response
      })

      //Redirect user on app
      if (props?.navigate)
        if (service.response?.numberOfConnections > 0) {
          console.log(props?.location)
          props.navigate(props?.location?.state?.from ?? ROUTE_DASHBOARD, {
            replace: true
          });
        }
        else
          props.navigate(ROUTE_UPDATE_PASSWORD, {
            replace: true,
            state: {
              password: password
            }
          });
    },
    message: roleService.error,
    errorAction: () => {
      props.logout();
    }
  })

  // handleValidSubmit
  const handleValidSubmit = (values) => {
    setPassword(values?.password);
    service.login(values);

    /* const navigate = (to, arg) => {
      console.log(to);
      props.navigate(to, arg);
    }
    props.loginUser(values, navigate) */
  }

  /**
   * Gestion des inputs du formulaire
   *
   * @param target
   */
  const handleChangeInput = ({ target }) => {
  }

  return (
    <React.Fragment>
      <div>
        <Container fluid className="p-0">
          <Row className="no-gutters">
            <MediaPage />

            <Col>
              <div className="auth-full-page-content p-md-5 p-4">
                <div className="w-100">
                  <div className="d-flex flex-column h-100">
                    <div className="my-auto">

                      <div className="account-pages my-3 pt-sm-3">
                        <Container>
                          <Row className="justify-content-center">
                            <Col md={6}>
                              <Card className="overflow-hidden">
                                <div className="bg-soft-primary">
                                  <Row>
                                    <Col className="col-7">
                                      <div className="text-primary p-4">
                                        <h5 className="text-primary">{props.t("Welcome Back !")}</h5>
                                        <p>{props.t("Sign in to continue to OGC")}</p>
                                      </div>
                                    </Col>
                                    <Col className="col-5 align-self-end">
                                      <img src={profile} alt="" className="img-fluid" />
                                    </Col>
                                  </Row>
                                </div>
                                <CardBody className="pt-0">
                                  <div>
                                    <Link to="/">
                                      <div className="avatar-md profile-user-wid mb-4">
                                        <span className="avatar-title rounded-circle bg-light">
                                          <img
                                            src={logo}
                                            alt=""
                                            height="34"
                                          />
                                        </span>
                                      </div>
                                    </Link>
                                  </div>
                                  <div className="p-2">
                                    <Form
                                      onSubmit={handleValidSubmit}
                                      data={{
                                        login: "",
                                        password: ""
                                      }}
                                      render={(control) => (
                                        <>
                                          <div className="form-group">
                                            <Label>
                                              {props.t("form.login")}
                                            </Label>
                                            <Input
                                              name="login"
                                              label={props.t("form.login")}
                                              control={control}
                                              className="form-control"
                                              placeholder={props.t("form.placeholder_login")}
                                              rules={{
                                                required: { value: true, message: props.t("This field is required") },
                                              }}
                                            />
                                          </div>

                                          <div className="form-group">
                                            <Label>
                                              {props.t("form.password")}
                                            </Label>
                                            <Input
                                              name="password"
                                              label={props.t("form.password")}
                                              control={control}
                                              type="password"
                                              rules={{
                                                required: { value: true, message: props.t("This field is required") },
                                                minLength: { value: 2, message: props.t("Your password must contain at least 2 characters") },
                                              }}
                                              placeholder={props.t("form.placeholder_password")}
                                            />
                                          </div>

                                          <div className="mt-3">
                                            <button
                                              className="btn btn-primary btn-block waves-effect waves-light"
                                              type="submit">
                                              {props.t("Log In")}{" "}
                                              {props.loading ? (<i className="bx bx-loader bx-spin font-size-16 align-middle mr-2" />) : ("")}
                                            </button>
                                          </div>
                                        </>
                                      )}
                                    />
                                  </div>
                                </CardBody>
                              </Card>
                            </Col>
                          </Row>
                        </Container>
                      </div>

                    </div>
                  </div>
                </div>
              </div>
            </Col>
          </Row>
        </Container>
      </div>
    </React.Fragment>
  )
}

Login.propTypes = {
  apiError: PropTypes.any,
  error: PropTypes.any,
  navigate: PropTypes.func,
  loginUser: PropTypes.func
}

const mapDispatchToProps = {
  login: login,
  logout: logout,
  setRole: loadUserRole
}

const mapStateToProps = (state) => {
  return {
    user: state.user
  }
}

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(withTranslation()(Login))
)
