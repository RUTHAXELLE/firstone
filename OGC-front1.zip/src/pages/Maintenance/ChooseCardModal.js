import { columnClasses, fullnameFormatter, transFormatter } from "common/data/Formatter";
import { useSearchCard } from "common/hooks/useCard";
import useResponder from "common/hooks/useResponder";
import { EntityList } from "components/Common/EntityManger";
import { createRowEvent } from "components/Common/SearchTable";
import { useState } from "react";
import BootstrapTable from "react-bootstrap-table-next";
import paginationFactory from "react-bootstrap-table2-paginator";
import { Button, Col, ListGroup, ListGroupItem, Modal, ModalBody, ModalFooter, ModalHeader, Row } from "reactstrap";

const { useTranslation } = require("react-i18next");


const columns = [
    {
        text: "form.id",
        dataField: "id",
        sort: true,
        hidden: true,
        headerFormatter: transFormatter

    },
    {
        text: "form.card_number",
        dataField: "code",
        sort: true,
        headerFormatter: transFormatter,
        searchable: true
    },
    {
        text: "form.fullname",
        dataField: "fullname",
        sort: true,
        headerFormatter: transFormatter,
        formatter: fullnameFormatter,
    },
    {
        text: "form.tarification",
        dataField: "typeCarteLibelle",
        sort: true,
        classes: columnClasses,
        title: true,
        headerFormatter: transFormatter,
        searchable: true
    },
]


const ChooseCardModal = ({ account, onChoose, opened, onClose }) => {
    const { t } = useTranslation();
    const [selectedCard, setSelectedCard] = useState(null);
    const [reload, setReload] = useState(false);

    const query = useSearchCard();
    useResponder({
        response: query.response,
        error: query.error,
        successAction: () => {
            console.log(query.response);
        },
    })

    const handleCardSelected = (card) => {
        setSelectedCard(card);
    }

    const handleChooseCard = () => {
        onChoose(selectedCard);
        onClose();
    }

    const handleQuery = (index, size, criteria) => {
        console.log(criteria)
        query?.search({
            ...criteria,
            ...account
        }, index, size);
    }

    const rowEvents = createRowEvent(selectedCard, handleCardSelected, "id", false);

    return (
        <Modal isOpen={opened} toggle={onClose} size={"lg"}>
            <ModalHeader toggle={onClose}>{t("form.list_card")}</ModalHeader>
            <ModalBody>
                <div>
                <EntityList
                    inCard={false}
                    data={query?.response}
                    dataColumns={columns}
                    rowEvents={rowEvents}
                    title={"card.waited_request"}
                    onLoad={handleQuery}
                    isRowSelectable={true}
                    mustUpdate={reload}
                    multiselect={false}
                    selected={selectedCard ? [selectedCard?.id] : []}
                />
                </div>
                {/* <ListGroup>
                    {
                        query?.response?.map((card) => (
                            <ListGroupItem
                                action
                                key={card?.code}
                                tag={"button"}
                                onClick={() => handleCardSelected(card)}
                                active={selectedCard?.code === card?.code}
                            >
                                <Row>
                                    <Col>
                                        {card?.code}
                                    </Col>
                                    <Col>
                                        {card?.typeCarteLibelle}
                                    </Col>
                                    <Col>
                                        {formatFullname(card)}
                                    </Col>
                                </Row>
                            </ListGroupItem>
                        ))
                    }
                </ListGroup> */}
            </ModalBody>
            <ModalFooter>
                <Button color="primary" onClick={handleChooseCard}>
                    {t("form.choose")}
                </Button>{' '}
                <Button color="secondary" onClick={onClose}>
                    {t("Cancel")}
                </Button>
            </ModalFooter>
        </Modal>
    )
}

export default ChooseCardModal;