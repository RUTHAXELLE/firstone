import React, { useState } from "react"
import { useTranslation, withTranslation } from "react-i18next"
import { withRouter } from "common/hoc/withRouter"
import { EntityList, EntityPage } from "components/Common/EntityManger"
import { useAllMaintenanceRequest, useDeleteOperation, useGetMaintenances } from "common/hooks/useCard"
import datasColumns from "common/data/RegisteredCardColumns"
import TypeOperation from "common/data/TypeOperationMaintenance"
import { useNavigate } from "react-router-dom"
import useResponder from "common/hooks/useResponder"
import { optionsFormatter, transFormatter } from "common/data/Formatter"
import { PERMISSION_OPERATION_CREATE, PERMISSION_OPERATION_DELETE } from "helpers/permission_helper"

import { Button, Col, Dropdown, FormGroup, Input, Label } from "reactstrap"
import Granted from "components/Common/Granted"
import { ROUTE_MAINTENANCE_ACCOUNT_EDIT, ROUTE_MAINTENANCE_CANCEL_CARD, ROUTE_MAINTENANCE_PRICING_EDIT } from "helpers/route_helper"
import { AvField } from "availity-reactstrap-validation"

const RequestList = withRouter(withTranslation()(({ query, onAdd, ...props }) => {

  const [operation, setOperation] = useState(ROUTE_MAINTENANCE_CANCEL_CARD);

  const deleteQuery = useDeleteOperation();
  const [mustUpdate, setMustUpdate] = useState();

  useResponder({
    response: deleteQuery.response,
    error: deleteQuery.error,
    errorMessage: "Une erreur est survenue lors de la suppression",
    successMessage: "La suppression a été effectuée avec succès",
    successAction: () => {
      setMustUpdate(!mustUpdate);
    }
  });

  const rowEvents = {
    onClick: (e, row, rowIndex) => {

    },
    onDoubleClick: (e, row, rowIndex) => {
      console.log(row)
    }
  }

  const handleAdd = () => {
    props.navigate(operation);
  }

  const handleEdit = () => {
    //Add navigation for edit form
  }

  const handleChangeOperation = ({ target: {value} }) => {
    setOperation(value);
  }

  const renderAddButton = () => {
    return (
      <div className="d-flex">
        <Col md={9}>
          <FormGroup className="m-0">
            <Label>
              {props.t("Select an operation")}
            </Label>
            <Input
              name="operation"
              type="select"
              onChange={handleChangeOperation}
              value={operation}
            >
              <option value={ROUTE_MAINTENANCE_CANCEL_CARD}>
                {props.t("Cancel card")}
              </option>
              <option value={ROUTE_MAINTENANCE_PRICING_EDIT}>
                {props.t("Edit pricing")}
              </option>
              <option value={ROUTE_MAINTENANCE_ACCOUNT_EDIT}>
                {props.t("Edit account")}
              </option>
            </Input>
          </FormGroup>
        </Col>
        <Col className="align-self-end">
          <Button onClick={handleAdd} color="success">{props.t("add")}</Button>
        </Col>
      </div>
    )
  }

  const addActions = () => {
    return [
      ...datasColumns,
      {
        text: "actions",
        dataField: "action",
        formatter: optionsFormatter,
        headerFormatter: transFormatter,
        formatExtraData: {
          onEdit: handleEdit,
          editPermission: PERMISSION_OPERATION_DELETE,
          onDelete: deleteQuery.del,
          id: "id",
          deletePermission: PERMISSION_OPERATION_DELETE
        }
      }
    ];
  }

  return (
    <>
      <Granted
        permission={PERMISSION_OPERATION_DELETE}
        errorComponent={
          <EntityList
            data={query.response}
            dataColumns={datasColumns}
            rowEvents={rowEvents}
            title={"card.list_maintenance_request"}
            onLoad={query.get}
            mustUpdate={mustUpdate}
            renderAdd={renderAddButton}
            addPermission={PERMISSION_OPERATION_CREATE}
            {...props}
          />
        }
      >
        <EntityList
          data={query.response}
          dataColumns={addActions()}
          rowEvents={rowEvents}
          title={"card.list_maintenance_request"}
          onLoad={query.get}
          mustUpdate={mustUpdate}
          renderAdd={renderAddButton}
          addPermission={PERMISSION_OPERATION_CREATE}
          {...props}
        />
      </Granted>
    </>
  )
}))

export const MaintenanceRequestList = ({ breadCrumb, ...props }) => {
  return (
    <EntityPage
      breadCrumb={breadCrumb}
    >
      <RequestList query={useAllMaintenanceRequest()} {...props} />
    </EntityPage>
  )
}
