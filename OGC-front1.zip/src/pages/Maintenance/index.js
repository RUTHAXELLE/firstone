import { useCancelCard, useDeleteOperation, useEditAccount, useEditPricing } from "common/hooks/useCard"
import { ONLY_NUMBERS_PATTERN } from "common/regex/pattern"
import { AddEntity } from "components/Common/EntityManger"
import { default as SearchItem } from "components/Common/SearchItem"
import { useState } from "react"
import { withTranslation } from "react-i18next"
import AccountUpdateForm from "./AccountUpdateForm"
import CancelForm from "./CancelForm"
import { CancelCardList, ChangePricingList, MaintenanceRequestList, UpdateAccountList } from "./CardList"
import ChangeTarificationForm from "./ChangeTarificationForm"
import SearchCard from "./SearchCard"
import { Breadcrumbs } from "common/data/breadcrumbs"
import { useNavigate } from "react-router-dom"
import { ROUTE_MAINTENANCE } from "helpers/route_helper"

const props = {
    onDelete: useDeleteOperation
}

export const CancelCardPage = withTranslation()(() => {
    const [card, setCard] = useState(null);
    const navigate = useNavigate();

    const handleSuccessCreate = () => {
        navigate(ROUTE_MAINTENANCE);
    }

    const formatData = (data) => {
        return {
            card_number: data?.code,
            card_label: data?.libelle,
            tarification: data?.typeCarteLibelle
        }
    }

    const useCancel = () => {
        const { cancel, response, loading, error } = useCancelCard();

        const create = () => {

            return cancel({
                carteId: card?.id,
                agent: "agent01"
            })

        }

        return { create, response, loading, error }
    }

    const handleFound = (found) => {
        console.log(found)
        setCard(found)
    }

    return (
        <AddEntity top={(
            <SearchCard onFound={handleFound} />
        )} data={formatData(card)} {...props} breadCrumb={Breadcrumbs.MAINTENANCE_CANCEL_CARD} onSuccessCreate={handleSuccessCreate} Form={CancelForm} onCreate={useCancel} />
    )
})

export const ListMaintenancePage = withTranslation()(() => {
    return (
        <MaintenanceRequestList breadCrumb={Breadcrumbs.MAINTENANCE} />
    )
})

export const ChangeTarificationPage = withTranslation()(() => {
    const [card, setCard] = useState(null);
    const navigate = useNavigate();

    const handleSuccessCreate = () => {
        navigate(ROUTE_MAINTENANCE);
    }

    const handleFound = (found) => {
        setCard(found)
    }

    const formatData = (data) => {
        return {
            card_number: data?.code,
            card_label: data?.libelle,
            tarification: data?.typeCarteLibelle
        }
    }

    const useEdit = () => {
        const query = useEditPricing();

        const create = (data) => {

            return query.edit({
                carteId: card?.id,
                agent: "agent01",
                codeTypeCarte: data?.tarification
            })

        }

        return { create, response: query.response, loading: query.loading, error: query.error }
    }

    return (
        <AddEntity top={(
            <SearchCard onFound={handleFound} />
        )} data={formatData(card)} {...props} breadCrumb={Breadcrumbs.MAINTENANCE_PRICING_EDIT} onSuccessCreate={handleSuccessCreate} Form={ChangeTarificationForm} onCreate={useEdit} />
    )
})

export const AccountUpdatePage = withTranslation()(() => {
    const [card, setCard] = useState(null);
    const navigate = useNavigate();

    const handleSuccessCreate = () => {
        navigate(ROUTE_MAINTENANCE);
    }

    const handleFound = (found) => {
        setCard(found)
    }

    const formatData = (data) => {
        return {
            card_number: data?.code,
            card_label: data?.libelle,
            tarification: data?.typeCarteLibelle,
            numeroCompte: data?.numeroCompte,
            agence: data?.codeAgenceCarte
        }
    }

    const useEdit = () => {
        const query = useEditAccount();

        const create = (data) => {

            return query.edit({
                carteId: card?.id,
                numeroCompte: data?.account,
                codeAgence: data?.agenceCode,
                agent: "agent 01"
            })

        }

        return { create, response: query.response, loading: query.loading, error: query.error }
    }

    return (
        <AddEntity top={(
            <SearchCard onFound={handleFound} />
        )} data={formatData(card)} {...props} breadCrumb={Breadcrumbs.MAINTENANCE_ACCOUNT_EDIT} onSuccessCreate={handleSuccessCreate} Form={AccountUpdateForm} onCreate={useEdit} />
    )
})