import { AvField, AvForm, AvGroup, AvInput } from "availity-reactstrap-validation"
import { useSearchAccount } from "common/hooks/useAccount"
import { useSearchCard } from "common/hooks/useCard"
import useResponder from "common/hooks/useResponder"
import SearchAccount from "components/Common/SearchAccount"
import PropTypes from "prop-types"
import { useRef, useState } from "react"
import { useTranslation } from "react-i18next"
import { Alert, Card, CardBody, CardHeader, CardTitle, Col, Label, Row } from "reactstrap"
import ChooseCardModal from "./ChooseCardModal"

const SearchCard = ({ onFound, ...props }) => {
    const { t } = useTranslation()
    const formRef = useRef();
    const [byAccount, setByAccount] = useState(true);
    const [openModal, setOpenModal] = useState(false);

    // search by account criteria
    const [account, setAccount] = useState(null);

    const initialFormValue = {
        by: true
    }

    const query = useSearchCard();
    useResponder({
        response: query.response,
        error: query.error,
        errorMessage: "Aucune carte ne correspond à ce compte",
        successAction: () => {
            console.log(query.response);
            if (byAccount) {
                toggleModal();
            } else {
                onFound(query.response?.items[0]);
            }
            resetForm();
        },
        errorAction: () => {
            resetForm();
        }
    });

    // Search account query
    const accountQuery = useSearchAccount();
    useResponder({
        response: accountQuery.response,
        error: accountQuery.error, 
        errorMessage: "Aucun compte de correspond à votre requête",
        successAction: () => {
            const values = {
                numeroCompte: accountQuery.response?.numero
            }
            setAccount(values);
            toggleModal();
        },
        errorAction: () => {
            setAccount(null);
            resetForm();
        }
    });

    const toggleModal = () => {
        setOpenModal(!openModal);
    }

    const resetForm = () => {
        if (!byAccount)
            formRef.current.reset();
        setByAccount(true);
    }

    const displayHeader = () => {
        return (
            <CardHeader className="bg-white">
                <CardTitle tag="h5" className="mt-2">
                    {t("card.search")}
                </CardTitle>
            </CardHeader>
        )
    }

    const handleSearch = (values) => {
        if (byAccount) {
            accountQuery.search(values);
        } else {
            query.search(values);
        }
    }

    const handleSubmit = (event, values) => {
        handleSearch(values)
    }

    const handleSearchBy = () => {
        setByAccount(!byAccount)
    }

    return (

        <>
            <Card>
                {displayHeader()}
                <CardBody>
                    <Row>
                        <Col>
                            {
                                (byAccount) ? (
                                    <SearchAccount onSearch={handleSearch} />
                                ) : (
                                    <AvForm
                                        className="form-horizontal"
                                        onValidSubmit={handleSubmit}
                                        ref={formRef}
                                        model={initialFormValue}
                                    >
                                        {props.error && props.error ? (
                                            <Alert color="danger">{props.error}</Alert>
                                        ) : null}
                                        <Row>
                                            <Col md={8}>
                                                <Col className="mb-2" md={12}>
                                                    <b>{t("form.card_number")}</b>
                                                </Col>
                                                <Col>
                                                    <AvField
                                                        name={"code"}
                                                        className="form-control"
                                                        placeholder={t('form.search')}
                                                        groupAttrs={{
                                                            className: "m-0"
                                                        }}
                                                        value={""}
                                                        validate={{
                                                            required: {
                                                                value: true,
                                                                errorMessage: t("This field is required"),
                                                            },
                                                        }}
                                                    />
                                                </Col>
                                            </Col>
                                            <Col className="align-self-end">
                                                <button
                                                    className="btn btn-primary waves-effect waves-light"
                                                    type="submit"
                                                >
                                                    {props.loading ? (
                                                        <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2" />
                                                    ) : (
                                                        <i className="bx bx-search mr-2" />
                                                    )}
                                                    {t("form.search")}
                                                </button>
                                            </Col>
                                        </Row>
                                    </AvForm>
                                )
                            }
                            <Row className="mt-2">
                                <Col>
                                    <Col>
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" name="by" checked={byAccount} onChange={handleSearchBy} />
                                            <label className="form-check-label">
                                                {t("form.by_account")}
                                            </label>
                                        </div>
                                    </Col>
                                </Col>
                            </Row>
                        </Col>
                    </Row>
                </CardBody>
            </Card>
            <ChooseCardModal opened={openModal} account={account} onChoose={onFound} onClose={toggleModal} />
        </>
    )
}

SearchCard.propTypes = {
    label: PropTypes.string,
    handleSubmit: PropTypes.func,
    name: PropTypes.string
}

export default SearchCard;