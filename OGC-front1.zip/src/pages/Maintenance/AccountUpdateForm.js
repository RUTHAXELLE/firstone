import { AvField } from "availity-reactstrap-validation"
import { useAllAgences } from "common/hooks/useAgence"
import { ONLY_NUMBERS_PATTERN } from "common/regex/pattern"
import { EntityForm, FormEntity } from "components/Common/EntityManger"
import Input from "components/Common/forms/Input"
import Select, { createOption } from "components/Common/forms/Select"
import { useEffect, useState } from "react"
import { withTranslation } from "react-i18next"
import { CardHeader, CardTitle, Col, Row } from "reactstrap"

const AccountUpdateForm = ({ onSubmit, data = null, ...props }) => {

    const query = useAllAgences(false)

    const [initData, setInitData] = useState({});

    useEffect(() => {
        if (data) {
            setInitData({
                card_number: data?.card_number ?? "",
                card_label: data?.card_label ?? "",
                tarification: data?.tarification ?? "",
                account: data?.numeroCompte ?? "",
                agenceCode: data?.agence ?? ""
            });
        }
    }, [data])

    useEffect(() => {
        query.get();
    }, [])

    return (
        <FormEntity
            onSubmit={onSubmit}
            initialData={initData}
            {...props}
            header={() => {
                return (
                    <CardHeader className="bg-white">
                        <CardTitle tag="h5" className="mt-2">
                            {`${props.t("card.edit_account")}`}
                        </CardTitle>
                    </CardHeader>
                )
            }}
            render={(control) => (
                <>
                    <Row>
                        <Col>
                            <Col className="mb-3" md={12}>
                                <b>{props.t('form.card_number')}</b>
                            </Col>
                            <Col>
                                <Input
                                    name="card_number"
                                    className="form-control"
                                    placeholder={props.t('form.card_number')}
                                    control={control}
                                    disabled={true}
                                    rules={{
                                        required: {
                                            value: true,
                                            message: props.t("This field is required"),
                                        },
                                    }}
                                />
                            </Col>
                        </Col>
                        <Col>
                            <Col className="mb-3" md={12}>
                                <b>{props.t('form.card_label')}</b>
                            </Col>
                            <Col>
                                <Input
                                    name="card_label"
                                    className="form-control"
                                    placeholder={props.t('form.card_label')}
                                    control={control}
                                    disabled={true}
                                    rules={{
                                        required: {
                                            value: true,
                                            message: props.t("This field is required"),
                                        },
                                    }}
                                />
                            </Col>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <Col className="mb-3" md={12}>
                                <b>{props.t('form.tarification')}</b>
                            </Col>
                            <Col>
                                <Input
                                    name="tarification"
                                    className="form-control"
                                    placeholder={props.t('form.tarification')}
                                    control={control}
                                    disabled={true}
                                    rules={{
                                        required: {
                                            value: true,
                                            message: props.t("This field is required"),
                                        },
                                    }}
                                />
                            </Col>
                        </Col>
                        <Col>
                            <Col className="mb-3" md={12}>
                                <b>{props.t('form.account_number')}</b>
                            </Col>
                            <Col>
                                <Input
                                    name="account"
                                    className="form-control"
                                    placeholder={props.t('form.account_number')}
                                    control={control}
                                    rules={{
                                        required: {
                                            value: true,
                                            message: props.t("This field is required"),
                                        },
                                        pattern: {
                                            value: ONLY_NUMBERS_PATTERN,
                                            message: props.t("messages.error.only_number")
                                        }
                                    }}
                                />
                            </Col>
                        </Col>
                        <Col>
                                <Col className="mb-3 px-0" md={12}>
                                    <b>{props.t("form.agence")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Select
                                        name="agenceCode"
                                        control={control}
                                        placeholder={props.t("form.select_agence")}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                        }}
                                        options={query.response?.map((item, i) => {
                                            return createOption(item.code, item.code);
                                        })}
                                    />
                                </Col>
                            </Col>
                    </Row>
                    <Row className="mt-3">
                        <Col>
                            <button
                                className="btn btn-primary waves-effect waves-light"
                                type="submit"
                            >
                                {props.loading ? (
                                    <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2" />
                                ) : (
                                    <i className="fas fa-save mr-2" />
                                )}
                                {props.t("form.save")}
                            </button>
                        </Col>
                    </Row>
                </>
            )}
        />
    )
}

export default withTranslation()(AccountUpdateForm)