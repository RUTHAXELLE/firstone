import React, { Component } from "react"
import { Card, CardBody, Col, Row } from "reactstrap"
import ReactApexChart from "react-apexcharts"
import { withTranslation } from "react-i18next"
import picto from "../../assets/images/picto.png"

class CardUser extends Component {
  constructor(props) {
    super(props)
    this.state = {}
  }


  options = {
    chart: {
      height: 350,
      type: "area",
      toolbar: {
        show: false
      }
    },
    colors: ["#80fa47", "#fc8d38"],
    dataLabels: {
      enabled: false
    },
    stroke: {
      curve: "smooth",
      width: 2
    },
    fill: {
      type: "gradient",
      gradient: {
        shadeIntensity: 1,
        inverseColors: false,
        opacityFrom: 0.45,
        opacityTo: 0.05,
        stops: [20, 100, 100, 100]
      }
    },
    xaxis: {
      categories: [
        "March",
        "June",
        "September",
        "December"
      ]
    },
    markers: {
      size: 3,
      strokeWidth: 3,

      hover: {
        size: 4,
        sizeOffset: 2
      }
    },
    legend: {
      position: "top",
      horizontalAlign: "right"
    }
  }

  render() {
    const { t, stats, cardreport } = this.props
    return (
      <React.Fragment>
        <Col xl={8}>
          <Row>
            <Col lg={6}>
              <Card className="blog-stats-wid">
                <CardBody>
                  <div className="d-flex flex-wrap">
                    <div className="mr-3">
                      <p className="text-muted mb-2">{t('Positive experiences')}</p>
                      <h5 className="mb-0">{ stats?.positive?.total }</h5>
                    </div>

                    <div className="avatar-sm ml-auto">
                      <div className="avatar-title bg-positive rounded-circle text-primary font-size-20">
                        <img src={picto} alt="" style={{ width: "20px" }}/>
                      </div>
                    </div>
                  </div>
                </CardBody>
              </Card>
            </Col>
            <Col lg={6}>
              <Card className="blog-stats-wid">
                <CardBody>
                  <div className="d-flex flex-wrap">
                    <div className="mr-3">
                      <p className="text-muted mb-2">{t('Perfectible experiences')}</p>
                      <h5 className="mb-0">{ stats?.perfectible?.total }</h5>
                    </div>

                    <div className="avatar-sm ml-auto">
                      <div className="avatar-title bg-perfectible rounded-circle text-primary font-size-20">
                        <img src={picto} alt="" style={{ width: "20px" }}/>
                      </div>
                    </div>
                  </div>
                </CardBody>
              </Card>
            </Col>
          </Row>

          <Card>
            <CardBody>
              <div className="d-flex flex-wrap">
                <h5 className="card-title mr-2">{t('Experience')}</h5>
                {/*<div className="ml-auto">
                  <div className="toolbar button-items text-right">
                    <button type="button" className="btn btn-light btn-sm">
                      ALL
                    </button>
                    <button type="button" className="btn btn-light btn-sm">
                      1M
                    </button>
                    <button type="button" className="btn btn-light btn-sm">
                      6M
                    </button>
                    <button
                      type="button"
                      className="btn btn-light btn-sm active"
                    >
                      1Y
                    </button>
                  </div>
                </div>*/}
              </div>

              {/*<Row className="text-center">
                <Col lg={4}>
                  <div className="mt-4">
                    <p className="text-muted mb-1">Today</p>
                    <h5>1024</h5>
                  </div>
                </Col>

                <Col lg={4}>
                  <div className="mt-4">
                    <p className="text-muted mb-1">This Month</p>
                    <h5>
                      12356{" "}
                      <span className="text-success font-size-13">
                        0.2 % <i className="mdi mdi-arrow-up ml-1"></i>
                      </span>
                    </h5>
                  </div>
                </Col>

                <Col lg={4}>
                  <div className="mt-4">
                    <p className="text-muted mb-1">This Year</p>
                    <h5>
                      102354{" "}
                      <span className="text-success font-size-13">
                        0.1 % <i className="mdi mdi-arrow-up ml-1"></i>
                      </span>
                    </h5>
                  </div>
                </Col>
              </Row>*/}

              <hr className="mb-4" />
              <div className="apex-charts" id="area-chart" dir="ltr">
                <ReactApexChart
                  options={this.props.cardreport.options}
                  series={this.props.cardreport.series}
                  type="area"
                  height={350}
                />
              </div>
            </CardBody>
          </Card>
        </Col>
      </React.Fragment>
    )
  }
}

export default withTranslation()(CardUser)
