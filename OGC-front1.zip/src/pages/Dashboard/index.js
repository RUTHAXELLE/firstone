import React from "react"
import { Col, Container, Row } from "reactstrap"
import { withTranslation } from "react-i18next"
import cards from "../../assets/images/K2.png"

const Dashboard = () => {
  return (
    <React.Fragment>
      <div className="page-content bg-white">
        <Container fluid>
          <div>
            <img
              src={cards}
              className="mx-auto d-block img-fluid"
            />
          </div>
        </Container>
      </div>
    </React.Fragment>
  )
}

export default withTranslation()(Dashboard)