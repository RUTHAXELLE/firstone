import { Breadcrumbs } from "common/data/breadcrumbs"
import { useCreateUser, useEditUser, useSearchUser } from "common/hooks/useUsers"
import { ONLY_LETTERS_NUMBERS_PATTERN } from "common/regex/pattern"
import { AddEntity, EditEntity } from "components/Common/EntityManger"
import { default as SearchItem } from "components/Common/SearchItem"
import { ROUTE_USER } from "helpers/route_helper"
import { useEffect, useState } from "react"
import { withTranslation } from "react-i18next"
import { useNavigate, useParams } from "react-router-dom"
import UserForm from "./UserForm"
import UserList from "./UserList"


const SearchUser = withTranslation()(({ onSearch, ...props }) => {
    return (
        <SearchItem label={props.t("form.login")} onSearch={onSearch} name="login" validators={{
            pattern: {
                value: ONLY_LETTERS_NUMBERS_PATTERN,
                errorMessage: props.t("messages.error.only_letter_number")
            }
        }} />
    )
})

const props = {
    Form: UserForm,
    List: UserList,
    Search: SearchUser,
    onCreate: useCreateUser,
    onSearch: useSearchUser,
    onEdit: useEditUser
}

export const AddUserPage = () => {
    const navigate = useNavigate();

    const handleSuccessCreate = () => {
        navigate(ROUTE_USER);
    }
    return (
        <AddEntity breadCrumb={Breadcrumbs.USER_ADD} onSuccessCreate={handleSuccessCreate} {...props} />
    )
}

export const EditUserPage = () => {
    const navigate = useNavigate();
    const {id} = useParams();
    const [mustSearch, setMustSearch] = useState(true);

    const handleSuccessEdit = () => {
        navigate(ROUTE_USER);
    }

    useEffect(() => {
        setMustSearch(!mustSearch);
    }, [id]);

    return (
        <EditEntity breadCrumb={Breadcrumbs.USER_EDIT} id={{id: id}} mustSearch={mustSearch} onSuccessEdit={handleSuccessEdit} {...props} />
    )
}

export const ListUserPage = () => {
    return (
        <UserList breadCrumb={Breadcrumbs.USER} />
    )
}