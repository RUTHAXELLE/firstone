import React, { useEffect, useRef, useState } from "react"
import {
    CardHeader,
    CardTitle,
    Col,
    FormGroup,
    Label,
    Row,
    Input as RInput
} from "reactstrap"
import { withTranslation } from "react-i18next"
import "toastr/build/toastr.min.css"
import { withRouter } from "common/hoc/withRouter"
import PropTypes from "prop-types"
import userStatus from "common/data/userStatus"
import { useAllAgences } from "common/hooks/useAgence"
import { useAllProfiles } from "common/hooks/useProfiles"
import { FormEntity } from "components/Common/EntityManger"
import { ONLY_LETTERS_SPACE_PATTERN } from "common/regex/pattern"
import { generatePassword } from "helpers/form_helper"
import { SYS_ADMIN_PROFILE } from "config"
import { connect } from "react-redux"
import Input from "components/Common/forms/Input"
import Select, { createOption } from "components/Common/forms/Select"

const UserForm = ({ loading = false, add = true, data = null, onSubmit, ...props }) => {

    const [mustReset, setMustReset] = useState(false);
    const passwordInputRef = useRef();

    const profileQuery = useAllProfiles(false)
    const agenceQuery = useAllAgences(false)

    const [initData, setInitData] = useState({
        nom: data?.nom ?? "",
        prenoms: data?.prenoms ?? "",
        login: data?.login ?? "",
        agenceId: data?.agenceId,
        roleId: profileQuery.response?.find((profile, index) => {
            return profile.code === data?.roleCode
        })?.id,
        isActif: data?.isActif
    });

    useEffect(() => {
        profileQuery.get();
        agenceQuery.get();
    }, [])

    const handleResetPassword = ({ target }) => {
        setMustReset(target.checked)
    }

    // Return only profils that aren't SYSADMIN profil either user's profil
    const handleProfilList = () => {
        return profileQuery.response?.filter((value) => {
            return value?.code !== SYS_ADMIN_PROFILE && value?.code !== props?.user?.roleCode;
        }) ?? [];
    }

    useEffect(() => {
        if (data) {
            console.log(data)
            setInitData({
                nom: data?.nom ?? "",
                prenoms: data?.prenoms ?? "",
                login: data?.login ?? "",
                agenceId: data?.agenceId,
                roleId: profileQuery.response?.find((profile, index) => {
                    return profile.code === data?.roleCode
                })?.id,
                isActif: `${data?.isActif}`
            });
        }
    }, [data])

    const handleSubmit = (data) => {
        data.isActif = data?.isActif === "true";
        console.log(data)
        //onSubmit(data);
    }

    return (

        <>
            <FormEntity
                {...props}
                initialData={initData}
                header={(user) => {
                    if (!add) {
                        return (
                            <CardHeader className="bg-white">
                                <CardTitle tag="h5" className="mt-2">
                                    {data ? `${props.t("card.edit_user")}: ${data?.nom} ${data?.prenoms}` : `${props.t("card.edit_user")}`}
                                </CardTitle>
                            </CardHeader>
                        )
                    } else {
                        return (
                            <CardHeader className="bg-white">
                                <CardTitle tag="h5" className="mt-2">
                                    {props.t("Add user")}
                                </CardTitle>
                            </CardHeader>
                        )
                    }
                }}
                onSubmit={handleSubmit}
                render={(control) => (
                    <>
                        <Row className="mb-2">
                            <Col>
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t('form.lastname')}</b>
                                </Col>
                                <Col className="px-0">
                                    <Input
                                        name={"nom"}
                                        control={control}
                                        className="form-control"
                                        placeholder={props.t('form.lastname')}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                            pattern: {
                                                value: ONLY_LETTERS_SPACE_PATTERN,
                                                message: props.t("messages.error.only_letter_space")
                                            }
                                        }}
                                    />
                                </Col>
                            </Col>
                            <Col>
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t('form.firstname')}</b>
                                </Col>
                                <Col className="px-0">
                                    <Input
                                        name="prenoms"
                                        control={control}
                                        className="form-control"
                                        placeholder={props.t('form.firstname')}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                            pattern: {
                                                value: ONLY_LETTERS_SPACE_PATTERN,
                                                message: props.t("messages.error.only_letter_space")
                                            }
                                        }}
                                    />
                                </Col>
                            </Col>
                        </Row>

                        <Row className="mb-2">
                            <Col>
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t("form.login")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Input
                                        name="login"
                                        control={control}
                                        className="form-control"
                                        placeholder={props.t("form.login")}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                            pattern: {
                                                value: ONLY_LETTERS_SPACE_PATTERN,
                                                message: props.t("messages.error.only_letter_space")
                                            }
                                        }}
                                    />
                                </Col>
                            </Col>
                            <Col>
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t("form.agence")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Select
                                        control={control}
                                        name="agenceId"
                                        placeholder={props.t("form.select_agence")}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                        }}
                                        options={agenceQuery.response?.map((item, i) => {
                                            return createOption(item.address, item.id);
                                        })}
                                    />
                                </Col>
                            </Col>
                        </Row>

                        <Row className="mb-2">
                            <Col>
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t("form.profile")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Select
                                        control={control}
                                        name="roleId"
                                        placeholder={props.t("form.select_profile")}
                                        rules={{
                                            required: { 
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                        }}
                                        options={handleProfilList()?.map((item, i) => {
                                            return createOption(item.libelle, item.id);
                                        })}
                                    />
                                </Col>
                            </Col>
                            <Col>
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t("form.status")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Select
                                        control={control}
                                        name="isActif"
                                        placeholder={props.t("form.select_status")}
                                        type="select"
                                        validate={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                        }}
                                        options={userStatus.map((item, i) => {
                                            return createOption(props.t(item.label), item.value)
                                        })}
                                    />
                                </Col>
                            </Col>
                        </Row>
                        {
                            !add && (
                                <Row className="mb-2">
                                    <Col>
                                        <FormGroup check>
                                            <Label check>
                                                <RInput type="checkbox" name="resetPassword" onChange={handleResetPassword} /> {props.t("form.reset_password")}
                                            </Label>
                                        </FormGroup>
                                        {
                                            mustReset && (
                                                <Row className="mt-3">
                                                    <Col className="">
                                                        <Input
                                                            control={control}
                                                            innerRef={passwordInputRef}
                                                            name="password"
                                                            placeholder={props.t("form.new_password")}
                                                            type="text"
                                                            rules={{
                                                                required: {
                                                                    value: true,
                                                                    message: props.t("This field is required"),
                                                                },
                                                                minLength: {
                                                                    value: 8,
                                                                    message: props.t("messages.error.min8")
                                                                }
                                                            }}
                                                        />
                                                    </Col>
                                                    <Col className="align-items-end">
                                                        <button type="button" className="btn btn-secondary waves-effect waves-light" onClick={() => generatePassword(passwordInputRef)}>
                                                            {props.t("form.generate_password")}
                                                        </button>
                                                    </Col>
                                                </Row>
                                            )
                                        }
                                    </Col>
                                </Row>
                            )
                        }

                        <Row className="mt-3">
                            <Col>
                                <button
                                    className="btn btn-primary waves-effect waves-light"
                                    type="submit"
                                >
                                    {props.loading ? (
                                        <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2" />
                                    ) : (
                                        <i className="fas fa-save mr-2" />
                                    )}
                                    {props.t("form.save")}
                                </button>
                            </Col>
                        </Row>
                    </>
                )}
            />
        </>
    )
}

UserForm.propTypes = {
    add: PropTypes.bool,
    user: PropTypes.object
}

const mapStateToProps = (state) => {
    return {
        user: state?.data?.data
    }
}

export default withRouter(withTranslation()(connect(mapStateToProps)(UserForm)))
