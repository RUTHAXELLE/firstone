import { AvField, AvForm } from "availity-reactstrap-validation";
import { useState } from "react";
import { withTranslation } from "react-i18next"
import { Alert, Card, CardBody, CardHeader, CardTitle, Col, Row } from "reactstrap";
import PropTypes from "prop-types"
import { Types_CardType } from "common/data/CardTypeType";


const SearchCardType = ({onSearch, ...props}) => {
    const [patterns, setPatterns] = useState({});

    const handleChangeData = ({ target }) => {
        setPatterns({
            ...patterns,
            [target.name]: target.value
        });
    }

    const displayHeader = () => {
        return (
            <CardHeader className="bg-white">
                <CardTitle tag="h5" className="mt-2">
                    {props.t("card.search")}
                </CardTitle>
            </CardHeader>
        )
    }

    const handleSubmit = (event, values) => {
        onSearch(values);
    }

    return (

        <Card>
            {displayHeader()}
            <CardBody>
                <Row>
                    <Col>
                        <AvForm
                            className="form-horizontal"
                            onValidSubmit={handleSubmit}
                        >
                            {props.error && props.error ? (
                                <Alert color="danger">{props.error}</Alert>
                            ) : null}

                            <Row>
                                <Col>
                                    <Col className="mb-2" md={12}>
                                        <b>{props.t("form.type_card")}</b>
                                    </Col>
                                    <Col>
                                        <AvField
                                            name="typeCarte"
                                            className="form-control"
                                            placeholder={props.t('form.type_card')}
                                            onChange={handleChangeData}
                                            value={""}
                                            validate={{
                                                required: {
                                                    value: true,
                                                    errorMessage: props.t("This field is required"),
                                                },
                                            }}
                                        />
                                    </Col>
                                </Col>
                                <Col>
                                    <Col className="mb-2" md={12}>
                                        <b>{props.t("form.type_gen")}</b>
                                    </Col>
                                    <Col>
                                        <AvField
                                            name="typeGen"
                                            className="form-control"
                                            placeholder={props.t('form.type_gen')}
                                            onChange={handleChangeData}
                                            value={""}
                                            validate={{
                                                required: {
                                                    value: true,
                                                    errorMessage: props.t("This field is required"),
                                                },
                                            }}
                                        />
                                    </Col>
                                </Col>
                                <Col>
                                    <Col className="mb-2 px-0" md={12}>
                                        <b>{props.t("form.type")}</b>
                                    </Col>
                                    <Col className="px-0">
                                        <AvField
                                            name="type"
                                            onChange={handleChangeData}
                                            type="select"
                                            validate={{
                                                required: {
                                                    value: true,
                                                    errorMessage: props.t("This field is required"),
                                                },
                                            }}
                                        >
                                            <option value="">
                                                {props.t("form.select_type")}
                                            </option>
                                            {Types_CardType.map((item, i) => (
                                                <option key={i} value={item.value}>{item.value}</option>
                                            ))}
                                        </AvField>
                                    </Col>
                                </Col>
                                <Col className="align-self-center">
                                    <button
                                        className="btn btn-primary waves-effect waves-light"
                                        type="submit"
                                    >
                                        {props.loading ? (
                                            <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2" />
                                        ) : (
                                            <i className="bx bx-search mr-2" />
                                        )}
                                        {props.t("form.search")}
                                    </button>
                                </Col>
                            </Row>
                        </AvForm>
                    </Col>
                </Row>
            </CardBody>
        </Card>
    )
}

SearchCardType.propTypes = {
    handleSubmit: PropTypes.func
}

export default withTranslation()(SearchCardType);