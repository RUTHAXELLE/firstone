import Breadcrumbs from "components/Common/Breadcrumb"
import { withTranslation } from "react-i18next"
import { Card, CardBody, CardHeader, CardTitle, Col, Container, Row } from "reactstrap"
import Generate from "./generate"
import MaintenanceForm from "./maintenanceForm"
import Validate from "./validate"
import { useEffect, useState } from "react"
import { useGenerateMaintenanceAPBATCH, useGenerateOrderAPBATCH, useLastGeneration, useValidateAccountUpdateMaintenanceAPBATCH, useValidateMaintenanceAPBATCH, useValidateOrderAPBATCH } from "common/hooks/useAPBATCH"
import useResponder from "common/hooks/useResponder"
import { EntityPage } from "components/Common/EntityManger"
import TypeOperation from "common/data/TypeOperationMaintenance"


export const GenerateOrderPage = withTranslation()(({ ...props }) => {

    const { generate, response, loading, error } = useGenerateOrderAPBATCH();
    useResponder({
        response,
        error, 
        successMessage: "Génération effectuée avec succès", 
        errorMessage: "Erreur lors de la generation, veuillez reessayer plus tard."
    })

    return (
        <EntityPage>
            <Generate onSubmit={generate} title={props.t("card.generate_order_apbatch")} loading={loading} />
        </EntityPage>
    )
})

export const ValidateOrderPage = withTranslation()(({ ...props }) => {

    const { validate, response, loading, error } = useValidateOrderAPBATCH();
    useResponder({
        response, 
        error, 
        successMessage: "Validation effectuée avec succès", 
        errorMessage: "Erreur lors de la validation, veuillez reessayer plus tard."
    })

    return (
        <EntityPage>
            <Validate title={props.t("card.validate_order_apbatch")} onSubmit={validate} loading={loading} />
        </EntityPage>
    )
})

export const GenerateMaintenancePage = withTranslation()(({ ...props }) => {
    const [type, setType] = useState(TypeOperation.cancelCard);
    const { generate, response, loading, error } = useGenerateMaintenanceAPBATCH();
    useResponder({
        response, 
        error, 
        successMessage: "Génération effectuée avec succès", 
        errorMessage: "Erreur lors de la generation, veuillez reessayer plus tard."
    })

    const handleProcess = () => {
        generate(type)
    }

    return (
        <EntityPage>
            <MaintenanceForm type={type} setType={setType} />
            <Generate title={props.t("card.generate_maintenance_apbatch")} onSubmit={handleProcess} loading={loading} />
        </EntityPage>
    )
})

export const ValidateMaintenancePage = withTranslation()(({ ...props }) => {
    const [type, setType] = useState(TypeOperation.cancelCard);
    const { validate, response, loading, error } = useValidateMaintenanceAPBATCH();
    useResponder({
        response, 
        error, 
        successMessage: "Validation effectuée avec succès", 
        errorMessage: "Erreur lors de la validation, veuillez reessayer plus tard."
    })

    const query = useValidateAccountUpdateMaintenanceAPBATCH();
    useResponder({
        response: query.response, 
        error: query.error, 
        successMessage: "Validation effectuée avec succès", 
        errorMessage: "Erreur lors de la validation, veuillez reessayer plus tard."
    })

    const handleProcess = () => {
        if (type !== TypeOperation.updateAccount)
            validate(type)
        else 
            query.validate();
    }

    return (
        <EntityPage>
            <MaintenanceForm type={type} setType={setType} />
            <Validate title={props.t("card.validate_maintenance_apbatch")} onSubmit={handleProcess} loading={loading} />
        </EntityPage>
    )
})

export const LastGenerationPage = withTranslation()(({ ...props }) => {

    const { get, response, loading, error } = useLastGeneration();
    useResponder({
        error, 
        errorMessage: "Erreur lors du chargement, veuillez reessayer plus tard."
    })

    useEffect(() => {
        get();
    }, []);

    return (
        <EntityPage>
            <Card>
                <CardHeader className="bg-white">
                    <CardTitle tag="h5">{props.t("card.generation_validated")}</CardTitle>
                </CardHeader>
                <CardBody>
                    <Row className="mt-3">
                        {
                            response ? (
                                <Col>
                                    <p>Information de la dernière génération du fichier;</p>
                                    <p>Nom fichier généré : {response ? response.fileName : ""}</p>
                                    <p>Chemin fichier généré : {response ? response.libelle : ""}</p>
                                    <p>Date génération : {response ? response.createdAt : ""}</p>
                                </Col>
                            ) : (
                                <Col>
                                    <p>Aucune génération</p>
                                </Col>
                            )
                        }
                    </Row>
                </CardBody>
            </Card>
        </EntityPage>
    )
})