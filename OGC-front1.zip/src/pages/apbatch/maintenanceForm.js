import TypeOperation from "common/data/TypeOperationMaintenance";
import { withTranslation } from "react-i18next";

const { Input, FormGroup, Label, Col, Row, CardBody, CardTitle, Card, CardHeader } = require("reactstrap");


const MaintenanceTypeForm = ({type, setType, ...props}) => {

    const handleChange = ({target}) => {
        setType(target.value);
    }

    return (
        <Card>
            <CardHeader className="bg-white">
                <CardTitle tag="h5">{props.t("card.maintenance_type")}</CardTitle>
            </CardHeader>
            <CardBody>
                <Row className="mt-3">
                    <Col>
                        <FormGroup check>
                            <Input
                                name="cancel_card"
                                type="radio"
                                value={TypeOperation.cancelCard}
                                checked={type === TypeOperation.cancelCard}
                                onChange={handleChange}
                            />
                            {' '}
                            <Label check>
                                {props.t("form.cancel_card")}
                            </Label>
                        </FormGroup>
                        <FormGroup check>
                            <Input
                                name="change_tarif"
                                type="radio"
                                value={TypeOperation.changePrice}
                                checked={type === TypeOperation.changePrice}
                                onChange={handleChange}
                            />
                            {' '}
                            <Label check>
                                {props.t("form.change_tarif")}
                            </Label>
                        </FormGroup>
                        <FormGroup
                            check
                        >
                            <Input
                                name="update_account"
                                type="radio"
                                value={TypeOperation.updateAccount}
                                checked={type === TypeOperation.updateAccount}
                                onChange={handleChange}
                            />
                            {' '}
                            <Label check>
                                {props.t("form.update_account")}
                            </Label>
                        </FormGroup>
                    </Col>
                </Row>
            </CardBody>
        </Card>
    )
}

export default withTranslation()(MaintenanceTypeForm);