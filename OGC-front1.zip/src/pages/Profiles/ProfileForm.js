import React, { useEffect, useState } from "react"
import {
    CardHeader,
    CardTitle,
    Col,
    Row,
} from "reactstrap"
import { withTranslation } from "react-i18next"
import { AvField } from "availity-reactstrap-validation"
import "toastr/build/toastr.min.css"
import { withRouter } from "common/hoc/withRouter"
import PropTypes from "prop-types"
import { EntityForm, EntityList, FormEntity } from "components/Common/EntityManger"
import { useAllFeatures } from "common/hooks/useFeatures"
import useResponder from "common/hooks/useResponder"
import datasColumns from "common/data/FeatureColumns"
import { createRowEvent } from "components/Common/SearchTable"
import Input from "components/Common/forms/Input"

const ProfileForm = ({ loading = false, add = true, data = null, onSubmit, onRemove, ...props }) => {
    const [features, setFeatures] = useState([]);
    const query = useAllFeatures();

    const [initData, setInitData] = useState({});

    useResponder({
        error: query.error,
        errorMessage: "Une erreur est survenue lors du chargement des données"
    })

    useEffect(() => {
        return () => {
            setFeatures([]);
        }
    }, []);

    useEffect(() => {
        if (data) {
            setInitData({
                code: data?.code ?? "",
                libelle: data?.libelle
            });

            if (data?.datasFunctionalities)
                setFeatures(data?.datasFunctionalities?.map((feature) => feature?.id));
        }
    }, [data])

    const keyField = "id"
    const rowEvents = createRowEvent(features, setFeatures, keyField);

    const handleSubmit = (data) => {
        onSubmit({
            ...data,
            datasFunctionalities: features.map((feature) => {
                return {
                    id: feature
                }
            })
        });
        setFeatures([]);
    }

    const handleLoad = (index, size) => {
        query.get(index, size);
    }

    return (

        <>
            <FormEntity
                onSubmit={handleSubmit}
                initialData={initData}
                {...props}
                header={(profile) => {
                    if (!add) {
                        return (
                            <CardHeader className="bg-white">
                                <CardTitle tag="h5" className="mt-2">
                                    {profile ? `${props.t("card.edit_profile")}: ${profile?.code}` : `${props.t("card.edit_profile")}`}
                                </CardTitle>
                            </CardHeader>
                        )
                    } else {
                        return (
                            <CardHeader className="bg-white">
                                <CardTitle tag="h5" className="mt-2">
                                    {props.t("card.create_profile")}
                                </CardTitle>
                            </CardHeader>
                        )
                    }
                }}
                render={(control) => (
                    <>
                        <Row className="mb-2">
                            <Col className="mb-2" md={12}>
                                <b>{props.t('form.code')}</b>
                            </Col>
                            <Col>
                                <Input
                                    control={control}
                                    name="code"
                                    className="form-control"
                                    placeholder={props.t('form.code')}
                                    rules={{
                                        required: {
                                            value: true,
                                            message: props.t("This field is required"),
                                        },
                                    }}
                                />
                            </Col>
                        </Row>

                        <Row className="mb-2">
                            <Col>
                                <Col className="mb-2 px-0" md={12}>
                                    <b>{props.t("form.label")}</b>
                                </Col>
                                <Col className="px-0">
                                    <Input
                                        name="libelle"
                                        className="form-control"
                                        control={control}
                                        placeholder={props.t("form.label")}
                                        rules={{
                                            required: {
                                                value: true,
                                                message: props.t("This field is required"),
                                            },
                                        }}
                                    />
                                </Col>
                            </Col>
                        </Row>

                        <EntityList
                            data={query.response}
                            dataColumns={datasColumns}
                            rowEvents={rowEvents}
                            title={"card.feature_list"}
                            onLoad={handleLoad}
                            mustUpdate={true}
                            isRowSelectable={true}
                            selected={features}
                        />

                        <Row className="mt-3">
                            <Col>
                                <button
                                    className="btn btn-primary waves-effect waves-light"
                                    type="submit"
                                >
                                    {props.loading ? (
                                        <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2" />
                                    ) : (
                                        <i className="fas fa-save mr-2" />
                                    )}
                                    {props.t("form.save")}
                                </button>
                            </Col>
                            {
                                (!add && onRemove) && (
                                    <Col md={11}>
                                        <button
                                            className="btn btn-danger waves-effect waves-light"
                                            type="button"
                                            onClick={onRemove}
                                        >
                                            {props.loading ? (
                                                <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2" />
                                            ) : (
                                                <i className="fas fa-trash mr-2" />
                                            )}
                                            {props.t("form.delete")}
                                        </button>
                                    </Col>
                                )
                            }
                        </Row>
                    </>
                )}
            />
        </>
    )
}

ProfileForm.propTypes = {
    add: PropTypes.bool,
    profile: PropTypes.object
}

export default withRouter(withTranslation()(ProfileForm))
