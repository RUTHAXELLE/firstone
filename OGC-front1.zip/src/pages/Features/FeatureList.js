import React, { useState } from "react"
import { withTranslation } from "react-i18next"
import { withRouter } from "common/hoc/withRouter"
import { useAllFeatures, useDeleteFeature } from "common/hooks/useFeatures"
import datasColumns from "common/data/FeatureColumns"
import { EntityList, EntityPage } from "components/Common/EntityManger"
import useResponder from "common/hooks/useResponder"
import { optionsFormatter, transFormatter } from "common/data/Formatter"
import { useNavigate } from "react-router-dom"
import { PERMISSION_FEATURE_CREATE, PERMISSION_FEATURE_DELETE } from "helpers/permission_helper"
import { ROUTE_FEATURE_CREATE } from "helpers/route_helper"
import Granted from "components/Common/Granted"

const FeatureList = ({ breadCrumb, ...props }) => {
  const query = useAllFeatures();
  const deleteQuery = useDeleteFeature();
  const [mustUpdate, setMustUpdate] = useState();
  const navigate = useNavigate();

  useResponder({
    error: query.error,
    errorMessage: "Une erreur est survenue lors du chargement des données"
  });

  useResponder({
    response: deleteQuery.response,
    error: deleteQuery.error,
    errorMessage: "Une erreur est survenue lors de la suppression",
    successMessage: "La suppression a été effectuée avec succès",
    successAction: () => {
      setMustUpdate(!mustUpdate);
    }
  });

  const handleAdd = () => {
    navigate(ROUTE_FEATURE_CREATE);
  }

  const rowEvents = {
    onClick: (e, row, rowIndex) => {

    },
    onDoubleClick: (e, row, rowIndex) => {
      console.log(row)
    }
  }

  const addActions = () => {
    return [
      ...datasColumns,
      {
        text: "actions",
        dataField: "action",
        formatter: optionsFormatter,
        headerFormatter: transFormatter,
        formatExtraData: {
          onDelete: deleteQuery.del,
          id: "id",
          deletePermission: PERMISSION_FEATURE_DELETE
        }
      }
    ];
  }



  return (
    <EntityPage
      breadCrumb={breadCrumb}
    >
      <Granted
        permission={PERMISSION_FEATURE_DELETE}
        errorComponent={
          <EntityList
            data={query.response}
            dataColumns={datasColumns}
            rowEvents={rowEvents}
            title={"card.feature_list"}
            onLoad={query.get}
            mustUpdate={mustUpdate}
            onAdd={handleAdd}
            addPermission={PERMISSION_FEATURE_CREATE}
            {...props}
          />
        }
      >
        <EntityList
          data={query.response}
          dataColumns={addActions()}
          rowEvents={rowEvents}
          title={"card.feature_list"}
          onLoad={query.get}
          mustUpdate={mustUpdate}
          onAdd={handleAdd}
          addPermission={PERMISSION_FEATURE_CREATE}
          {...props}
        />
      </Granted>
    </EntityPage>
  )
}

export default withRouter(withTranslation()(FeatureList))
