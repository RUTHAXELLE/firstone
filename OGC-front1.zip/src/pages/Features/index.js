import { Breadcrumbs } from "common/data/breadcrumbs"
import { useCreateFeature } from "common/hooks/useFeatures"
import { AddEntity } from "components/Common/EntityManger"
import { ROUTE_FEATURE } from "helpers/route_helper"
import { useNavigate } from "react-router-dom"
import FeatureForm from "./FeatureForm"
import FeatureList from "./FeatureList"


const props = {
    Form: FeatureForm,
    onCreate: useCreateFeature,
}

export const AddFeaturePage = () => {
    const navigate = useNavigate();

    const handleSuccessCreate = () => {
        navigate(ROUTE_FEATURE);
    }

    return (
        <AddEntity breadCrumb={Breadcrumbs.FEATURE_ADD} onSuccessCreate={handleSuccessCreate} {...props} />
    )
}

export const ListFeaturePage = () => {

    return (
        <FeatureList breadCrumb={Breadcrumbs.FEATURE} />
    )
}