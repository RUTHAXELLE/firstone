import React from "react"
import {
    CardHeader,
    CardTitle,
    Col,
    Row,
} from "reactstrap"
import { withTranslation } from "react-i18next"
import { AvField } from "availity-reactstrap-validation"
import "toastr/build/toastr.min.css"
import { withRouter } from "common/hoc/withRouter"
import PropTypes from "prop-types"
import { EntityForm } from "components/Common/EntityManger"

const FeatureForm = ({ loading = false, add = true, data = null, onSubmit, ...props }) => {

    return (

        <>
            <EntityForm
                onSubmit={onSubmit}
                data={data}
                {...props}
                header={(feature) => {
                    if (!add) {
                        return (
                            <CardHeader className="bg-white">
                                <CardTitle tag="h5" className="mt-2">
                                    {feature ? `${props.t("card.edit_feature")}: ${feature?.code}` : `${props.t("card.edit_feature")}`}
                                </CardTitle>
                            </CardHeader>
                        )
                    } else {
                        return (
                            <CardHeader className="bg-white">
                                <CardTitle tag="h5" className="mt-2">
                                    {props.t("card.create_feature")}
                                </CardTitle>
                            </CardHeader>
                        )
                    }
                }}
                render={(handleChangeData, feature) => (
                    <>
                        <Row>
                            <Col className="mb-3" md={12}>
                                <b>{props.t('form.code')}</b>
                            </Col>
                            <Col>
                                <AvField
                                    name="code"
                                    className="form-control"
                                    placeholder={props.t('form.code')}
                                    onChange={handleChangeData}
                                    value={feature?.code ?? ""}
                                    validate={{
                                        required: {
                                            value: true,
                                            errorMessage: props.t("This field is required"),
                                        },
                                    }}
                                />
                            </Col>
                        </Row>

                        <Row>
                            <Col>
                                <Col className="mb-3 px-0" md={12}>
                                    <b>{props.t("form.label")}</b>
                                </Col>
                                <Col className="px-0">
                                    <AvField
                                        name="libelle"
                                        className="form-control"
                                        placeholder={props.t("form.label")}
                                        onChange={handleChangeData}
                                        value={feature?.address}
                                        validate={{
                                            required: {
                                                value: true,
                                                errorMessage: props.t("This field is required"),
                                            },
                                        }}
                                    />
                                </Col>
                            </Col>
                        </Row>

                        <Row className="mt-3">
                            <Col>
                                <button
                                    className="btn btn-primary waves-effect waves-light"
                                    type="submit"
                                >
                                    {props.loading ? (
                                        <i className="bx bx-loader bx-spin font-size-16 align-middle mr-2" />
                                    ) : (
                                        <i className="fas fa-save mr-2" />
                                    )}
                                    {props.t("form.save")}
                                </button>
                            </Col>
                        </Row>
                    </>
                )}
            />
        </>
    )
}

FeatureForm.propTypes = {
    add: PropTypes.bool,
    feature: PropTypes.object
}

export default withRouter(withTranslation()(FeatureForm))
