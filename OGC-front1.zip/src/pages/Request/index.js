import { Breadcrumbs } from "common/data/breadcrumbs"
import { useSearchAccount } from "common/hooks/useAccount"
import { useCreateRequest, useDeleteRequest, useEditRequest, useSearchRequest, useUnValidatedRequest } from "common/hooks/useRequest"
import useResponder from "common/hooks/useResponder"
import { ONLY_NUMBERS_PATTERN } from "common/regex/pattern"
import { AddEntity, DeleteEntity, EditEntity } from "components/Common/EntityManger"
import SearchAccount from "components/Common/SearchAccount"
import { default as SearchItem } from "components/Common/SearchItem"
import { ROUTE_REQUEST } from "helpers/route_helper"
import { useEffect, useState } from "react"
import { withTranslation } from "react-i18next"
import { useNavigate, useParams } from "react-router-dom"
import { Card, CardBody, CardHeader, CardTitle, Col, Row } from "reactstrap"
import RequestForm from "./RequestForm"
import { AllRequestList } from "./RequestList"


const SearchRequest = withTranslation()(({ onSearch, ...props }) => {
    return (
        <SearchItem label={props.t("form.registration_number")} onSearch={onSearch} name="id" validators={{
            pattern: {
                value: ONLY_NUMBERS_PATTERN,
                errorMessage: props.t("messages.error.only_number")
            }
        }} />
    )
})

const SearchRequestByAccount = withTranslation()(({ onSearch, ...props }) => {
    const displayHeader = () => {
        return (
            <CardHeader className="bg-white">
                <CardTitle tag="h5" className="mt-2">
                    {props.t("card.search")}
                </CardTitle>
            </CardHeader>
        )
    }

    return (

        <Card>
            {displayHeader()}
            <CardBody>
                <Row>
                    <Col>
                        <SearchAccount 
                            onSearch={onSearch}
                        />
                    </Col>
                </Row>
            </CardBody>
        </Card>
    )
})

const DeleteRequest = withTranslation()(({ onSearch, ...props }) => {
    return (
        <SearchItem label={props.t("form.registration_number")} actionText={props.t("form.delete")} onSearch={onSearch} name="id" validators={{
            pattern: {
                value: ONLY_NUMBERS_PATTERN,
                errorMessage: props.t("messages.error.only_number")
            }
        }} />
    )
})

const props = {
    Form: RequestForm,
    List: AllRequestList,
    Search: SearchRequest,
    onCreate: useCreateRequest,
    onSearch: useSearchRequest,
    onEdit: useEditRequest,
    onDelete: useDeleteRequest
}

export const AddRequestPage = () => {
    const [account, setAccount] = useState(null);
    const query = useSearchAccount();

    const navigate = useNavigate();

    useResponder({
        response: query.response,
        error: query.error, 
        errorMessage: "Aucun compte de correspond à votre requête",
        successAction: () => setAccount(query.response),
        errorAction: () => setAccount(null)
    });

    const handleSearch = (pattern) => {
        query.search(pattern);
    }

    const handleSuccessCreate = () => {
        navigate(ROUTE_REQUEST);
    }

    const formatData = (data) => {
        return {
            noms: data?.nomClient,
            prenom: data?.prenomsClient,
            numeroCompte: data?.numero,
            civiliteClient: data?.civiliteClient ?? undefined
        }
    }

    return (
        <AddEntity breadCrumb={Breadcrumbs.REQUEST_ADD} top={(
            <SearchRequestByAccount onSearch={handleSearch} />
        )} data={formatData(account)} onSuccessCreate={handleSuccessCreate} {...props} />
    )
}

export const EditRequestPage = () => {
    const navigate = useNavigate();
    const {id} = useParams();
    const [mustSearch, setMustSearch] = useState(true);

    const handleSuccessEdit = () => {
        navigate(ROUTE_REQUEST);
    }

    useEffect(() => {
        setMustSearch(!mustSearch);
    }, [id]);

    return (
        <EditEntity breadCrumb={Breadcrumbs.REQUEST_EDIT} id={{id: id}} mustSearch={mustSearch} onSuccessEdit={handleSuccessEdit} {...props} />
    )
}

export const DeleteRequestPage = () => {
    return (
        <DeleteEntity breadCrumb={Breadcrumbs.REQUEST_DELETE} {...props} Search={DeleteRequest} />
    )
}

export const ListRequestPage = () => {
    return (
        <AllRequestList breadCrumb={Breadcrumbs.REQUEST} {...props} />
    )
}