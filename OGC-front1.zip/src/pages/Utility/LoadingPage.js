import PreLoader from "components/CommonForBoth/PreLoader";


const LoadingPage = () => {

    return (
        <PreLoader />
    );
}

export default LoadingPage;