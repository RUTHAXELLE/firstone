import React, { Component } from "react"
import PropTypes from "prop-types"
import { BrowserRouter as Router, Route, Routes } from "react-router-dom"
import { connect } from "react-redux"

// Import Routes
import { authProtectedRoutes, publicRoutes } from "./routes/"
import AppRoute from "./routes/route"

// layouts
import VerticalLayout from "./components/VerticalLayout/"
import HorizontalLayout from "./components/HorizontalLayout/"
import NonAuthLayout from "./components/NonAuthLayout"

// Import scss
import "./assets/scss/theme.scss"
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';

// Import fackbackend Configuration file
import Pages404 from "./pages/Utility/pages-404"
import { usePersistData } from "common/hooks/usePersistance"
import { restoreRole, storeRole } from "store/auth/roles/roleReducer"
import { restoreUser, storeUser } from "store/auth/user/userReducer"
import LoadingPage from "pages/Utility/LoadingPage"

const App = ({ ...props }) => {

  usePersistData(() => props.restoreUser(), () => props.storeUser());
  usePersistData(() => props.restoreRole(), () => props.storeRole());

  /**
   * Returns the layout
   */
  const getLayout = () => {
    let layoutCls = VerticalLayout

    switch (props.layout.layoutType) {
      case "horizontal":
        layoutCls = HorizontalLayout
        break
      default:
        layoutCls = VerticalLayout
        break
    }
    return layoutCls
  }

  // onRoutechange() {
  //   alert("hii")
  //   setTimeout(() => {
  //     if (document.getElementsByClassName("mm-active").length > 0) {
  //       console.log(ref.current.el);
  //       const currentPosition = document.getElementsByClassName("mm-active")[0]
  //         .offsetTop
  //         console.log(currentPosition)
  //       if (currentPosition > 500)
  //         this.$refs.currentMenu.SimpleBar.getScrollElement().scrollTop =
  //           currentPosition + 300
  //     }
  //   }, 300)
  // }

  const Layout = getLayout()

  return (
    <>
      {
        !(props.userLoading && props.roleLoading) ? (
          <Routes>

            {publicRoutes.map((route, idx) => {
              return (
                <Route element={
                  <AppRoute
                    layout={NonAuthLayout}
                    component={route.component}
                    isAuthProtected={false}
                  />
                } path={route.path} key={idx} />
              )
            })}

            {authProtectedRoutes.map((route, idx) => {
              return (
                <Route exact element={
                  <AppRoute
                    layout={route.noLayout ? NonAuthLayout : Layout}
                    component={route.component}
                    role={route.role}
                    isAuthProtected={true}
                  />
                } path={route.path} key={idx} />
              )
            })}

            <Route
              path="*"
              element={
                <NonAuthLayout>
                  <Pages404 />
                </NonAuthLayout>
              }
            />
          </Routes>
        ) : (
          <LoadingPage />
        )
      }
    </>
  )
}

const mapStateToProps = state => {
  return {
    layout: state.Layout,
    userLoading: state.user.loading,
    roleLoading: state.role.loading
  }
}

const mapDispatchToProps = {
  storeRole: storeRole,
  restoreRole: restoreRole,
  storeUser: storeUser,
  restoreUser: restoreUser
}

App.propTypes = {
  layout: PropTypes.object,
}

export default connect(mapStateToProps, mapDispatchToProps)(App)
