//LOGIN
export const ROUTE_LOGIN = "/login"
export const ROUTE_LOGOUT = "/logout"
export const ROUTE_FORGET_PASSWORD = "/forgot-password"
export const ROUTE_UPDATE_PASSWORD = "/update_password"

//DASHBOARD
export const ROUTE_DASHBOARD = "/"
export const ROUTE_DASHBOARD_SETTINGS = ROUTE_DASHBOARD + "settings/"


//USER
export const ROUTE_USER = ROUTE_DASHBOARD + "users"
export const ROUTE_USER_CREATE = ROUTE_USER + "/create"
export const ROUTE_USER_EDIT = ROUTE_USER + "/edit"

//AGENCE
export const ROUTE_AGENCE = ROUTE_DASHBOARD + "agences"
export const ROUTE_AGENCE_CREATE = ROUTE_AGENCE + "/create"
export const ROUTE_AGENCE_EDIT = ROUTE_AGENCE + "/edit"
export const ROUTE_AGENCE_DELETE = ROUTE_AGENCE + "/delete"

//PROFILE
export const ROUTE_PROFILE = ROUTE_DASHBOARD + "profiles"
export const ROUTE_PROFILE_CREATE = ROUTE_PROFILE + "/create"
export const ROUTE_PROFILE_EDIT = ROUTE_PROFILE + "/edit"
export const ROUTE_PROFILE_DELETE = ROUTE_PROFILE + "/delete"

//FEATURE
export const ROUTE_FEATURE = ROUTE_DASHBOARD + "features"
export const ROUTE_FEATURE_CREATE = ROUTE_FEATURE + "/create"
export const ROUTE_FEATURE_DELETE = ROUTE_FEATURE + "/delete"

//REQUEST
export const ROUTE_REQUEST = ROUTE_DASHBOARD + "request"
export const ROUTE_REQUEST_CREATE = ROUTE_REQUEST + "/create"
export const ROUTE_REQUEST_EDIT = ROUTE_REQUEST + "/edit"
export const ROUTE_REQUEST_DELETE = ROUTE_REQUEST + "/delete"
export const ROUTE_REQUEST_CHECK = ROUTE_REQUEST + "/check"
export const ROUTE_REQUEST_STATE = ROUTE_REQUEST + "/state"
export const ROUTE_INVALID_REQUEST_STATE = ROUTE_REQUEST + "/state/invalid"
export const ROUTE_VALID_REQUEST_STATE = ROUTE_REQUEST + "/state/valid"
export const ROUTE_REQUEST_TOVALIDATE = ROUTE_REQUEST + "/to_validate"

//CARD TYPE
export const ROUTE_CARD_TYPE = ROUTE_DASHBOARD + "card/type"
export const ROUTE_CARD_TYPE_CREATE = ROUTE_CARD_TYPE + "/create"
export const ROUTE_CARD_TYPE_EDIT = ROUTE_CARD_TYPE + "/edit"

//MAINTENANCE
export const ROUTE_MAINTENANCE = ROUTE_DASHBOARD + "maintenance"
export const ROUTE_MAINTENANCE_CANCEL_CARD = ROUTE_MAINTENANCE + "/card/cancel"
export const ROUTE_MAINTENANCE_PRICING_EDIT = ROUTE_MAINTENANCE + "/pricing/edit"
export const ROUTE_MAINTENANCE_ACCOUNT_EDIT = ROUTE_MAINTENANCE + "/account/edit"
export const ROUTE_MAINTENANCE_OPERATION_DELETE = ROUTE_MAINTENANCE + "/operation/delete"

//PROCESSING
export const ROUTE_PROCESSING = ROUTE_DASHBOARD + "processing"
export const ROUTE_PROCESSING_LAST_INFO = ROUTE_PROCESSING + "/last_info"
export const ROUTE_PROCESSING_GENERATE_APBATCH_COMMAND = ROUTE_PROCESSING + "/generate_apbatch_command"
export const ROUTE_PROCESSING_GENERATE_APBATCH_MAINTENANCE = ROUTE_PROCESSING + "/generate_apbatch_maintenance"
export const ROUTE_PROCESSING_VALIDATE_APBATCH_COMMAND = ROUTE_PROCESSING + "/validate_apbatch_command"
export const ROUTE_PROCESSING_VALIDATE_APBATCH_MAINTENANCE = ROUTE_PROCESSING + "/validate_apbatch_maintenance"

