
export const CODE_DATA_NOT_EXIST = "902"