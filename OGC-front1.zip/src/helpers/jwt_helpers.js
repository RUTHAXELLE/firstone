import { STORAGE_TOKEN } from "./localStorage_helper"

let jwt = require("jsonwebtoken")
const key = "asdfSFS34wfsdfsdfSDSD32dfsddDDerQSNCK34SOWEK5354fdgdf4" // Clé publique de cryptage pour le token

/**
 * Checks token validity
 *
 * @returns {object} user connected and isValid field when token is valid otherwise error field
 *
 * @author [Paul-Marie TATI]
 */
export const isValidToken = () => {
  try {
    const token = localStorage.getItem(STORAGE_TOKEN)
    let decoded = jwt.verify(token, key)
    return { isValid: true, user: decoded }
  } catch (error) {
    return { isValid: false, error: error }
  }
}

export const loggedUser = () => {
  try {
    const token = localStorage.getItem(STORAGE_TOKEN)
    return jwt.decode(token)
  } catch (error) {
    return null
  }
}

export const isGranted = ( role ) => {
  try {
    const token = isValidToken()
    let user = token.user

    if (!user) {
      user = loggedUser()
    }
    return ( user?.profile?.permissions?.filter(permission => permission.role === role).length )
  } catch (error) {
    return false
  }
}

