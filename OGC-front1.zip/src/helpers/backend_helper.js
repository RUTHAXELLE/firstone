import axios from "axios"
import { del, get, post, put } from "./api_helper"
import * as url from "./url_helper"
import { STORAGE_AUTH_USER, STORAGE_TOKEN } from "./localStorage_helper"
import TypeOperation from "common/data/TypeOperationMaintenance"

/* export const resetPassword = (data) => post(
  `${url.RESET_PASSWORD_URL}`,
  {
    email: data?.mailAddress || localStorage.getItem("mailAddress"),
    newpassword: data?.newPassword
  }
)

export const refreshToken = (token) => post(`${url.REFRESH_TOKEN}`, {
  token: token || localStorage.getItem(STORAGE_TOKEN)
})


const uploadFile = (data, forVehicle = false, vehicleId = undefined) => {
  return new Promise((resolve, reject) => {
    post(url.POST_FILES, data,
      {
        headers: {
          "Authorization": `Bearer ${localStorage.getItem("token")}`,
          "Content-Type": `multipart/form-data; boundary=${data._boundary}`
        }
      })
      .then(response => {
        resolve(response)
      })
      .catch(err => reject(err))

  })
} */
//---------------------------

// Get local session token
export const getToken = () => {
  const token = localStorage.getItem(STORAGE_TOKEN)
  if (token) return token
  return null
}

// Gets the logged in user data from local session
export const getLoggedInUser = () => {
  const user = localStorage.getItem(STORAGE_AUTH_USER)
  if (user) return JSON.parse(user)
  return null
}

//is user is logged in
export const isUserAuthenticated = () => {
  return getLoggedInUser() !== null
}

//is user is granted in
export const isUserGranted = (roles) => {
  // TODO: définir les droits d'accès aux pages et menus
  return true
}

// Login Method
export const postLogin = data => post(url.LOGIN_USER, data, {
  format: true,
  array: false
})

// Agences
export const getAllAgences = (options) => get(url.GET_AGENCE, {}, options);
export const createAgence = (data) => post(url.CREATE_AGENCE, data);
export const searchAgences = (criteria) => get(url.GET_AGENCE, criteria);
export const editAgence = (data) => put(url.EDIT_AGENCE, data);
export const deleteAgence = (data) => del(url.DELETE_AGENCE, data);

// CardTypes
export const getAllCardTypes = (options) => get(url.GET_CARD_TYPE, {}, options);
export const createCardType = (data) => post(url.CREATE_CARD_TYPE, data);
export const searchCardTypes = (criteria, options) => get(url.GET_CARD_TYPE, criteria, options);
export const editCardType = (data) => put(url.EDIT_CARD_TYPE, data);
export const deleteCardType = (data) => del(url.DELETE_CARD_TYPE, data);

// Request
export const getAllRequests = (options) => get(url.GET_REQUEST, {}, options);
export const createRequest = (data) => post(url.CREATE_REQUEST, data);
export const searchRequests = (criteria, options) => get(url.GET_REQUEST, criteria, options);
export const editRequest = (data) => put(url.EDIT_REQUEST, data);
export const deleteRequest = (data) => del(url.DELETE_REQUEST, data);

// Profiles
export const getAllProfiles = (options) => get(url.GET_PROFILE, {}, options);
export const createProfile = (data) => post(url.CREATE_PROFILE, data);
export const searchProfiles = (criteria, options) => get(url.GET_PROFILE, criteria, options);
export const editProfile = (data) => put(url.EDIT_PROFILE, data);
export const deleteProfile = (data) => del(url.DELETE_PROFILE, data);
export const getFeatures = (data, options) => get(url.GET_PROFILE_FEATURES, data, options);

// Features
export const getAllFeatures = (options) => get(url.GET_FEATURE, {}, options);
export const createFeature = (data) => post(url.CREATE_FEATURE, data);
export const searchFeatures = (criteria, options) => get(url.GET_FEATURE, criteria, options);
export const editFeature = (data) => put(url.EDIT_FEATURE, data);
export const deleteFeature = (data) => del(url.DELETE_FEATURE, data);

// Users
export const getAllUsers = (options) => get(url.GET_USER, {}, options);
export const createUser = (data) => post(url.CREATE_USER, data);
export const searchUsers = (criteria, options) => get(url.GET_USER, criteria, options);
export const editUser = (data) => put(url.EDIT_USER, data);
export const changeUserPassword = (data) => post(url.CHANGE_USER_PASSWORD, data, {
  format: true,
  array: false
});

// Checking
export const makeControl = () => post(url.CONTROL_REQUESTS, {}, {
  array: false
})
export const getInvalidRequests = (options) => get(url.GET_INVALID_REQUESTS, {}, options);
export const getValidRequests = (options) => get(url.GET_VALID_REQUESTS, {}, options);
export const validateRequests = (data) => put(url.VALIDATE_REQUESTS, data);

// Account
export const searchAccount = (criteria) => get(url.GET_ACCOUNT, criteria);

// APBATCH
export const generateOrderApbatch = () => post(url.GENERATE_APBATCH_FILE, {}, {
  format: false,
  array: false
});
export const getLastOrderApbatch = (criteria) => get(url.GET_GENERATED_APBATCH, criteria);
export const validateOrderApbatch = (criteria) => post(url.VALIDATE_APBATCH, criteria, {
  array: false
});


// Card
export const searchCard = (criteria, options) => get(url.GET_CARD, criteria, options);

// Maintenance
export const cancelCard = (criteria) => post(url.MAINTENANCE_OPERATION, {
  ...criteria,
  codeTypeOperation: TypeOperation.cancelCard
})
export const editPricing = (criteria) => post(url.MAINTENANCE_OPERATION, {
  ...criteria,
  codeTypeOperation: TypeOperation.changePrice
})

export const updateAccount = (data) => post(url.MAINTENANCE_OPERATION, {
  ...data,
  codeTypeOperation: TypeOperation.updateAccount
})

export const deleteMaintenance = (criteria) => del(url.MAINTENANCE_OPERATION, criteria);

export const getMaintenances = (options) => get(url.GET_MAINTENANCE_REQUEST, {}, options)

export const getCustomMaintenances = (criteria, options) => get(url.GET_CUSTOM_MAINTENANCE_REQUEST, criteria, options)

export const generateMaintenanceApbatch = (criteria) => get(url.GENERATE_MAINTENANCE_APBATCH, criteria)

export const validateMaintenanceApbatch = (criteria) => get(url.VALIDATE_MAINTENANCE_APBATCH, {
  ...criteria,
  isValidated: true
});

export const validateAccountUpdateApbatch = () => get(url.VALIDATE_UPDATE_ACCOUNT_MAINTENANCE_APBATCH, {
  isValidated: true
});

export const getLastGeneratedMaintenance = (criteria) => get(url.GET_GENERATED_MAINTENANCE_APBATCH, criteria)