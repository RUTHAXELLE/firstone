//API_URLS
export const BASE_URL = '35.180.211.191:3010';

//REGISTER
export const POST_FAKE_REGISTER = "/post-fake-register"

//LOGIN
export const POST_LOGIN = "/auth/login"
export const POST_FAKE_LOGIN = "/post-fake-login"
export const POST_FAKE_JWT_LOGIN = "/post-jwt-login"
export const POST_FAKE_PASSWORD_FORGET = "/fake-forget-pwd"
export const POST_FAKE_JWT_PASSWORD_FORGET = "/jwt-forget-pwd"

//USER
export const USER = "/users"
export const CREATE_USER = USER + ""
export const EDIT_USER = USER + ""
export const DELETE_USER = USER + ""
export const GET_USER = USER + "/getByCriteria"
export const LOGIN_USER = USER + "/login"
export const CHANGE_USER_PASSWORD = USER + "/resetPassWordUser"

//ROLES
export const PROFILE = "/roles"
export const CREATE_PROFILE = PROFILE + ""
export const EDIT_PROFILE = PROFILE + ""
export const GET_PROFILE = PROFILE + "/getByCriteria"
export const DELETE_PROFILE = PROFILE + ""
export const GET_PROFILE_FEATURES = PROFILE + "/getFunctionalities"

//FEATURES
export const FEATURE = "/functionalities"
export const CREATE_FEATURE = FEATURE + ""
export const EDIT_FEATURE = FEATURE + ""
export const GET_FEATURE = FEATURE + "/getByCriteria"
export const DELETE_FEATURE = FEATURE + ""

//AGENCE
export const AGENCE = "/agences"
export const CREATE_AGENCE = AGENCE + ""
export const EDIT_AGENCE = AGENCE + ""
export const DELETE_AGENCE = AGENCE + ""
export const GET_AGENCE = AGENCE + "/getByCriteria"

//REQUEST
export const REQUEST = "/demandes"
export const CREATE_REQUEST = REQUEST + ""
export const EDIT_REQUEST = REQUEST + ""
export const DELETE_REQUEST = REQUEST + ""
export const GET_REQUEST = REQUEST + "/getByCriteria" //"/allDemandeEnAttenteDeValidation"

export const CONTROL_REQUESTS = REQUEST + "/controleAllDemande"
export const GET_INVALID_REQUESTS = REQUEST + "/allDemandeInchorente"
export const GET_VALID_REQUESTS = REQUEST + "/allDemandeValide"
export const VALIDATE_REQUESTS = REQUEST + "/toForceDemandeToValidate"

export const GENERATE_APBATCH_FILE = REQUEST + "/generateApBatchFile"
export const GET_GENERATED_APBATCH = REQUEST + "/getApFile"
export const VALIDATE_APBATCH = REQUEST + "/validateApBatch"

// ACCOUNT
export const ACCOUNT = "/comptes"
export const GET_ACCOUNT = ACCOUNT + "/getByCriteria"

//CARD TYPE
export const CARD_TYPE = "/typeCartes"
export const ADD_CARD_TYPE = CARD_TYPE + ""
export const CREATE_CARD_TYPE = CARD_TYPE + ""
export const EDIT_CARD_TYPE = CARD_TYPE + ""
export const DELETE_CARD_TYPE = CARD_TYPE + ""
export const GET_CARD_TYPE = CARD_TYPE + "/getByCriteria"
export const GET_TYPE_CARD_TYPE = CARD_TYPE + "/type"

// CARD
export const CARD = "/cartes"
export const GET_CARD = CARD + "/getByCriteria"

// MAINTENANCE
export const MAINTENANCE_OPERATION = "/demandesMaintenance";
export const GET_MAINTENANCE_REQUEST = MAINTENANCE_OPERATION + "/allDemandeMaintenanceEnCours";
export const GET_CUSTOM_MAINTENANCE_REQUEST = MAINTENANCE_OPERATION + "/getByCriteria";
export const GENERATE_MAINTENANCE_APBATCH = MAINTENANCE_OPERATION + "/generateMaintenanceApBatchFile";
export const VALIDATE_MAINTENANCE_APBATCH = MAINTENANCE_OPERATION + "/validateApBatch";
export const VALIDATE_UPDATE_ACCOUNT_MAINTENANCE_APBATCH = MAINTENANCE_OPERATION + "/validateApBatchUpdateAccount";
export const GET_GENERATED_MAINTENANCE_APBATCH = MAINTENANCE_OPERATION + "/getApFileMaintenance";

