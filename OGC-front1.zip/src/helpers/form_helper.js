

const getNativeValueSetter = () => {
    return Object.getOwnPropertyDescriptor(
        window.HTMLInputElement.prototype,
        "value"
    ).set;
}

export const generatePassword = (ref) => {
    var chars = "0123456789abcdefghijklmnopqrstuvwxyz!@#$%^&*()ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    var passwordLength = 12;
    var password = "";

    for (var i = 0; i <= passwordLength; i++) {
        var randomNumber = Math.floor(Math.random() * chars.length);
        password += chars.substring(randomNumber, randomNumber + 1);
    }

    const setter = getNativeValueSetter();
    setter.call(ref.current, password)

    var inputEvent = new Event("input", { bubbles: true });
    ref.current.dispatchEvent(inputEvent)
}