--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

-- Started on 2022-10-11 18:27:40

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 3183 (class 0 OID 16395)
-- Dependencies: 200
-- Data for Name: agence; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.agence (id, address, code, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by) VALUES (19, 'Agence Abatta', 'abatta', '2022-06-07 14:49:10.119', NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.agence (id, address, code, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by) VALUES (20, 'Agence Abobo Mairie', 'abobm', '2022-06-07 14:49:10.121', NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.agence (id, address, code, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by) VALUES (21, 'Agence Abobo Samake', 'abobsm', '2022-06-07 14:49:10.128', NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.agence (id, address, code, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by) VALUES (22, 'Agence Aboisso', 'aboisso', '2022-06-07 14:49:10.13', NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.agence (id, address, code, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by) VALUES (23, 'Agence Adjame Liberté', 'adjamlib', '2022-06-07 14:49:10.133', NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.agence (id, address, code, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by) VALUES (24, 'Agence Adjame Nangui Abrogoua', 'adjamnao', '2022-06-07 14:49:10.141', NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.agence (id, address, code, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by) VALUES (25, 'Agence Aghien', 'aghien', '2022-06-07 14:49:10.142', NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.agence (id, address, code, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by) VALUES (26, 'Agence Akwaba', 'akwaba', '2022-06-07 14:49:10.144', NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.agence (id, address, code, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by) VALUES (3, 'Port Bouët marché ', 'portbtAG1', '2022-06-14 16:33:52.788', NULL, '2022-06-15 14:48:14.318', NULL, true, NULL, NULL);



--
-- TOC entry 3204 (class 0 OID 16641)
-- Dependencies: 221
-- Data for Name: type_client; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.type_client (id, code, created_at, created_by, deleted_at, deleted_by, description, is_deleted, libelle, updated_at, updated_by) VALUES (1, 'RETAILS', NULL, NULL, NULL, NULL, NULL, false, NULL, NULL, NULL);
INSERT INTO public.type_client (id, code, created_at, created_by, deleted_at, deleted_by, description, is_deleted, libelle, updated_at, updated_by) VALUES (2, 'CORPORATE', NULL, NULL, NULL, NULL, NULL, false, NULL, NULL, NULL);


--
-- TOC entry 3186 (class 0 OID 16419)
-- Dependencies: 203
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.client (id, code, contact, created_at, created_by, deleted_at, deleted_by, is_deleted, nom, prenoms, updated_at, updated_by, civilite, adress_postale_1, adress_postale_2, city, date_birth, indicatif_pays, type_client_id) VALUES (31, '001SG', '0794553230', '2022-06-15 12:41:57.497', NULL, NULL, NULL, false, 'DIBLO', 'Gaston Paul', '2022-06-23 09:47:55.919', NULL, 'M', 'BP TCHAD03', 'BP TCHAD03', 'N''DJAMENA', '1986-01-24 00:00:00', '+235', 2);
INSERT INTO public.client (id, code, contact, created_at, created_by, deleted_at, deleted_by, is_deleted, nom, prenoms, updated_at, updated_by, civilite, adress_postale_1, adress_postale_2, city, date_birth, indicatif_pays, type_client_id) VALUES (32, '002SG', '0794554112', '2022-06-15 12:41:57.5', NULL, NULL, NULL, false, 'ROUKOUSS', 'Malick Ndeye', '2022-06-23 09:48:34.25', NULL, 'M', 'BP TCHAD04', 'BP TCHAD04', 'N''DJAMENA', '1976-01-21 00:00:00', '+235', 1);


--
-- TOC entry 3198 (class 0 OID 16506)
-- Dependencies: 215
-- Data for Name: type_compte; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.type_compte (id, code, created_at, created_by, deleted_at, deleted_by, description, is_deleted, libelle, updated_at, updated_by) VALUES (29, 'EPA', '2022-06-15 12:30:56.972', NULL, NULL, NULL, NULL, false, 'Epargne', NULL, NULL);
INSERT INTO public.type_compte (id, code, created_at, created_by, deleted_at, deleted_by, description, is_deleted, libelle, updated_at, updated_by) VALUES (30, 'CHE', '2022-06-15 12:30:56.975', NULL, NULL, NULL, NULL, false, 'Chèque', NULL, NULL);


--
-- TOC entry 3187 (class 0 OID 16427)
-- Dependencies: 204
-- Data for Name: compte; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.compte (id, created_at, created_by, deleted_at, deleted_by, description, is_actif, is_deleted, numero, updated_at, updated_by, agence_id, client_id, type_compte_id) VALUES (33, '2022-06-15 12:56:13.005', NULL, NULL, NULL, NULL, true, false, '0001345567800', NULL, NULL, 26, 31, 30);
INSERT INTO public.compte (id, created_at, created_by, deleted_at, deleted_by, description, is_actif, is_deleted, numero, updated_at, updated_by, agence_id, client_id, type_compte_id) VALUES (34, '2022-06-15 12:56:13.03', NULL, NULL, NULL, NULL, false, false, '0001345567256', NULL, NULL, 25, 32, 30);


--
-- TOC entry 3195 (class 0 OID 16485)
-- Dependencies: 212
-- Data for Name: status; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.status (id, code, created_at, created_by, deleted_at, deleted_by, description, is_deleted, updated_at, updated_by) VALUES (1, 'EnCours', NULL, NULL, NULL, NULL, 'Demande en cours de traitement', false, NULL, NULL);
INSERT INTO public.status (id, code, created_at, created_by, deleted_at, deleted_by, description, is_deleted, updated_at, updated_by) VALUES (2, 'Valide', NULL, NULL, NULL, NULL, 'DemandeValidée', false, NULL, NULL);
INSERT INTO public.status (id, code, created_at, created_by, deleted_at, deleted_by, description, is_deleted, updated_at, updated_by) VALUES (3, 'Invalide', NULL, NULL, NULL, NULL, 'Demande invalide', false, NULL, NULL);
INSERT INTO public.status (id, code, created_at, created_by, deleted_at, deleted_by, description, is_deleted, updated_at, updated_by) VALUES (4, 'Incoherent', NULL, NULL, NULL, NULL, 'Demande incohérente', false, NULL, NULL);
INSERT INTO public.status (id, code, created_at, created_by, deleted_at, deleted_by, description, is_deleted, updated_at, updated_by) VALUES (5, 'AppBatchValide', NULL, NULL, NULL, NULL, 'Demande APBATCH', false, NULL, NULL);


--
-- TOC entry 3197 (class 0 OID 16498)
-- Dependencies: 214
-- Data for Name: type_carte; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.type_carte (id, acc_country, bin, business, code, code_banque, code_produit, code_tarif, created_at, created_by, deleted_at, deleted_by, description, devise, identifiant_groupe, identifiant_institution, identifiant_produit, is_deleted, libelle, pays, produit, type, type_carte, type_gen, updated_at, updated_by) VALUES (10, 'THD', '48899000', 'CARTE BANCAIRE SGT', '6', '60002', '006', 'EX', '2022-06-15 09:39:49.095', NULL, NULL, NULL, NULL, '950', 'SGTB10', '2006600019', '006', false, NULL, 'TCHAD', 'GK', 'PUCE', 'VISA GOLD PACKAGE', 'CARTE VISA GOLD', NULL, NULL);
INSERT INTO public.type_carte (id, acc_country, bin, business, code, code_banque, code_produit, code_tarif, created_at, created_by, deleted_at, deleted_by, description, devise, identifiant_groupe, identifiant_institution, identifiant_produit, is_deleted, libelle, pays, produit, type, type_carte, type_gen, updated_at, updated_by) VALUES (11, 'THD', '48898900', 'CARTE BANCAIRE SGT', '6', '60002', '007', 'EX', '2022-06-15 12:06:27.99', NULL, NULL, NULL, NULL, '950', 'SGTB12', '2006600019', '007', false, NULL, 'TCHAD', 'CM', 'PUCE', 'VISA CLASSIC PROMOTIONNEL', 'CARTE VISA CLASSIC', NULL, NULL);
INSERT INTO public.type_carte (id, acc_country, bin, business, code, code_banque, code_produit, code_tarif, created_at, created_by, deleted_at, deleted_by, description, devise, identifiant_groupe, identifiant_institution, identifiant_produit, is_deleted, libelle, pays, produit, type, type_carte, type_gen, updated_at, updated_by) VALUES (22, 'THD', '48898900', 'CARTE BANCAIRE SGT', '6', '60002', '007', '00', '2022-06-16 08:23:38.543', NULL, NULL, NULL, NULL, '950', 'SGTB12', '2006600019', '007', false, NULL, 'TCHAD', 'CG', 'PUCE', 'VISA CLASSIC GRATUIT', 'CARTE VISA CLASSIC', NULL, NULL);
INSERT INTO public.type_carte (id, acc_country, bin, business, code, code_banque, code_produit, code_tarif, created_at, created_by, deleted_at, deleted_by, description, devise, identifiant_groupe, identifiant_institution, identifiant_produit, is_deleted, libelle, pays, produit, type, type_carte, type_gen, updated_at, updated_by) VALUES (51, 'THD', '44784602', 'CARTE BANCAIRE SGT', '6', '60002', '005', '00', '2022-06-16 12:07:43.232', NULL, NULL, NULL, NULL, '950', 'SGTB08', '2006600019', '005', false, NULL, 'TCHAD', 'BG', 'PUCE', 'VISA BUSINESS GRATUIT', 'CARTE VISA BUSINESS', NULL, NULL);
INSERT INTO public.type_carte (id, acc_country, bin, business, code, code_banque, code_produit, code_tarif, created_at, created_by, deleted_at, deleted_by, description, devise, identifiant_groupe, identifiant_institution, identifiant_produit, is_deleted, libelle, pays, produit, type, type_carte, type_gen, updated_at, updated_by) VALUES (219, 'THD', '48898900', 'CARTE BANCAIRE SGT', '6', '60002', '007', 'PR', '2022-06-23 11:42:23.58', NULL, NULL, NULL, NULL, '950', 'SGTB12', '2006600019', '007', false, NULL, 'TCHAD', 'CP', 'PUCE', 'VISA CLASSIC PERSONNEL', 'CARTE VISA CLASSIC', NULL, NULL);
INSERT INTO public.type_carte (id, acc_country, bin, business, code, code_banque, code_produit, code_tarif, created_at, created_by, deleted_at, deleted_by, description, devise, identifiant_groupe, identifiant_institution, identifiant_produit, is_deleted, libelle, pays, produit, type, type_carte, type_gen, updated_at, updated_by) VALUES (264, 'THD', '48898900', 'CARTE BANCAIRE SGT', '6', '60002', '006', '00', '2022-06-23 16:10:43.225', NULL, NULL, NULL, NULL, '950', 'SGTB12', '2006600019', '006', false, NULL, 'TCHAD', 'BG', 'PUCE', 'VISA BUSINESS PROMO', 'CARTE VISA BUSINESS', NULL, NULL);
INSERT INTO public.type_carte (id, acc_country, bin, business, code, code_banque, code_produit, code_tarif, created_at, created_by, deleted_at, deleted_by, description, devise, identifiant_groupe, identifiant_institution, identifiant_produit, is_deleted, libelle, pays, produit, type, type_carte, type_gen, updated_at, updated_by) VALUES (812, 'THD', '45242610', 'CARTE BANCAIRE SGT', '6', '60002', 'PM', 'P5', '2022-08-26 16:03:46.021', 741, '2022-08-26 16:33:28.045', 741, NULL, '950', 'SGTB18', '2006600019', '008', true, NULL, 'TCHAD', 'PM', 'PUCE', 'VISA PLATINUM PROMOTIONNEL', 'CARTE VISA PLATINUM', '2022-08-26 16:15:54.317', 741);
INSERT INTO public.type_carte (id, acc_country, bin, business, code, code_banque, code_produit, code_tarif, created_at, created_by, deleted_at, deleted_by, description, devise, identifiant_groupe, identifiant_institution, identifiant_produit, is_deleted, libelle, pays, produit, type, type_carte, type_gen, updated_at, updated_by) VALUES (322, 'THD', '45242610', 'CARTE BANCAIRE SGT', '6', '60002', 'PS', '03', '2022-06-28 15:25:24.451', NULL, NULL, NULL, NULL, '950', 'SGTB16', '2006600019', '008', false, NULL, 'TCHAD', 'PS', 'PUCE', 'VISA PLATINUM STANDARD', 'CARTE VISA PLATINUM', '2022-08-29 09:32:28.913', 741);
INSERT INTO public.type_carte (id, acc_country, bin, business, code, code_banque, code_produit, code_tarif, created_at, created_by, deleted_at, deleted_by, description, devise, identifiant_groupe, identifiant_institution, identifiant_produit, is_deleted, libelle, pays, produit, type, type_carte, type_gen, updated_at, updated_by) VALUES (1039, 'THD', '48899000', 'CARTE BANCAIRE SGT', '6', '60002', '006', 'EX', '2022-08-31 11:44:24.27', 741, '2022-08-31 11:44:31.694', 741, NULL, '950', 'SGTB12', '2006600019', '007', true, NULL, 'TCHAD', 'CM', 'PISTE', 'VISA PLATINUM STANDARDqs', 'CARTE VISA CLASSICs', NULL, NULL);
INSERT INTO public.type_carte (id, acc_country, bin, business, code, code_banque, code_produit, code_tarif, created_at, created_by, deleted_at, deleted_by, description, devise, identifiant_groupe, identifiant_institution, identifiant_produit, is_deleted, libelle, pays, produit, type, type_carte, type_gen, updated_at, updated_by) VALUES (1038, 'THD', '48898900', 'CARTE BANCAIRE SGT', '6', '60002', '007', '00', '2022-08-31 11:42:53.974', 741, '2022-08-31 11:44:34.669', 741, NULL, '950', 'SGTB12', '2006600019', '006', true, NULL, 'TCHAD', 'CM', 'PISTE', 'VISA GOLD PACKAGEdsfds', 'CARTE VISA CLASSIC', NULL, NULL);
INSERT INTO public.type_carte (id, acc_country, bin, business, code, code_banque, code_produit, code_tarif, created_at, created_by, deleted_at, deleted_by, description, devise, identifiant_groupe, identifiant_institution, identifiant_produit, is_deleted, libelle, pays, produit, type, type_carte, type_gen, updated_at, updated_by) VALUES (1383, 'THD', '45242615', 'CARTE BANCAIRE SGT', '15', '60002', '007', '00', '2022-10-03 11:32:03.71', 2000, '2022-10-03 11:32:13.98', 2000, NULL, '950', 'SGTB12', '2006600019', '007', true, NULL, 'TCHAD', 'CG', 'PUCE', 'VISA EMERAULD PACKAGE', 'CARTE VISA EMERAULD', NULL, NULL);



--
-- TOC entry 3191 (class 0 OID 16456)
-- Dependencies: 208
-- Data for Name: groupe; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.groupe (id, code, created_at, created_by, deleted_at, deleted_by, description, is_deleted, updated_at, updated_by) VALUES (1, '0000', NULL, NULL, NULL, NULL, 'default', NULL, NULL, NULL);


--
-- TOC entry 3185 (class 0 OID 16411)
-- Dependencies: 202
-- Data for Name: carte; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.carte (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by, groupe_id, type_carte_id, noms, prenom, compte_id, type_carte_libelle, numero_carte) VALUES (375, 'CARTE001', '2022-07-06 11:57:27.287', NULL, NULL, NULL, false, 'Carte bancaire 001', NULL, NULL, NULL, 51, 'Alzouma Moussa', 'Mahamadou', 33, 'VISA BUSINESS GRATUIT', NULL);
INSERT INTO public.carte (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by, groupe_id, type_carte_id, noms, prenom, compte_id, type_carte_libelle, numero_carte) VALUES (376, 'CARTE002', '2022-07-06 11:57:27.296', NULL, NULL, NULL, false, 'Carte bancaire 002', NULL, NULL, NULL, 264, 'Alzouma Moussa', 'Mahamadou', 34, 'VISA BUSINESS PROMO', NULL);
INSERT INTO public.carte (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by, groupe_id, type_carte_id, noms, prenom, compte_id, type_carte_libelle, numero_carte) VALUES (438, '00000000411', '2022-07-15 15:31:20.97', NULL, NULL, NULL, false, 'VISA CLASSIC PERSONNEL', NULL, NULL, NULL, 219, 'ROUKOUSS', 'Malick Ndeye', 34, 'VISA CLASSIC PERSONNEL', NULL);
INSERT INTO public.carte (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by, groupe_id, type_carte_id, noms, prenom, compte_id, type_carte_libelle, numero_carte) VALUES (410, '00000000377', '2022-07-14 16:11:03.38', NULL, NULL, NULL, false, 'VISA CLASSIC PERSONNEL', NULL, NULL, NULL, 219, 'ROUKOUSS', 'Malick Ndeye', 34, 'VISA CLASSIC PERSONNEL', NULL);
INSERT INTO public.carte (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by, groupe_id, type_carte_id, noms, prenom, compte_id, type_carte_libelle, numero_carte) VALUES (588, '00000000588', '2022-08-04 16:36:40.3', NULL, NULL, NULL, false, 'VISA BUSINESS PROMO', NULL, NULL, NULL, 264, 'ROUKOUSS', 'Malick Ndeye', 34, 'VISA BUSINESS PROMO', NULL);
INSERT INTO public.carte (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by, groupe_id, type_carte_id, noms, prenom, compte_id, type_carte_libelle, numero_carte) VALUES (587, '00000000552', '2022-08-04 16:36:40.288', NULL, NULL, NULL, false, 'VISA CLASSIC PERSONNEL', NULL, NULL, NULL, 219, 'DIBLO', 'Gaston Paul', 33, 'VISA CLASSIC PERSONNEL', NULL);
INSERT INTO public.carte (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by, groupe_id, type_carte_id, noms, prenom, compte_id, type_carte_libelle, numero_carte) VALUES (551, '00000000551', '2022-08-01 14:40:23.304', NULL, NULL, NULL, false, 'VISA CLASSIC GRATUIT', NULL, NULL, NULL, 22, 'DIBLO', 'Gaston Paul', 33, 'VISA CLASSIC GRATUIT', NULL);
INSERT INTO public.carte (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by, groupe_id, type_carte_id, noms, prenom, compte_id, type_carte_libelle, numero_carte) VALUES (550, '00000000439', '2022-08-01 14:40:23.295', NULL, NULL, NULL, false, 'VISA GOLD PACKAGE', NULL, NULL, NULL, 10, 'DIBLO', 'Gaston Paul', 33, 'VISA GOLD PACKAGE', NULL);
INSERT INTO public.carte (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by, groupe_id, type_carte_id, noms, prenom, compte_id, type_carte_libelle, numero_carte) VALUES (784, '00000000784', '2022-08-19 16:22:17.521', NULL, NULL, NULL, false, 'VISA CLASSIC PERSONNEL', NULL, NULL, NULL, 219, 'DIBLO', 'Gaston Paul', 33, 'VISA CLASSIC PERSONNEL', NULL);
INSERT INTO public.carte (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by, groupe_id, type_carte_id, noms, prenom, compte_id, type_carte_libelle, numero_carte) VALUES (783, '00000000769', '2022-08-19 16:22:17.515', NULL, NULL, NULL, false, 'VISA BUSINESS PROMO', NULL, NULL, NULL, 264, 'DIBLO', 'Gaston Paul', 33, 'VISA BUSINESS PROMO', NULL);
INSERT INTO public.carte (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by, groupe_id, type_carte_id, noms, prenom, compte_id, type_carte_libelle, numero_carte) VALUES (768, '00000000589', '2022-08-19 15:03:05.117', NULL, NULL, NULL, false, 'VISA BUSINESS PROMO', NULL, NULL, NULL, 264, 'DIBLO', 'Gaston Paul', 33, 'VISA BUSINESS PROMO', NULL);
INSERT INTO public.carte (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by, groupe_id, type_carte_id, noms, prenom, compte_id, type_carte_libelle, numero_carte) VALUES (1164, '00000001164', '2022-09-22 16:54:56.934', NULL, NULL, NULL, false, 'VISA CLASSIC PERSONNEL', NULL, NULL, NULL, 219, 'ROUKOUSS', 'Malick Ndeye', 34, 'VISA CLASSIC PERSONNEL', NULL);
INSERT INTO public.carte (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by, groupe_id, type_carte_id, noms, prenom, compte_id, type_carte_libelle, numero_carte) VALUES (1161, '00000001156', '2022-09-22 16:54:56.897', NULL, NULL, NULL, false, 'VISA BUSINESS PROMO', NULL, NULL, NULL, 264, 'ROUKOUSS', 'Malick Ndeye', 34, 'VISA BUSINESS PROMO', NULL);
INSERT INTO public.carte (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by, groupe_id, type_carte_id, noms, prenom, compte_id, type_carte_libelle, numero_carte) VALUES (1154, '00000001154', '2022-09-22 16:54:17.881', NULL, NULL, NULL, false, 'VISA CLASSIC PERSONNEL', NULL, NULL, NULL, 219, 'ROUKOUSS', 'Malick Ndeye', 34, 'VISA CLASSIC PERSONNEL', NULL);
INSERT INTO public.carte (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by, groupe_id, type_carte_id, noms, prenom, compte_id, type_carte_libelle, numero_carte) VALUES (1151, '00000001143', '2022-09-22 16:54:17.85', NULL, NULL, NULL, false, 'VISA BUSINESS PROMO', NULL, NULL, NULL, 264, 'ROUKOUSS', 'Malick Ndeye', 34, 'VISA BUSINESS PROMO', NULL);
INSERT INTO public.carte (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by, groupe_id, type_carte_id, noms, prenom, compte_id, type_carte_libelle, numero_carte) VALUES (1165, '00000001165', '2022-09-22 16:54:56.952', NULL, NULL, NULL, false, 'VISA GOLD PACKAGE', NULL, NULL, NULL, 10, 'DIBLO', 'Gaston Paul', 33, 'VISA GOLD PACKAGE', NULL);
INSERT INTO public.carte (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by, groupe_id, type_carte_id, noms, prenom, compte_id, type_carte_libelle, numero_carte) VALUES (1163, '00000001163', '2022-09-22 16:54:56.929', NULL, NULL, NULL, false, 'VISA CLASSIC GRATUIT', NULL, NULL, NULL, 22, 'DIBLO', 'Gaston Paul', 33, 'VISA CLASSIC GRATUIT', NULL);
INSERT INTO public.carte (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by, groupe_id, type_carte_id, noms, prenom, compte_id, type_carte_libelle, numero_carte) VALUES (1162, '00000001162', '2022-09-22 16:54:56.922', NULL, NULL, NULL, false, 'VISA PLATINUM STANDARD', NULL, NULL, NULL, 322, 'DIBLO', 'Gaston Paul', 33, 'VISA PLATINUM STANDARD', NULL);
INSERT INTO public.carte (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by, groupe_id, type_carte_id, noms, prenom, compte_id, type_carte_libelle, numero_carte) VALUES (1155, '00000001155', '2022-09-22 16:54:17.899', NULL, NULL, NULL, false, 'VISA GOLD PACKAGE', NULL, NULL, NULL, 10, 'DIBLO', 'Gaston Paul', 33, 'VISA GOLD PACKAGE', NULL);
INSERT INTO public.carte (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by, groupe_id, type_carte_id, noms, prenom, compte_id, type_carte_libelle, numero_carte) VALUES (1153, '00000001153', '2022-09-22 16:54:17.874', NULL, NULL, NULL, false, 'VISA CLASSIC GRATUIT', NULL, NULL, NULL, 22, 'DIBLO', 'Gaston Paul', 33, 'VISA CLASSIC GRATUIT', NULL);
INSERT INTO public.carte (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by, groupe_id, type_carte_id, noms, prenom, compte_id, type_carte_libelle, numero_carte) VALUES (1152, '00000001152', '2022-09-22 16:54:17.867', NULL, NULL, NULL, false, 'VISA PLATINUM STANDARD', NULL, NULL, NULL, 322, 'DIBLO', 'Gaston Paul', 33, 'VISA PLATINUM STANDARD', NULL);
INSERT INTO public.carte (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by, groupe_id, type_carte_id, noms, prenom, compte_id, type_carte_libelle, numero_carte) VALUES (1142, '00000001142', '2022-09-22 16:13:14.189', NULL, NULL, NULL, false, 'VISA CLASSIC PERSONNEL', NULL, NULL, NULL, 219, 'DIBLO', 'Gaston Paul', 33, 'VISA CLASSIC PERSONNEL', NULL);
INSERT INTO public.carte (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by, groupe_id, type_carte_id, noms, prenom, compte_id, type_carte_libelle, numero_carte) VALUES (1141, '00000000785', '2022-09-22 16:13:14.124', NULL, NULL, NULL, false, 'VISA BUSINESS PROMO', NULL, NULL, NULL, 264, 'DIBLO', 'Gaston Paul', 33, 'VISA BUSINESS PROMO', NULL);


--
-- TOC entry 3207 (class 0 OID 16680)
-- Dependencies: 224
-- Data for Name: type_operation; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.type_operation (id, code, created_at, created_by, deleted_at, deleted_by, description, is_deleted, updated_at, updated_by) VALUES (372, 'ANNULATIONCARTE', '2022-07-06 11:36:26.075', NULL, NULL, NULL, 'Annulation de carte', false, NULL, NULL);
INSERT INTO public.type_operation (id, code, created_at, created_by, deleted_at, deleted_by, description, is_deleted, updated_at, updated_by) VALUES (373, 'CHANGEMENTTARIFICATION', '2022-07-06 11:36:26.076', NULL, NULL, NULL, 'Changement de tarification de carte', false, NULL, NULL);
INSERT INTO public.type_operation (id, code, created_at, created_by, deleted_at, deleted_by, description, is_deleted, updated_at, updated_by) VALUES (374, 'MISEAJOURCOMPTE', '2022-07-06 11:36:26.076', NULL, NULL, NULL, 'Changement de numéro de compte ou d''agence', false, NULL, NULL);




--
-- TOC entry 3184 (class 0 OID 16403)
-- Dependencies: 201
-- Data for Name: attribution; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3189 (class 0 OID 16443)
-- Dependencies: 206
-- Data for Name: document; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3190 (class 0 OID 16448)
-- Dependencies: 207
-- Data for Name: functionality; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2000, 'ROLE_PROFILE_DELETE', '2022-08-19 12:16:48.328', 2000, NULL, NULL, false, 'Supprimer un profil utilisateur', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2001, 'ROLE_MAINTENANCE_UPDATE_ACCOUNT', '2022-08-19 12:25:19.341', 2000, '2022-08-19 12:25:32.932', 2000, true, 'UPDATE ACCOUNT', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2002, 'ROLE_MAINTENANCE_ACCOUNT_UPDATE', '2022-08-19 12:26:21.16', 2000, '2022-08-29 09:18:52.097', 2000, true, 'UPDATE ACCOUNT', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2003, 'ROLE_MAINTENANCE_CARD_CANCEL', '2022-08-19 12:24:39.328', 2000, '2022-08-29 09:19:05.646', 2000, true, 'CANCEL CARD', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2004, 'ROLE_REQUEST_LIST', '2022-08-19 12:07:22.645', 2000, '2022-08-19 12:08:33.927', 2000, true, 'Lister les saisies de demande de carte', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2005, 'ROLE_REQUEST_CREATE', '2022-08-19 12:08:22.646', 2000, NULL, NULL, false, 'Saisir une demande de carte', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2006, 'ROLE_REQUEST_LIST', '2022-08-19 12:08:56.2018', 2000, NULL, NULL, false, 'Lister les demandes de carte saisies', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2007, 'ROLE_REQUEST_UPDATE', '2022-08-19 12:09:19.242', 2000, NULL, NULL, false, 'Mettre à jour une demande de carte', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2008, 'ROLE_REQUEST_DELETE', '2022-08-19 12:10:03.979', 2000, NULL, NULL, false, 'Supprimer une demande de carte', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2009, 'ROLE_CARD_TYPE_LIST', '2022-08-19 12:11:11.675', 2000, NULL, NULL, false, 'Lister les types de carte', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2010, 'ROLE_CARD_TYPE_CREATE', '2022-08-19 12:11:33.903', 2000, NULL, NULL, false, 'Créer un type de carte', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2011, 'ROLE_CARD_TYPE_UPDATE', '2022-08-19 12:11:58.521', 2000, NULL, NULL, false, 'Mettre à jour un type de carte', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2012, 'ROLE_USER_LIST', '2022-08-19 12:12:42.69', 2000, NULL, NULL, false, 'Lister les utilisateurs ', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2013, 'ROLE_USER_CREATE', '2022-08-19 12:13:17.238', 2000, NULL, NULL, false, 'Créer un utilisateur', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2014, 'ROLE_USER_UPDATE', '2022-08-19 12:13:39.239', 2000, NULL, NULL, false, 'Mettre à jour un utilisateur', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2015, 'ROLE_PROFILE_LIST', '2022-08-19 12:14:33.638', 2000, NULL, NULL, false, 'Lister les profils utilisateur', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2016, 'ROLE_PROFILE_CREATE', '2022-08-19 12:14:58.563', 2000, NULL, NULL, false, 'Créer un profil utilisateur', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2017, 'ROLE_PROFILE_UPDATE', '2022-08-19 12:15:30.117', 2000, NULL, NULL, false, 'Mettre à jour un profil utilisateur', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2018, 'ROLE_FEATURE_LIST', '2022-08-19 12:17:10.956', 2000, NULL, NULL, false, 'Lister les fonctionnalités', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2019, 'ROLE_FEATURE_CREATE', '2022-08-19 12:18:12.524', 2000, NULL, NULL, false, 'Créer une fonctionnalité', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2020, 'ROLE_FEATURE_DELETE', '2022-08-19 12:19:13.831', 2000, NULL, NULL, false, 'Supprimer une fonctionnalité', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2021, 'ROLE_VALID_REQUEST_LIST', '2022-08-19 12:20:06.2022', 2000, NULL, NULL, false, 'Lister les demandes de carte valides', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2022, 'ROLE_INVALID_REQUEST_LIST', '2022-08-19 12:20:35.561', 2000, NULL, NULL, false, 'Lister les demandes de carte invalides', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2023, 'ROLE_INVALID_REQUEST_VALIDATE', '2022-08-19 12:21:57.923', 2000, NULL, NULL, false, 'Forcer la validation de demandes de carte invalides', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2024, 'ROLE_REQUEST_CHECK', '2022-08-19 12:22:33.657', 2000, NULL, NULL, false, 'Contrôler les demandes de carte', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2025, 'ROLE_CARD_CANCEL', '2022-08-19 12:22:58.807', 2000, '2022-08-19 12:24:12.654', 2000, true, 'Annuler une carte', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2026, 'ROLE_MAINTENANCE_PRICING_CHANGE', '2022-08-19 12:24:02.442', 2000, '2022-08-29 09:21:47.916', 2000, true, 'Changer la tarification d''une carte', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2027, 'ROLE_MAINTENANCE_OPERATION_DELETE', '2022-08-19 12:27:12.713', 2000, NULL, NULL, false, 'Supprimer un opération de maintenance de carte', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2028, 'ROLE_APBATCH_COMMAND_GENERATE', '2022-08-19 12:28:59.002', 2000, NULL, NULL, false, 'Générer un APBATCH de commande', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2029, 'ROLE_APBATCH_COMMAND_VALIDATE', '2022-08-19 12:29:39.267', 2000, NULL, NULL, false, 'Valider un APBATCH de commande', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2030, 'ROLE_APBATCH_MAINTENANCE_GENERATE', '2022-08-19 12:30:34.388', 2000, NULL, NULL, false, 'Générer un APBATCH de maintenance', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2031, 'ROLE_APBATCH_MAINTENANCE_VALIDATE', '2022-08-19 12:31:20.991', 2000, NULL, NULL, false, 'Valider un APBATCH de maintenance', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2032, 'ROLE_MAINTENANCE_OPERATION_CREATE', '2022-08-29 09:18:30.48', 2000, NULL, NULL, false, 'Créer une opération de maintenance de carte', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2033, 'ROLE_MAINTENANCE_OPERATION_LIST', '2022-08-31 10:38:43.554', 2000, NULL, NULL, false, 'Lister les opérations de maintenance de carte enregistrées', NULL, NULL);
INSERT INTO public.functionality (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2034, 'ROLE_CARD_TYPE_DELETE', '2022-08-31 11:07:04.954', 2000, NULL, NULL, false, 'Supprimer un type de carte', NULL, NULL);


--
-- TOC entry 3203 (class 0 OID 16633)
-- Dependencies: 220
-- Data for Name: parameters; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.parameters (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, valeur) VALUES (35, 'institutionId', '2022-06-21 11:25:00.215', NULL, NULL, NULL, false, NULL, NULL, '2006600019');
INSERT INTO public.parameters (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, valeur) VALUES (37, 'filiale', '2022-06-21 12:14:42.17', NULL, NULL, NULL, false, NULL, NULL, 'CH');
INSERT INTO public.parameters (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, valeur) VALUES (38, 'nbreGenerationMaintenance', '2022-06-21 12:14:42.17', NULL, NULL, NULL, false, NULL, NULL, '47');
INSERT INTO public.parameters (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, valeur) VALUES (36, 'nbreGeneration', '2022-06-21 11:25:00.274', NULL, NULL, NULL, false, NULL, NULL, '55');


--
-- TOC entry 3193 (class 0 OID 16472)
-- Dependencies: 210
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.role (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (1399, 'r', '2022-10-10 09:38:23.358', 2000, '2022-10-10 09:38:34.642', 2000, true, 'r', NULL, NULL);
INSERT INTO public.role (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2002, 'SYS_ADMIN', '2022-09-21 09:28:41.791', NULL, NULL, NULL, false, 'Admin System', '2022-09-26 10:44:41.829', 2000);
INSERT INTO public.role (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2003, 'PROFILE_ADMIN', '2022-08-19 12:58:53.111', 2000, NULL, NULL, false, 'Administrateur', '2022-09-26 10:54:14.901', 2000);
INSERT INTO public.role (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2001, 'PROFILE_CC', '2022-08-19 14:18:18.795', 2000, NULL, NULL, false, 'Chargé de clientèle', '2022-09-26 12:04:27.162', 2000);
INSERT INTO public.role (id, code, created_at, created_by, deleted_at, deleted_by, is_deleted, libelle, updated_at, updated_by) VALUES (2000, 'PROFILE_RA', '2022-08-19 14:10:38.969', 2000, NULL, NULL, false, 'Responsable d''agence', '2022-09-26 12:05:57.163', 2000);


--
-- TOC entry 3194 (class 0 OID 16480)
-- Dependencies: 211
-- Data for Name: role_functionalities; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (2000, '2022-08-19 12:58:53.158', 2000, '2022-08-29 11:14:31.221', 2000, true, NULL, NULL, 2012, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1400, '2022-10-10 09:38:23.878', 2000, NULL, NULL, false, NULL, NULL, 2030, 1399);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1401, '2022-10-10 09:38:23.886', 2000, NULL, NULL, false, NULL, NULL, 2032, 1399);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1402, '2022-10-10 09:38:23.899', 2000, NULL, NULL, false, NULL, NULL, 2024, 1399);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1403, '2022-10-10 09:38:23.907', 2000, NULL, NULL, false, NULL, NULL, 2022, 1399);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (2001, '2022-08-25 16:59:51.835', 2000, '2022-09-26 10:44:41.643', 2000, true, NULL, NULL, 2013, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (2002, '2022-08-25 16:59:51.837', 2000, '2022-09-26 10:44:41.646', 2000, true, NULL, NULL, 2014, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (2003, '2022-08-25 17:26:54.387', 2000, '2022-09-26 10:44:41.647', 2000, true, NULL, NULL, 2015, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (2004, '2022-08-19 12:58:53.128', 2000, '2022-09-26 10:44:41.648', 2000, true, NULL, NULL, 2016, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (2005, '2022-08-19 14:10:38.988', 2000, '2022-09-26 10:44:41.649', 2000, true, NULL, NULL, 2017, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (2006, '2022-08-19 14:18:18.811', 2000, '2022-09-26 10:44:41.651', 2000, true, NULL, NULL, 2018, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (2007, '2022-08-19 12:58:53.129', 2000, '2022-09-26 10:44:41.652', 2000, true, NULL, NULL, 2019, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (2008, '2022-08-19 14:10:38.987', 2000, '2022-09-26 10:44:41.653', 2000, true, NULL, NULL, 2020, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (2009, '2022-08-19 14:18:18.81', 2000, '2022-09-26 10:44:41.654', 2000, true, NULL, NULL, 2000, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1175, '2022-09-26 10:44:41.667', 2000, NULL, NULL, false, NULL, NULL, 2034, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1176, '2022-09-26 10:44:41.669', 2000, NULL, NULL, false, NULL, NULL, 2033, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1177, '2022-09-26 10:44:41.671', 2000, NULL, NULL, false, NULL, NULL, 2032, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1178, '2022-09-26 10:44:41.674', 2000, NULL, NULL, false, NULL, NULL, 2031, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1179, '2022-09-26 10:44:41.676', 2000, NULL, NULL, false, NULL, NULL, 2030, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1180, '2022-09-26 10:44:41.68', 2000, NULL, NULL, false, NULL, NULL, 2029, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1181, '2022-09-26 10:44:41.682', 2000, NULL, NULL, false, NULL, NULL, 2028, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1182, '2022-09-26 10:44:41.684', 2000, NULL, NULL, false, NULL, NULL, 2027, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1183, '2022-09-26 10:44:41.697', 2000, NULL, NULL, false, NULL, NULL, 2024, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1184, '2022-09-26 10:44:41.7', 2000, NULL, NULL, false, NULL, NULL, 2023, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1185, '2022-09-26 10:44:41.702', 2000, NULL, NULL, false, NULL, NULL, 2022, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1186, '2022-09-26 10:44:41.703', 2000, NULL, NULL, false, NULL, NULL, 2021, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1187, '2022-09-26 10:44:41.706', 2000, NULL, NULL, false, NULL, NULL, 2020, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1188, '2022-09-26 10:44:41.707', 2000, NULL, NULL, false, NULL, NULL, 2019, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1189, '2022-09-26 10:44:41.709', 2000, NULL, NULL, false, NULL, NULL, 2018, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1190, '2022-09-26 10:44:41.711', 2000, NULL, NULL, false, NULL, NULL, 2017, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1191, '2022-09-26 10:44:41.713', 2000, NULL, NULL, false, NULL, NULL, 2016, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1192, '2022-09-26 10:44:41.716', 2000, NULL, NULL, false, NULL, NULL, 2015, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1193, '2022-09-26 10:44:41.727', 2000, NULL, NULL, false, NULL, NULL, 2014, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1194, '2022-09-26 10:44:41.729', 2000, NULL, NULL, false, NULL, NULL, 2013, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1195, '2022-09-26 10:44:41.731', 2000, NULL, NULL, false, NULL, NULL, 2012, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1196, '2022-09-26 10:44:41.733', 2000, NULL, NULL, false, NULL, NULL, 2011, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1197, '2022-09-26 10:44:41.734', 2000, NULL, NULL, false, NULL, NULL, 2010, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1198, '2022-09-26 10:44:41.736', 2000, NULL, NULL, false, NULL, NULL, 2009, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1199, '2022-09-26 10:44:41.738', 2000, NULL, NULL, false, NULL, NULL, 2008, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1200, '2022-09-26 10:44:41.739', 2000, NULL, NULL, false, NULL, NULL, 2007, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1201, '2022-09-26 10:44:41.741', 2000, NULL, NULL, false, NULL, NULL, 2006, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1202, '2022-09-26 10:44:41.743', 2000, NULL, NULL, false, NULL, NULL, 2005, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1203, '2022-09-26 10:44:41.745', 2000, NULL, NULL, false, NULL, NULL, 2000, 2002);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1253, '2022-09-26 10:48:01.357', 2000, '2022-09-26 10:54:14.658', 2000, true, NULL, NULL, 2006, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1254, '2022-09-26 10:48:01.36', 2000, '2022-09-26 10:54:14.668', 2000, true, NULL, NULL, 2005, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1233, '2022-09-26 10:48:01.292', 2000, '2022-09-26 10:54:14.676', 2000, true, NULL, NULL, 2034, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1234, '2022-09-26 10:48:01.295', 2000, '2022-09-26 10:54:14.677', 2000, true, NULL, NULL, 2033, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1235, '2022-09-26 10:48:01.298', 2000, '2022-09-26 10:54:14.679', 2000, true, NULL, NULL, 2032, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1236, '2022-09-26 10:48:01.3', 2000, '2022-09-26 10:54:14.68', 2000, true, NULL, NULL, 2031, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1237, '2022-09-26 10:48:01.302', 2000, '2022-09-26 10:54:14.681', 2000, true, NULL, NULL, 2030, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1238, '2022-09-26 10:48:01.304', 2000, '2022-09-26 10:54:14.682', 2000, true, NULL, NULL, 2029, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1239, '2022-09-26 10:48:01.305', 2000, '2022-09-26 10:54:14.683', 2000, true, NULL, NULL, 2028, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1240, '2022-09-26 10:48:01.307', 2000, '2022-09-26 10:54:14.684', 2000, true, NULL, NULL, 2027, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1241, '2022-09-26 10:48:01.321', 2000, '2022-09-26 10:54:14.685', 2000, true, NULL, NULL, 2024, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1242, '2022-09-26 10:48:01.323', 2000, '2022-09-26 10:54:14.686', 2000, true, NULL, NULL, 2023, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1243, '2022-09-26 10:48:01.325', 2000, '2022-09-26 10:54:14.698', 2000, true, NULL, NULL, 2022, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1244, '2022-09-26 10:48:01.327', 2000, '2022-09-26 10:54:14.699', 2000, true, NULL, NULL, 2014, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1245, '2022-09-26 10:48:01.33', 2000, '2022-09-26 10:54:14.7', 2000, true, NULL, NULL, 2013, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1246, '2022-09-26 10:48:01.332', 2000, '2022-09-26 10:54:14.701', 2000, true, NULL, NULL, 2012, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1247, '2022-09-26 10:48:01.334', 2000, '2022-09-26 10:54:14.702', 2000, true, NULL, NULL, 2011, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1248, '2022-09-26 10:48:01.336', 2000, '2022-09-26 10:54:14.703', 2000, true, NULL, NULL, 2010, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1249, '2022-09-26 10:48:01.338', 2000, '2022-09-26 10:54:14.704', 2000, true, NULL, NULL, 2009, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1250, '2022-09-26 10:48:01.34', 2000, '2022-09-26 10:54:14.706', 2000, true, NULL, NULL, 2008, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1251, '2022-09-26 10:48:01.352', 2000, '2022-09-26 10:54:14.707', 2000, true, NULL, NULL, 2021, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1252, '2022-09-26 10:48:01.355', 2000, '2022-09-26 10:54:14.708', 2000, true, NULL, NULL, 2007, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1300, '2022-09-26 10:54:14.832', 2000, NULL, NULL, false, NULL, NULL, 2005, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1301, '2022-09-26 10:54:14.834', 2000, NULL, NULL, false, NULL, NULL, 2006, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1302, '2022-09-26 10:54:14.837', 2000, NULL, NULL, false, NULL, NULL, 2007, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1303, '2022-09-26 10:54:14.838', 2000, NULL, NULL, false, NULL, NULL, 2008, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1304, '2022-09-26 10:54:14.838', 2000, NULL, NULL, false, NULL, NULL, 2009, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1305, '2022-09-26 10:54:14.838', 2000, NULL, NULL, false, NULL, NULL, 2010, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1306, '2022-09-26 10:54:14.854', 2000, NULL, NULL, false, NULL, NULL, 2011, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1307, '2022-09-26 10:54:14.854', 2000, NULL, NULL, false, NULL, NULL, 2012, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1308, '2022-09-26 10:54:14.854', 2000, NULL, NULL, false, NULL, NULL, 2013, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1309, '2022-09-26 10:54:14.854', 2000, NULL, NULL, false, NULL, NULL, 2014, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1310, '2022-09-26 10:54:14.854', 2000, NULL, NULL, false, NULL, NULL, 2021, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1311, '2022-09-26 10:54:14.854', 2000, NULL, NULL, false, NULL, NULL, 2022, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1312, '2022-09-26 10:54:14.87', 2000, NULL, NULL, false, NULL, NULL, 2023, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1313, '2022-09-26 10:54:14.87', 2000, NULL, NULL, false, NULL, NULL, 2024, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1314, '2022-09-26 10:54:14.87', 2000, NULL, NULL, false, NULL, NULL, 2027, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1315, '2022-09-26 10:54:14.885', 2000, NULL, NULL, false, NULL, NULL, 2028, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1316, '2022-09-26 10:54:14.885', 2000, NULL, NULL, false, NULL, NULL, 2029, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1317, '2022-09-26 10:54:14.885', 2000, NULL, NULL, false, NULL, NULL, 2030, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1318, '2022-09-26 10:54:14.885', 2000, NULL, NULL, false, NULL, NULL, 2031, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1319, '2022-09-26 10:54:14.885', 2000, NULL, NULL, false, NULL, NULL, 2032, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1320, '2022-09-26 10:54:14.885', 2000, NULL, NULL, false, NULL, NULL, 2033, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1321, '2022-09-26 10:54:14.901', 2000, NULL, NULL, false, NULL, NULL, 2034, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1322, '2022-09-26 10:54:14.901', 2000, NULL, NULL, false, NULL, NULL, 2015, 2003);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1343, '2022-09-26 12:04:27.131', 2000, NULL, NULL, false, NULL, NULL, 2033, 2001);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1344, '2022-09-26 12:04:27.135', 2000, NULL, NULL, false, NULL, NULL, 2032, 2001);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1345, '2022-09-26 12:04:27.145', 2000, NULL, NULL, false, NULL, NULL, 2027, 2001);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1346, '2022-09-26 12:04:27.149', 2000, NULL, NULL, false, NULL, NULL, 2022, 2001);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1347, '2022-09-26 12:04:27.151', 2000, NULL, NULL, false, NULL, NULL, 2021, 2001);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1348, '2022-09-26 12:04:27.153', 2000, NULL, NULL, false, NULL, NULL, 2009, 2001);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1349, '2022-09-26 12:04:27.155', 2000, NULL, NULL, false, NULL, NULL, 2008, 2001);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1350, '2022-09-26 12:04:27.157', 2000, NULL, NULL, false, NULL, NULL, 2007, 2001);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1351, '2022-09-26 12:04:27.159', 2000, NULL, NULL, false, NULL, NULL, 2006, 2001);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1352, '2022-09-26 12:04:27.161', 2000, NULL, NULL, false, NULL, NULL, 2005, 2001);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1353, '2022-09-26 12:05:57.12', 2000, NULL, NULL, false, NULL, NULL, 2033, 2000);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1354, '2022-09-26 12:05:57.132', 2000, NULL, NULL, false, NULL, NULL, 2032, 2000);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1355, '2022-09-26 12:05:57.134', 2000, NULL, NULL, false, NULL, NULL, 2027, 2000);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1356, '2022-09-26 12:05:57.136', 2000, NULL, NULL, false, NULL, NULL, 2024, 2000);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1357, '2022-09-26 12:05:57.137', 2000, NULL, NULL, false, NULL, NULL, 2023, 2000);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1358, '2022-09-26 12:05:57.139', 2000, NULL, NULL, false, NULL, NULL, 2022, 2000);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1359, '2022-09-26 12:05:57.142', 2000, NULL, NULL, false, NULL, NULL, 2021, 2000);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1360, '2022-09-26 12:05:57.144', 2000, NULL, NULL, false, NULL, NULL, 2009, 2000);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1361, '2022-09-26 12:05:57.146', 2000, NULL, NULL, false, NULL, NULL, 2008, 2000);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1362, '2022-09-26 12:05:57.148', 2000, NULL, NULL, false, NULL, NULL, 2007, 2000);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1363, '2022-09-26 12:05:57.15', 2000, NULL, NULL, false, NULL, NULL, 2006, 2000);
INSERT INTO public.role_functionalities (id, created_at, created_by, deleted_at, deleted_by, is_deleted, updated_at, updated_by, functionalities_id, role_id) VALUES (1364, '2022-09-26 12:05:57.163', 2000, NULL, NULL, false, NULL, NULL, 2005, 2000);


--
-- TOC entry 3196 (class 0 OID 16493)
-- Dependencies: 213
-- Data for Name: type_compte_type_carte; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3199 (class 0 OID 16514)
-- Dependencies: 216
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.users (id, created_at, created_by, deleted_at, deleted_by, is_actif, is_deleted, is_first, last_connection_date, login, matricule, nom, nom_prenoms, password, prenoms, updated_at, updated_by, agence_id, role_id, number_of_connections) VALUES (1338, '2022-09-26 11:12:32.057', 1277, NULL, NULL, true, false, true, '2022-09-30 10:08:15.201', 'LQK74SM', NULL, 'Koffi', NULL, 'f7c3bc1d808e04732adf679965ccc34ca7ae3441', 'Etienne', NULL, NULL, 19, 2001, 1);
INSERT INTO public.users (id, created_at, created_by, deleted_at, deleted_by, is_actif, is_deleted, is_first, last_connection_date, login, matricule, nom, nom_prenoms, password, prenoms, updated_at, updated_by, agence_id, role_id, number_of_connections) VALUES (1342, '2022-09-26 11:16:27.008', 1341, NULL, NULL, true, false, true, NULL, 'MQLIZ78', NULL, 'ORO', NULL, '87acec17cd9dcd20a716cc2cf67417b71c8a7016', 'George', NULL, NULL, 24, 2001, NULL);
INSERT INTO public.users (id, created_at, created_by, deleted_at, deleted_by, is_actif, is_deleted, is_first, last_connection_date, login, matricule, nom, nom_prenoms, password, prenoms, updated_at, updated_by, agence_id, role_id, number_of_connections) VALUES (1277, '2022-09-26 10:52:11.227', 2000, NULL, NULL, true, false, true, '2022-10-04 08:54:57.087', 'ADJ52KS', NULL, 'Mona', NULL, 'f7c3bc1d808e04732adf679965ccc34ca7ae3441', 'Paul Fabrice', NULL, NULL, 26, 2003, 1);
INSERT INTO public.users (id, created_at, created_by, deleted_at, deleted_by, is_actif, is_deleted, is_first, last_connection_date, login, matricule, nom, nom_prenoms, password, prenoms, updated_at, updated_by, agence_id, role_id, number_of_connections) VALUES (2000, '2022-09-21 09:25:51.935', 2000, NULL, NULL, true, false, true, '2022-10-10 08:50:35.527', 'SYSADMIN', NULL, 'Root', NULL, '80e93403887682e0b01ec1ac5c4b9f283a502a94', 'System', '2022-09-21 09:29:16.992', 2000, 26, 2002, 1);
INSERT INTO public.users (id, created_at, created_by, deleted_at, deleted_by, is_actif, is_deleted, is_first, last_connection_date, login, matricule, nom, nom_prenoms, password, prenoms, updated_at, updated_by, agence_id, role_id, number_of_connections) VALUES (1339, '2022-09-26 11:13:16.649', 1277, NULL, NULL, true, false, true, '2022-09-26 12:04:40.874', 'NBQ02IQ', NULL, 'Yapi', NULL, 'f7c3bc1d808e04732adf679965ccc34ca7ae3441', 'Eros', NULL, NULL, 25, 2001, 1);
INSERT INTO public.users (id, created_at, created_by, deleted_at, deleted_by, is_actif, is_deleted, is_first, last_connection_date, login, matricule, nom, nom_prenoms, password, prenoms, updated_at, updated_by, agence_id, role_id, number_of_connections) VALUES (1341, '2022-09-26 11:14:57.016', 2000, NULL, NULL, true, false, true, '2022-09-26 12:15:25.453', 'BBQG225', NULL, 'DOBOU', NULL, 'f7c3bc1d808e04732adf679965ccc34ca7ae3441', 'Armel', NULL, NULL, 25, 2003, 1);
INSERT INTO public.users (id, created_at, created_by, deleted_at, deleted_by, is_actif, is_deleted, is_first, last_connection_date, login, matricule, nom, nom_prenoms, password, prenoms, updated_at, updated_by, agence_id, role_id, number_of_connections) VALUES (1324, '2022-09-26 10:56:18.832', 1277, NULL, NULL, true, false, true, NULL, 'J7PO5AZ', NULL, 'Bossou', NULL, '87acec17cd9dcd20a716cc2cf67417b71c8a7016', 'Pierre Pacome', NULL, NULL, 24, 2000, NULL);
INSERT INTO public.users (id, created_at, created_by, deleted_at, deleted_by, is_actif, is_deleted, is_first, last_connection_date, login, matricule, nom, nom_prenoms, password, prenoms, updated_at, updated_by, agence_id, role_id, number_of_connections) VALUES (1325, '2022-09-26 10:57:01.105', 1277, NULL, NULL, true, false, true, NULL, 'B4JH230', NULL, 'Emissou', NULL, '87acec17cd9dcd20a716cc2cf67417b71c8a7016', 'Paul Orel', NULL, NULL, 23, 2000, NULL);
INSERT INTO public.users (id, created_at, created_by, deleted_at, deleted_by, is_actif, is_deleted, is_first, last_connection_date, login, matricule, nom, nom_prenoms, password, prenoms, updated_at, updated_by, agence_id, role_id, number_of_connections) VALUES (1326, '2022-09-26 10:57:39.768', 1277, NULL, NULL, true, false, true, NULL, 'GFQT54A', NULL, 'Houra', NULL, '87acec17cd9dcd20a716cc2cf67417b71c8a7016', 'Gilbert Bertrand', NULL, NULL, 22, 2000, NULL);
INSERT INTO public.users (id, created_at, created_by, deleted_at, deleted_by, is_actif, is_deleted, is_first, last_connection_date, login, matricule, nom, nom_prenoms, password, prenoms, updated_at, updated_by, agence_id, role_id, number_of_connections) VALUES (1327, '2022-09-26 10:58:27.151', 1277, NULL, NULL, true, false, true, NULL, 'HG78QJ2', NULL, 'Ekra', NULL, '87acec17cd9dcd20a716cc2cf67417b71c8a7016', 'Flora', NULL, NULL, 21, 2000, NULL);
INSERT INTO public.users (id, created_at, created_by, deleted_at, deleted_by, is_actif, is_deleted, is_first, last_connection_date, login, matricule, nom, nom_prenoms, password, prenoms, updated_at, updated_by, agence_id, role_id, number_of_connections) VALUES (1330, '2022-09-26 11:01:20.222', 1277, NULL, NULL, true, false, true, NULL, 'NB0U72H', NULL, 'Konaga', NULL, '87acec17cd9dcd20a716cc2cf67417b71c8a7016', 'Francois', NULL, NULL, 26, 2000, NULL);
INSERT INTO public.users (id, created_at, created_by, deleted_at, deleted_by, is_actif, is_deleted, is_first, last_connection_date, login, matricule, nom, nom_prenoms, password, prenoms, updated_at, updated_by, agence_id, role_id, number_of_connections) VALUES (1331, '2022-09-26 11:02:54.945', 1277, NULL, NULL, true, false, true, NULL, 'Q4STR0N', NULL, 'ASSOUMOU', NULL, '87acec17cd9dcd20a716cc2cf67417b71c8a7016', 'Jeanne', NULL, NULL, 26, 2001, NULL);
INSERT INTO public.users (id, created_at, created_by, deleted_at, deleted_by, is_actif, is_deleted, is_first, last_connection_date, login, matricule, nom, nom_prenoms, password, prenoms, updated_at, updated_by, agence_id, role_id, number_of_connections) VALUES (1332, '2022-09-26 11:04:02.956', 1277, NULL, NULL, true, false, true, NULL, 'HS54M20', NULL, 'Gegro', NULL, '87acec17cd9dcd20a716cc2cf67417b71c8a7016', 'Robert', NULL, NULL, 25, 2001, NULL);
INSERT INTO public.users (id, created_at, created_by, deleted_at, deleted_by, is_actif, is_deleted, is_first, last_connection_date, login, matricule, nom, nom_prenoms, password, prenoms, updated_at, updated_by, agence_id, role_id, number_of_connections) VALUES (1333, '2022-09-26 11:05:34.23', 1277, NULL, NULL, true, false, true, NULL, 'OP22UYE', NULL, 'Edo', NULL, '87acec17cd9dcd20a716cc2cf67417b71c8a7016', 'Camara', NULL, NULL, 24, 2001, NULL);
INSERT INTO public.users (id, created_at, created_by, deleted_at, deleted_by, is_actif, is_deleted, is_first, last_connection_date, login, matricule, nom, nom_prenoms, password, prenoms, updated_at, updated_by, agence_id, role_id, number_of_connections) VALUES (1334, '2022-09-26 11:06:05.777', 1277, NULL, NULL, true, false, true, NULL, 'BBH67GQ', NULL, 'AMICHIA', NULL, '87acec17cd9dcd20a716cc2cf67417b71c8a7016', 'Pauline', NULL, NULL, 23, 2001, NULL);
INSERT INTO public.users (id, created_at, created_by, deleted_at, deleted_by, is_actif, is_deleted, is_first, last_connection_date, login, matricule, nom, nom_prenoms, password, prenoms, updated_at, updated_by, agence_id, role_id, number_of_connections) VALUES (1335, '2022-09-26 11:06:35.665', 1277, NULL, NULL, true, false, true, NULL, 'JSHJQ52', NULL, 'Adou', NULL, '87acec17cd9dcd20a716cc2cf67417b71c8a7016', 'Pacome', NULL, NULL, 22, 2001, NULL);
INSERT INTO public.users (id, created_at, created_by, deleted_at, deleted_by, is_actif, is_deleted, is_first, last_connection_date, login, matricule, nom, nom_prenoms, password, prenoms, updated_at, updated_by, agence_id, role_id, number_of_connections) VALUES (1340, '2022-09-26 11:14:09.806', 1277, NULL, NULL, true, false, true, '2022-09-28 14:48:53.139', 'BVQ254S', NULL, 'Comoe', NULL, 'f7c3bc1d808e04732adf679965ccc34ca7ae3441', 'Francis', NULL, NULL, 26, 2001, 1);
INSERT INTO public.users (id, created_at, created_by, deleted_at, deleted_by, is_actif, is_deleted, is_first, last_connection_date, login, matricule, nom, nom_prenoms, password, prenoms, updated_at, updated_by, agence_id, role_id, number_of_connections) VALUES (1337, '2022-09-26 11:11:51.653', 1277, NULL, NULL, true, false, true, NULL, 'L4IQU21', NULL, 'KAMATE', NULL, '87acec17cd9dcd20a716cc2cf67417b71c8a7016', 'Affitiatou', NULL, NULL, 20, 2001, NULL);
INSERT INTO public.users (id, created_at, created_by, deleted_at, deleted_by, is_actif, is_deleted, is_first, last_connection_date, login, matricule, nom, nom_prenoms, password, prenoms, updated_at, updated_by, agence_id, role_id, number_of_connections) VALUES (1323, '2022-09-26 10:55:22.066', 1277, NULL, NULL, true, false, true, '2022-09-28 14:59:31.998', 'M74UI6A', NULL, 'Kouakou', NULL, 'f7c3bc1d808e04732adf679965ccc34ca7ae3441', 'Jonas', NULL, NULL, 25, 2000, 1);
INSERT INTO public.users (id, created_at, created_by, deleted_at, deleted_by, is_actif, is_deleted, is_first, last_connection_date, login, matricule, nom, nom_prenoms, password, prenoms, updated_at, updated_by, agence_id, role_id, number_of_connections) VALUES (1329, '2022-09-26 11:00:11.664', 1277, NULL, NULL, true, false, true, '2022-09-30 09:29:51.082', 'TRAG45P', NULL, 'KoKu', NULL, 'f7c3bc1d808e04732adf679965ccc34ca7ae3441', 'Teodore', NULL, NULL, 19, 2000, 1);
INSERT INTO public.users (id, created_at, created_by, deleted_at, deleted_by, is_actif, is_deleted, is_first, last_connection_date, login, matricule, nom, nom_prenoms, password, prenoms, updated_at, updated_by, agence_id, role_id, number_of_connections) VALUES (1328, '2022-09-26 10:59:26.417', 1277, NULL, NULL, true, false, true, '2022-09-30 09:38:29.078', 'Z12A36P', NULL, 'Djobi', NULL, 'f7c3bc1d808e04732adf679965ccc34ca7ae3441', 'Marc Antoine', NULL, NULL, 20, 2000, 1);
INSERT INTO public.users (id, created_at, created_by, deleted_at, deleted_by, is_actif, is_deleted, is_first, last_connection_date, login, matricule, nom, nom_prenoms, password, prenoms, updated_at, updated_by, agence_id, role_id, number_of_connections) VALUES (1336, '2022-09-26 11:07:23.256', 1277, NULL, NULL, true, false, true, '2022-09-30 10:07:29.421', 'HGJJH451', NULL, 'BECRO', NULL, 'f7c3bc1d808e04732adf679965ccc34ca7ae3441', 'Georgette', '2022-09-26 11:07:49.741', 1277, 21, 2001, 1);


--
-- TOC entry 3215 (class 0 OID 0)
-- Dependencies: 217
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hibernate_sequence', 1411, true);


-- Completed on 2022-10-11 18:27:41

--
-- PostgreSQL database dump complete
--

