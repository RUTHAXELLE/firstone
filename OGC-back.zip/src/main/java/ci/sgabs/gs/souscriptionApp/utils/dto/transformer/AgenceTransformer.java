package ci.sgabs.gs.souscriptionApp.utils.dto.transformer;

import ci.sgabs.gs.souscriptionApp.dao.entity.Agence;
import ci.sgabs.gs.souscriptionApp.helper.contrat.FullTransformerQualifier;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.AgenceDto;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

@Mapper
public interface AgenceTransformer {

    AgenceTransformer INSTANCE = Mappers.getMapper(AgenceTransformer.class);

    @FullTransformerQualifier
    @Mappings({
            @Mapping(source = "entity.id", target = "id"),
            @Mapping(source = "entity.code", target = "code"),
            @Mapping(source = "entity.address", target = "address"),
            @Mapping(source="entity.updatedAt", dateFormat="dd/MM/yyyy",target="updatedAt"),
            @Mapping(source="entity.createdAt", dateFormat="dd/MM/yyyy",target="createdAt"),
            @Mapping(source="entity.deletedAt", dateFormat="dd/MM/yyyy",target="deletedAt"),
            @Mapping(source="entity.updatedBy",target="updatedBy"),
            @Mapping(source="entity.createdBy", target="createdBy"),
            @Mapping(source="entity.deletedBy", target="deletedBy"),
            @Mapping(source="entity.isDeleted", target="isDeleted"),
    })
    AgenceDto toDto(Agence entity);

    @IterableMapping(qualifiedBy = {FullTransformerQualifier.class})
    List<AgenceDto> toDtos(List<Agence> entities) throws ParseException;

    public default AgenceDto toLiteDto(Agence entity) {
        if (entity == null) {
            return null;
        }
        AgenceDto dto = new AgenceDto();
        dto.setId( entity.getId() );
        dto.setCode( entity.getCode() );
        dto.setAddress(entity.getAddress());
        return dto;
    }

    public default List<AgenceDto> toLiteDtos(List<Agence> entities) {
        if (entities == null || entities.stream().allMatch(o -> o == null)) {
            return null;
        }
        List<AgenceDto> dtos = new ArrayList<AgenceDto>();
        for (Agence entity : entities) {
            dtos.add(toLiteDto(entity));
        }
        return dtos;
    }
    @InheritInverseConfiguration
    Agence toEntity(AgenceDto dto);
}
