package ci.sgabs.gs.souscriptionApp.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Compte implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @Column(name="numero", length=255)
    private String numero;
    @Column(name="description", length=255)
    private String description;
    @ManyToOne(fetch = FetchType.EAGER)
    private TypeCompte typeCompte;
    @ManyToOne(fetch = FetchType.EAGER)
    private Client client;
    @ManyToOne(fetch = FetchType.EAGER)
    private Agence agence;

    @Column(name="is_deleted")
    private Boolean isDeleted;
    @Column(name="is_actif")
    private Boolean isActif;

    private Date createdAt;
    private Date updatedAt;
    private Date deletedAt;

    private Integer createdBy;
    private Integer updatedBy;
    private Integer deletedBy;


}

