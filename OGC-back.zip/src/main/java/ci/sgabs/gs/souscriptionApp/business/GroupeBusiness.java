package ci.sgabs.gs.souscriptionApp.business;

import ci.sgabs.gs.souscriptionApp.dao.entity.Groupe;
import ci.sgabs.gs.souscriptionApp.dao.repository.GroupeRepository;
import ci.sgabs.gs.souscriptionApp.helper.contrat.IBasicBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.errors.TechnicalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.helper.validation.Validate;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.GroupeDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.GroupeTransformer;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Log
@Component
public class GroupeBusiness implements IBasicBusiness<Request<GroupeDto>, Response<GroupeDto>> {

    private Response<GroupeDto> response;
    @Autowired
    private GroupeRepository groupeRepository;
    
    @Autowired
    private FunctionalError functionalError;
    @Autowired
    private TechnicalError technicalError;
    @Autowired
    private ExceptionUtils exceptionUtils;
    @Autowired
    private EntityManager em;
    private final SimpleDateFormat dateFormat;
    private final SimpleDateFormat dateTimeFormat;

    public GroupeBusiness() {
        dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    }
    
    
    @Override
    public Response<GroupeDto> create(Request<GroupeDto> request, Locale locale) throws Exception {

        log.info("----begin create Groupe-----");

        Response<GroupeDto> response = new Response<GroupeDto>();
        List<Groupe> items = new ArrayList<Groupe>();

        for(GroupeDto dto : request.getDatas()){

            //******* Definition et verification des parametres obligatoires ******//

            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("code", dto.getCode());
            fieldsToVerify.put("description", dto.getDescription());

            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }

            //***** Verification s'il existe deja un Groupe en base ou dans la liste à inséré avec le même code  *********//

            Groupe existingEntity = null;
            existingEntity = groupeRepository.findByCode(dto.getCode(), false); //verification en base
            if (existingEntity != null) {
                response.setStatus(functionalError.DATA_EXIST("Groupe code -> " + dto.getCode(), locale));
                response.setHasError(true);
                return response;
            }

            if (items.stream().anyMatch(a -> a.getCode().equalsIgnoreCase(dto.getCode()))) { // verification deans la liste à inseré
                response.setStatus(functionalError.DATA_DUPLICATE(" code ", locale));
                response.setHasError(true);
                return response;
            }

            Groupe entityToSave = GroupeTransformer.INSTANCE.toEntity(dto);
            entityToSave.setIsDeleted(false);
            entityToSave.setCreatedAt(Utilities.getCurrentDate());
            entityToSave.setCreatedBy(request.userID);
            items.add(entityToSave);
        }

        //***** insertion en base de données *********//

        if (!items.isEmpty()) {
            List<Groupe> itemsSaved = null;
            itemsSaved = groupeRepository.saveAll((Iterable<Groupe>) items);
            
            if (itemsSaved == null) {
                response.setStatus(functionalError.SAVE_FAIL("Groupe", locale));
                response.setHasError(true);
                return response;
            }
            List<GroupeDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading())) ? GroupeTransformer.INSTANCE.toLiteDtos(itemsSaved) : GroupeTransformer.INSTANCE.toDtos(itemsSaved);

            response.setItems(itemsDto);
            response.setHasError(false);
            response.setStatus(functionalError.SUCCESS("", locale));
        }
        log.info("----end create Groupe-----");
        
        return response;
    }

    @Override
    public Response<GroupeDto> update(Request<GroupeDto> request, Locale locale) throws ParseException {

        log.info("----begin update Groupe-----");

        Response<GroupeDto> response = new Response<GroupeDto>();
        List<Groupe> items = new ArrayList<Groupe>();

        for(GroupeDto dto : request.getDatas()){

            //******* Definition et verification des parametres obligatoires ******//

            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());

            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {

                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);

                return response;
            }

            //***** Verification s'il existe un Groupe en base avec l'id fourni *********//

            Groupe entityToSave = null;
            entityToSave = groupeRepository.findOne(dto.getId(), false);

            if (entityToSave == null) {

                response.setStatus(functionalError.DATA_NOT_EXIST("Groupe id -> " + dto.getId(), locale));
                response.setHasError(true);

                return response;
            }

            //***** Verification s'il existe deja un Groupe en base ou dans la liste à inséré, avec le meme code *********//

            Integer entityToSaveId = entityToSave.getId();
            GroupeDto entityToSaveDto = GroupeTransformer.INSTANCE.toDto(entityToSave);

            if (Utilities.isNotBlank(dto.getCode()) && !dto.getCode().equals(entityToSave.getCode())) { //verify code
                Groupe existingEntity = groupeRepository.findByCode(dto.getCode(), false);
                if (existingEntity != null && !existingEntity.getId().equals(entityToSave.getId())) {
                    response.setStatus(functionalError.DATA_EXIST("Groupe code -> " + dto.getCode(), locale));
                    response.setHasError(true);

                    return response;
                }

                if (items.stream().anyMatch(a -> a.getCode().equalsIgnoreCase(dto.getCode()) && !a.getId().equals(entityToSaveId))) {
                    response.setStatus(functionalError.DATA_DUPLICATE("Tentative de duplication du code '" + dto.getCode() + "' pour les Groupes ", locale));
                    response.setHasError(true);

                    return response;
                }
                entityToSaveDto.setCode(dto.getCode());
            }

            //***** Verification et modification des autres attributs fournis *********//
            if (Utilities.isNotBlank(dto.getDescription()) && !dto.getDescription().equals(entityToSave.getDescription())) {
                entityToSaveDto.setDescription(dto.getDescription());
            }

            Groupe groupeEntity = GroupeTransformer.INSTANCE.toEntity(entityToSaveDto);
            groupeEntity.setUpdatedAt(Utilities.getCurrentDate());
            groupeEntity.setUpdatedBy(request.userID);
            items.add(groupeEntity);
        }

        //***** insertion en base de données *********//

        if (!items.isEmpty()) {
            
            List<Groupe> itemsSaved = null;
            itemsSaved = groupeRepository.saveAll((Iterable<Groupe>) items);
            
            if (itemsSaved == null) {
                response.setStatus(functionalError.SAVE_FAIL("Groupe", locale));
                response.setHasError(true);
                return response;
            }
            
            List<GroupeDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading())) ? GroupeTransformer.INSTANCE.toLiteDtos(itemsSaved) : GroupeTransformer.INSTANCE.toDtos(itemsSaved);

            response.setItems(itemsDto);
            response.setHasError(false);
            response.setStatus(functionalError.SUCCESS("", locale));
        }
        log.info("----end update Groupe-----");
        return response;
    }

    @Override
    public Response<GroupeDto> delete(Request<GroupeDto> request, Locale locale) {

        log.info("----begin delete Groupe-----");

        Response<GroupeDto> response = new Response<GroupeDto>();
        List<Groupe> items = new ArrayList<Groupe>();

        for(GroupeDto dto : request.getDatas()){

            //******* Definition et verification des parametres obligatoires ******//

            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }

            //***** Verification s'il existe un Groupe en base avec l'id fourni *********//

            Groupe existingEntity = null;
            existingEntity = groupeRepository.findOne(dto.getId(), false);
            if (existingEntity == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Groupe id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }

            existingEntity.setIsDeleted(true);
            existingEntity.setDeletedAt(Utilities.getCurrentDate());
            existingEntity.setDeletedBy(request.userID);
            items.add(existingEntity);
        }

        //***** envoi de la reponse *********//

        if (!items.isEmpty()) {
            response.setHasError(false);
            response.setStatus(functionalError.SUCCESS("", locale));
        }

        log.info("----end delete Groupe-----");
        
        return response;
    }

    @Override
    public Response<GroupeDto> forceDelete(Request<GroupeDto> request, Locale locale) throws ParseException {
        return null;
    }

    @Override
    public Response<GroupeDto> getByCriteria(Request<GroupeDto> request, Locale locale) throws Exception {

        log.info("----begin get Groupe-----");

        Response<GroupeDto> response = new Response<GroupeDto>();

        //****** verification si le parametre d'ordre à été fourni, sinon nous mettons le paramètre à vide ********//

        if (Utilities.blank(request.getData().getOrderField())) {
            request.getData().setOrderField("");
        }

        //****** verification si le parametre direction à été fourni, sinon nous mettons le paramètre ascendant( du plus ancien au plus ressent) ********//

        if (Utilities.blank(request.getData().getOrderDirection())) {
            request.getData().setOrderDirection("asc");
        }

        //****** recuperation des entités en base *******//

        List<Groupe> items = groupeRepository.getByCriteria(request, em, locale);

        if (Utilities.isEmpty(items)) {
            response.setStatus(functionalError.DATA_EMPTY("Groupe", locale));
            response.setHasError(false);
            return response;
        }

        List<GroupeDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading())) ? GroupeTransformer.INSTANCE.toLiteDtos(items) : GroupeTransformer.INSTANCE.toDtos(items);


        response.setItems(itemsDto);
        response.setCount(groupeRepository.count(request, em, locale));
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        log.info("----end get Groupe-----");
        return response;
    }
}
