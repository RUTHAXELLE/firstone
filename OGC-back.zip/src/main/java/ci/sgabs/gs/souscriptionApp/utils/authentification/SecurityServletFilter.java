package ci.sgabs.gs.souscriptionApp.utils.authentification;

import ci.sgabs.gs.souscriptionApp.dao.entity.Users;
import ci.sgabs.gs.souscriptionApp.dao.repository.UsersRepository;
import ci.sgabs.gs.souscriptionApp.helper.contrat.RequestBase;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.UsersDto;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.annotation.ServletSecurity;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;


@Slf4j
@Component
@WebFilter(filterName = "Filter", urlPatterns = {"/roles"})
public class SecurityServletFilter extends HttpFilter {

    @Autowired
    private FunctionalError functionalError;
    @Autowired
    private ExceptionUtils exceptionUtils;
    @Autowired
    private UsersRepository usersRepository;

    private static String	defaultTenant	= "null";
    private static String defaultLanguage = "fr";

    @Override
    protected void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain)  {
        log.info("filter method begin");
        log.info(request.getRequestURI());

        SecurityServices.languageManager(request);
        String        languageID = (String) request.getAttribute("CURRENT_LANGUAGE_IDENTIFIER");
        Locale locale     = new Locale(languageID, "");
        Response<UsersDto> resp = new Response<UsersDto>();

        //ULRS exemptions authorization
        List<String> listUrlDoNotHaveAuthentication = Collections.synchronizedList(new ArrayList<String>());
        listUrlDoNotHaveAuthentication.add("/users/login");

        inializationResponseParamHeaders((HttpServletResponse) response);
        try{
            String path = request.getServletPath();
            if(listUrlDoNotHaveAuthentication.contains(path) ||  path.contains("swagger") || path.contains("/v2") || request.getMethod().toUpperCase().equalsIgnoreCase("OPTIONS")){
                chain.doFilter(request, response);
                return;
            }
            String token = SecurityServices.extractToken(request);
            if(token==null){
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED); // HTTP 401.
                resp.setStatus(functionalError.DATA_NOT_EXIST("Authentification Echouée", locale));
                resp.setHasError(true);
                response.getWriter().write(String.valueOf(resp));
                return;
            }
            Jws<Claims> jwt = SecurityServices.decodeAndValidateToken(token);
            if(jwt==null){
                 response.setStatus(HttpServletResponse.SC_UNAUTHORIZED); // HTTP 401.
                 resp.setStatus(functionalError.DATA_NOT_EXIST("Token invalide", locale));
                 resp.setHasError(true);
                 response.getWriter().write(String.valueOf(resp));
                 return;
            }
            boolean isAuthenticated=isAuthenticated=authenticateUser(jwt);
            if(!isAuthenticated){
                 response.setStatus(HttpServletResponse.SC_UNAUTHORIZED); // HTTP 401.
                 resp.setStatus(functionalError.DATA_NOT_EXIST("Utilisateur non autentifié", locale));
                 resp.setHasError(true);
                 response.getWriter().write(String.valueOf(resp));
                return;
            }
            RequestBase.userID = Integer.valueOf(jwt.getBody().getId());
            chain.doFilter(request, response); // (4)
        }catch (IOException e){
            exceptionUtils.PERMISSION_DENIED_DATA_ACCESS_EXCEPTION(resp, locale, e);
        }catch (ServletException e){
            exceptionUtils.PERMISSION_DENIED_DATA_ACCESS_EXCEPTION(resp, locale, e);
        }finally {
            if (resp.isHasError() && resp.getStatus() != null) {
                log.info(String.format("Erreur| code: {} -  message: {}", resp.getStatus().getCode(), resp.getStatus().getMessage()));
                throw new RuntimeException(resp.getStatus().getCode() + ";" + resp.getStatus().getMessage());
            }
        }
   }

    private void inializationResponseParamHeaders(HttpServletResponse response) {

        HttpServletResponse res = response;
        res.setHeader("Access-Control-Allow-Origin","*");
        res.setHeader("Access-Control-Allow-Methods", "POST,GET,PUT,DELETE");
        res.setHeader("Access-Control-Allow-Credentials","true");
        res.setHeader("Access-Control-Allow-Headers","Origin, Access-Control-Allow-Methods, " +
                "Accept, X-Requested-With, Content-Type, Access-Control-Allow-Origin, Access-Control-Request-Method, Authorization," +
                "Access-Control-Request-Headers, Show-Success-Message, Show-Loader, Show-Error-Message, sessionUser, lang, user, token, sessionuser, xsrf-token");
        res.addHeader("Access-Control-Expose-Headers", " xsrf-token");

    }

    private boolean authenticateUser(Jws<Claims> token) {
        Integer userId = Integer.valueOf(token.getBody().getId());
        Users user = usersRepository.findOne(userId,false);
        if(user == null){
            return false;
        }
        return true;
    }
}
