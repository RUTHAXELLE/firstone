package ci.sgabs.gs.souscriptionApp.utils.dto.transformer;

import ci.sgabs.gs.souscriptionApp.dao.entity.*;
import ci.sgabs.gs.souscriptionApp.helper.contrat.FullTransformerQualifier;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.AttributionDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.CompteDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.DemandeDto;
import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

@Mapper
public interface DemandeTransformer {

    DemandeTransformer INSTANCE = Mappers.getMapper(DemandeTransformer.class);

    @FullTransformerQualifier
    @Mappings({
            @Mapping(source = "entity.id", target = "id"),
            @Mapping(source = "entity.code", target = "code"),
            @Mapping(source = "entity.matricule", target = "matricule"),
            @Mapping(source = "entity.noms", target = "noms"),
            @Mapping(source = "entity.prenom", target = "prenom"),
            @Mapping(source = "entity.telephone", target = "telephone"),
            @Mapping(source = "entity.motif", target = "motif"),
            @Mapping(source = "entity.intitule", target = "intitule"),
            @Mapping(source = "entity.agence", target = "agence"),
            @Mapping(source = "entity.produit", target = "produit"),
            @Mapping(source = "entity.status.id", target = "statusId"),
            @Mapping(source = "entity.compte.id", target = "compteId"),
            @Mapping(source = "entity.typeCarte.id", target = "typeCarteId"),
            @Mapping(source = "entity.compte.numero", target = "numeroCompte"),
            @Mapping(source = "entity.typeCarte.code", target = "codeTypeCarte"),
            @Mapping(source = "entity.login", target = "login"),

            @Mapping(source = "entity.isPlafondHaut", target = "isPlafondHaut"),
            @Mapping(source = "entity.isPlafondBas", target = "isPlafondBas"),
            @Mapping(source = "entity.isPlafondMoyen", target = "isPlafondMoyen"),
            @Mapping(source = "entity.isGenreatedContrat", target = "isGenreatedContrat"),
            @Mapping(source = "entity.isForced", target = "isForced"),
            @Mapping(source = "entity.nomBeneficiaire", target = "nomBeneficiaire"),
            @Mapping(source = "entity.prenomBeneficiaire", target = "prenomBeneficiaire"),
            @Mapping(source = "entity.isBeneficiary", target = "isBeneficiary"),

            @Mapping(source = "entity.updatedAt", dateFormat = "dd/MM/yyyy", target = "updatedAt"),
            @Mapping(source = "entity.createdAt", dateFormat = "dd/MM/yyyy", target = "createdAt"),
            @Mapping(source = "entity.deletedAt", dateFormat = "dd/MM/yyyy", target = "deletedAt"),
            @Mapping(source = "entity.updatedBy", target = "updatedBy"),
            @Mapping(source = "entity.createdBy", target = "createdBy"),
            @Mapping(source = "entity.deletedBy", target = "deletedBy"),
            @Mapping(source = "entity.isDeleted", target = "isDeleted"),
    })
    DemandeDto toDto(Demande entity);

    @IterableMapping(qualifiedBy = {FullTransformerQualifier.class})
    List<DemandeDto> toDtos(List<Demande> entities) throws ParseException;

    public default DemandeDto toLiteDto(Demande entity) {
        if (entity == null) {
            return null;
        }

        DemandeDto dto = new DemandeDto();

        dto.setId(entity.getId());
        dto.setMatricule(entity.getMatricule());
        dto.setIntitule(entity.getIntitule());
        dto.setNoms(entity.getNoms());
        dto.setPrenom(entity.getPrenom());
        dto.setTelephone(entity.getTelephone());

        return dto;

    }

    public default List<DemandeDto> toLiteDtos(List<Demande> entities) {
        if (entities == null || entities.stream().allMatch(o -> o == null)) {
            return null;
        }
        List<DemandeDto> dtos = new ArrayList<DemandeDto>();
        for (Demande entity : entities) {
            dtos.add(toLiteDto(entity));
        }
        return dtos;
    }

    @Mappings({
            @Mapping(source = "dto.id", target = "id"),
            @Mapping(source = "dto.code", target = "code"),
            @Mapping(source = "dto.matricule", target = "matricule"),
            @Mapping(source = "dto.noms", target = "noms"),
            @Mapping(source = "dto.prenom", target = "prenom"),
            @Mapping(source = "dto.telephone", target = "telephone"),
            @Mapping(source = "dto.motif", target = "motif"),
            @Mapping(source = "dto.intitule", target = "intitule"),
            @Mapping(source = "dto.agence", target = "agence"),
            @Mapping(source = "dto.produit", target = "produit"),
            @Mapping(source = "dto.numeroCompte", target = "numeroCompte"),
            @Mapping(source = "dto.login", target = "login"),

            @Mapping(source = "dto.isPlafondHaut", target = "isPlafondHaut"),
            @Mapping(source = "dto.isPlafondBas", target = "isPlafondBas"),
            @Mapping(source = "dto.isPlafondMoyen", target = "isPlafondMoyen"),
            @Mapping(source = "dto.isGenreatedContrat", target = "isGenreatedContrat"),
            @Mapping(source = "dto.isForced", target = "isForced"),
            @Mapping(source = "dto.nomBeneficiaire", target = "nomBeneficiaire"),
            @Mapping(source = "dto.prenomBeneficiaire", target = "prenomBeneficiaire"),
            @Mapping(source = "dto.isBeneficiary", target = "isBeneficiary"),
            @Mapping(source = "dto.updatedAt", dateFormat = "dd/MM/yyyy", target = "updatedAt"),
            @Mapping(source = "dto.createdAt", dateFormat = "dd/MM/yyyy", target = "createdAt"),
            @Mapping(source = "dto.deletedAt", dateFormat = "dd/MM/yyyy", target = "deletedAt"),
            @Mapping(source = "dto.updatedBy", target = "updatedBy"),
            @Mapping(source = "dto.createdBy", target = "createdBy"),
            @Mapping(source = "dto.deletedBy", target = "deletedBy"),
            @Mapping(source = "dto.isDeleted", target = "isDeleted"),

            @Mapping(source = "typeCarte", target = "typeCarte"),
            @Mapping(source = "compte", target = "compte"),
            @Mapping(source = "status", target = "status")
    })
    Demande toEntity(DemandeDto dto, TypeCarte typeCarte, Compte compte, Status status);
}
