package ci.sgabs.gs.souscriptionApp.utils.dto.transformer;

import ci.sgabs.gs.souscriptionApp.dao.entity.*;
import ci.sgabs.gs.souscriptionApp.helper.contrat.FullTransformerQualifier;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.AttributionDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.CompteDto;
import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

@Mapper
public interface CompteTransformer {

    CompteTransformer INSTANCE = Mappers.getMapper(CompteTransformer.class);

    @FullTransformerQualifier
    @Mappings({
            @Mapping(source = "entity.id", target = "id"),
            @Mapping(source = "entity.numero", target = "numero"),
            @Mapping(source = "entity.description", target = "description"),
            @Mapping(source = "entity.client.id", target = "clientId"),
            @Mapping(source = "entity.typeCompte.id", target = "typeCompteId"),
            @Mapping(source = "entity.agence.id", target = "agenceId"),
            @Mapping(source = "entity.client.code", target = "codeClient"),
            @Mapping(source = "entity.client.nom", target = "nomClient"),
            @Mapping(source = "entity.client.prenoms", target = "prenomsClient"),
            @Mapping(source = "entity.client.civilite", target = "civiliteClient"),
            @Mapping(source = "entity.typeCompte.code", target = "codeTypeCompte"),
            @Mapping(source = "entity.agence.code", target = "codeAgence"),
            @Mapping(source = "entity.isActif", target = "isActif"),

            @Mapping(source="entity.updatedAt", dateFormat="dd/MM/yyyy HH:mm:ss",target="updatedAt"),
            @Mapping(source="entity.createdAt", dateFormat="dd/MM/yyyy HH:mm:ss",target="createdAt"),
            @Mapping(source="entity.deletedAt", dateFormat="dd/MM/yyyy HH:mm:ss",target="deletedAt"),
            @Mapping(source="entity.updatedBy",target="updatedBy"),
            @Mapping(source="entity.createdBy", target="createdBy"),
            @Mapping(source="entity.deletedBy", target="deletedBy"),
            @Mapping(source="entity.isDeleted", target="isDeleted"),
    })
    CompteDto toDto(Compte entity);
    @IterableMapping(qualifiedBy = {FullTransformerQualifier.class})
    List<CompteDto> toDtos(List<Compte> entities) throws ParseException;

    public default CompteDto toLiteDto(Compte entity) {
        if (entity == null) {
            return null;
        }
        CompteDto dto = new CompteDto();
        dto.setId( entity.getId() );
        dto.setNumero( entity.getNumero() );
        dto.setDescription(entity.getDescription());
        return dto;
    }

    public default List<CompteDto> toLiteDtos(List<Compte> entities) {
        if (entities == null || entities.stream().allMatch(o -> o == null)) {
            return null;
        }
        List<CompteDto> dtos = new ArrayList<CompteDto>();
        for (Compte entity : entities) {
            dtos.add(toLiteDto(entity));
        }
        return dtos;
    }

    @Mappings({
            @Mapping(source = "dto.id", target = "id"),
            @Mapping(source = "dto.numero", target = "numero"),
            @Mapping(source = "dto.description", target = "description"),

            @Mapping(source="dto.updatedAt", dateFormat="dd/MM/yyyy HH:mm:ss",target="updatedAt"),
            @Mapping(source="dto.createdAt", dateFormat="dd/MM/yyyy HH:mm:ss",target="createdAt"),
            @Mapping(source="dto.deletedAt", dateFormat="dd/MM/yyyy HH:mm:ss",target="deletedAt"),
            @Mapping(source="dto.updatedBy",target="updatedBy"),
            @Mapping(source="dto.createdBy", target="createdBy"),
            @Mapping(source="dto.deletedBy", target="deletedBy"),
            @Mapping(source="dto.isDeleted", target="isDeleted"),
            @Mapping(source="dto.isActif", target="isActif"),
            @Mapping(source = "client", target = "client"),
            @Mapping(source = "typeCompte", target = "typeCompte"),
            @Mapping(source = "agence", target = "agence")
    })
    Compte toEntity(CompteDto dto, Client client, TypeCompte typeCompte, Agence agence);
}

