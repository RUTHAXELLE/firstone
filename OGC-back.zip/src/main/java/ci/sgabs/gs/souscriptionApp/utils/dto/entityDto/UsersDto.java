
package ci.sgabs.gs.souscriptionApp.utils.dto.entityDto;

import ci.sgabs.gs.souscriptionApp.dao.entity.Role;
import ci.sgabs.gs.souscriptionApp.helper.searchFunctions.SearchParam;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.models.auth.In;
import lombok.Data;
import lombok.ToString;
import java.util.Date;

@Data
@ToString @JsonInclude(JsonInclude.Include.NON_NULL) @JsonPropertyOrder(alphabetic = true)
public class UsersDto {

    private Integer id;

    private String nom;
    private String prenoms;
    private String matricule;
    private String login;
    private String password;

    //role information
    private Integer roleId;
    private String roleCode;
    private String roleLibelle;
    private Integer numberOfConnections; //Permet de compter le nombre de fois qu'un utilisateur s'est authentifié

    private Boolean isDeleted;
    private String createdAt;
    private String  updatedAt;
    private String  deletedAt;

    private Integer createdBy;
    private Integer updatedBy;
    private Integer deletedBy;
    private String token;
    private String agenceAddress;
    private Integer agenceId;
    private String agenceCode;
    private String nomPrenoms;
    private Boolean isActif;
    private Boolean isFirst;
    private  String lastConnectionDate;
    private String lastConnection;
    /// SEARCH PARAM//

    private SearchParam<Integer> idParam;
    private SearchParam<String> matriculeParam;
    private SearchParam<String> loginParam;
    private SearchParam<String> codeParam;
    private SearchParam<String>  libelleParam;
    private SearchParam<String> roleCodeParam;
    private SearchParam<String> roleLibelleParam;
    private SearchParam<Boolean> isDeletedParam;
    private SearchParam<String> createdAtParam;
    private SearchParam<String> updatedAtParam;
    private SearchParam<String> deletedAtParam;
    private SearchParam<Integer> createdByParam;
    private SearchParam<Integer> updatedByParam;
    private SearchParam<Integer> deletedByParam;

    private SearchParam<String> agenceAddressParam;
    private SearchParam<Integer> agenceIdParam;
    private SearchParam<String> agenceCodeParam;
    private SearchParam<String>  nomPrenomsParam;
    private SearchParam<Integer> isActifParam;
    private SearchParam<Boolean> isFirstParam;

    // order param
    private String orderField;
    private String orderDirection;

}
