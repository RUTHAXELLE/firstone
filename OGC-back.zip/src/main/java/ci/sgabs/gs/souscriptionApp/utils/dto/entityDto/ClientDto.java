package ci.sgabs.gs.souscriptionApp.utils.dto.entityDto;

import ci.sgabs.gs.souscriptionApp.helper.searchFunctions.SearchParam;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;
import lombok.ToString;

import java.util.Collection;
import java.util.Date;

@Data
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL) @JsonPropertyOrder(alphabetic = true)
public class ClientDto {

    private Integer id;

    private String code;

    private String nom;

    private String prenoms;

    private Boolean isDeleted;

    private String createdAt;
    private String updatedAt;
    private String deletedAt;

    private Integer createdBy;
    private Integer updatedBy;
    private Integer deletedBy;
    private String contact;
    private String civilite;
    private Integer typeClientId;
    private String typeClientLibelle;
    private String adressPostale1;
    private String adressPostale2;
    private String city;
    private String dateBirth;
    private String indicatifPays;

    /// SEARCH PARAM//

    private SearchParam<Integer> idParam;
    private SearchParam<String> codeParam;
    private SearchParam<String>   nomParam;
    private SearchParam<String>   prenomsParam;
    private SearchParam<Boolean> isDeletedParam;
    private SearchParam<String> createdAtParam;
    private SearchParam<String> updatedAtParam;
    private SearchParam<String> deletedAtParam;
    private SearchParam<Integer> createdByParam;
    private SearchParam<Integer> updatedByParam;
    private SearchParam<Integer> deletedByParam;
    private SearchParam<String> contactParam;
    private SearchParam<String> civiliteParam;
    // order param
    private String orderField;
    private String orderDirection;
}
