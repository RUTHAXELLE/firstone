package ci.sgabs.gs.souscriptionApp.business;

import ci.sgabs.gs.souscriptionApp.dao.entity.*;
import ci.sgabs.gs.souscriptionApp.dao.repository.*;
import ci.sgabs.gs.souscriptionApp.helper.contrat.IBasicBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.errors.TechnicalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.helper.validation.Validate;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.HistoriqueDemandeMaintenanceDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.HistoriqueDemandeMaintenanceTransformer;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Log
@Component
public class HistoriqueDemandeMaintenanceBusiness implements IBasicBusiness<Request<HistoriqueDemandeMaintenanceDto>, Response<HistoriqueDemandeMaintenanceDto>> {

    private Response<HistoriqueDemandeMaintenanceDto> response;

    @Autowired
    private HistoriqueDemandeMaintenanceRepository historiqueDemandeMaintenanceRepository;

    @Autowired
    private DemandeMaintenanceRepository demandeMaintenanceRepository;

    @Autowired
    private StatusRepository statusRepository;

    @Autowired
    private FunctionalError functionalError;

    @Autowired
    private TechnicalError technicalError;

    @Autowired
    private ExceptionUtils exceptionUtils;

    @Autowired
    private EntityManager em;

    private final SimpleDateFormat dateFormat;
    private final SimpleDateFormat dateTimeFormat;

    public HistoriqueDemandeMaintenanceBusiness() {
        dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    }
    
    @Override
    public Response<HistoriqueDemandeMaintenanceDto> create(Request<HistoriqueDemandeMaintenanceDto> request, Locale locale) throws ParseException {

        log.info("----begin create HistoriqueDemande-----");

        Response<HistoriqueDemandeMaintenanceDto> response = new Response<HistoriqueDemandeMaintenanceDto>();
        List<HistoriqueDemandeMaintenance> items = new ArrayList<HistoriqueDemandeMaintenance>();

        //Verificatioon de la liste de données recues
        if(request.getDatas().isEmpty() || request.getDatas() == null){
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ",locale));
            response.setHasError(true);
            return response;
        }

        //Verification des parametres obligatoires & des duplications de donn�es
        List<HistoriqueDemandeMaintenanceDto> itemsDtos =  Collections.synchronizedList(new ArrayList<HistoriqueDemandeMaintenanceDto>());
        for(HistoriqueDemandeMaintenanceDto dto: request.getDatas() ) {

            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("demandeMaintenanceId", dto.getDemandeMaintenanceId());
            fieldsToVerify.put("statusId", dto.getStatusId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            itemsDtos.add(dto);

        }

        //Verification
        for(HistoriqueDemandeMaintenanceDto dto : request.getDatas()){

            //Verification de doublon
            HistoriqueDemandeMaintenance existingEntity = null;
            existingEntity = historiqueDemandeMaintenanceRepository.findByCode(dto.getCode(), false);
            if (existingEntity != null) {
                response.setStatus(functionalError.DATA_EXIST("HistoriqueDemandeMaintenance code -> " + dto.getCode(), locale));
                response.setHasError(true);
                return response;
            }

            //Verification de la demande attachée
            DemandeMaintenance existingDemandeMaintenance = null;
            if (Utilities.isValidID(dto.getDemandeMaintenanceId())) {
                existingDemandeMaintenance = demandeMaintenanceRepository.findOne(dto.getDemandeMaintenanceId(), false);
                if (existingDemandeMaintenance == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("DemandeMaintenance-> " + dto.getDemandeMaintenanceId(), locale));
                    response.setHasError(true);
                    return response;
                }
            }

            //Verification du status attaché
            Status existingStatus = null;
            if (Utilities.isValidID(dto.getStatusId())) {
                existingStatus = statusRepository.findOne(dto.getStatusId(), false);
                if (existingStatus == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("Status StatusID -> " + dto.getStatusId(), locale));
                    response.setHasError(true);
                    return response;
                }
            }

            //Transformation
            HistoriqueDemandeMaintenance entityToSave = HistoriqueDemandeMaintenanceTransformer
                        .INSTANCE.toEntity(dto, existingDemandeMaintenance, existingStatus);

            entityToSave.setIsDeleted(false);
            entityToSave.setCreatedAt(Utilities.getCurrentDate());
            entityToSave.setCreatedBy(request.userID);

            items.add(entityToSave);
        }

        if(items == null ||items.isEmpty()){
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ",locale));
            response.setHasError(true);
            return response;
        }

        //Persistence
        List<HistoriqueDemandeMaintenance> itemsSaved = null;
        itemsSaved = historiqueDemandeMaintenanceRepository.saveAll((Iterable<HistoriqueDemandeMaintenance>) items);

        if (itemsSaved == null) {
            response.setStatus(functionalError.SAVE_FAIL("HistoriqueDemande", locale));
            response.setHasError(true);
            return response;
        }

        //Transformation
        List<HistoriqueDemandeMaintenanceDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                                ? HistoriqueDemandeMaintenanceTransformer.INSTANCE.toLiteDtos(itemsSaved)
                                : HistoriqueDemandeMaintenanceTransformer.INSTANCE.toDtos(itemsSaved);

        //Envoie de la reponse
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        log.info("----end create HistoriqueDemande-----");
        return response;

    }

    @Override
    public Response<HistoriqueDemandeMaintenanceDto> update(Request<HistoriqueDemandeMaintenanceDto> request, Locale locale) throws ParseException {

        log.info("----begin update HistoriqueDemande -----");

        Response<HistoriqueDemandeMaintenanceDto> response = new Response<HistoriqueDemandeMaintenanceDto>();
        List<HistoriqueDemandeMaintenance> items = new ArrayList<HistoriqueDemandeMaintenance>();

        //Verificatioon de la liste de données recues
        if(request.getDatas() == null  || request.getDatas().isEmpty()){
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ",locale));
            response.setHasError(true);
            return response;
        }

        //Verification des parametres obligatoires
        for(HistoriqueDemandeMaintenanceDto dto: request.getDatas() ) {

            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }

        }

        //Verification
        for(HistoriqueDemandeMaintenanceDto dto : request.getDatas()){

            HistoriqueDemandeMaintenance entityToSave = null;
            entityToSave = historiqueDemandeMaintenanceRepository.findOne(dto.getId(), false);
            if (entityToSave == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("HistoriqueDemande id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }

            //Verification de la demande attachée
            DemandeMaintenance existingDemandeMaintenance = null;

            if (Utilities.isValidID(dto.getDemandeMaintenanceId()) && !entityToSave.getDemandeMaintenance().getId().equals(dto.getDemandeMaintenanceId())) {
                existingDemandeMaintenance = demandeMaintenanceRepository.findOne(dto.getDemandeMaintenanceId(), false);
                if (existingDemandeMaintenance == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("Demande DemandeId -> " + dto.getDemandeMaintenanceId(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setDemandeMaintenance(existingDemandeMaintenance);
            }

            //Verification du status attaché
            Status existingStatus = null;
            if (Utilities.isValidID(dto.getStatusId()) && !entityToSave.getStatus().getId().equals(dto.getStatusId())) {
                existingStatus = statusRepository.findOne(dto.getStatusId(), false);
                if (existingStatus == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("Status StatusId -> " + dto.getStatusId(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setStatus(existingStatus);
            }

            //Verification du code
            if (Utilities.isNotBlank(dto.getLibelle()) && !dto.getLibelle().equals(entityToSave.getLibelle())) {
                entityToSave.setLibelle(dto.getLibelle());
            }

            entityToSave.setUpdatedAt(Utilities.getCurrentDate());
            entityToSave.setUpdatedBy(request.userID);
            items.add(entityToSave);
        }

        if (items == null || items.isEmpty()) {
            response.setHasError(false);
            response.setStatus(functionalError.SUCCESS("", locale));
        }

        //Persistence
        List<HistoriqueDemandeMaintenance> itemsSaved = null;
        itemsSaved = historiqueDemandeMaintenanceRepository.saveAll((Iterable<HistoriqueDemandeMaintenance>) items);

        if (itemsSaved == null) {
                response.setStatus(functionalError.SAVE_FAIL("HistoriqueDemande", locale));
                response.setHasError(true);
                return response;
        }

        //Transformation
        List<HistoriqueDemandeMaintenanceDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                                    ? HistoriqueDemandeMaintenanceTransformer.INSTANCE.toLiteDtos(itemsSaved)
                                    : HistoriqueDemandeMaintenanceTransformer.INSTANCE.toDtos(itemsSaved);

        //Envoie de la reponse
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("end HistoriqueDemande update");
        return response;
    }

    @Override
    public Response<HistoriqueDemandeMaintenanceDto> delete(Request<HistoriqueDemandeMaintenanceDto> request, Locale locale) {

        log.info("----begin delete HistoriqueDemande-----");

        Response<HistoriqueDemandeMaintenanceDto> response = new Response<HistoriqueDemandeMaintenanceDto>();
        List<HistoriqueDemandeMaintenance> items = new ArrayList<HistoriqueDemandeMaintenance>();

        //Verificatioon de la liste de données recues
        if(request.getDatas() == null  || request.getDatas().isEmpty()){
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ",locale));
            response.setHasError(true);
            return response;
        }

        //Verification des parametres obligatoires
        for(HistoriqueDemandeMaintenanceDto dto: request.getDatas() ) {
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
        }

        //Verification
        for(HistoriqueDemandeMaintenanceDto dto : request.getDatas()){

            //Verification de doublon
            HistoriqueDemandeMaintenance existingEntity = null;
            existingEntity = historiqueDemandeMaintenanceRepository.findOne(dto.getId(), false);

            if (existingEntity == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("HistoriqueDemande id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }
            existingEntity.setIsDeleted(true);
            existingEntity.setDeletedAt(Utilities.getCurrentDate());
            existingEntity.setDeletedBy(request.userID);
            items.add(existingEntity);
        }

        if (items == null || items.isEmpty()) {
            response.setHasError(false);
            response.setStatus(functionalError.SUCCESS("", locale));
        }

        //Envoie de la reponse
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        return response;

    }

    @Override
    public Response<HistoriqueDemandeMaintenanceDto> forceDelete(Request<HistoriqueDemandeMaintenanceDto> request, Locale locale) throws ParseException {
        return null;
    }

    @Override
    public Response<HistoriqueDemandeMaintenanceDto> getByCriteria(Request<HistoriqueDemandeMaintenanceDto> request, Locale locale) throws Exception {

        log.info("----begin get HistoriqueDemande-----");
/*
        Response<HistoriqueDemandeDto> response = new Response<HistoriqueDemandeDto>();

        //verification si le parametre d'ordre à été fourni, sinon nous mettons le paramètre à vide
        if (Utilities.blank(request.getData().getOrderField())) {
            request.getData().setOrderField("");
        }

        //verification si le parametre direction à été fourni, sinon nous mettons le paramètre ascendant( du plus ancien au plus ressent)
        if (Utilities.blank(request.getData().getOrderDirection())) {
            request.getData().setOrderDirection("asc");
        }

        //recuperation des entités en base
        List<HistoriqueDemande> items = historiqueDemandeRepository.getByCriteria(request, em, locale);

        if (Utilities.isEmpty(items)) {
            response.setStatus(functionalError.DATA_EMPTY("HistoriqueDemande", locale));
            response.setHasError(false);
            return response;
        }

        //Transformation
        List<HistoriqueDemandeDto> itemsDto = HistoriqueDemandeTransformer.INSTANCE.toDtos(items);

        //Envoie de la reponse
        response.setItems(itemsDto);
        response.setCount(historiqueDemandeRepository.count(request, em, locale));
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        log.info("----end get HistoriqueDemande-----");*/

        return null;

    }
}
