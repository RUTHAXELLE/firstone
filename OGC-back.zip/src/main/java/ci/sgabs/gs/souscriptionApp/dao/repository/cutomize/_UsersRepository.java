package ci.sgabs.gs.souscriptionApp.dao.repository.cutomize;

import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.UsersDto;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

@Repository
public interface _UsersRepository {

    default List<String> _generateCriteria(UsersDto dto, HashMap<String, Object> param, Integer index, Locale locale) throws Exception {
        List<String> listOfQuery = new ArrayList<String>();

        // PUT YOUR RIGHT CUSTOM CRITERIA HERE

        return listOfQuery;
    }
}
