package ci.sgabs.gs.souscriptionApp.utils.dto.transformer;

import ci.sgabs.gs.souscriptionApp.dao.entity.Agence;
import ci.sgabs.gs.souscriptionApp.dao.entity.Role;
import ci.sgabs.gs.souscriptionApp.dao.entity.Users;
import ci.sgabs.gs.souscriptionApp.helper.contrat.FullTransformerQualifier;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.UsersDto;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

@Mapper
public interface UsersTransformer {

    UsersTransformer INSTANCE = Mappers.getMapper(UsersTransformer.class);

    @FullTransformerQualifier
    @Mappings({
            @Mapping(source = "entity.id", target = "id"),
            @Mapping(source = "entity.nom", target = "nom"),
            @Mapping(source = "entity.prenoms", target = "prenoms"),
            @Mapping(source = "entity.matricule", target = "matricule"),
            @Mapping(source = "entity.numberOfConnections", target = "numberOfConnections"),
            @Mapping(source = "entity.password", ignore = true, target = "password"),
            @Mapping(source = "entity.login", target = "login"),
            @Mapping(source = "entity.role.code", target = "roleCode"),
            @Mapping(source = "entity.role.libelle", target = "roleLibelle"),
            @Mapping(source = "entity.agence.id", target = "agenceId"),
            @Mapping(source = "entity.agence.code", target = "agenceCode"),
            @Mapping(source = "entity.agence.address", target = "agenceAddress"),
            @Mapping(source="entity.updatedAt", dateFormat="dd/MM/yyyy HH:mm:ss",target="updatedAt"),
            @Mapping(source="entity.createdAt", dateFormat="dd/MM/yyyy HH:mm:ss",target="createdAt"),
            @Mapping(source="entity.deletedAt", dateFormat="dd/MM/yyyy HH:mm:ss",target="deletedAt"),
            @Mapping(source="entity.lastConnectionDate", dateFormat="dd/MM/yyyy HH:mm:ss",target="lastConnectionDate"),
            @Mapping(source="entity.updatedBy",target="updatedBy"),
            @Mapping(source="entity.createdBy", target="createdBy"),
            @Mapping(source="entity.deletedBy", target="deletedBy"),
            @Mapping(source="entity.isDeleted", target="isDeleted"),
    })
    UsersDto toDto(Users entity);
    @IterableMapping(qualifiedBy = {FullTransformerQualifier.class})
    List<UsersDto> toDtos(List<Users> entities) throws ParseException;

    public default UsersDto toLiteDto(Users entity) {
        if (entity == null) {
            return null;
        }
        UsersDto dto = new UsersDto();
        dto.setId( entity.getId() );
        dto.setNom( entity.getNom() );
        dto.setPrenoms(entity.getPrenoms());
        dto.setMatricule(entity.getMatricule());
        dto.setLogin(entity.getLogin());
        dto.setRoleLibelle(entity.getRole().getLibelle());
        return dto;

    }

    public default List<UsersDto> toLiteDtos(List<Users> entities) {
        if (entities == null || entities.stream().allMatch(o -> o == null)) {
            return null;
        }
        List<UsersDto> dtos = new ArrayList<UsersDto>();
        for (Users entity : entities) {
            dtos.add(toLiteDto(entity));
        }
        return dtos;
    }

    @Mappings({
            @Mapping(source = "dto.id", target = "id"),
            @Mapping(source = "dto.nom", target = "nom"),
            @Mapping(source = "dto.prenoms", target = "prenoms"),
            @Mapping(source = "dto.matricule", target = "matricule"),
            @Mapping(source = "dto.login", target = "login"),
            @Mapping(source = "dto.numberOfConnections", target = "numberOfConnections"),
            @Mapping(source = "dto.isActif", target = "isActif"),
            @Mapping(source = "dto.isFirst", target = "isFirst"),
            @Mapping(source="dto.updatedAt", dateFormat="dd/MM/yyyy HH:mm:ss",target="updatedAt"),
            @Mapping(source="dto.createdAt", dateFormat="dd/MM/yyyy HH:mm:ss",target="createdAt"),
            @Mapping(source="dto.deletedAt", dateFormat="dd/MM/yyyy HH:mm:ss",target="deletedAt"),
            @Mapping(source="dto.lastConnectionDate", dateFormat="dd/MM/yyyy HH:mm:ss",target="lastConnectionDate"),
            @Mapping(source="dto.updatedBy",target="updatedBy"),
            @Mapping(source="dto.createdBy", target="createdBy"),
            @Mapping(source="dto.deletedBy", target="deletedBy"),
            @Mapping(source="dto.isDeleted", target="isDeleted"),
            @Mapping(source = "role", target = "role"),
    })
    Users toEntity(UsersDto dto, Role role, Agence agence);
}
