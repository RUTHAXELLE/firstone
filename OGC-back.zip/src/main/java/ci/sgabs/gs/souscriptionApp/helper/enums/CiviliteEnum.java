package ci.sgabs.gs.souscriptionApp.helper.enums;

import java.util.stream.Stream;

public enum CiviliteEnum {
    Mr, Mme,Mlle;
    //values makke recognize values set
    public static boolean isValidTag(String tag) {
        return Stream.of(values()).anyMatch(t -> t.name().equals(tag));
    }
}
