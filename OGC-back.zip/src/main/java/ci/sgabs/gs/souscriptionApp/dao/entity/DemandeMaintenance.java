package ci.sgabs.gs.souscriptionApp.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DemandeMaintenance implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    @Column(name="noms", length=100)
    private String noms;
    @Column(name="prenom", length=50)
    private String prenom;
    @Column(name="agence", length=50)
    private String codeAgence;
    @Column(name="agent", length=50)
    private String agent ;
    private String numeroCompte;
    private String produit ;
    private String codeTypeCarte;
    @Column(name="is_deleted")
    private Boolean isDeleted;
    @Transient
    private String libelleTypeCarte;
    @Transient
    private String numberCard;
    private String login;

    @ManyToOne
    private Status status;
    @ManyToOne
    private TypeOperation typeOperation;
    @OneToOne
    private Carte carte;

    private Boolean isForced;
    private Boolean isGenreatedContrat;
    private Boolean isNewCompte;
    private Boolean isNewAgence;

    private Date createdAt;
    private Date updatedAt;
    private Date deletedAt;

    private Integer createdBy;
    private Integer updatedBy;
    private Integer deletedBy;

}