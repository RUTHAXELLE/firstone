package ci.sgabs.gs.souscriptionApp.utils.dto.transformer;

import ci.sgabs.gs.souscriptionApp.dao.entity.*;
import ci.sgabs.gs.souscriptionApp.helper.contrat.FullTransformerQualifier;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.TypeCompteTypeCarteDto;
import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

@Mapper
public interface TypeCompteTypeCarteTransformer {

    TypeCompteTypeCarteTransformer INSTANCE = Mappers.getMapper(TypeCompteTypeCarteTransformer.class);

    @FullTransformerQualifier
    @Mappings({
            @Mapping(source = "entity.id", target = "id"),
            @Mapping(source = "entity.typeCompte.id", target = "typeCompteId"),
            @Mapping(source = "entity.typeCompte.code", target = "typeCompteCode"),
            @Mapping(source = "entity.typeCarte.id", target = "typeCarteId"),
            @Mapping(source = "entity.typeCarte.code", target = "typeCarteCode"),

            @Mapping(source="entity.updatedAt", dateFormat="dd/MM/yyyy",target="updatedAt"),
            @Mapping(source="entity.createdAt", dateFormat="dd/MM/yyyy",target="createdAt"),
            @Mapping(source="entity.deletedAt", dateFormat="dd/MM/yyyy",target="deletedAt"),
            @Mapping(source="entity.updatedBy",target="updatedBy"),
            @Mapping(source="entity.createdBy", target="createdBy"),
            @Mapping(source="entity.deletedBy", target="deletedBy"),


    })
    TypeCompteTypeCarteDto toDto(TypeCompteTypeCarte entity);

    @IterableMapping(qualifiedBy = {FullTransformerQualifier.class})
    List<TypeCompteTypeCarteDto> toDtos(List<TypeCompteTypeCarte> entities) throws ParseException;

    public default TypeCompteTypeCarteDto toLiteDto(TypeCompteTypeCarte entity) {
        if (entity == null) {
            return null;
        }
        TypeCompteTypeCarteDto dto = new TypeCompteTypeCarteDto();
        dto.setId( entity.getId() );
        dto.setTypeCompteId( entity.getTypeCompte().getId() );
        dto.setTypeCompteCode(entity.getTypeCompte().getCode());
        dto.setTypeCarteId(entity.getTypeCarte().getId());
        dto.setTypeCarteCode(entity.getTypeCarte().getCode());

        return dto;
    }

    public default List<TypeCompteTypeCarteDto> toLiteDtos(List<TypeCompteTypeCarte> entities) {
        if (entities == null || entities.stream().allMatch(o -> o == null)) {
            return null;
        }
        List<TypeCompteTypeCarteDto> dtos = new ArrayList<TypeCompteTypeCarteDto>();
        for (TypeCompteTypeCarte entity : entities) {
            dtos.add(toLiteDto(entity));
        }
        return dtos;
    }

    @Mappings({
            @Mapping(source = "dto.id", target = "id"),
            @Mapping(source = "typeCompte", target = "typeCompte"),
            @Mapping(source = "typeCarte", target = "typeCarte"),


            @Mapping(source="dto.updatedAt", dateFormat="dd/MM/yyyy",target="updatedAt"),
            @Mapping(source="dto.createdAt", dateFormat="dd/MM/yyyy",target="createdAt"),
            @Mapping(source="dto.deletedAt", dateFormat="dd/MM/yyyy",target="deletedAt"),
            @Mapping(source="dto.updatedBy",target="updatedBy"),
            @Mapping(source="dto.createdBy", target="createdBy"),
            @Mapping(source="dto.deletedBy", target="deletedBy"),
            @Mapping(source="dto.isDeleted", target="isDeleted"),

    })
    TypeCompteTypeCarte toEntity(TypeCompteTypeCarteDto dto, TypeCompte typeCompte, TypeCarte typeCarte);
}
