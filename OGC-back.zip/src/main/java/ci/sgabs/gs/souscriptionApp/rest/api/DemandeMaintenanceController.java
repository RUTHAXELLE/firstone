package ci.sgabs.gs.souscriptionApp.rest.api;

import ci.sgabs.gs.souscriptionApp.business.ApFileBusiness;
import ci.sgabs.gs.souscriptionApp.business.ApFileMaintenanceBusiness;
import ci.sgabs.gs.souscriptionApp.business.DemandeMaintenanceBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.enums.FunctionalityEnum;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.status.StatusCode;
import ci.sgabs.gs.souscriptionApp.helper.status.StatusMessage;
import ci.sgabs.gs.souscriptionApp.rest.fact.ControllerFactory;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.ApFileDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.ApFileMaintenanceDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.DemandeMaintenanceDto;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.CannotCreateTransactionException;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Locale;

@Log
@CrossOrigin("*")
@RestController
@RequestMapping(value = "/demandesMaintenance")
public class DemandeMaintenanceController {


    @Autowired
    private ControllerFactory<DemandeMaintenanceDto> controllerFactory;
    @Autowired
    private DemandeMaintenanceBusiness demandeMaintenanceBusiness;

    @Autowired
    private ApFileMaintenanceBusiness apFileMaintenanceBusiness;

    @Autowired
    private FunctionalError functionalError;
    @Autowired
    private ExceptionUtils exceptionUtils;
    @Autowired
    private HttpServletRequest requestBasic;

    @Autowired
    private ApFileBusiness apFileBusiness;

    @RequestMapping(value = "", method = RequestMethod.POST, consumes = {"application/json"}, produces = {"application/json"})
    public Response<DemandeMaintenanceDto> create(@RequestBody Request<DemandeMaintenanceDto> request) {
        log.info("start method /DemandeMaintenance/create");
        Response<DemandeMaintenanceDto> response = controllerFactory.create(demandeMaintenanceBusiness, request, FunctionalityEnum.CREATE_DEMANDE);
        log.info("end method /DemandeMaintenance/create");
        return response;
    }

    @RequestMapping(value = "", method = RequestMethod.PUT, consumes = {"application/json"}, produces = {"application/json"})
    public Response<DemandeMaintenanceDto> update(@RequestBody Request<DemandeMaintenanceDto> request) {
        log.info("start method /Demandes/update");
        Response<DemandeMaintenanceDto> response = controllerFactory.update(demandeMaintenanceBusiness, request, FunctionalityEnum.UPDATE_DEMANDE);
        log.info("end method /Demande/update");
        return response;
    }

    @RequestMapping(value = "", method = RequestMethod.DELETE, consumes = {"application/json"}, produces = {"application/json"})
    public Response<DemandeMaintenanceDto> delete(@RequestBody Request<DemandeMaintenanceDto> request) {
        log.info("start method /Demande/delete");
        Response<DemandeMaintenanceDto> response = controllerFactory.delete(demandeMaintenanceBusiness, request, FunctionalityEnum.DELETE_DEMANDE);
        log.info("end method /Demande/delete");
        return response;
    }

    /*
        @RequestMapping(value = "/forceDelete", method = RequestMethod.DELETE, consumes = {"application/json"}, produces = {"application/json"})
        public Response<DemandeDto> forceDelete(@RequestBody Request<DemandeDto> request) {
            log.info("start method /Demande/forceDelete");
            Response<DemandeDto> response = controllerFactory.forceDelete(demandeMaintenanceBusiness, request, FunctionalityEnum.DELETE_DEMANDE);
            log.info("end method /Demande/forceDelete");
            return response;
        }

    */
    @RequestMapping(value = "/getByCriteria", method = RequestMethod.POST, consumes = {"application/json"}, produces = {"application/json"})
    public Response<DemandeMaintenanceDto> getByCriteria(@RequestBody Request<DemandeMaintenanceDto> request) {
        log.info("start method /Demande/getByCriteria");
        Response<DemandeMaintenanceDto> response = controllerFactory.getByCriteria(demandeMaintenanceBusiness, request, FunctionalityEnum.VIEW_DEMANDE);
        log.info("end method /Demande/getByCriteria");
        return response;
    }

    @RequestMapping(value = "/allDemandeMaintenanceEnCours", method = RequestMethod.POST, consumes = {"application/json"}, produces = {"application/json"})
    public Response<DemandeMaintenanceDto> allDemandeMaintenanceEnCours(@RequestBody Request<DemandeMaintenanceDto> request) {
        Response<DemandeMaintenanceDto> response = new Response<DemandeMaintenanceDto>();
        String languageID = (String) requestBasic.getAttribute("CURRENT_LANGUAGE_IDENTIFIER");
        log.info("la langue " + languageID);
        Locale locale = new Locale(languageID, "");
        try {
            response = demandeMaintenanceBusiness.requestMaintenanceInProgressList(request, locale);
            if (response.isHasError()) {
                log.info(String.format("Erreur| code: {} -  message: {}", response.getStatus().getCode(), response.getStatus().getMessage()));
                return response;
            }
            log.info(String.format("code: {} -  message: {}", StatusCode.SUCCESS, StatusMessage.SUCCESS));
        } catch (CannotCreateTransactionException e) {
            exceptionUtils.CANNOT_CREATE_TRANSACTION_EXCEPTION(response, locale, e);
        } catch (TransactionSystemException e) {
            exceptionUtils.TRANSACTION_SYSTEM_EXCEPTION(response, locale, e);
        } catch (RuntimeException e) {
            exceptionUtils.RUNTIME_EXCEPTION(response, locale, e);
        } catch (Exception e) {
            exceptionUtils.EXCEPTION(response, locale, e);
        }
        return response;
    }

    @RequestMapping(value = "/generateMaintenanceApBatchFile", method = RequestMethod.POST, consumes = {"application/json"}, produces = {"application/json"})
    public Response<DemandeMaintenanceDto> generate(@RequestBody Request<DemandeMaintenanceDto> request) {
        Response<DemandeMaintenanceDto> response = new Response<DemandeMaintenanceDto>();
        String languageID = (String) requestBasic.getAttribute("CURRENT_LANGUAGE_IDENTIFIER");
        Locale locale = new Locale(languageID, "");
        try {
            response = demandeMaintenanceBusiness.generateMaintenanceApBatchFile(request, locale);
            if (response.isHasError()) {
                log.info(String.format("Erreur| code: {} -  message: {}", response.getStatus().getCode(), response.getStatus().getMessage()));
                return response;
            }
            log.info(String.format("code: {} -  message: {}", StatusCode.SUCCESS, StatusMessage.SUCCESS));
        } catch (CannotCreateTransactionException e) {
            exceptionUtils.CANNOT_CREATE_TRANSACTION_EXCEPTION(response, locale, e);
        } catch (TransactionSystemException e) {
            exceptionUtils.TRANSACTION_SYSTEM_EXCEPTION(response, locale, e);
        } catch (RuntimeException e) {
            exceptionUtils.RUNTIME_EXCEPTION(response, locale, e);
        } catch (Exception e) {
            exceptionUtils.EXCEPTION(response, locale, e);
        }
        return response;
    }

    @RequestMapping(value = "/getApFileMaintenance", method = RequestMethod.POST, consumes = {"application/json"}, produces = {"application/json"})
    public Response<ApFileMaintenanceDto> getApFile(@RequestBody Request<ApFileMaintenanceDto> request) {
        Response<ApFileMaintenanceDto> response = new Response<ApFileMaintenanceDto>();
        String languageID = (String) requestBasic.getAttribute("CURRENT_LANGUAGE_IDENTIFIER");
        Locale locale = new Locale(languageID, "");
        try {
            response = apFileMaintenanceBusiness.getByCriteria(request, locale);
            if (response.isHasError()) {
                log.info(String.format("Erreur| code: {} -  message: {}", response.getStatus().getCode(), response.getStatus().getMessage()));
                return response;
            }
            log.info(String.format("code: {} -  message: {}", StatusCode.SUCCESS, StatusMessage.SUCCESS));
        } catch (CannotCreateTransactionException e) {
            exceptionUtils.CANNOT_CREATE_TRANSACTION_EXCEPTION(response, locale, e);
        } catch (TransactionSystemException e) {
            exceptionUtils.TRANSACTION_SYSTEM_EXCEPTION(response, locale, e);
        } catch (RuntimeException e) {
            exceptionUtils.RUNTIME_EXCEPTION(response, locale, e);
        } catch (Exception e) {
            exceptionUtils.EXCEPTION(response, locale, e);
        }
        return response;
    }

    //Annulation de carte
    @RequestMapping(value = "/validateApBatch", method = RequestMethod.POST, consumes = {"application/json"}, produces = {"application/json"})
    public Response<ApFileDto> validateApBatch(@RequestBody Request<ApFileDto> request) {
        Response<ApFileDto> response = new Response<ApFileDto>();
        String languageID = (String) requestBasic.getAttribute("CURRENT_LANGUAGE_IDENTIFIER");
        Locale locale = new Locale(languageID, "");
        try {
            response = demandeMaintenanceBusiness.validateApBatch(request, locale);
            if (response.isHasError()) {
                log.info(String.format("Erreur| code: {} -  message: {}", response.getStatus().getCode(), response.getStatus().getMessage()));
                return response;
            }
            log.info(String.format("code: {} -  message: {}", StatusCode.SUCCESS, StatusMessage.SUCCESS));
        } catch (CannotCreateTransactionException e) {
            exceptionUtils.CANNOT_CREATE_TRANSACTION_EXCEPTION(response, locale, e);
        } catch (TransactionSystemException e) {
            exceptionUtils.TRANSACTION_SYSTEM_EXCEPTION(response, locale, e);
        } catch (RuntimeException e) {
            exceptionUtils.RUNTIME_EXCEPTION(response, locale, e);
        } catch (Exception e) {
            exceptionUtils.EXCEPTION(response, locale, e);
        }
        return response;
    }


    @RequestMapping(value = "/validateApBatchUpdateAccount", method = RequestMethod.POST, consumes = {"application/json"}, produces = {"application/json"})
    public Response<ApFileDto> validateApBatchUpdateAccount(@RequestBody Request<ApFileDto> request) {
        Response<ApFileDto> response = new Response<ApFileDto>();
        String languageID = (String) requestBasic.getAttribute("CURRENT_LANGUAGE_IDENTIFIER");
        Locale locale = new Locale(languageID, "");
        try {
            response = demandeMaintenanceBusiness.validateApBatchUpdateAccount(request, locale);
            if (response.isHasError()) {
                log.info(String.format("Erreur| code: {} -  message: {}", response.getStatus().getCode(), response.getStatus().getMessage()));
                return response;
            }
            log.info(String.format("code: {} -  message: {}", StatusCode.SUCCESS, StatusMessage.SUCCESS));
        } catch (CannotCreateTransactionException e) {
            exceptionUtils.CANNOT_CREATE_TRANSACTION_EXCEPTION(response, locale, e);
        } catch (TransactionSystemException e) {
            exceptionUtils.TRANSACTION_SYSTEM_EXCEPTION(response, locale, e);
        } catch (RuntimeException e) {
            exceptionUtils.RUNTIME_EXCEPTION(response, locale, e);
        } catch (Exception e) {
            exceptionUtils.EXCEPTION(response, locale, e);
        }
        return response;
    }

}
