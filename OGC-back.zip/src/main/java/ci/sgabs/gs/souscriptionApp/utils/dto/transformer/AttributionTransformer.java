package ci.sgabs.gs.souscriptionApp.utils.dto.transformer;

import ci.sgabs.gs.souscriptionApp.dao.entity.*;
import ci.sgabs.gs.souscriptionApp.helper.contrat.FullTransformerQualifier;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.AttributionDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.UsersDto;
import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

@Mapper
public interface AttributionTransformer {

    AttributionTransformer INSTANCE = Mappers.getMapper(AttributionTransformer.class);

    @FullTransformerQualifier
    @Mappings({
            @Mapping(source = "entity.id", target = "id"),
            @Mapping(source = "entity.code", target = "code"),
            @Mapping(source = "entity.libelle", target = "libelle"),
            @Mapping(source = "entity.demande.id", target = "demandeId"),
            @Mapping(source = "entity.carte.id", target = "carteId"),
            @Mapping(source = "entity.demande.code", target = "codeDemande"),
            @Mapping(source = "entity.carte.code", target = "codeCarte"),

            @Mapping(source="entity.updatedAt", dateFormat="dd/MM/yyyy",target="updatedAt"),
            @Mapping(source="entity.createdAt", dateFormat="dd/MM/yyyy",target="createdAt"),
            @Mapping(source="entity.deletedAt", dateFormat="dd/MM/yyyy",target="deletedAt"),
            @Mapping(source="entity.updatedBy",target="updatedBy"),
            @Mapping(source="entity.createdBy", target="createdBy"),
            @Mapping(source="entity.deletedBy", target="deletedBy"),
            @Mapping(source="entity.isDeleted", target="isDeleted"),
    })
    AttributionDto toDto(Attribution entity);
    @IterableMapping(qualifiedBy = {FullTransformerQualifier.class})
    List<AttributionDto> toDtos(List<Attribution> entities) throws ParseException;

    public default AttributionDto toLiteDto(Attribution entity) {
        if (entity == null) {
            return null;
        }
        AttributionDto dto = new AttributionDto();
        dto.setId( entity.getId() );
        dto.setCode( entity.getCode() );
        dto.setLibelle(entity.getLibelle());
        return dto;
    }

    public default List<AttributionDto> toLiteDtos(List<Attribution> entities) {
        if (entities == null || entities.stream().allMatch(o -> o == null)) {
            return null;
        }
        List<AttributionDto> dtos = new ArrayList<AttributionDto>();
        for (Attribution entity : entities) {
            dtos.add(toLiteDto(entity));
        }
        return dtos;
    }

    @Mappings({
            @Mapping(source = "dto.id", target = "id"),
            @Mapping(source = "dto.code", target = "code"),
            @Mapping(source = "dto.libelle", target = "libelle"),

            @Mapping(source="dto.updatedAt", dateFormat="dd/MM/yyyy",target="updatedAt"),
            @Mapping(source="dto.createdAt", dateFormat="dd/MM/yyyy",target="createdAt"),
            @Mapping(source="dto.deletedAt", dateFormat="dd/MM/yyyy",target="deletedAt"),
            @Mapping(source="dto.updatedBy",target="updatedBy"),
            @Mapping(source="dto.createdBy", target="createdBy"),
            @Mapping(source="dto.deletedBy", target="deletedBy"),
            @Mapping(source="dto.isDeleted", target="isDeleted"),

            @Mapping(source = "demande", target = "demande"),
            @Mapping(source = "carte", target = "carte")
    })
    Attribution toEntity(AttributionDto dto, Demande demande, Carte carte);
}
