package ci.sgabs.gs.souscriptionApp.helper.searchFunctions;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

@Data
@ToString
@NoArgsConstructor
public class SearchParam<T> {

    String	operator;
    T		start;
    T		end;
    List<T> datas;




    //public SearchParam() {}

    public SearchParam(String operator, T start, T end, List<T> datas) {
        super();
        this.operator = operator;
        this.start = start;
        this.end = end;
        this.datas = datas;
    }

    public SearchParam(String operator) {
        this(operator, null, null, null);
    }

    public SearchParam(String operator, T start, T end) {
        this(operator, start, end, null);
    }

    public SearchParam(String operator, List<T> datas) {
        this(operator, null, null, datas);
    }


}
