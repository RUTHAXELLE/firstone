package ci.sgabs.gs.souscriptionApp.rest.api;

import ci.sgabs.gs.souscriptionApp.business.TypeCompteBusiness;
import ci.sgabs.gs.souscriptionApp.business.TypeCompteTypeCarteBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.enums.FunctionalityEnum;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.status.StatusCode;
import ci.sgabs.gs.souscriptionApp.helper.status.StatusMessage;
import ci.sgabs.gs.souscriptionApp.helper.validation.Validate;
import ci.sgabs.gs.souscriptionApp.rest.fact.ControllerFactory;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.DemandeDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.TypeCompteDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.TypeCompteTypeCarteDto;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.CannotCreateTransactionException;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Locale;

@Log
@CrossOrigin("*")
@RestController
@RequestMapping(value="/typeComptes")
public class TypeCompteController {

    @Autowired
    private ControllerFactory<TypeCompteDto> controllerFactory;
    @Autowired
    private TypeCompteBusiness typeCompteBusiness;


    @Autowired
    private FunctionalError functionalError;
    @Autowired
    private ExceptionUtils exceptionUtils;
    @Autowired
    private HttpServletRequest requestBasic;
    @Autowired
    private TypeCompteTypeCarteBusiness typeCompteTypeCarteBusiness;



    @RequestMapping(value="",method= RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<TypeCompteDto> create(@RequestBody Request<TypeCompteDto> request) {
        log.info("start method /TypeCompte/create");
        Response<TypeCompteDto> response = controllerFactory.create(typeCompteBusiness, request, FunctionalityEnum.CREATE_TYPECOMPTE);
        log.info("end method /TypeCompte/create");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.PUT,consumes = {"application/json"},produces={"application/json"})
    public Response<TypeCompteDto> update(@RequestBody Request<TypeCompteDto> request) {
        log.info("start method /TypeCompte/update");
        Response<TypeCompteDto> response = controllerFactory.update(typeCompteBusiness, request, FunctionalityEnum.UPDATE_TYPECOMPTE);
        log.info("end method /TypeCompte/update");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.DELETE,consumes = {"application/json"},produces={"application/json"})
    public Response<TypeCompteDto> delete(@RequestBody Request<TypeCompteDto> request) {
        log.info("start method /TypeCompte/delete");
        Response<TypeCompteDto> response = controllerFactory.delete(typeCompteBusiness, request, FunctionalityEnum.DELETE_TYPECOMPTE);
        log.info("end method /TypeCompte/delete");
        return response;
    }

    @RequestMapping(value="/forceDelete",method=RequestMethod.DELETE,consumes = {"application/json"},produces={"application/json"})
    public Response<TypeCompteDto> forceDelete(@RequestBody Request<TypeCompteDto> request) {
        log.info("start method /TypeCompte/forceDelete");
        Response<TypeCompteDto> response = controllerFactory.forceDelete(typeCompteBusiness, request, FunctionalityEnum.DELETE_TYPECOMPTE);
        log.info("end method /TypeCompte/forceDelete");
        return response;
    }

    @RequestMapping(value="/getByCriteria",method=RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<TypeCompteDto> getByCriteria(@RequestBody Request<TypeCompteDto> request) {
        log.info("start method /TypeCompte/getByCriteria");
        Response<TypeCompteDto> response = controllerFactory.getByCriteria(typeCompteBusiness, request, FunctionalityEnum.VIEW_TYPECOMPTE);
        log.info("end method /TypeCompte/getByCriteria");
        return response;
    }


//    @RequestMapping(value="/addTypeCarteToTypeCompte",method=RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
//    public Response<TypeCompteTypeCarteDto> addTypeCarteToTypeCompte(Request<TypeCompteTypeCarteDto> request) {
//        Response<TypeCompteTypeCarteDto> response   = new Response<TypeCompteTypeCarteDto>();
//        String        languageID = (String) requestBasic.getAttribute("CURRENT_LANGUAGE_IDENTIFIER");
//        Locale locale     = new Locale(languageID, "");
//        try {
//            response = typeCompteTypeCarteBusiness.addTypeCarteToTypeCompte(request,locale);
//            if(response.isHasError()){
//                log.info(String.format("Erreur| code: {} -  message: {}", response.getStatus().getCode(), response.getStatus().getMessage()));
//                return response;
//            }
//            log.info(String.format("code: {} -  message: {}", StatusCode.SUCCESS, StatusMessage.SUCCESS));
//        } catch (CannotCreateTransactionException e) {
//            exceptionUtils.CANNOT_CREATE_TRANSACTION_EXCEPTION(response, locale, e);
//        } catch (TransactionSystemException e) {
//            exceptionUtils.TRANSACTION_SYSTEM_EXCEPTION(response, locale, e);
//        } catch (RuntimeException e) {
//            exceptionUtils.RUNTIME_EXCEPTION(response, locale, e);
//        } catch (Exception e) {
//            exceptionUtils.EXCEPTION(response, locale, e);
//        }
//        return response;
//    }

}
