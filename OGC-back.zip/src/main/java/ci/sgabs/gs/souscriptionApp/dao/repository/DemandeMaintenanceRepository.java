package ci.sgabs.gs.souscriptionApp.dao.repository;

import ci.sgabs.gs.souscriptionApp.dao.entity.Demande;
import ci.sgabs.gs.souscriptionApp.dao.entity.DemandeMaintenance;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.searchFunctions.CriteriaUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.DemandeMaintenanceDto;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import java.util.*;

public interface DemandeMaintenanceRepository extends JpaRepository<DemandeMaintenance, Integer> {

    @Query("select e from DemandeMaintenance e where e.id= :id and e.isDeleted= :isDeleted")
    DemandeMaintenance findOne(@Param("id") Integer id, @Param("isDeleted") Boolean isDeleted);
    @Query("select e from DemandeMaintenance e where e.status.id= :statusId and e.isDeleted= :isDeleted")
    List<DemandeMaintenance> findByStatusId(@Param("statusId") Integer statusId, @Param("isDeleted") Boolean isDeleted);
    @Query("select  e from DemandeMaintenance e where e.carte.id= :carteId and e.isDeleted= :isDeleted")
    DemandeMaintenance findByCarteId(@Param("carteId") Integer carteId, @Param("isDeleted") Boolean isDeleted);
    @Query("select e from DemandeMaintenance e where e.numeroCompte= :numeroCompte and e.isDeleted= :isDeleted")
    List<DemandeMaintenance> findByNumeroCompte(@Param("numeroCompte") String numeroCompte, @Param("isDeleted") Boolean isDeleted);
    @Query("select e from DemandeMaintenance e where e.codeTypeCarte= :codeTypeCarte and e.isDeleted= :isDeleted")
    List<DemandeMaintenance> findByTypeCarteCode(@Param("codeTypeCarte") String codeTypeCarte, @Param("isDeleted") Boolean isDeleted);
    @Query("select e from DemandeMaintenance e where e.status.code= :codeStatus and e.isDeleted= :isDeleted")
    List<DemandeMaintenance> findByStatusCode(@Param("codeStatus") String codeStatus, @Param("isDeleted") Boolean isDeleted,Pageable pageable);
    @Query( "select d from DemandeMaintenance d where d.status.code= :codeStatus and d.createdBy= :createdBy and d.isDeleted= :isDeleted")
    List<DemandeMaintenance> findByStatusCode1(@Param("codeStatus") String  codeStatus , @Param("createdBy") int createdBy, @Param("isDeleted") Boolean isDeleted, Pageable pageable);
    @Query( "select d from DemandeMaintenance d where d.status.code=:codeStatus and d.codeAgence= :codeAgence  and d.isDeleted= :isDeleted")
    List<DemandeMaintenance> findByStatusCode2(@Param("codeStatus") String  codeStatus ,@Param("codeAgence") String agenceId, @Param("isDeleted") Boolean isDeleted, Pageable pageable);
    @Query("select count(*) from DemandeMaintenance e where e.status.code= :codeStatus and e.isDeleted= :isDeleted")
    Long countByStatusCode(@Param("codeStatus") String codeStatus, @Param("isDeleted") Boolean isDeleted);
    @Query("select e from DemandeMaintenance e where e.typeOperation.code= :codeTypeOperation and e.status.code= :codeStatus and e.isDeleted= :isDeleted")
    List<DemandeMaintenance> findByTypeOperationCode(@Param("codeTypeOperation") String codeTypeOperation, @Param("codeStatus") String codeStatus, @Param("isDeleted") Boolean isDeleted);
    @Query("select e from DemandeMaintenance e where e.typeOperation.code= :codeTypeOperation and e.status.code= :codeStatus and e.isNewCompte= :isNewCompte and e.isNewAgence= :isNewAgence and e.isDeleted= :isDeleted")
    List<DemandeMaintenance> findByTypeOperationCodeAndUpdateAccountOnly(@Param("codeTypeOperation") String codeTypeOperation, @Param("codeStatus") String codeStatus, @Param("isNewCompte") Boolean isNewCompte, @Param("isNewAgence") Boolean isNewAgence, @Param("isDeleted") Boolean isDeleted);
    @Query("select e from DemandeMaintenance e where e.typeOperation.code= :codeTypeOperation and e.status.code= :codeStatus and e.isNewAgence= :isNewAgence and e.isDeleted= :isDeleted")
    List<DemandeMaintenance> findByTypeOperationCodeAndUpdateAgency(@Param("codeTypeOperation") String codeTypeOperation, @Param("codeStatus") String codeStatus, @Param("isNewAgence") Boolean isNewAgence, @Param("isDeleted") Boolean isDeleted);
    @Query("select e from DemandeMaintenance e where e.isDeleted= :isDeleted")
    List<DemandeMaintenance> getAllPagination(@Param("isDeleted") Boolean isDeleted, Pageable pageable);
    @Query("select count(*) from DemandeMaintenance e where e.isDeleted= :isDeleted")
    long countAllPagination(@Param("isDeleted") Boolean isDeleted);

    // criteria search//
    public default List<DemandeMaintenance> getByCriteria(Request<DemandeMaintenanceDto> request, EntityManager em, Locale locale) throws DataAccessException, Exception {
        String req = "select e from DemandeMaintenance e where e IS NOT NULL";
        HashMap<String, Object> param = new HashMap<String, Object>();
        req += getWhereExpression(request, param, locale);
        TypedQuery<DemandeMaintenance> query = em.createQuery(req, DemandeMaintenance.class);
        for (Map.Entry<String, Object> entry : param.entrySet()) {
            query.setParameter(entry.getKey(), entry.getValue());
        }
        if (request.getIndex() != null && request.getSize() != null) {
            query.setFirstResult(request.getIndex() * request.getSize());
            query.setMaxResults(request.getSize());
        }
        return query.getResultList();
    }

    public default Long count(Request<DemandeMaintenanceDto> request, EntityManager em, Locale locale) throws DataAccessException, Exception {
        String req = "select count(*) from DemandeMaintenance e where e IS NOT NULL";
        HashMap<String, Object> param = new HashMap<String, Object>();
        req += getWhereExpressionCount(request, param, locale);
        javax.persistence.Query query = em.createQuery(req);
        for (Map.Entry<String, Object> entry : param.entrySet()) {
            query.setParameter(entry.getKey(), entry.getValue());
        }
        Long count = (Long) query.getResultList().get(0);
        return count;
    }

    /**
     * get where expression
     *
     * @param request
     * @param param
     * @param locale
     * @return
     * @throws Exception
     */
    default String getWhereExpression(Request<DemandeMaintenanceDto> request, HashMap<String, Object> param, Locale locale) throws Exception {
        // main query
        DemandeMaintenanceDto dto = request.getData() != null ? request.getData() : new DemandeMaintenanceDto();
        dto.setIsDeleted(false);
        String mainReq = generateCriteria(dto, param, 0, locale);
        // others query
        String othersReq = "";
        if (request.getDatas() != null && !request.getDatas().isEmpty()) {
            Integer index = 1;
            for (DemandeMaintenanceDto elt : request.getDatas()) {
                elt.setIsDeleted(false);
                String eltReq = generateCriteria(elt, param, index, locale);
                if (request.getIsAnd() != null && request.getIsAnd()) {
                    othersReq += "and (" + eltReq + ") ";
                } else {
                    othersReq += "or (" + eltReq + ") ";
                }
                index++;
            }
        }
        String req = "";
        if (!mainReq.isEmpty()) {
            req += " and (" + mainReq + ") ";
        }
        req += othersReq;

        //order
        if (Sort.Direction.fromOptionalString(dto.getOrderDirection()).orElse(null) != null && Utilities.notBlank(dto.getOrderField())) {
            req += " order by e." + dto.getOrderField() + " " + dto.getOrderDirection();
        } else {
            req += " order by  e.id desc";
        }
        return req;
    }


    default String getWhereExpressionCount(Request<DemandeMaintenanceDto> request, HashMap<String, Object> param, Locale locale) throws Exception {
        // main query
        DemandeMaintenanceDto dto = request.getData() != null ? request.getData() : new DemandeMaintenanceDto();
        dto.setIsDeleted(false);
        String mainReq = generateCriteria(dto, param, 0, locale);
        // others query
        String othersReq = "";
        if (request.getDatas() != null && !request.getDatas().isEmpty()) {
            Integer index = 1;
            for (DemandeMaintenanceDto elt : request.getDatas()) {
                elt.setIsDeleted(false);
                String eltReq = generateCriteria(elt, param, index, locale);
                if (request.getIsAnd() != null && request.getIsAnd()) {
                    othersReq += "and (" + eltReq + ") ";
                } else {
                    othersReq += "or (" + eltReq + ") ";
                }
                index++;
            }
        }
        String req = "";
        if (!mainReq.isEmpty()) {
            req += " and (" + mainReq + ") ";
        }
        req += othersReq;
        return req;
    }

    /**
     * generate sql query for dto
     *
     * @param dto
     * @param param
     * @param index
     * @param locale
     * @return
     * @throws Exception
     */
    default String generateCriteria(DemandeMaintenanceDto dto, HashMap<String, Object> param, Integer index, Locale locale) throws Exception {
        List<String> listOfQuery = new ArrayList<String>();
        if (dto != null) {
            if (dto.getId() != null || Utilities.searchParamIsNotEmpty(dto.getIdParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("id", dto.getId(), "e.id", "Integer", dto.getIdParam(), param, index, locale));
            }

            if (dto.getLibelleTypeCarte() != null || Utilities.searchParamIsNotEmpty(dto.getTypeCarteParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("libelleTypeCarte", dto.getCodeTypeCarte(), "e.libelleTypeCarte", "String", dto.getTypeCarteParam(), param, index, locale));
            }
            if (Utilities.isNotBlank(dto.getNumeroCompte()) || Utilities.searchParamIsNotEmpty(dto.getNumeroCompteParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("numeroCompte", dto.getNumeroCompte(), "e.numeroCompte", "String", dto.getNumeroCompteParam(), param, index, locale));
            }
            if (dto.getStatusId() != null || Utilities.searchParamIsNotEmpty(dto.getStatusIdParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("statusId", dto.getStatusId(), "e.status.id", "Integer", dto.getStatusIdParam(), param, index, locale));
            }
            if (Utilities.isNotBlank(dto.getCodeStatus()) || Utilities.searchParamIsNotEmpty(dto.getCodeStatusParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("codeStatus", dto.getCodeStatus(), "e.status.code", "String", dto.getCodeStatusParam(), param, index, locale));
            }
            if (Utilities.isNotBlank(dto.getUpdatedAt()) || Utilities.searchParamIsNotEmpty(dto.getUpdatedAtParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("updatedAt", dto.getUpdatedAt(), "e.updatedAt", "Date", dto.getUpdatedAtParam(), param, index, locale));
            }
            if (dto.getIsDeleted() != null || Utilities.searchParamIsNotEmpty(dto.getIsDeletedParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("isDeleted", dto.getIsDeleted(), "e.isDeleted", "Boolean", dto.getIsDeletedParam(), param, index, locale));
            }
            if (dto.getUpdatedBy() != null || Utilities.searchParamIsNotEmpty(dto.getUpdatedByParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("updatedBy", dto.getUpdatedBy(), "e.updatedBy", "Long", dto.getUpdatedByParam(), param, index, locale));
            }
            if (Utilities.isNotBlank(dto.getCreatedAt()) || Utilities.searchParamIsNotEmpty(dto.getCreatedAtParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("createdAt", dto.getCreatedAt(), "e.createdAt", "Date", dto.getCreatedAtParam(), param, index, locale));
            }
            if (dto.getCreatedBy() != null || Utilities.searchParamIsNotEmpty(dto.getCreatedByParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("createdBy", dto.getCreatedBy(), "e.createdBy", "Long", dto.getCreatedByParam(), param, index, locale));
            }
            if (Utilities.isNotBlank(dto.getDeletedAt()) || Utilities.searchParamIsNotEmpty(dto.getDeletedAtParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("deletedAt", dto.getDeletedAt(), "e.deletedAt", "Date", dto.getDeletedAtParam(), param, index, locale));
            }
            if (dto.getDeletedBy() != null || Utilities.searchParamIsNotEmpty(dto.getDeletedByParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("deletedBy", dto.getDeletedBy(), "e.deletedBy", "Long", dto.getDeletedByParam(), param, index, locale));
            }
            if (dto.getCodeTypeOperation() != null || Utilities.searchParamIsNotEmpty(dto.getCodeTypeOperationParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("codeTypeOperation", dto.getCodeTypeOperation(), "e.typeOperation.code", "String", dto.getCodeTypeOperationParam(), param, index, locale));
            }
            if (dto.getNumberCard() != null || Utilities.searchParamIsNotEmpty(dto.getNumeroCarteParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("numberCard", dto.getNumberCard(), "e.carte.code", "String", dto.getNumeroCarteParam(), param, index, locale));
            }
            if (dto.getCodeAgence() != null || Utilities.searchParamIsNotEmpty(dto.getCodeAgenceParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("codeAgence", dto.getCodeAgence(), "e.codeAgence", "String", dto.getCodeAgenceParam(), param, index, locale));
            }
            if (dto.getProduit() != null || Utilities.searchParamIsNotEmpty(dto.getProduitParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("produit", dto.getProduit(), "e.produit", "String", dto.getProduitParam(), param, index, locale));
            }

            if (dto.getNoms() != null || Utilities.searchParamIsNotEmpty(dto.getNomsParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("noms", dto.getNoms(), "e.noms", "String", dto.getNomsParam(), param, index, locale));
            }

            if (dto.getLogin() != null || Utilities.searchParamIsNotEmpty(dto.getLoginParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("login", dto.getLogin(), "e.login", "String", dto.getLoginParam(), param, index, locale));
            }

            if (dto.getAgence() != null || Utilities.searchParamIsNotEmpty(dto.getAgenceParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("agence", dto.getAgence(), "e.codeAgence", "String", dto.getAgenceParam(), param, index, locale));
            }

        }
        return CriteriaUtils.getCriteriaByListOfQuery(listOfQuery);
    }

}
