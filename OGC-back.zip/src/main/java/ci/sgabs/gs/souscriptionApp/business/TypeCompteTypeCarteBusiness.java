package ci.sgabs.gs.souscriptionApp.business;

import ci.sgabs.gs.souscriptionApp.dao.entity.TypeCarte;
import ci.sgabs.gs.souscriptionApp.dao.entity.TypeCompte;
import ci.sgabs.gs.souscriptionApp.dao.entity.TypeCompteTypeCarte;
import ci.sgabs.gs.souscriptionApp.dao.repository.TypeCarteRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.TypeCompteRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.TypeCompteTypeCarteRepository;
import ci.sgabs.gs.souscriptionApp.helper.contrat.IBasicBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.errors.TechnicalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.helper.validation.Validate;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.TypeCarteDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.TypeCompteTypeCarteDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.TypeCompteTypeCarteTransformer;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Log
@Component
public class TypeCompteTypeCarteBusiness implements IBasicBusiness<Request<TypeCompteTypeCarteDto>, Response<TypeCompteTypeCarteDto>> {

    private Response<TypeCompteTypeCarteDto> response;

    @Autowired
    private TypeCompteTypeCarteRepository typeCompteTypeCarteRepository;
    @Autowired
    private TypeCompteRepository typeCompteRepository;
    @Autowired
    private TypeCarteRepository typeCarteRepository;
    @Autowired
    private FunctionalError functionalError;
    @Autowired
    private TechnicalError technicalError;
    @Autowired
    private ExceptionUtils exceptionUtils;
    @Autowired
    private EntityManager em;
    private final SimpleDateFormat dateFormat;
    private final SimpleDateFormat dateTimeFormat;

    public TypeCompteTypeCarteBusiness() {
        dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    }

    @Override
    public Response<TypeCompteTypeCarteDto> create(Request<TypeCompteTypeCarteDto> request, Locale locale) throws ParseException {
        log.info("----begin create TypeCompteTypeCarte-----");
        Response<TypeCompteTypeCarteDto> response = new Response<TypeCompteTypeCarteDto>();
        List<TypeCompteTypeCarte> items = new ArrayList<TypeCompteTypeCarte>();
        //Verification des champs obligatoires
        List<TypeCompteTypeCarteDto> itemsDtos = Collections.synchronizedList(new ArrayList<TypeCompteTypeCarteDto>());
//        for(TypeCompteTypeCarteDto dto: request.getDatas()){
//            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
//            fieldsToVerify.put("typeCompteId", dto.getTypeCompteId());
//            fieldsToVerify.put("typeCarteId", dto.getTypeCarteId());
//            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
//                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
//                response.setHasError(true);
//                return response;
//            }
//            if (itemsDtos.stream().anyMatch(a -> a.getTypeCarteId().equals(dto.getTypeCarteId()))) { //verification numero
//                response.setStatus(functionalError.DATA_DUPLICATE("type carte id", locale));
//                response.setHasError(true);
//                return response;
//            }
//            if (itemsDtos.stream().anyMatch(a -> a.getTypeCompteId().equals(dto.getTypeCompteId()))) { //verification numero
//                response.setStatus(functionalError.DATA_DUPLICATE("type compte id", locale));
//                response.setHasError(true);
//                return response;
//            }
//            itemsDtos.add(dto);
//        }
        //Verification
        for (TypeCompteTypeCarteDto dto : itemsDtos) {
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("typeCompteId", dto.getTypeCompteId());
            fieldsToVerify.put("typeCarteId", dto.getTypeCarteId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            TypeCompte existingTypeCompte = null;
            existingTypeCompte = typeCompteRepository.findOne(dto.getTypeCompteId(), false);
            if (existingTypeCompte == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("TypeCompte TypeCompteId -> " + dto.getTypeCompteId(), locale));
                response.setHasError(true);
                return response;
            }
            //Verification du typeCarte attaché
            TypeCarte existingTypeCarte = null;
            existingTypeCarte = typeCarteRepository.findOne(dto.getTypeCarteId(), false);
            if (existingTypeCarte == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("TypeCarte TypeCarteId -> " + dto.getTypeCarteId(), locale));
                response.setHasError(true);
                return response;
            }
            //Verification du doublon
            TypeCompteTypeCarte existingEntity = null;
            existingEntity = typeCompteTypeCarteRepository.findByTypeCompteIdAndTypeCarteId(dto.getTypeCompteId(), dto.getTypeCarteId(), false);
            if (existingEntity != null) {
                response.setStatus(functionalError.DATA_EXIST("TypeCompteTypeCarte typeCompteId -> " + dto.getTypeCompteId() + " TypeCompteTypeCarte typeCarteId -> " + dto.getTypeCarteId(), locale));
                response.setHasError(true);
                return response;
            }
            TypeCompteTypeCarte entityToSave = TypeCompteTypeCarteTransformer
                    .INSTANCE.toEntity(dto, existingTypeCompte, existingTypeCarte);
            entityToSave.setIsDeleted(false);
            entityToSave.setCreatedAt(Utilities.getCurrentDate());
            entityToSave.setCreatedBy(request.userID);
            items.add(entityToSave);
        }
        List<TypeCompteTypeCarte> itemsSaved = null;
        itemsSaved = typeCompteTypeCarteRepository.saveAll((Iterable<TypeCompteTypeCarte>) items);
        if (itemsSaved == null) {
            response.setStatus(functionalError.SAVE_FAIL("TypeCompteTypeCarte", locale));
            response.setHasError(true);
            return response;
        }
        List<TypeCompteTypeCarteDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                ? TypeCompteTypeCarteTransformer.INSTANCE.toLiteDtos(itemsSaved)
                : TypeCompteTypeCarteTransformer.INSTANCE.toDtos(itemsSaved);
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end create TypeCompteTypeCarte-----");
        return response;
    }


    public Response<TypeCompteTypeCarteDto> addTypeCarteToTypeCompte(Request<TypeCompteTypeCarteDto> request, Locale locale) throws ParseException {
        log.info("----begin create addTypeCarteToTypeCompte-----");
        Response<TypeCompteTypeCarteDto> response = new Response<TypeCompteTypeCarteDto>();
        List<TypeCompteTypeCarte> items = new ArrayList<TypeCompteTypeCarte>();
        //Verification des champs obligatoires
        List<TypeCompteTypeCarteDto> itemsDtos = Collections.synchronizedList(new ArrayList<TypeCompteTypeCarteDto>());
        //Verification
        for (TypeCompteTypeCarteDto dto : request.getDatas()) {
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("typeCompteId", dto.getTypeCompteId());
            fieldsToVerify.put("datasTypeCarte", dto.getDatasTypeCarte());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            TypeCompte existingTypeCompte = null;
            existingTypeCompte = typeCompteRepository.findOne(dto.getTypeCompteId(), false);
            if (existingTypeCompte == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("TypeCompte TypeCompteId -> " + dto.getTypeCompteId(), locale));
                response.setHasError(true);
                return response;
            }
          List<TypeCompteTypeCarte> typeCompteTypeCarts =  typeCompteTypeCarteRepository.findByTypeCompteId(existingTypeCompte.getId(),Boolean.FALSE);
            if(Utilities.isNotEmpty(typeCompteTypeCarts)){
                typeCompteTypeCarteRepository.deleteAll(typeCompteTypeCarts);
            }
            List<TypeCompteTypeCarte> typeCompteTypeCartes = Collections.synchronizedList(new ArrayList<TypeCompteTypeCarte>());
            for (TypeCarteDto typeCarteDto : dto.getDatasTypeCarte()) {
                fieldsToVerify.put("id", typeCarteDto.getId());
                if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                    response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                    response.setHasError(true);
                    return response;
                }
                TypeCarte typeCarte = typeCarteRepository.findOne(typeCarteDto.getId(), Boolean.FALSE);
                if (typeCarte == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("Type carte Id -> " + typeCarteDto.getId(), locale));
                    response.setHasError(true);
                    return response;
                }
                TypeCompteTypeCarte existingEntity = null;
                existingEntity = typeCompteTypeCarteRepository.findByTypeCompteIdAndTypeCarteId(existingTypeCompte.getId(), typeCarte.getId(), false);
                if (existingEntity != null) {
                    response.setStatus(functionalError.DATA_EXIST("TypeCompteTypeCarte typeCompteId -> " + existingTypeCompte.getId() + " TypeCompteTypeCarte typeCarteId -> " + typeCarte.getId(), locale));
                    response.setHasError(true);
                    return response;
                }
                TypeCompteTypeCarte typeCompteTypeCarte = new TypeCompteTypeCarte();
                typeCompteTypeCarte.setTypeCarte(typeCarte);
                typeCompteTypeCarte.setTypeCompte(existingTypeCompte);
                typeCompteTypeCarte.setIsDeleted(Boolean.FALSE);
                typeCompteTypeCarte.setCreatedAt(Utilities.getCurrentDate());
                typeCompteTypeCartes.add(typeCompteTypeCarte);
            }
            if (Utilities.isNotEmpty(typeCompteTypeCartes)) {
                typeCompteTypeCarteRepository.saveAll(typeCompteTypeCartes);
            }
        }
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end create addTypeCarteToTypeCompte-----");
        return response;
    }


    @Override
    public Response<TypeCompteTypeCarteDto> update(Request<TypeCompteTypeCarteDto> request, Locale locale) throws ParseException {

        log.info("----begin update TypeCompteTypeCarte -----");

        Response<TypeCompteTypeCarteDto> response = new Response<TypeCompteTypeCarteDto>();
        List<TypeCompteTypeCarte> items = new ArrayList<TypeCompteTypeCarte>();

        if (request.getDatas() == null || request.getDatas().isEmpty()) {
            response.setStatus(functionalError.DATA_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }

        //Verification
        for (TypeCompteTypeCarteDto dto : request.getDatas()) {

            TypeCompteTypeCarte entityToSave = null;
            entityToSave = typeCompteTypeCarteRepository.findOne(dto.getId(), false);

            if (entityToSave == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("TypeCompteTypeCarte id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }

            //Verification du type compte attaché
            TypeCompte existingTypeCompte = entityToSave.getTypeCompte();

            if (Utilities.isValidID(dto.getTypeCompteId()) && !entityToSave.getTypeCompte().getId().equals(dto.getTypeCompteId())) {
                existingTypeCompte = typeCompteRepository.findOne(dto.getTypeCompteId(), false);

                if (existingTypeCompte == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("TypeCompte TypeCompteId -> " + dto.getTypeCompteId(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setTypeCompte(existingTypeCompte);
            }

            //Verification du tyep de la  carte attaché
            TypeCarte existingTypeCarte = entityToSave.getTypeCarte();

            if (Utilities.isValidID(dto.getTypeCarteId()) && !entityToSave.getTypeCarte().getId().equals(dto.getTypeCarteId())) {
                existingTypeCarte = typeCarteRepository.findOne(dto.getTypeCarteId(), false);
                if (existingTypeCarte == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("TypeCarte TypeCarteId -> " + dto.getTypeCarteId(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setTypeCarte(existingTypeCarte);
            }

            entityToSave.setUpdatedAt(Utilities.getCurrentDate());
            entityToSave.setUpdatedBy(request.userID);
            items.add(entityToSave);
        }

        if (items == null || items.isEmpty()) {
            response.setStatus(functionalError.DATA_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }

        //Transformation
        List<TypeCompteTypeCarteDto> itemsDto = TypeCompteTypeCarteTransformer.INSTANCE.toDtos(items);

        //Envoi de la reponse
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("end TypeCompteTypeCarte update");
        return response;

    }

    @Override
    public Response<TypeCompteTypeCarteDto> delete(Request<TypeCompteTypeCarteDto> request, Locale locale) {

        log.info("----begin delete TypeCompteTypeCarte-----");

        Response<TypeCompteTypeCarteDto> response = new Response<TypeCompteTypeCarteDto>();
        List<TypeCompteTypeCarte> items = new ArrayList<TypeCompteTypeCarte>();

        if (request.getDatas() == null || request.getDatas().isEmpty()) {
            response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
            response.setHasError(true);
            return response;
        }

        //Verification
        for (TypeCompteTypeCarteDto dto : request.getDatas()) {
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
        }

        //Verification
        for (TypeCompteTypeCarteDto dto : request.getDatas()) {

            // Verification s'il existe une entité TypeCompteTypeCarte en base avec l'id fourni
            TypeCompteTypeCarte existingEntity = null;
            existingEntity = typeCompteTypeCarteRepository.findOne(dto.getId(), false);

            if (existingEntity == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("TypeCompteTypeCarte id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }

            existingEntity.setIsDeleted(true);
            existingEntity.setDeletedAt(Utilities.getCurrentDate());
            existingEntity.setDeletedBy(request.userID);

            items.add(existingEntity);
        }

        //Verification
        if (items == null || items.isEmpty()) {
            response.setStatus(functionalError.DATA_EMPTY("Liste viste ", locale));
            response.setHasError(true);
            return response;
        }

        //Envoie de la reponse
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end delete TypeCompteTypeCarte-----");
        return response;

    }

    @Override
    public Response<TypeCompteTypeCarteDto> forceDelete(Request<TypeCompteTypeCarteDto> request, Locale locale) throws ParseException {
        return null;
    }

    @Override
    public Response<TypeCompteTypeCarteDto> getByCriteria(Request<TypeCompteTypeCarteDto> request, Locale locale) throws Exception {

        log.info("----begin get TypeCompteTypeCarte-----");

        Response<TypeCompteTypeCarteDto> response = new Response<TypeCompteTypeCarteDto>();

        //Verification si le parametre d'ordre à été fourni, sinon nous mettons le paramètre à vide
        if (Utilities.blank(request.getData().getOrderField())) {
            request.getData().setOrderField("");
        }

        //Verification si le parametre direction à été fourni, sinon nous mettons le paramètre ascendant( du plus ancien au plus ressent)
        if (Utilities.blank(request.getData().getOrderDirection())) {
            request.getData().setOrderDirection("asc");
        }

        //Recuperation des entités en base
        List<TypeCompteTypeCarte> items = typeCompteTypeCarteRepository.getByCriteria(request, em, locale);

        if (Utilities.isEmpty(items)) {
            response.setStatus(functionalError.DATA_EMPTY("TypeCompteTypeCarte", locale));
            response.setHasError(false);
            return response;
        }

        //Transformation
        List<TypeCompteTypeCarteDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                ? TypeCompteTypeCarteTransformer.INSTANCE.toLiteDtos(items)
                : TypeCompteTypeCarteTransformer.INSTANCE.toDtos(items);

        //Envoie de la reponse
        response.setItems(itemsDto);
        response.setCount(typeCompteTypeCarteRepository.count(request, em, locale));
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end get TypeCompteTypeCarte-----");
        return response;
    }

}
