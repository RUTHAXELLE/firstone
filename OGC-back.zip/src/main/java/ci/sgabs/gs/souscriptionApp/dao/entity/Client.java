package ci.sgabs.gs.souscriptionApp.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity @Data @NoArgsConstructor @AllArgsConstructor
public class Client implements Serializable{

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @Column(name="code", length=255)
    private String code;

    @Column(name="nom", length=255)
    private String nom;

    @Column(name="prenoms", length=255)
    private String prenoms;

    @Column(name="contact", length=255)
    private String contact;
    @Column(name="civilite", length=255)
    private String civilite;

    @Column(name="adress_postale_1", length=255)
    private String adressPostale1;
    @Column(name="adress_postale_2", length=255)
    private String adressPostale2;
    @Column(name="city", length=255)
    private String city;
    @Column(name="date_birth")
    private Date dateBirth;
    @Column(name="indicatif_pays", length=255)
    private String indicatifPays;
    @Column(name="is_deleted")
    private Boolean isDeleted;
    private Date createdAt;
    private Date updatedAt;
    private Date deletedAt;
    private Integer createdBy;
    private Integer updatedBy;
    private Integer deletedBy;

    @ManyToOne(fetch = FetchType.EAGER)
    private TypeClient typeClient;
}
