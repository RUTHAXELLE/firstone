package ci.sgabs.gs.souscriptionApp.helper.contrat;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import java.util.Map;

@Data
@ToString
@NoArgsConstructor
@XmlRootElement
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Response<T> extends ResponseBase {

    protected List<T> items;
    protected T             		item;
    protected List<T> 				datas;
    protected Map<String, Object> itemsAsMap;
}