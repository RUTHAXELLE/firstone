package ci.sgabs.gs.souscriptionApp;

import ci.sgabs.gs.souscriptionApp.business.DemandeBusiness;
import ci.sgabs.gs.souscriptionApp.dao.entity.Compte;
import ci.sgabs.gs.souscriptionApp.dao.entity.Demande;
import ci.sgabs.gs.souscriptionApp.dao.entity.Parameters;
import ci.sgabs.gs.souscriptionApp.dao.repository.CompteRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.DemandeRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.ParametersRepository;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.utils.ParamsUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.nio.file.Files;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

@SpringBootApplication
public class SouscriptionAppApplication implements CommandLineRunner {
    public static void main(String[] args) {
        SpringApplication.run(SouscriptionAppApplication.class, args);
    }
    @Override
    public void run(String... args) throws Exception {

    }
}
