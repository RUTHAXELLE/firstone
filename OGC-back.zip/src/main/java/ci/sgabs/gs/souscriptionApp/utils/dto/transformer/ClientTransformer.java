package ci.sgabs.gs.souscriptionApp.utils.dto.transformer;

import ci.sgabs.gs.souscriptionApp.dao.entity.*;
import ci.sgabs.gs.souscriptionApp.helper.contrat.FullTransformerQualifier;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.ClientDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.DemandeDto;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

@Mapper
public interface ClientTransformer {


    ClientTransformer INSTANCE = Mappers.getMapper(ClientTransformer.class);

    @FullTransformerQualifier
    @Mappings({
            @Mapping(source = "entity.id", target = "id"),
            @Mapping(source = "entity.code", target = "code"),
            @Mapping(source = "entity.nom", target = "nom"),
            @Mapping(source = "entity.prenoms", target = "prenoms"),
            @Mapping(source = "entity.contact", target = "contact"),
            @Mapping(source = "entity.updatedAt", dateFormat = "dd/MM/yyyy HH:mm:ss", target = "updatedAt"),
            @Mapping(source = "entity.createdAt", dateFormat = "dd/MM/yyyy HH:mm:ss", target = "createdAt"),
            @Mapping(source = "entity.deletedAt", dateFormat = "dd/MM/yyyy HH:mm:ss", target = "deletedAt"),
            @Mapping(source = "entity.dateBirth", dateFormat = "dd/MM/yyyy", target = "dateBirth"),
            @Mapping(source = "entity.updatedBy", target = "updatedBy"),
            @Mapping(source = "entity.createdBy", target = "createdBy"),
            @Mapping(source = "entity.deletedBy", target = "deletedBy"),
            @Mapping(source = "entity.isDeleted", target = "isDeleted"),
            @Mapping(source = "entity.adressPostale1", target = "adressPostale1"),
            @Mapping(source = "entity.adressPostale2", target = "adressPostale2"),
            @Mapping(source = "entity.indicatifPays", target = "indicatifPays"),
            @Mapping(source = "entity.city", target = "city"),
            @Mapping(source = "entity.typeClient.id", target = "typeClientId"),
            @Mapping(source = "entity.typeClient.libelle", target = "typeClientLibelle"),
    })
    ClientDto toDto(Client entity);

    @IterableMapping(qualifiedBy = {FullTransformerQualifier.class})
    List<ClientDto> toDtos(List<Client> entities) throws ParseException;

    public default ClientDto toLiteDto(Client entity) {
        if (entity == null) {
            return null;
        }
        ClientDto dto = new ClientDto();
        dto.setId(entity.getId());
        dto.setCode(entity.getCode());
        dto.setNom(entity.getNom());
        dto.setPrenoms(entity.getPrenoms());
        return dto;
    }

    public default List<ClientDto> toLiteDtos(List<Client> entities) {
        if (entities == null || entities.stream().allMatch(o -> o == null)) {
            return null;
        }
        List<ClientDto> dtos = new ArrayList<ClientDto>();
        for (Client entity : entities) {
            dtos.add(toLiteDto(entity));
        }
        return dtos;
    }

    @Mappings({
            @Mapping(source = "dto.id", target = "id"),
            @Mapping(source = "dto.code", target = "code"),
            @Mapping(source = "dto.nom", target = "nom"),
            @Mapping(source = "dto.prenoms", target = "prenoms"),
            @Mapping(source = "dto.contact", target = "contact"),
            @Mapping(source = "dto.civilite", target = "civilite"),
            @Mapping(source = "dto.updatedAt", dateFormat = "dd/MM/yyyy HH:m:ss", target = "updatedAt"),
            @Mapping(source = "dto.createdAt", dateFormat = "dd/MM/yyyy HH:mm:ss", target = "createdAt"),
            @Mapping(source = "dto.deletedAt", dateFormat = "dd/MM/yyyy HH:mm:ss", target = "deletedAt"),
            @Mapping(source = "dto.dateBirth", dateFormat = "dd/MM/yyyy", target = "dateBirth"),
            @Mapping(source = "dto.updatedBy", target = "updatedBy"),
            @Mapping(source = "dto.createdBy", target = "createdBy"),
            @Mapping(source = "dto.deletedBy", target = "deletedBy"),
            @Mapping(source = "dto.isDeleted", target = "isDeleted"),
            @Mapping(source = "dto.adressPostale1", target = "adressPostale1"),
            @Mapping(source = "dto.adressPostale2", target = "adressPostale2"),
            @Mapping(source = "dto.indicatifPays", target = "indicatifPays"),
            @Mapping(source = "dto.city", target = "city"),
            @Mapping(source = "typeClient", target = "typeClient")
    })
    Client toEntity(ClientDto dto, TypeClient typeClient);
}
