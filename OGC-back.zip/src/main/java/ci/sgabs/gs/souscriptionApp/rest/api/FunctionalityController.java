package ci.sgabs.gs.souscriptionApp.rest.api;

import ci.sgabs.gs.souscriptionApp.business.FunctionalityBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.enums.FunctionalityEnum;
import ci.sgabs.gs.souscriptionApp.rest.fact.ControllerFactory;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.FunctionalityDto;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Log
@CrossOrigin("*")
@RestController
@RequestMapping(value="/functionalities")
public class FunctionalityController {

    @Autowired
    private ControllerFactory<FunctionalityDto> controllerFactory;
    @Autowired
    private FunctionalityBusiness functionalityBusiness;

    @RequestMapping(value="",method= RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<FunctionalityDto> create(@RequestBody Request<FunctionalityDto> request) {
        log.info("start method /Functionality/create"+request.getDatas() + functionalityBusiness.toString());
        Response<FunctionalityDto> response = controllerFactory.create(functionalityBusiness, request, FunctionalityEnum.CREATE_FUNCTIONALITY);
        log.info("end method /Functionality/create");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.PUT,consumes = {"application/json"},produces={"application/json"})
    public Response<FunctionalityDto> update(@RequestBody Request<FunctionalityDto> request) {
        log.info("start method /Functionality/update");
        Response<FunctionalityDto> response = controllerFactory.update(functionalityBusiness, request, FunctionalityEnum.UPDATE_FUNCTIONALITY);
        log.info("end method /Functionality/update");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.DELETE,consumes = {"application/json"},produces={"application/json"})
    public Response<FunctionalityDto> delete(@RequestBody Request<FunctionalityDto> request) {
        log.info("start method /Functionality/delete");
        Response<FunctionalityDto> response = controllerFactory.delete(functionalityBusiness, request, FunctionalityEnum.DELETE_FUNCTIONALITY);
        log.info("end method /Functionality/delete");
        return response;
    }

    @RequestMapping(value="/forceDelete",method=RequestMethod.DELETE,consumes = {"application/json"},produces={"application/json"})
    public Response<FunctionalityDto> forceDelete(@RequestBody Request<FunctionalityDto> request) {
        log.info("start method /Functionality/forceDelete");
        Response<FunctionalityDto> response = controllerFactory.forceDelete(functionalityBusiness, request, FunctionalityEnum.DELETE_FUNCTIONALITY);
        log.info("end method /Functionality/forceDelete");
        return response;
    }

    @RequestMapping(value="/getByCriteria",method=RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<FunctionalityDto> getByCriteria(@RequestBody Request<FunctionalityDto> request) {
        log.info("start method /Functionality/getByCriteria");
        Response<FunctionalityDto> response = controllerFactory.getByCriteria(functionalityBusiness, request, FunctionalityEnum.VIEW_FUNCTIONALITY);
        log.info("end method /Functionality/getByCriteria");
        return response;
    }

}
