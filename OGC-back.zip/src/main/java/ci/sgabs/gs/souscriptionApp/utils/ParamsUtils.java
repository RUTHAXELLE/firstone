package ci.sgabs.gs.souscriptionApp.utils;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Getter
@NoArgsConstructor
@ToString
public class ParamsUtils {
    @Value("${path.ap.batch.file}")
    private String pathApBatchFile;
    @Value("${path.ap.batch.file.link}")
    private String linkApBatchFile;
    @Value("${path.ap.batch.file.zip}")
    private String zipApBatchFile;

}
