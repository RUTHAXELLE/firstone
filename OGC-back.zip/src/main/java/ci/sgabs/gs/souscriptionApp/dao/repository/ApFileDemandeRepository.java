package ci.sgabs.gs.souscriptionApp.dao.repository;

import ci.sgabs.gs.souscriptionApp.dao.entity.ApFileDemande;
import ci.sgabs.gs.souscriptionApp.dao.entity.Demande;
import ci.sgabs.gs.souscriptionApp.dao.entity.Functionality;
import ci.sgabs.gs.souscriptionApp.dao.entity.RoleFunctionality;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.searchFunctions.CriteriaUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.RoleFunctionalityDto;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import java.util.*;

public interface ApFileDemandeRepository extends JpaRepository<ApFileDemande, Integer> {

    @Query("select e from ApFileDemande e where e.id= :id and e.isDeleted= :isDeleted")
    ApFileDemande findOne(@Param("id") Integer id, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from ApFileDemande e where e.apFile.id= :apFileId and e.isDeleted= :isDeleted")
    List<ApFileDemande> findByApFileId(@Param("apFileId") Integer apFileId, @Param("isDeleted") Boolean isDeleted);

    @Query("select e.demande from ApFileDemande e where e.apFile.id= :apFileId and e.isDeleted= :isDeleted")
    List<Demande> getDemandeByApFileId(@Param("apFileId") Integer apFileId, @Param("isDeleted") Boolean isDeleted);

    @Query("select count(*) from ApFileDemande e where e.apFile.id= :apFileId and e.isDeleted= :isDeleted")
    long countDemandeByApFileId(@Param("apFileId") Integer apFileId, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from ApFileDemande e where e.demande.id= :demandeId and e.isDeleted= :isDeleted")
    List<ApFileDemande> findByDemandeId(@Param("demandeId") Integer demandeId, @Param("isDeleted") Boolean isDeleted);


    @Query("select e from ApFileDemande e where e.demande.id= :demandeId and e.isDeleted= :isDeleted")
    List<ApFileDemande> getByDemandeId(@Param("demandeId") Integer demandeId, @Param("isDeleted") Boolean isDeleted, Pageable pageable);






}
