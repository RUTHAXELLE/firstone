package ci.sgabs.gs.souscriptionApp.utils.dto.entityDto;

import ci.sgabs.gs.souscriptionApp.helper.searchFunctions.SearchParam;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;
import lombok.ToString;

import java.util.Collection;

@Data
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL) @JsonPropertyOrder(alphabetic = true)
public class CarteDto {

    private Integer id;
    private String code;
    private String numeroCarte;
    private String libelle;
    private String noms;
    private String prenom ;
    private Integer typeCarteId;
    private Integer groupeId;
    private String codeTypeCarte;
    private String codeGroupe;
    private Integer compteId;
    private String  numeroCompte;
    private Boolean isDeleted;
    private String typeCarteLibelle;
    private String codeAgenceCarte;

    private String createdAt;
    private String updatedAt;
    private String deletedAt;

    private Integer createdBy;
    private Integer updatedBy;
    private Integer deletedBy;

    /// SEARCH PARAM//

    private SearchParam<Integer> idParam;
    private SearchParam<String> codeParam;
    private SearchParam<String> nomsParam;
    private SearchParam<String> numeroCompteParam;
    private SearchParam<Integer> groupeIdParam;
    private SearchParam<Integer> typeCarteIdParam;
    private SearchParam<String> codeTypeCarteParam;
    private SearchParam<Integer> typeCarteLibelleParam;
    private SearchParam<String>   codeGroupeParam;
    private SearchParam<Boolean> isDeletedParam;
    private SearchParam<String> createdAtParam;
    private SearchParam<String> updatedAtParam;
    private SearchParam<String> deletedAtParam;
    private SearchParam<Integer> createdByParam;
    private SearchParam<Integer> updatedByParam;
    private SearchParam<Integer> deletedByParam;

    // order param
    private String orderField;
    private String orderDirection;

}
