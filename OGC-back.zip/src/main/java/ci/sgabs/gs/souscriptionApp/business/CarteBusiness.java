package ci.sgabs.gs.souscriptionApp.business;

import ci.sgabs.gs.souscriptionApp.dao.entity.*;
import ci.sgabs.gs.souscriptionApp.dao.repository.CarteRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.CompteRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.GroupeRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.TypeCarteRepository;
import ci.sgabs.gs.souscriptionApp.helper.contrat.IBasicBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.errors.TechnicalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.helper.validation.Validate;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.CarteDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.CarteTransformer;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Log
@Component
public class CarteBusiness implements IBasicBusiness<Request<CarteDto>, Response<CarteDto>> {


    private Response<CarteDto> response;
    @Autowired
    private CarteRepository carteRepository;
    @Autowired
    private TypeCarteRepository typeCarteRepository;
    @Autowired
    private CompteRepository compteRepository;
    @Autowired
    private GroupeRepository groupeRepository;
    @Autowired
    private FunctionalError functionalError;
    @Autowired
    private TechnicalError technicalError;
    @Autowired
    private ExceptionUtils exceptionUtils;
    @Autowired
    private EntityManager em;
    private final SimpleDateFormat dateFormat;
    private final SimpleDateFormat dateTimeFormat;

    public CarteBusiness() {
        dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    }
    
    @Override
    public Response<CarteDto> create(Request<CarteDto> request, Locale locale) throws Exception {

        log.info("----begin create Carte-----");

        Response<CarteDto> response = new Response<CarteDto>();
        List<Carte> items = new ArrayList<Carte>();

        //Verification des datas
        if (request.getDatas() == null || request.getDatas().isEmpty()){
            response.setStatus(functionalError.DATA_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }

        //Verififcation des champs obligatoires
        List<CarteDto> itemsDtos =  Collections.synchronizedList(new ArrayList<CarteDto>());
        for(CarteDto dto: request.getDatas()){
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("code", dto.getCode());
            fieldsToVerify.put("libelle", dto.getLibelle());
            fieldsToVerify.put("noms", dto.getNoms());
            fieldsToVerify.put("prenom", dto.getPrenom());
            fieldsToVerify.put("typeCarteId", dto.getTypeCarteId());
           // fieldsToVerify.put("groupeId", dto.getGroupeId());
            fieldsToVerify.put("compteId", dto.getCompteId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            if (itemsDtos.stream().anyMatch(a -> a.getCode().equalsIgnoreCase(dto.getCode()))) { //verification numero
                response.setStatus(functionalError.DATA_DUPLICATE(" numero ", locale));
                response.setHasError(true);
                return response;
            }
            if (itemsDtos.stream().anyMatch(a -> a.getCompteId().equals(dto.getCompteId()))) { //verification numero
                response.setStatus(functionalError.DATA_DUPLICATE(" Identifiant compte ", locale));
                response.setHasError(true);
                return response;
            }
            itemsDtos.add(dto);
        }

        //Verification portant sur les entités attachées
        for(CarteDto dto : request.getDatas()){
            //Verification de doublon de la carte
            Carte existingEntity = null;
            existingEntity = carteRepository.findByCode(dto.getCode(), false); //verification du code
            if (existingEntity != null) {
                response.setStatus(functionalError.DATA_EXIST("Carte code -> " + dto.getCode(), locale));
                response.setHasError(true);
                return response;
            }

            //Verification du groupe attaché à la carte
            Groupe existingGroupe = null;
            if (Utilities.isValidID(dto.getGroupeId())) {
                existingGroupe = groupeRepository.findOne(dto.getGroupeId(), false);
                if (existingGroupe == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("Le groupe ayant l'identifiant -> " +  dto.getGroupeId() +" n'existe pas ,", locale));
                    response.setHasError(true);
                    return response;
                }
            }
            //Verification du type de carte attaché à la carte
            TypeCarte existingTypeCarte = null;
            if (Utilities.isValidID(dto.getTypeCarteId())) {
                existingTypeCarte = typeCarteRepository.findOne(dto.getTypeCarteId(), false);
                if (existingTypeCarte == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("TypeCarte TypeCarteID -> " + dto.getTypeCarteId(), locale));
                    response.setHasError(true);
                    return response;
                }
                if(existingTypeCarte.getTypeCarte() != null){
                    dto.setTypeCarteLibelle(existingTypeCarte.getTypeCarte());
                }
            }

            //Verification du compte de la carte
            Compte existingCompte = null;
            if (Utilities.isValidID(dto.getCompteId())) {
                existingCompte = compteRepository.findOne(dto.getCompteId(), false);
                if (existingCompte == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("Compte compteID -> " + dto.getCompteId(), locale));
                    response.setHasError(true);
                    return response;
                }
            }

            //TRansformer CarteDto en Carte
            Carte entityToSave = CarteTransformer.INSTANCE.toEntity(dto, existingTypeCarte, existingGroupe,existingCompte);

            entityToSave.setIsDeleted(false);
            entityToSave.setCreatedAt(Utilities.getCurrentDate());
            entityToSave.setCreatedBy(request.userID);
            items.add(entityToSave);
        }

        //Verification des items
        if(items == null || items.isEmpty()){
            response.setStatus(functionalError.DATA_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }

        //Persistence de la liste des cartes
        List<Carte> itemsSaved = null;
        itemsSaved = carteRepository.saveAll((Iterable<Carte>) items);
        if (itemsSaved == null) {
            response.setStatus(functionalError.SAVE_FAIL("Carte", locale));
            response.setHasError(true);
            return response;
        }

        //Transformer les Cartes en carteDto
        List<CarteDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                            ? CarteTransformer.INSTANCE.toLiteDtos(itemsSaved)
                            : CarteTransformer.INSTANCE.toDtos(itemsSaved);

        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        log.info("----end create Carte-----");
        return response;
    }
    
    @Override
    public Response<CarteDto> update(Request<CarteDto> request, Locale locale) throws ParseException {

        log.info("----begin update Carte -----");

        Response<CarteDto> response = new Response<CarteDto>();
        List<Carte> items = new ArrayList<Carte>();

        //Verification des datas
        if (request.getDatas() == null || request.getDatas().isEmpty()){
            response.setStatus(functionalError.DATA_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }

        //Verification des champs obligatoires
        List<CarteDto> itemsDtos = Collections.synchronizedList(new ArrayList<CarteDto>());
        for(CarteDto dto : request.getDatas()) {
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
        }

        //Verification et modification des differents de la carte
        for(CarteDto dto : request.getDatas()){

            //Verification de la carte
            Carte entityToSave = null;
            entityToSave = carteRepository.findOne(dto.getId(), false);
            if (entityToSave == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Carte id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }

            //Verification du groupe attaché à la carte
            Groupe existingGroupe = null;
            if (Utilities.isValidID(dto.getGroupeId())&& !entityToSave.getGroupe().getId().equals(dto.getGroupeId()) ) {
                existingGroupe = groupeRepository.findOne(dto.getGroupeId(), false);
                if (existingGroupe == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("groupe groupeID -> " + dto.getGroupeId(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setGroupe(existingGroupe);
            }

            //Verification du type de la carte attaché à la carte
            TypeCarte existingTypeCarte = null;
            if (Utilities.isValidID(dto.getTypeCarteId()) && !entityToSave.getTypeCarte().getId().equals(dto.getTypeCarteId())) {
                existingTypeCarte = typeCarteRepository.findOne(dto.getTypeCarteId(), false);
                if (existingTypeCarte == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("TypeCarte TypeCarteID -> " + dto.getTypeCarteId(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setTypeCarte(existingTypeCarte);
                entityToSave.setTypeCarteLibelle(existingTypeCarte.getTypeCarte()==null?null:(existingTypeCarte.getTypeCarte()));
            }

            //Verification du code
            if (Utilities.isNotBlank(dto.getCode()) && !dto.getCode().equals(entityToSave.getCode())) { //verify code
                Carte existingEntity = carteRepository.findByCode(dto.getCode(), false);
                if (existingEntity != null && !existingEntity.getId().equals(entityToSave.getId())) {
                    response.setStatus(functionalError.DATA_EXIST("Carte -> " + dto.getCode(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setCode(dto.getCode());
            }
            //Verification du libellé
            if (Utilities.isNotBlank(dto.getLibelle()) && !dto.getLibelle().equals(entityToSave.getLibelle())) {
                entityToSave.setLibelle(dto.getLibelle());
            }
            //Date et utilisateur de la modification
            entityToSave.setUpdatedAt(Utilities.getCurrentDate());
            entityToSave.setUpdatedBy(request.userID);
            items.add(entityToSave);
        }

        //Verificatioon de la liste de données recues
        if(items == null  || items.isEmpty()){
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ",locale));
            response.setHasError(true);
            return response;
        }

        //Transformation
        List<CarteDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                                ? CarteTransformer.INSTANCE.toLiteDtos(items)
                                : CarteTransformer.INSTANCE.toDtos(items);

        //Envoie de la requete
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        log.info("end Carte update");

        return response;

    }

    @Override
    public Response<CarteDto> delete(Request<CarteDto> request, Locale locale) {

        log.info("----begin update Carte-----");

        Response<CarteDto> response = new Response<CarteDto>();
        List<Carte> items = new ArrayList<Carte>();

        //Verification des datas
        if (request.getDatas() == null || request.getDatas().isEmpty()){
            response.setStatus(functionalError.DATA_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }

        //Verification des champs obligatoires
        for(CarteDto dto : request.getDatas()) {
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
        }


        //Suppression logique des cartes
        for(CarteDto dto : request.getDatas()){
            Carte existingEntity = null;
            existingEntity = carteRepository.findOne(dto.getId(), false);
            if (existingEntity == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Carte id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }
            existingEntity.setIsDeleted(true);
            existingEntity.setDeletedAt(Utilities.getCurrentDate());
            existingEntity.setDeletedBy(request.userID);
            items.add(existingEntity);
        }

        //Verificatioon de la liste de données recues
        if(items == null  || items.isEmpty()){
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ",locale));
            response.setHasError(true);
            return response;
        }

        //Envoie de la reponse
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        log.info("----end delete User-----");
        return response;

    }

    @Override
    public Response<CarteDto> forceDelete(Request<CarteDto> request, Locale locale) throws ParseException {
        return null;
    }

    @Override
    public Response<CarteDto> getByCriteria(Request<CarteDto> request, Locale locale) throws Exception {

        log.info("----begin get Carte-----");

        Response<CarteDto> response = new Response<CarteDto>();

        //Verification des datas
        if (request.getData() == null ){
            response.setStatus(functionalError.DATA_EMPTY("Aucune donnée", locale));
            response.setHasError(true);
            return response;
        }

        //verification si le parametre d'ordre à été fourni, sinon nous mettons le paramètre à vide
        if (Utilities.blank(request.getData().getOrderField())) {
            request.getData().setOrderField("");
        }

        //verification si le parametre direction à été fourni, sinon nous mettons le paramètre ascendant( du plus ancien au plus ressent)
        if (Utilities.blank(request.getData().getOrderDirection())) {
            request.getData().setOrderDirection("asc");
        }

        //recuperation des entités en base
        List<Carte> items = carteRepository.getByCriteria(request, em, locale);

        if (Utilities.isEmpty(items)) {
            response.setStatus(functionalError.DATA_EMPTY("Carte", locale));
            response.setHasError(false);
            return response;
        }

        //Verification et alimentation de la propriété typeCarte de la carte
        updateProprieteTypeCarteLibelleofCarteByTypeCarte(items);

        //Recherche de l'agence du compte de chaque carte
        for(Carte carte:items){
            if(carte !=null){
                if(carte.getCompte()!=null && Utilities.isValidID(carte.getCompte().getId())){
                    //Ramener le compte dans le contexte de persistence
                    Compte existingCompte=null;
                    existingCompte=compteRepository.findOne(carte.getCompte().getId(),false);
                    if (existingCompte == null) {
                        response.setStatus(functionalError.DATA_NOT_EXIST("Compte de la carte n'existe pas -> " + carte.getId(), locale));
                        response.setHasError(true);
                        return response;
                    }
                    //Extraction de l'agence du compte
                    Agence existingAgence=null;
                    existingAgence=existingCompte.getAgence();
                    if (existingAgence == null || existingAgence.getCode()==null) {
                        response.setStatus(functionalError.DATA_NOT_EXIST("Le compte de la carte n'est rattaché à aucune agence " , locale));
                        response.setHasError(true);
                        return response;
                    }
                    carte.setCodeAgenceCarte(existingAgence.getCode());
                }
            }
        }

        //Transformation
        List<CarteDto> itemsDto = CarteTransformer.INSTANCE.toDtos(items);

        response.setItems(itemsDto);
        response.setCount(carteRepository.count(request, em, locale));
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        log.info("----end get Carte-----");
        return response;

    }

    private void updateProprieteTypeCarteLibelleofCarteByTypeCarte(List<Carte> items) {
        items.forEach(i->{
            if(i != null && i.getTypeCarteLibelle() == null){
                if(i.getTypeCarte() != null && i.getTypeCarte().getTypeCarte() != null){
                    i.setTypeCarteLibelle(i.getTypeCarte().getTypeCarte());
                }
            }
        });
    }

}
