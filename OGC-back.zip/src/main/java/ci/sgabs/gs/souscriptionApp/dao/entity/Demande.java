package ci.sgabs.gs.souscriptionApp.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Demande implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @Column(name="code", length=255)
    private String code;
    @Column(name="matricule", length=255)
    private String matricule ;
    @Column(name="noms", length=255)
    private String noms;
    @Column(name="prenom", length=255)
    private String prenom;
    @Column(name="telephone", length=255)
    private String telephone;
    @Column(name="motif", length=255)
    private String motif;
    @Column(name="intitule", length=4)
    private String intitule;
    private String numeroCompte;
    @Column(name="agence", length=255)
    private String agence ;
    private String login;

    //Libelle du type de la carte
    @Column(name="produit")
    private String produit ;
    @ManyToOne(fetch = FetchType.EAGER)
    private TypeCarte typeCarte;
    @ManyToOne(fetch = FetchType.EAGER)
    private Compte compte;
    @ManyToOne
    private Status status;

    @Column(name="is_deleted")
    private Boolean isDeleted;
    @Column(name="is_beneficiary")
    private Boolean isBeneficiary;

    private String nomBeneficiaire;
    private String prenomBeneficiaire;
    private Boolean isPlafondHaut;
    private Boolean isForced;
    private Boolean isPlafondBas;
    private Boolean isPlafondMoyen;
    private Boolean isGenreatedContrat;

    private Date createdAt;
    private Date updatedAt;
    private Date deletedAt;

    private Integer createdBy;
    private Integer updatedBy;
    private Integer deletedBy;

}