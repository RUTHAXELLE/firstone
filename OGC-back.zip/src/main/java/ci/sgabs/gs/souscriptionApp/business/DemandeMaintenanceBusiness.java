package ci.sgabs.gs.souscriptionApp.business;

import ci.sgabs.gs.souscriptionApp.dao.entity.*;
import ci.sgabs.gs.souscriptionApp.dao.repository.*;
import ci.sgabs.gs.souscriptionApp.helper.contrat.IBasicBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.errors.TechnicalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.helper.validation.Validate;
import ci.sgabs.gs.souscriptionApp.utils.ParamsUtils;
import ci.sgabs.gs.souscriptionApp.utils.authentification.SecurityConstants;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.*;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.ApFileMaintenanceTransformer;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.DemandeMaintenanceTransformer;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * @author Alzouma Moussa Mahamadou
 * Modification de la classe en prenant en consideration , les nouveaux champs de la classe Entité Demande
 * @Date Modif : 03/06/2022
 */
@Log
@Component
public class DemandeMaintenanceBusiness implements IBasicBusiness<Request<DemandeMaintenanceDto>, Response<DemandeMaintenanceDto>> {


    private Response<DemandeMaintenanceDto> response;

    @Autowired
    private DemandeMaintenanceRepository demandeMaintenanceRepository;
    @Autowired
    private TypeCarteRepository typeCarteRepository;
    @Autowired
    private StatusRepository statusRepository;
    @Autowired
    private CarteRepository carteRepository;
    @Autowired
    private TypeOperationRepository typeOperationRepository;
    @Autowired
    private HistoriqueDemandeMaintenanceBusiness historiqueDemandeMaintenanceBusiness;
    @Autowired
    private FunctionalError functionalError;
    @Autowired
    private TechnicalError technicalError;
    @Autowired
    private ExceptionUtils exceptionUtils;
    @Autowired
    private CompteRepository compteRepository;
    @Autowired
    private AgenceRepository agenceRepository;

    @Autowired
    private HistoriqueDemandeBusiness historiqueDemandeBusiness;
    @Autowired
    private ParamsUtils paramsUtils;
    @Autowired
    private ParametersRepository parametersRepository;
    @Autowired
    EntityManager entityManager;
    @Autowired
    private DemandeBusiness demandeBusiness;
    @Autowired
    private UsersBusiness usersBusiness;

    //Declaration des constants
    public static final String ANNULATIONCARTE = "ANNULATIONCARTE";
    public static final String CHANGEMENTTARIFICATION = "CHANGEMENTTARIFICATION";
    public static final String MISEAJOURCOMPTE = "MISEAJOURCOMPTE";


    @Autowired
    private EntityManager em;

    private final SimpleDateFormat dateFormat;
    private final SimpleDateFormat dateTimeFormat;
    @Autowired
    private ApFileDemandeRepository apFileDemandeRepository;
    @Autowired
    private UsersRepository usersRepository;
    @Autowired
    private ApFileRepository apFileRepository;
    @Autowired
    private ApFileMaintenanceRepository apFileMaintenanceRepository;
    @Autowired
    private ApFileMaintenanceDemandeMaintenanceRepository apFileMaintenanceDemandeMaintenanceRepository;

    @Autowired
    private HistoriqueDemandeMaintenanceRepository historiqueDemandeRepository;


    public DemandeMaintenanceBusiness() {
        dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    }
    @Override
    public Response<DemandeMaintenanceDto> create(Request<DemandeMaintenanceDto> request, Locale locale) throws Exception {
        log.info("----begin create DemandeMaintenance-----");
        Response<DemandeMaintenanceDto> response = new Response<DemandeMaintenanceDto>();
        List<DemandeMaintenance> items = new ArrayList<DemandeMaintenance>();
        if (request.getDatas() == null || request.getDatas().isEmpty()) {
            response.setStatus(functionalError.DATA_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_MAINTENANCE_OPERATION_CREATE);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas créer une demande de maintenance.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        //Vérification des champs obligatoires
        Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
        List<DemandeMaintenanceDto> itemsDtos = new ArrayList<DemandeMaintenanceDto>();
        for (DemandeMaintenanceDto dto : request.getDatas()) {
            fieldsToVerify.put("carteId", dto.getCarteId());
            fieldsToVerify.put("codetypeOperation", dto.getCodeTypeOperation());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            if (itemsDtos.stream().anyMatch(a -> a.getNumeroCompte().equalsIgnoreCase(dto.getNumeroCompte()))) {
                response.setStatus(functionalError.DATA_DUPLICATE(" Numéro de compte ", locale));
                response.setHasError(true);
                return response;
            }
            if (itemsDtos.stream().anyMatch(a -> a.getCarteId().equals(dto.getCarteId()))) {
                response.setStatus(functionalError.DATA_DUPLICATE(" Carte ", locale));
                response.setHasError(true);
                return response;
            }
            itemsDtos.add(dto);
        }
        //Vérification des contraintes
        Map<String, Object> fieldsToVerify1 = new HashMap<String, Object>();
        for (DemandeMaintenanceDto dto : itemsDtos) {
            //Recherche de doublon
            DemandeMaintenance existingDemandeMaintenance = null;
            String oldCodeAgence = null;
            String produit = null ;
            existingDemandeMaintenance = demandeMaintenanceRepository.findByCarteId(dto.getCarteId(), false);
            if (existingDemandeMaintenance != null) {
                response.setStatus(functionalError.DATA_EXIST("Une demande portant sur la carte suivante -> " + dto.getCarteId() + "  existe", locale));
                response.setHasError(true);
                return response;
            }
            // Vérification de la carte
            Carte existingCarte=null;
            String numberCard=null;
            existingCarte = carteRepository.findOne(dto.getCarteId(), false);
            if (existingCarte == null) {
                response.setStatus(functionalError.DATA_EXIST("Carte inexistante -> " + dto.getCarteId(), locale));
                response.setHasError(true);
                return response;
            }
            if(existingCarte.getTypeCarte() == null || Utilities.isBlank(existingCarte.getTypeCarte().getTypeCarte())){
                response.setStatus(functionalError.DATA_EXIST("Type carte non trouvé -> " + existingCarte.getNumeroCarte(), locale));
                response.setHasError(true);
                return response;
            }
            dto.setProduit(existingCarte.getTypeCarte().getTypeCarte());
            if (Utilities.isNotBlank(existingCarte.getNoms())) {
                dto.setNoms(existingCarte.getNoms());
            }
            if (Utilities.isNotBlank(existingCarte.getCode())) {
               dto.setNumberCard(existingCarte.getCode());
            }
            if (Utilities.isNotBlank(existingCarte.getPrenom())) {
                dto.setPrenom(existingCarte.getPrenom());
            }
            if (existingCarte.getCompte() != null
                    && existingCarte.getCompte().getAgence() != null
                    && existingCarte.getCompte().getAgence().getCode() != null) {
                oldCodeAgence = existingCarte.getCompte().getAgence().getCode();
            }
            //Vérificatio du type de l'operation
            TypeOperation existingTypeOperation = null;
            existingTypeOperation = typeOperationRepository.findTypeOperationByCode(dto.getCodeTypeOperation(), false);
            if (existingTypeOperation == null) {
                response.setStatus(functionalError.DATA_EXIST("Type Operation  inexistant -> " + dto.getCodeTypeOperation(), locale));
                response.setHasError(true);
                return response;
            }
            if (existingTypeOperation.getCode().equals(DemandeMaintenanceBusiness.CHANGEMENTTARIFICATION)) {
                fieldsToVerify1.put("typeCarte", dto.getCodeTypeCarte());
                if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                    response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                    response.setHasError(true);
                    return response;
                }
                TypeCarte existingTypeCarte = null;
                existingTypeCarte = typeCarteRepository.findBytypeCarte(dto.getCodeTypeCarte(), false);
                if (existingTypeCarte == null) {
                    response.setStatus(functionalError.DATA_EXIST("TypeCarte inexistant -> " + dto.getCodeTypeCarte(), locale));
                    response.setHasError(true);
                    return response;
                }
                if (Utilities.isNotBlank(existingCarte.getTypeCarte().getTypeCarte())) { //verify code
                    dto.setProduit(existingCarte.getTypeCarte().getTypeCarte());
                }
            } else if (existingTypeOperation.getCode().equals(DemandeMaintenanceBusiness.MISEAJOURCOMPTE)) {
                //Vérification des chmpas obligatoires pour la demande de maintenance de mise à jour
                fieldsToVerify1.put("numeroCompte", dto.getNumeroCompte());
                fieldsToVerify1.put("codeAgence", dto.getCodeAgence());
                if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                    response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                    response.setHasError(true);
                    return response;
                }
                /**
                 * Vérifications portant sur la mise à jour du compte
                 * Si le numéro de compte fourni est different de celui de l'ancienne da demande Maitenance
                 * alors la propriété NuméroCompte de l'anncienne demandeMaintenance aura pour valeur le numéroCompte fourni
                 * Si le numero de compte est changé alors:
                 *  la propriété isNewCompte sera à true
                 */
                Compte existingCompte = null;
                existingCompte = compteRepository.findByNumeroCompte(dto.getNumeroCompte(), false);
                if (existingCompte == null) {
                    response.setStatus(functionalError.DATA_EXIST("Compte inexistant -> " + dto.getNumeroCompte(), locale));
                    response.setHasError(true);
                    return response;
                }
                String oldNumeroCompte = null;
                if (existingCarte.getCompte() != null && existingCarte.getCompte().getNumero() != null) {
                    oldNumeroCompte = existingCarte.getCompte().getNumero();
                }
                if (Utilities.isNotBlank(oldNumeroCompte) && !existingCompte.getNumero().equals(oldNumeroCompte)) { //verify code
                    dto.setIsNewCompte(true);
                } else {
                    dto.setIsNewCompte(false);
                }
                /**
                 * Vérification de l'agence:
                 * Vérifier si le code agence fourni correspond bien évidement au code agence du compte de la carte
                 * Autrement dit,si le compte est domicilié desormais dans une nouvelle agence
                 * Si effectivement le compte est desormais domicilé dans une nouvelle alors:
                 *      La propirété isNewAgence de la demandeMaintenace sera initialisée à True.
                 */
                Agence existingAgence = null;
                existingAgence = agenceRepository.findByCode(dto.getCodeAgence(), false);
                if (existingAgence == null) {
                    response.setStatus(functionalError.DATA_EXIST("Agence inexistante -> " + dto.getCodeAgence(), locale));
                    response.setHasError(true);
                    return response;
                }
                if (Utilities.isNotBlank(oldCodeAgence) && !existingAgence.getCode().equals(oldCodeAgence)) {
                    dto.setIsNewAgence(true);
                } else {
                    dto.setIsNewAgence(false);
                }
            }else{

            }
            dto.setCodeAgence(oldCodeAgence);
            //Persistence
            Status status = null;
            status = statusRepository.findByCode(DemandeBusiness.DEMANDETATUSENCOURS, false);
            if (status == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Status inexistant", locale));
                response.setHasError(true);
                return response;
            }
            //Transformation de l'objet DemandeMaintenance DTO  en objt Entity
            DemandeMaintenance entityToSave = DemandeMaintenanceTransformer.INSTANCE.toEntity(dto, existingTypeOperation, existingCarte, status);
            entityToSave.setIsDeleted(false);
            entityToSave.setCreatedAt(Utilities.getCurrentDate());
            entityToSave.setCreatedBy(request.userID);
            Users users=usersRepository.findOne(request.userID,false);
            entityToSave.setLogin(users.getLogin()!=null?users.getLogin():null);
            //Persistence de l'objet
            DemandeMaintenance entitySaved = demandeMaintenanceRepository.save(entityToSave);
            items.add(entitySaved);
            if (entitySaved == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Liste vide ", locale));
                response.setHasError(true);
                return response;
            }
            //Historisation du statut actuel de la demande mainteance: HistoriqueDemandeMaintenance
            List<HistoriqueDemandeMaintenanceDto> datasHistoriqueDemandeMaintenance = new ArrayList<HistoriqueDemandeMaintenanceDto>();
            HistoriqueDemandeMaintenanceDto historiqueDemandeMaintenanceDto = new HistoriqueDemandeMaintenanceDto();
            historiqueDemandeMaintenanceDto.setDemandeMaintenanceId(entitySaved.getId());
            historiqueDemandeMaintenanceDto.setStatusId(status.getId());
            datasHistoriqueDemandeMaintenance.add(historiqueDemandeMaintenanceDto);
            //Appel à la classe HistoriqueDemandeBusiness
            Request<HistoriqueDemandeMaintenanceDto> subRequest = new Request<HistoriqueDemandeMaintenanceDto>();
            subRequest.setDatas(datasHistoriqueDemandeMaintenance);
            Response<HistoriqueDemandeMaintenanceDto> subResponse = historiqueDemandeMaintenanceBusiness.create(subRequest, locale);
            if (subResponse.isHasError()) {
                response.setStatus(subResponse.getStatus());
                response.setHasError(true);
                return response;
            }
        }
        if (items == null || items.isEmpty()) {
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste vide ", locale));
            response.setHasError(true);
            return response;
        }
        //Transformation de la liste demanddeMaintenance en objt DTO
        List<DemandeMaintenanceDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                ? DemandeMaintenanceTransformer.INSTANCE.toLiteDtos(items)
                : DemandeMaintenanceTransformer.INSTANCE.toDtos(items);

        //Envoie de la reponse
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end create Demande-----");
        return response;
    }

    @Override
    public Response<DemandeMaintenanceDto> update(Request<DemandeMaintenanceDto> request, Locale locale) throws ParseException {

        log.info("----begin create DemandeMaintenance-----");
        Response<DemandeMaintenanceDto> response = new Response<DemandeMaintenanceDto>();
        List<DemandeMaintenance> items = new ArrayList<DemandeMaintenance>();
        if (request.getDatas() == null || request.getDatas().isEmpty()) {
            response.setStatus(functionalError.DATA_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_MAINTENANCE_OPERATION_UPDATE);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas modifier une demande de maintenance.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        //Verification des champs obligatoires
        Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
        List<DemandeMaintenanceDto> itemsDtos = new ArrayList<DemandeMaintenanceDto>();
        for (DemandeMaintenanceDto dto : request.getDatas()) {
            fieldsToVerify.put("id", dto.getId());
            fieldsToVerify.put("codetypeOperation", dto.getCodeTypeOperation());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            itemsDtos.add(dto);
        }
        //Vérification des contraintes
        Map<String, Object> fieldsToVerify1 = new HashMap<String, Object>();
        for (DemandeMaintenanceDto dto : itemsDtos) {
            DemandeMaintenance entityToSave = demandeMaintenanceRepository.findOne(dto.getId(), false);
            if (entityToSave == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Cette demande maintenance ayant " + dto.getId() + " n'existe pas", locale));
                response.setHasError(true);
                return response;
            }
            if (entityToSave.getStatus() == null || entityToSave.getStatus().getCode() == null
                    || Utilities.blank(entityToSave.getStatus().getCode())) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Cette demande maintenance ayant " + dto.getId() + " n'a aucun statut associé", locale));
                response.setHasError(true);
                return response;
            }
            //Verification du status de la demande maintenance
            String codeStatusDemandeMaintenanceToModify = entityToSave.getStatus().getCode();
            Status existingStatus = null;
            existingStatus = statusRepository.findByCode(entityToSave.getStatus().getCode(), false);
            if (existingStatus == null || existingStatus.getCode() == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Le statut ayant le code  " + entityToSave.getStatus().getCode() + "n'existe pas", locale));
                response.setHasError(true);
                return response;
            }
            if (!codeStatusDemandeMaintenanceToModify.equalsIgnoreCase(existingStatus.getCode())) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Erreur de correspondance portant sur le statut de la demande maintenance ", locale));
                response.setHasError(true);
                return response;
            }
            //Vérification et mise jour de la carte de la demande maintenance à mettre à jour
            if (!Utilities.isValidID(dto.getCarteId())) {
                response.setStatus(functionalError.DATA_NOT_EXIST("L'identifiant de la carte n'est pas valdie  ", locale));
                response.setHasError(true);
                return response;
            }
            Carte existingCarte = null;
            existingCarte = carteRepository.findOne(dto.getCarteId(), false);
            if (existingCarte == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("La carte ayant l'identifiant  " + dto.getCarteId() + "n'existe pas", locale));
                response.setHasError(true);
                return response;
            }
            if (entityToSave.getCarte() != null && entityToSave.getCarte().getId() != null
                    && !entityToSave.equals(existingCarte.getId())) {
                if (Utilities.isNotBlank(existingCarte.getNoms()) && !entityToSave.getNoms().equals(existingCarte.getNoms())) {
                    entityToSave.setNoms(existingCarte.getNoms());
                }
                if (Utilities.isNotBlank(existingCarte.getPrenom()) && !entityToSave.getPrenom().equals(existingCarte.getPrenom())) {
                    entityToSave.setPrenom(existingCarte.getPrenom());
                }
            }
            //Vérification et mise jour du type operation de la demande maintenance à mettre à jour
            if (!Utilities.isValidID(dto.getTypeOperationId())) {
                response.setStatus(functionalError.DATA_NOT_EXIST("L'identifiant du type de l'opération n'est pas valdie  ", locale));
                response.setHasError(true);
                return response;
            }
            TypeOperation existingTypeOperation = null;
            // existingTypeOperation = typeOperationRepository.findTypeOperationById(dto.getTypeOperationId(), false);
            existingTypeOperation = typeOperationRepository.findTypeOperationByCode(dto.getCodeTypeOperation(), false);
            if (existingTypeOperation == null || existingTypeOperation.getCode() == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Le type operation ayant l'identifiant " + dto.getCodeTypeOperation() + "n'existe pas", locale));
                response.setHasError(true);
                return response;
            }
            if (entityToSave.getTypeOperation() == null || entityToSave.getTypeOperation().getCode() == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Type operation non trouvé", locale));
                response.setHasError(true);
                return response;
            }
            String codeTypeOperationDemandeMaintenanceToModify = null;
            codeTypeOperationDemandeMaintenanceToModify = entityToSave.getTypeOperation().getCode();
            //A executer si le code typeOperation est différent de celui du typeOperation de l'ancienne demandeMaintenance
            if (!codeTypeOperationDemandeMaintenanceToModify.equals(existingTypeOperation.getCode())) {
                entityToSave.setTypeOperation(existingTypeOperation);
            }
            if (existingTypeOperation.getCode().equals(DemandeMaintenanceBusiness.CHANGEMENTTARIFICATION)) {
                //Verification des informations obligatoires d'une modification d'une demandde maintenance de changement de tarification
                fieldsToVerify1.put("typeCarte", dto.getCodeTypeCarte());
                if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                    response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                    response.setHasError(true);
                    return response;
                }
                //Récuperation du type de la carte et mise à jour si nécessaire
                TypeCarte existingTypeCarte = null;
                existingTypeCarte = typeCarteRepository.findBytypeCarte(dto.getCodeTypeCarte(), false);
                if (existingTypeCarte == null) {
                    response.setStatus(functionalError.DATA_EXIST("TypeCarte inexistant -> " + dto.getCodeTypeCarte(), locale));
                    response.setHasError(true);
                    return response;
                }
                if (Utilities.isNotBlank(entityToSave.getCodeTypeCarte()) && !entityToSave.getCodeTypeCarte().equals(dto.getCodeTypeCarte())) {
                    entityToSave.setCodeTypeCarte(dto.getCodeTypeCarte());
                }
                //Récuperation du libellé du type de la carte
                if (Utilities.isNotBlank(existingTypeCarte.getLibelle())) { //verify code
                    entityToSave.setProduit(existingTypeCarte.getLibelle());
                }
                entityToSave.setIsNewAgence(null);
                entityToSave.setIsNewCompte(null);
                entityToSave.setNumeroCompte(null);
            } else if (existingTypeOperation.getCode().equals(DemandeMaintenanceBusiness.MISEAJOURCOMPTE)) {
                //Verification des informations obligatoires d'une modification d'une demandde maintenance de mise à jour de compte
                fieldsToVerify1.put("numeroCompte", dto.getNumeroCompte());
                fieldsToVerify1.put("codeAgence", dto.getCodeAgence());
                if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                    response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                    response.setHasError(true);
                    return response;
                }
                /**
                 * Vérifications portant sur la mise à jour du compte
                 * Si le numéro de compte fourni est different de celui de l'ancienne da demande Maitenance
                 * alors la propriété NuméroCompte de l'anncienne demandeMaintenance aura pour valeur le numéroCompte fourni
                 *
                 * Si le numero de compte est changé alors:
                 *  la propriété isNewCompte sera à true
                 */
                Compte existingCompte = null;
                existingCompte = compteRepository.findByNumeroCompte(dto.getNumeroCompte(), false);
                if (existingCompte == null) {
                    response.setStatus(functionalError.DATA_EXIST("Compte inexistant -> " + dto.getNumeroCompte(), locale));
                    response.setHasError(true);
                    return response;
                }
                if (entityToSave.getNumeroCompte() == null || !dto.getNumeroCompte().equals(entityToSave.getNumeroCompte())) {
                    entityToSave.setNumeroCompte(dto.getNumeroCompte());
                }
                String oldNumeroCompte = null;
                if (existingCarte.getCompte() != null && existingCarte.getCompte().getNumero() != null) {
                    oldNumeroCompte = existingCarte.getCompte().getNumero();
                }
                if (Utilities.isNotBlank(oldNumeroCompte) && !existingCompte.getNumero().equals(oldNumeroCompte)) { //verify code
                    entityToSave.setIsNewCompte(true);
                } else {
                    entityToSave.setIsNewCompte(false);
                }
                //Update de la propriété codeAgence
                Agence existingAgence = null;
                existingAgence = agenceRepository.findByCode(dto.getCodeAgence(), false);
                if (existingAgence == null) {
                    response.setStatus(functionalError.DATA_EXIST("Agence inexistante -> " + dto.getCodeAgence(), locale));
                    response.setHasError(true);
                    return response;
                }
                if (entityToSave.getCodeAgence() == null || !entityToSave.getCodeAgence().equals(existingAgence.getCode())) {
                    entityToSave.setCodeAgence(dto.getCodeAgence());
                }

                /**
                 * Vérification de l'agence:
                 * Vérifier si le code agence fourni correspond bien évidement au code agence du compte de la carte
                 * Autrement dit,si le compte est domicilié desormais dans une nouvelle agence
                 * Si effectivement le compte est desormais domicilé dans une nouvelle alors:
                 * La propirété isNewAgence de la demandeMaintenace sera initialisée à True.
                 */
                String oldCodeAgence = null;
                if (existingCarte.getCompte() != null
                        && existingCarte.getCompte().getAgence() != null
                        && existingCarte.getCompte().getAgence().getCode() != null) {
                    oldCodeAgence = existingCarte.getCompte().getAgence().getCode();
                }
                if (Utilities.isNotBlank(oldCodeAgence) && !existingAgence.getCode().equals(oldCodeAgence)) {
                    entityToSave.setIsNewAgence(true);
                } else {
                    entityToSave.setIsNewAgence(false);
                }
                entityToSave.setCodeTypeCarte(null);
            }
            if (Utilities.isNotBlank(dto.getAgent()) && !entityToSave.getAgent().equals(dto.getAgent())) {
                entityToSave.setAgent(dto.getAgent());
            }
            if(dto.getLogin()!=null && !dto.getLogin().equals(entityToSave.getLogin())){
                Users userExisting = usersRepository.findOne(request.userID,false);
                if(userExisting==null){
                    response.setStatus(functionalError.DATA_EMPTY("Utilisateur authentifié non trouvé", locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setLogin(userExisting.getLogin());
            }
            //Informations de tracage
            entityToSave.setUpdatedAt(Utilities.getCurrentDate());
            entityToSave.setUpdatedBy(request.userID);
            items.add(entityToSave);
        }
        if (items == null || items.isEmpty()) {
            response.setStatus(functionalError.DATA_EMPTY("Liste vide ", locale));
            response.setHasError(true);
            return response;
        }
        //Transformation en DTO
        List<DemandeMaintenanceDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                ? DemandeMaintenanceTransformer.INSTANCE.toLiteDtos(items)
                : DemandeMaintenanceTransformer.INSTANCE.toDtos(items);

        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("end Demande update");
        return response;

    }

    public Response<DemandeMaintenanceDto> generateMaintenanceApBatchFile(Request<DemandeMaintenanceDto> request, Locale locale) {

        Response<DemandeMaintenanceDto> response = new Response<DemandeMaintenanceDto>();
        List<DemandeMaintenance> items = new ArrayList<DemandeMaintenance>();
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_MAINTENANCE_APBATCH_GENERATION);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas générer le fichier des demandes de maintenance de carte.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        try {
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("codetypeOperation", request.getData().getCodeTypeOperation());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            String header = demandeBusiness.generateHeaderMaintenance();
            String fullInfo = "";
            String fileName = demandeBusiness.generateFileName();
            Path completedFileName = Path.of(paramsUtils.getPathApBatchFile().concat(fileName));
            fullInfo += header.concat("\n");
            // Writing into the file
            if (request.getData().getCodeTypeOperation().equalsIgnoreCase(DemandeMaintenanceBusiness.ANNULATIONCARTE)) {
                List<DemandeMaintenance> demandeMaintenancesAnnulationCarte = demandeMaintenanceRepository.findByTypeOperationCode(DemandeMaintenanceBusiness.ANNULATIONCARTE, DemandeBusiness.DEMANDETATUSENCOURS, Boolean.FALSE);
                if (Utilities.isNotEmpty(demandeMaintenancesAnnulationCarte)) {
                    int i = 1;
                    for (DemandeMaintenance demandeMaintenance : demandeMaintenancesAnnulationCarte) {
                        String recordGroupingId = Utilities.codeUnderNdigits(i, 24);
                        String recordType = "CH"; // 2 caractères
                        String fileUpdateCode = "8"; //Add 1 caractère
                        String space1 = DemandeBusiness.leftPadding(" ", ' ', 3); //30
                        //31 start
                        String pan = DemandeBusiness.leftPadding(demandeMaintenance.getCarte().getCode(), '0', 19); //card number
                        String space2 = DemandeBusiness.leftPadding(" ", ' ', 4); //54
                        String institutionId = demandeBusiness.getInstitutionId().substring(0, 10);
                        String cardStatus = DemandeBusiness.leftPadding("C3", ' ', 2); // maintenance card
                        String space3 = DemandeBusiness.leftPadding(" ", ' ', 204); //204
                        String primaryNumber = "01";
                        String space4 = DemandeBusiness.leftPadding(" ", ' ', 312); //312
                        String cardOrderStatusFlag = "4"; //order delivered
                        String space5 = DemandeBusiness.leftPadding(" ", ' ', 6); //6
                        String cardIssueReasonFlag = "0";
                        String cardRemplacementIndicator = "y";
                        fullInfo += recordGroupingId.concat(recordType).concat(fileUpdateCode).concat(space1).concat(pan).concat(space2).concat(institutionId).concat(cardStatus).concat(space3).concat(primaryNumber)
                                .concat(space4).concat(cardOrderStatusFlag).concat(space5).concat(cardIssueReasonFlag).concat(cardRemplacementIndicator).concat("\n");
                        i++;
                    }
                    //add trailer
                    fullInfo = addTrailer(fullInfo, demandeMaintenancesAnnulationCarte);
                } else {
                    response.setStatus(functionalError.DATA_EMPTY("aucune demandes de maintenance d'annulation de carte encours", locale));
                    response.setHasError(false);
                    return response;
                }
                Files.writeString(completedFileName, fullInfo);
                ApFileMaintenance apFile = new ApFileMaintenance();
                apFile.setLibelle(paramsUtils.getPathApBatchFile().concat(fileName));
                apFile.setCode(paramsUtils.getLinkApBatchFile().concat(fileName));
                apFile.setFileName(fileName);
                apFile.setCreatedAt(Utilities.getCurrentDate());
                apFile.setIsDeleted(Boolean.FALSE);
                apFile.setIsValidated(Boolean.FALSE);
                apFile.setTypeOperation(DemandeMaintenanceBusiness.ANNULATIONCARTE);
                ApFileMaintenance apFileSaved = apFileMaintenanceRepository.save(apFile);
                List<ApFileMaintenanceDemandeMaintenance> apFileDemandes = Collections.synchronizedList(new ArrayList<ApFileMaintenanceDemandeMaintenance>());
                if (Utilities.isNotEmpty(demandeMaintenancesAnnulationCarte)) {
                    for (DemandeMaintenance demande : demandeMaintenancesAnnulationCarte) {
                        ApFileMaintenanceDemandeMaintenance apFileDemande = new ApFileMaintenanceDemandeMaintenance();
                        apFileDemande.setDemandeMaintenance(demande);
                        apFileDemande.setApFile(apFileSaved);
                        apFileDemande.setIsDeleted(Boolean.FALSE);
                        apFileDemande.setCreatedAt(Utilities.getCurrentDate());
                        apFileDemandes.add(apFileDemande);
                    }
                }
                if (Utilities.isNotEmpty(apFileDemandes)) {
                    apFileMaintenanceDemandeMaintenanceRepository.saveAll(apFileDemandes);
                }
                response.setHasError(Boolean.FALSE);
                response.setStatus(functionalError.SUCCESS("", locale));
                response.setFilePath(apFile.getCode());
            } else {
                //GENERATION APBATCH CODE TARIFICATION
                if (request.getData().getCodeTypeOperation().equalsIgnoreCase(DemandeMaintenanceBusiness.CHANGEMENTTARIFICATION)) {
                    List<DemandeMaintenance> demandeMaintenancesAnnulationCarte = demandeMaintenanceRepository.findByTypeOperationCode(DemandeMaintenanceBusiness.CHANGEMENTTARIFICATION, DemandeBusiness.DEMANDETATUSENCOURS, Boolean.FALSE);
                    if (Utilities.isNotEmpty(demandeMaintenancesAnnulationCarte)) {
                        int i = 1;
                        for (DemandeMaintenance demandeMaintenance : demandeMaintenancesAnnulationCarte) {
                            String recordGroupingId = Utilities.codeUnderNdigits(i, 24);
                            String recordType = "CH"; // 2 caractères
                            String fileUpdateCode = "8"; //Add 1 caractère
                            String space1 = DemandeBusiness.leftPadding(" ", ' ', 3); //30
                            //31 start
                            String pan = DemandeBusiness.leftPadding(demandeMaintenance.getCarte().getCode(), '0', 19); //card number
                            String space2 = DemandeBusiness.leftPadding(" ", ' ', 4); //54
                            String institutionId = demandeBusiness.getInstitutionId().substring(0, 10);
                            String space3 = DemandeBusiness.leftPadding(" ", ' ', 206);
                            String primaryNumber = "01";
                            String space4 = DemandeBusiness.leftPadding(" ", ' ', 438);
                            // les 2 premiers caractères du code du type de carte
                            String feeGroupId = demandeMaintenance.getCodeTypeCarte().substring(0, 2);
                            fullInfo += recordGroupingId.concat(recordType).concat(fileUpdateCode).concat(space1).concat(pan).concat(space2).concat(institutionId).concat(space3).concat(primaryNumber).concat(space4).concat(feeGroupId).concat("\n");
                            i++;
                        }
                        //add trailer
                        fullInfo = addTrailer(fullInfo, demandeMaintenancesAnnulationCarte);
                    } else {
                        response.setStatus(functionalError.DATA_EMPTY("aucune demandes de maintenance de changement de code tarification", locale));
                        response.setHasError(false);
                        return response;
                    }
                    Files.writeString(completedFileName, fullInfo);
                    ApFileMaintenance apFile = new ApFileMaintenance();
                    apFile.setLibelle(paramsUtils.getPathApBatchFile().concat(fileName));
                    apFile.setCode(paramsUtils.getLinkApBatchFile().concat(fileName));
                    apFile.setFileName(fileName);
                    apFile.setCreatedAt(Utilities.getCurrentDate());
                    apFile.setIsDeleted(Boolean.FALSE);
                    apFile.setIsValidated(Boolean.FALSE);
                    apFile.setTypeOperation(DemandeMaintenanceBusiness.CHANGEMENTTARIFICATION);
                    ApFileMaintenance apFileSaved = apFileMaintenanceRepository.save(apFile);
                    List<ApFileMaintenanceDemandeMaintenance> apFileDemandes = Collections.synchronizedList(new ArrayList<ApFileMaintenanceDemandeMaintenance>());
                    if (Utilities.isNotEmpty(demandeMaintenancesAnnulationCarte)) {
                        for (DemandeMaintenance demande : demandeMaintenancesAnnulationCarte) {
                            ApFileMaintenanceDemandeMaintenance apFileDemande = new ApFileMaintenanceDemandeMaintenance();
                            apFileDemande.setDemandeMaintenance(demande);
                            apFileDemande.setApFile(apFileSaved);
                            apFileDemande.setIsDeleted(Boolean.FALSE);
                            apFileDemande.setCreatedAt(Utilities.getCurrentDate());
                            apFileDemandes.add(apFileDemande);
                        }
                    }
                    if (Utilities.isNotEmpty(apFileDemandes)) {
                        apFileMaintenanceDemandeMaintenanceRepository.saveAll(apFileDemandes);
                    }
                    response.setHasError(Boolean.FALSE);
                    response.setStatus(functionalError.SUCCESS("", locale));
                    response.setFilePath(apFile.getCode());
                } else {
                    //GENERATION APBATCH MISE A JOUR COMPTE
                    if (request.getData().getCodeTypeOperation().equalsIgnoreCase(DemandeMaintenanceBusiness.MISEAJOURCOMPTE)) {
                        // demande portant sur la modification du compte uniquement
                        List<DemandeMaintenance> demandeMaintenancesAnnulationCarte = demandeMaintenanceRepository.findByTypeOperationCodeAndUpdateAccountOnly(DemandeMaintenanceBusiness.MISEAJOURCOMPTE, DemandeBusiness.DEMANDETATUSENCOURS, Boolean.TRUE, Boolean.FALSE, Boolean.FALSE);
                        if (Utilities.isNotEmpty(demandeMaintenancesAnnulationCarte)) {
                            int i = 1;
                            for (DemandeMaintenance demandeMaintenance : demandeMaintenancesAnnulationCarte) {
                                String recordGroupingId = Utilities.codeUnderNdigits(i, 24);
                                String recordType = "CA"; // 2 caractères
                                String fileUpdateCode = "8"; //Add 1 caractère
                                String pan = DemandeBusiness.leftPadding(demandeMaintenance.getCarte().getCode(), '0', 19); //card number
                                String space1 = DemandeBusiness.leftPadding(" ", ' ', 17);
                                String accountNumber = DemandeBusiness.rightPadding(DemandeBusiness.rightPadding(demandeMaintenance.getCodeAgence(), ' ', 5).concat("950").concat(demandeMaintenance.getNumeroCompte()), ' ', 28);
                                fullInfo += recordGroupingId.concat(recordType).concat(fileUpdateCode).concat(pan).concat(space1).concat(accountNumber).concat("\n");
                                i++;
                            }
                            //add trailer
                            fullInfo = addTrailer(fullInfo, demandeMaintenancesAnnulationCarte);
                            Files.writeString(completedFileName, fullInfo);
                            ApFileMaintenance apFile = new ApFileMaintenance();
                            apFile.setLibelle(paramsUtils.getPathApBatchFile().concat(fileName));
                            apFile.setCode(paramsUtils.getLinkApBatchFile().concat(fileName));
                            apFile.setFileName(fileName);
                            apFile.setCreatedAt(Utilities.getCurrentDate());
                            apFile.setIsDeleted(Boolean.FALSE);
                            apFile.setIsValidated(Boolean.FALSE);
                            apFile.setTypeOperation(DemandeMaintenanceBusiness.MISEAJOURCOMPTE);
                            apFile.setIsCompte(Boolean.TRUE);
                            apFile.setIsAgence(Boolean.FALSE);
                            ApFileMaintenance apFileSaved = apFileMaintenanceRepository.save(apFile);
                            List<ApFileMaintenanceDemandeMaintenance> apFileDemandes = Collections.synchronizedList(new ArrayList<ApFileMaintenanceDemandeMaintenance>());
                            if (Utilities.isNotEmpty(demandeMaintenancesAnnulationCarte)) {
                                for (DemandeMaintenance demande : demandeMaintenancesAnnulationCarte) {
                                    ApFileMaintenanceDemandeMaintenance apFileDemande = new ApFileMaintenanceDemandeMaintenance();
                                    apFileDemande.setDemandeMaintenance(demande);
                                    apFileDemande.setApFile(apFileSaved);
                                    apFileDemande.setIsDeleted(Boolean.FALSE);
                                    apFileDemande.setCreatedAt(Utilities.getCurrentDate());
                                    apFileDemandes.add(apFileDemande);
                                }
                            }
                            if (Utilities.isNotEmpty(apFileDemandes)) {
                                apFileMaintenanceDemandeMaintenanceRepository.saveAll(apFileDemandes);
                            }
                            response.setHasError(Boolean.FALSE);
                            response.setStatus(functionalError.SUCCESS("", locale));
                            response.setFilePath(apFile.getCode());
                        }
                        Date actuallyDate = Utilities.getCurrentDate();
                        header = demandeBusiness.generateHeaderMaintenanceUpdate(actuallyDate);
                        fullInfo = "";
                        fileName = demandeBusiness.generateFileNameUpdate(actuallyDate);
                        completedFileName = Path.of(paramsUtils.getPathApBatchFile().concat(fileName));
                        fullInfo += header.concat("\n");

                        //demande portant sur la modification d'agence et/ou compte
                        //1ère génération des lignes CA
                        demandeMaintenancesAnnulationCarte = new ArrayList<>();
                        demandeMaintenancesAnnulationCarte = demandeMaintenanceRepository.findByTypeOperationCodeAndUpdateAgency(DemandeMaintenanceBusiness.MISEAJOURCOMPTE, DemandeBusiness.DEMANDETATUSENCOURS, Boolean.TRUE, Boolean.FALSE);
                        if (Utilities.isNotEmpty(demandeMaintenancesAnnulationCarte)) {
                            int i = 1;
                            for (DemandeMaintenance demandeMaintenance : demandeMaintenancesAnnulationCarte) {
                                String recordGroupingId = Utilities.codeUnderNdigits(i, 24);
                                String recordType = "CA"; // 2 caractères
                                String fileUpdateCode = "8"; //Add 1 caractère
                                String pan = DemandeBusiness.leftPadding(demandeMaintenance.getCarte().getCode(), '0', 19); //card number
                                String space1 = DemandeBusiness.leftPadding(" ", ' ', 17);
                                String accountNumber = DemandeBusiness.rightPadding(DemandeBusiness.rightPadding(demandeMaintenance.getCodeAgence(), ' ', 5).concat("950").concat(demandeMaintenance.getNumeroCompte()), ' ', 28);
                                fullInfo += recordGroupingId.concat(recordType).concat(fileUpdateCode).concat(pan).concat(space1).concat(accountNumber).concat("\n");
                                i++;
                            }
                            //add trailer
                            fullInfo = addTrailer(fullInfo, demandeMaintenancesAnnulationCarte);
                            Files.writeString(completedFileName, fullInfo);
                            ApFileMaintenance apFile = new ApFileMaintenance();
                            apFile.setLibelle(paramsUtils.getPathApBatchFile().concat(fileName));
                            apFile.setCode(paramsUtils.getLinkApBatchFile().concat(fileName));
                            apFile.setFileName(fileName);
                            apFile.setCreatedAt(Utilities.getCurrentDate());
                            apFile.setIsDeleted(Boolean.FALSE);
                            apFile.setIsValidated(Boolean.FALSE);
                            apFile.setTypeOperation(DemandeMaintenanceBusiness.MISEAJOURCOMPTE);
                            apFile.setIsCompte(Boolean.FALSE);
                            apFile.setIsAgence(Boolean.TRUE);
                            apFile.setIsCa(Boolean.TRUE);
                            apFile.setIsCh(Boolean.FALSE);
                            ApFileMaintenance apFileSaved = apFileMaintenanceRepository.save(apFile);
                            List<ApFileMaintenanceDemandeMaintenance> apFileDemandes = Collections.synchronizedList(new ArrayList<ApFileMaintenanceDemandeMaintenance>());
                            if (Utilities.isNotEmpty(demandeMaintenancesAnnulationCarte)) {
                                for (DemandeMaintenance demande : demandeMaintenancesAnnulationCarte) {
                                    ApFileMaintenanceDemandeMaintenance apFileDemande = new ApFileMaintenanceDemandeMaintenance();
                                    apFileDemande.setDemandeMaintenance(demande);
                                    apFileDemande.setApFile(apFileSaved);
                                    apFileDemande.setIsDeleted(Boolean.FALSE);
                                    apFileDemande.setCreatedAt(Utilities.getCurrentDate());
                                    apFileDemandes.add(apFileDemande);
                                }
                            }
                            if (Utilities.isNotEmpty(apFileDemandes)) {
                                apFileMaintenanceDemandeMaintenanceRepository.saveAll(apFileDemandes);
                            }
                        }
                        //2ième génération des lignes CH
                        Calendar calendar = new GregorianCalendar();
                        calendar.setTime(Utilities.getCurrentDate());
                        calendar.add(Calendar.MINUTE, +1);
                        actuallyDate = calendar.getTime();
                        header = demandeBusiness.generateHeaderMaintenanceUpdate(actuallyDate);
                        fullInfo = "";
                        fileName = demandeBusiness.generateFileNameUpdate(actuallyDate);
                        completedFileName = Path.of(paramsUtils.getPathApBatchFile().concat(fileName));
                        fullInfo += header.concat("\n");
                        if (Utilities.isNotEmpty(demandeMaintenancesAnnulationCarte)) {
                            int i = 1;
                            for (DemandeMaintenance demandeMaintenance : demandeMaintenancesAnnulationCarte) {
                                String recordGroupingId = Utilities.codeUnderNdigits(i, 24);
                                String recordType = "CH"; // 2 caractères
                                String fileUpdateCode = "8"; //Add 1 caractère
                                String space1 = DemandeBusiness.leftPadding(" ", ' ', 2);
                                String pan = DemandeBusiness.leftPadding(demandeMaintenance.getCarte().getCode(), '0', 19); //card number
                                String space2 = DemandeBusiness.leftPadding(" ", ' ', 223);
                                String branchNumber = DemandeBusiness.leftPadding(demandeMaintenance.getCodeAgence(), '0', 6);
                                fullInfo += recordGroupingId.concat(recordType).concat(fileUpdateCode).concat(space1).concat(pan).concat(space2).concat(branchNumber).concat("\n");
                                i++;
                            }
                            //add trailer
                            fullInfo = addTrailer(fullInfo, demandeMaintenancesAnnulationCarte);
                            Files.writeString(completedFileName, fullInfo);
                            ApFileMaintenance apFile = new ApFileMaintenance();
                            apFile.setLibelle(paramsUtils.getPathApBatchFile().concat(fileName));
                            apFile.setCode(paramsUtils.getLinkApBatchFile().concat(fileName));
                            apFile.setFileName(fileName);
                            apFile.setCreatedAt(Utilities.getCurrentDate());
                            apFile.setIsDeleted(Boolean.FALSE);
                            apFile.setIsValidated(Boolean.FALSE);
                            apFile.setTypeOperation(DemandeMaintenanceBusiness.MISEAJOURCOMPTE);
                            apFile.setIsCompte(Boolean.FALSE);
                            apFile.setIsAgence(Boolean.TRUE);
                            apFile.setIsCh(Boolean.TRUE);
                            apFile.setIsCa(Boolean.FALSE);
                            ApFileMaintenance apFileSaved = apFileMaintenanceRepository.save(apFile);
                            List<ApFileMaintenanceDemandeMaintenance> apFileDemandes = Collections.synchronizedList(new ArrayList<ApFileMaintenanceDemandeMaintenance>());
                            if (Utilities.isNotEmpty(demandeMaintenancesAnnulationCarte)) {
                                for (DemandeMaintenance demande : demandeMaintenancesAnnulationCarte) {
                                    ApFileMaintenanceDemandeMaintenance apFileDemande = new ApFileMaintenanceDemandeMaintenance();
                                    apFileDemande.setDemandeMaintenance(demande);
                                    apFileDemande.setApFile(apFileSaved);
                                    apFileDemande.setIsDeleted(Boolean.FALSE);
                                    apFileDemande.setCreatedAt(Utilities.getCurrentDate());
                                    apFileDemandes.add(apFileDemande);
                                }
                            }
                            if (Utilities.isNotEmpty(apFileDemandes)) {
                                apFileMaintenanceDemandeMaintenanceRepository.saveAll(apFileDemandes);
                            }
                        }
                    }
                    response.setHasError(Boolean.FALSE);
                    response.setStatus(functionalError.SUCCESS("", locale));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }

    private String addTrailer(String fullInfo, List<DemandeMaintenance> demandeMaintenancesAnnulationCarte) {
        String trailFilter = demandeBusiness.leftPadding(" ", ' ', 24);
        String trailRecordType = "TR";
        String instiutionId = demandeBusiness.getInstitutionId();
        String controlNumber = null;
        Parameters parametersNbreGeneration = parametersRepository.findByCode("nbreGenerationMaintenance", Boolean.FALSE);
        if (parametersNbreGeneration != null) {
            String recupLastValue = String.valueOf((Integer.parseInt(parametersNbreGeneration.getValeur())));
            controlNumber = Utilities.codeUnderNdigits(Integer.parseInt(recupLastValue), 3);
        }
        String totalRecordNumber = demandeBusiness.leftPadding(String.valueOf(demandeMaintenancesAnnulationCarte.size() * 2), '0', 11);
        String hastTotal = demandeBusiness.leftPadding(" ", '0', 10);
        String trailFilterEnd = demandeBusiness.leftPadding(" ", ' ', 788);
        fullInfo += trailFilter.concat(trailRecordType).concat(instiutionId).concat(controlNumber).concat(totalRecordNumber).concat(hastTotal).concat(trailFilterEnd);
        return fullInfo;
    }

    public Response<ApFileMaintenanceDto> getApFile(Request<ApFileMaintenanceDto> request, Locale locale) throws Exception {
        Response<ApFileMaintenanceDto> response = new Response<ApFileMaintenanceDto>();
        log.info("----begin list getApFile-----");
        try {
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("index", request.getIndex());
            fieldsToVerify.put("size", request.getSize());
            fieldsToVerify.put("typeOperation", request.getData().getTypeOperation());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            List<ApFileMaintenance> apFiles = apFileMaintenanceRepository.getApFile(request.getData().getTypeOperation(), Boolean.FALSE, PageRequest.of(request.getIndex(), request.getSize()));
            long countAppFile = apFileMaintenanceRepository.countApFile(Boolean.FALSE);
            response.setHasError(Boolean.FALSE);
            if (Utilities.isNotEmpty(apFiles)) {
                response.setItems(ApFileMaintenanceTransformer.INSTANCE.toDtos(apFiles));
                response.setCount(countAppFile);
            } else {
                response.setItems(new ArrayList<>());
                response.setCount(0L);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        log.info("----end get list getApFile-----");
        return response;
    }

    private void logicToValidateApBatchFile(Request<ApFileDto> request, ApFileMaintenance apFile, List<HistoriqueDemandeMaintenance> historiqueDemandes) {
        if (request.getData().getIsValidated()) {
            Status status = statusRepository.findByCode(DemandeBusiness.APPBATCHSTATUSVALIDE, Boolean.FALSE);
            List<DemandeMaintenance> demandes = apFileMaintenanceDemandeMaintenanceRepository.getDemandeByApFileId(apFile.getId(), Boolean.FALSE);
            if (Utilities.isNotEmpty(demandes) && status != null) {
                List<Carte> cartes = Collections.synchronizedList(new ArrayList<Carte>());
                for (DemandeMaintenance r : demandes) {
                    r.setStatus(status);
                    r.setUpdatedAt(Utilities.getCurrentDate());
                    HistoriqueDemandeMaintenance historiqueDemande = new HistoriqueDemandeMaintenance();
                    historiqueDemande.setDemandeMaintenance(r);
                    historiqueDemande.setStatus(status);
                    historiqueDemande.setIsDeleted(Boolean.FALSE);
                    historiqueDemande.setCreatedAt(Utilities.getCurrentDate());
                    historiqueDemandes.add(historiqueDemande);
                }
                demandeMaintenanceRepository.saveAll(demandes);
            }
            //historisation
            if (Utilities.isNotEmpty(historiqueDemandes)) {
                historiqueDemandeRepository.saveAll(historiqueDemandes);
            }
            //suprress older
            List<ApFileMaintenance> filesOld = apFileMaintenanceRepository.getDifferent(apFile.getId(), Boolean.FALSE, Boolean.FALSE);
            if (Utilities.isNotEmpty(filesOld)) {
                filesOld.forEach(f -> {
                    f.setIsDeleted(Boolean.TRUE);
                    f.setDeletedAt(Utilities.getCurrentDate());
                });
                apFileMaintenanceRepository.saveAll(filesOld);
            }
        }
    }

    public Response<ApFileDto> validateApBatch(Request<ApFileDto> request, Locale locale) throws Exception {
        Response<ApFileDto> response = new Response<ApFileDto>();
        log.info("----begin validateApBatch-----");
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_MAINTENANCE_APBATCH_VALIDATION);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas valider le fichier des demandes de maintenance de carte.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        //Traitement de validation de AppBatch
        try {
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", request.getData().getId());
            fieldsToVerify.put("isValidated", request.getData().getIsValidated());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            ApFileMaintenance apFile = apFileMaintenanceRepository.findOne(request.getData().getId(), Boolean.FALSE);
            if (apFile == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("api batch inexistant", locale));
                response.setHasError(false);
                return response;
            }
            List<HistoriqueDemandeMaintenance> historiqueDemandes = Collections.synchronizedList(new ArrayList<HistoriqueDemandeMaintenance>());
            apFile.setIsValidated(request.getData().getIsValidated());
            apFile.setUpdatedAt(Utilities.getCurrentDate());
            apFileMaintenanceRepository.save(apFile);
            //zipping file
            zippingToCftFolder(apFile);
            //if true change status of demande
            logicToValidateApBatchFile(request, apFile, historiqueDemandes);
            response.setStatus(functionalError.SUCCESS("", locale));
            response.setHasError(Boolean.FALSE);
        } catch (Exception e) {
            response.setHasError(Boolean.TRUE);
            ci.sgabs.gs.souscriptionApp.helper.status.Status status = new ci.sgabs.gs.souscriptionApp.helper.status.Status();
            status.setCode("804");
            status.setMessage(e.getMessage());
            response.setStatus(status);
            e.printStackTrace();
            return response;
        }
        log.info("----end validateApBatch-----");
        return response;
    }

    public Response<ApFileDto> validateApBatchUpdateAccount(Request<ApFileDto> request, Locale locale) throws Exception {
        Response<ApFileDto> response = new Response<ApFileDto>();
        log.info("----begin validateApBatchUpdateAccount-----");
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_MAINTENANCE_APBATCH_VALIDATION);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas valider le fichier des demandes de maintenance de carte.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        try {
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("isValidated", request.getData().getIsValidated());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            List<HistoriqueDemandeMaintenance> historiqueDemandes = Collections.synchronizedList(new ArrayList<HistoriqueDemandeMaintenance>());
            List<ApFileMaintenance> apFileMaintenanceMisAjourCompteOnly = apFileMaintenanceRepository.getApFileMiseAjourCompte(DemandeMaintenanceBusiness.MISEAJOURCOMPTE, Boolean.FALSE, PageRequest.of(0, 1));
            if (Utilities.isNotEmpty(apFileMaintenanceMisAjourCompteOnly)) {
                zipAndHisto(request, historiqueDemandes, apFileMaintenanceMisAjourCompteOnly);
            }

            List<ApFileMaintenance> apFileMaintenanceMisAjourAgenceCa = apFileMaintenanceRepository.getApFileMiseAjourAgenceCa(DemandeMaintenanceBusiness.MISEAJOURCOMPTE, Boolean.FALSE, PageRequest.of(0, 1));
            if (Utilities.isNotEmpty(apFileMaintenanceMisAjourAgenceCa)) {
                zipAndHisto(request, historiqueDemandes, apFileMaintenanceMisAjourAgenceCa);
            }

            List<ApFileMaintenance> apFileMaintenanceMisAjourAgenceCh = apFileMaintenanceRepository.getApFileMiseAjourAgenceCh(DemandeMaintenanceBusiness.MISEAJOURCOMPTE, Boolean.FALSE, PageRequest.of(0, 1));
            if (Utilities.isNotEmpty(apFileMaintenanceMisAjourAgenceCh)) {
                zipAndHisto(request, historiqueDemandes, apFileMaintenanceMisAjourAgenceCh);
            }
            //new logics
            response.setStatus(functionalError.SUCCESS("", locale));
            response.setHasError(Boolean.FALSE);
        } catch (Exception e) {
            response.setHasError(Boolean.TRUE);
            ci.sgabs.gs.souscriptionApp.helper.status.Status status = new ci.sgabs.gs.souscriptionApp.helper.status.Status();
            status.setCode("804");
            status.setMessage(e.getMessage());
            response.setStatus(status);
            e.printStackTrace();
            return response;
        }
        log.info("----end validateApBatchUpdateAccount-----");
        return response;
    }

    private void zipAndHisto(Request<ApFileDto> request, List<HistoriqueDemandeMaintenance> historiqueDemandes, List<ApFileMaintenance> apFileMaintenanceMisAjourCompteOnly) throws IOException {
        for (ApFileMaintenance apFile : apFileMaintenanceMisAjourCompteOnly) {
            apFile.setIsValidated(request.getData().getIsValidated());
            apFile.setUpdatedAt(Utilities.getCurrentDate());
            apFileMaintenanceRepository.save(apFile);
            //zipping file
            zippingToCftFolder(apFile);
            Status status = statusRepository.findByCode(DemandeBusiness.APPBATCHSTATUSVALIDE, Boolean.FALSE);
            List<DemandeMaintenance> demandes = apFileMaintenanceDemandeMaintenanceRepository.getDemandeByApFileId(apFile.getId(), Boolean.FALSE);
            if (Utilities.isNotEmpty(demandes) && status != null) {
                for (DemandeMaintenance r : demandes) {
                    r.setStatus(status);
                    r.setUpdatedAt(Utilities.getCurrentDate());
                    HistoriqueDemandeMaintenance historiqueDemande = new HistoriqueDemandeMaintenance();
                    historiqueDemande.setDemandeMaintenance(r);
                    historiqueDemande.setStatus(status);
                    historiqueDemande.setIsDeleted(Boolean.FALSE);
                    historiqueDemande.setCreatedAt(Utilities.getCurrentDate());
                    historiqueDemandes.add(historiqueDemande);
                }
                demandeMaintenanceRepository.saveAll(demandes);
            }
            //historisation
            if (Utilities.isNotEmpty(historiqueDemandes)) {
                historiqueDemandeRepository.saveAll(historiqueDemandes);
            }
        }
    }

    private void zippingToCftFolder(ApFileMaintenance apFile) throws IOException {
        String sourceFile = apFile.getLibelle();
        FileOutputStream fos = new FileOutputStream(paramsUtils.getZipApBatchFile().concat(apFile.getFileName()).concat(".zip"));
        ZipOutputStream zipOut = new ZipOutputStream(fos);

        File fileToZip = new File(sourceFile);
        FileInputStream fis = new FileInputStream(fileToZip);
        ZipEntry zipEntry = new ZipEntry(fileToZip.getName());
        zipOut.putNextEntry(zipEntry);
        byte[] bytes = new byte[1024];
        int length;
        while ((length = fis.read(bytes)) >= 0) {
            zipOut.write(bytes, 0, length);
        }
        zipOut.close();
        fis.close();
        fos.close();
    }

    @Override
    public Response<DemandeMaintenanceDto> delete(Request<DemandeMaintenanceDto> request, Locale locale) {

        Response<DemandeMaintenanceDto> response = new Response<DemandeMaintenanceDto>();
        List<DemandeMaintenance> items = new ArrayList<DemandeMaintenance>();
        if (request.getDatas() == null || request.getDatas().isEmpty()) {
            response.setStatus(functionalError.FIELD_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_MAINTENANCE_OPERATION_DELETE);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas supprimer une demande de maintenance.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        //Verification des parametres obligatoires
        for (DemandeMaintenanceDto dto : request.getDatas()) {
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
        }
        //Verification du champ obligatoire id
        for (DemandeMaintenanceDto dto : request.getDatas()) {
            DemandeMaintenance existingEntity = null;
            existingEntity = demandeMaintenanceRepository.findOne(dto.getId(), false);
            if (existingEntity == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("DemandeMaintenance id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }
            if (existingEntity.getStatus() != null
                    && existingEntity.getStatus().getCode() != null
                    && !existingEntity.getStatus().getCode().equals(DemandeBusiness.DEMANDETATUSENCOURS)) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Cette demande-> " + dto.getId() + " ne peut être surpprimée,car elle n'est plus en cours de traitement", locale));
                response.setHasError(true);
                return response;
            }
            existingEntity.setIsDeleted(true);
            existingEntity.setDeletedAt(Utilities.getCurrentDate());
            existingEntity.setDeletedBy(request.userID);
            items.add(existingEntity);
        }
        if (items == null || items.isEmpty()) {
            response.setStatus(functionalError.FIELD_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end delete User-----");
        return response;
    }

    @Override
    public Response<DemandeMaintenanceDto> forceDelete(Request<DemandeMaintenanceDto> request, Locale locale) throws ParseException {
        return null;
    }

    @Override
    public Response<DemandeMaintenanceDto> getByCriteria(Request<DemandeMaintenanceDto> request, Locale locale) throws Exception {

        log.info("----begin get Demande Maintenance-----");
        Response<DemandeMaintenanceDto> response = new Response<DemandeMaintenanceDto>();
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_MAINTENANCE_OPERATION_LIST);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas lister les demandes de maintenance en cours.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        if (Utilities.blank(request.getData().getOrderField())) {
            request.getData().setOrderField("");
        }
        if (Utilities.blank(request.getData().getOrderDirection())) {
            request.getData().setOrderDirection("asc");
        }
        List<DemandeMaintenance> items = demandeMaintenanceRepository.getByCriteria(request, em, locale);
        if (Utilities.isEmpty(items)) {
            response.setStatus(functionalError.DATA_EMPTY("Demande Maintenance", locale));
            response.setHasError(false);
            return response;
        }
        List<DemandeMaintenanceDto> itemsDto = DemandeMaintenanceTransformer.INSTANCE.toDtos(items);
        response.setItems(itemsDto);
        response.setCount(demandeMaintenanceRepository.count(request, em, locale));
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end get Demande Maintenance-----");
        return response;

    }


    @Transactional(rollbackFor = {RuntimeException.class, Exception.class})
    public Response<DemandeMaintenanceDto> requestMaintenanceInProgressList(Request<DemandeMaintenanceDto> request, Locale locale) throws Exception {

        Response<DemandeMaintenanceDto> response = new Response<DemandeMaintenanceDto>();
        List<DemandeMaintenance> requestMaintenanceInProgressList = new ArrayList<DemandeMaintenance>();
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_MAINTENANCE_OPERATION_LIST);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas lister les demandes de maintenance en cours.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        //Verification des parametres obligatoires
        Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
        fieldsToVerify.put("index", request.getIndex());
        fieldsToVerify.put("size", request.getSize());
        if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
            response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
            response.setHasError(true);
            return response;
        }
        Long count=0L;
        int index=request.getIndex();
        int size=request.getSize();
        count=demandeMaintenanceRepository.countByStatusCode(DemandeBusiness.DEMANDETATUSENCOURS, false);
        Role userAuthenticatedRole=usersBusiness.getRoleUserAuthenticated(Request.userID);
        if(userAuthenticatedRole==null || userAuthenticatedRole.getCode()==null){
            response.setStatus(functionalError.DATA_EMPTY("L'utilisateur authentifié ne dispose d'aucun rôle", locale));
            response.setHasError(false);
            return response;
        }
        if(userAuthenticatedRole.getCode().equals(SecurityConstants.PROFIL_CC)){
            requestMaintenanceInProgressList=demandeMaintenanceRepository.findByStatusCode1(DemandeBusiness.DEMANDETATUSENCOURS,Request.userID, false,PageRequest.of(index,size));
        }else if(userAuthenticatedRole.getCode().equals(SecurityConstants.PROFIL_RA)) {
            Agence userAuthenticatedAgency=null;
            userAuthenticatedAgency=usersBusiness.getAgenceUserAuthenticated(Request.userID);
            if(userAuthenticatedAgency==null || userAuthenticatedAgency.getId()==null){
                response.setStatus(functionalError.DATA_EMPTY("L'utilisateur authentifié n'est rattaché à aucune agence", locale));
                response.setHasError(false);
                return response;
            }
            String codeAgency=userAuthenticatedAgency.getCode();
            requestMaintenanceInProgressList=demandeMaintenanceRepository.findByStatusCode2(DemandeBusiness.DEMANDETATUSENCOURS,codeAgency,false,PageRequest.of(index,size));
        }else{
            requestMaintenanceInProgressList=demandeMaintenanceRepository.findByStatusCode(DemandeBusiness.DEMANDETATUSENCOURS, false,PageRequest.of(index,size));
        }
        if (Utilities.isEmpty(requestMaintenanceInProgressList)) {
            response.setStatus(functionalError.DATA_EMPTY("Aucune demande maintenance valide disponible", locale));
            response.setHasError(false);
            return response;
        }
        List<DemandeMaintenanceDto> itemsDto = DemandeMaintenanceTransformer.INSTANCE.toDtos(requestMaintenanceInProgressList);
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setCount(count);
        response.setStatus(functionalError.SUCCESS("", locale));

        return response;
    }

}
