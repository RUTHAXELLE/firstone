package ci.sgabs.gs.souscriptionApp.rest.api;

import ci.sgabs.gs.souscriptionApp.business.ClientBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.enums.FunctionalityEnum;
import ci.sgabs.gs.souscriptionApp.rest.fact.ControllerFactory;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.ClientDto;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@Log
@CrossOrigin("*")
@RestController
@RequestMapping(value="/clients")
public class ClientController {

    @Autowired
    private ControllerFactory<ClientDto> controllerFactory;
    @Autowired
    private ClientBusiness clientBusiness;


    @RequestMapping(value="",method= RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<ClientDto> create(@RequestBody Request<ClientDto> request) {
        log.info("start method create");
        Response<ClientDto> response = controllerFactory.create(clientBusiness, request, FunctionalityEnum.CREATE_USER);
        log.info("end method create");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.PUT,consumes = {"application/json"},produces={"application/json"})
    public Response<ClientDto> update(@RequestBody Request<ClientDto> request) {
        log.info("start method update");
        Response<ClientDto> response = controllerFactory.update(clientBusiness, request, FunctionalityEnum.UPDATE_USER);
        log.info("end method update");
        return response;
    }


    @RequestMapping(value="/delete",method=RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<ClientDto> delete(@RequestBody Request<ClientDto> request) {
        log.info("start method delete");
        Response<ClientDto> response = controllerFactory.delete(clientBusiness, request, FunctionalityEnum.DELETE_USER);
        log.info("end method delete");
        return response;
    }


    @RequestMapping(value="/getByCriteria",method=RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<ClientDto> getByCriteria(@RequestBody Request<ClientDto> request) {
        log.info("start method getByCriteria");
        Response<ClientDto> response = controllerFactory.getByCriteria(clientBusiness, request, FunctionalityEnum.VIEW_USER);
        log.info("end method getByCriteria");
        return response;
    }

}
