package ci.sgabs.gs.souscriptionApp.helper.contrat;

import ci.sgabs.gs.souscriptionApp.helper.status.Status;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
public class ResponseBase {

    protected Status status;
    protected boolean	hasError;
    protected String	sessionUser;
    protected Long		count;
    protected String  	filePath;

}