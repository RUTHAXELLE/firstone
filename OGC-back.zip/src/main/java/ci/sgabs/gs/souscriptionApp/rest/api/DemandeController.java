package ci.sgabs.gs.souscriptionApp.rest.api;

import ci.sgabs.gs.souscriptionApp.business.ApFileBusiness;
import ci.sgabs.gs.souscriptionApp.business.DemandeBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.enums.FunctionalityEnum;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.status.StatusCode;
import ci.sgabs.gs.souscriptionApp.helper.status.StatusMessage;
import ci.sgabs.gs.souscriptionApp.rest.fact.ControllerFactory;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.ApFileDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.DemandeDto;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.CannotCreateTransactionException;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Locale;

@Log
@CrossOrigin("*")
@RestController
@RequestMapping(value = "/demandes")
public class DemandeController {


    @Autowired
    private ControllerFactory<DemandeDto> controllerFactory;
    @Autowired
    private DemandeBusiness demandeBusiness;

    @Autowired
    private FunctionalError functionalError;
    @Autowired
    private ExceptionUtils exceptionUtils;
    @Autowired
    private HttpServletRequest requestBasic;

    @Autowired
    private ApFileBusiness apFileBusiness;

    @RequestMapping(value = "", method = RequestMethod.POST, consumes = {"application/json"}, produces = {"application/json"})
    public Response<DemandeDto> create(@RequestBody Request<DemandeDto> request) {
        log.info("start method /Demande/create");
        Response<DemandeDto> response = controllerFactory.create(demandeBusiness, request, FunctionalityEnum.CREATE_DEMANDE);
        log.info("end method /Demande/create");
        return response;
    }

    @RequestMapping(value = "", method = RequestMethod.PUT, consumes = {"application/json"}, produces = {"application/json"})
    public Response<DemandeDto> update(@RequestBody Request<DemandeDto> request) {
        log.info("start method /Demandes/update");
        Response<DemandeDto> response = controllerFactory.update(demandeBusiness, request, FunctionalityEnum.UPDATE_DEMANDE);
        log.info("end method /Demande/update");
        return response;
    }

    @RequestMapping(value = "", method = RequestMethod.DELETE, consumes = {"application/json"}, produces = {"application/json"})
    public Response<DemandeDto> delete(@RequestBody Request<DemandeDto> request) {
        log.info("start method /Demande/delete");
        Response<DemandeDto> response = controllerFactory.delete(demandeBusiness, request, FunctionalityEnum.DELETE_DEMANDE);
        log.info("end method /Demande/delete");
        return response;
    }

    @RequestMapping(value = "/forceDelete", method = RequestMethod.DELETE, consumes = {"application/json"}, produces = {"application/json"})
    public Response<DemandeDto> forceDelete(@RequestBody Request<DemandeDto> request) {
        log.info("start method /Demande/forceDelete");
        Response<DemandeDto> response = controllerFactory.forceDelete(demandeBusiness, request, FunctionalityEnum.DELETE_DEMANDE);
        log.info("end method /Demande/forceDelete");
        return response;
    }


    @RequestMapping(value = "/getByCriteria", method = RequestMethod.POST, consumes = {"application/json"}, produces = {"application/json"})
    public Response<DemandeDto> getByCriteria(@RequestBody Request<DemandeDto> request) {
        log.info("start method /Demande/getByCriteria");
        Response<DemandeDto> response = controllerFactory.getByCriteria(demandeBusiness, request, FunctionalityEnum.VIEW_DEMANDE);
        log.info("end method /Demande/getByCriteria");
        return response;
    }

    @RequestMapping(value = "/controleAllDemande", method = RequestMethod.POST, consumes = {"application/json"}, produces = {"application/json"})
    public Response<DemandeDto> ControleAllDemande(Request<DemandeDto> request) {
        Response<DemandeDto> response = new Response<DemandeDto>();
        String languageID = (String) requestBasic.getAttribute("CURRENT_LANGUAGE_IDENTIFIER");
        log.info("la langue " + languageID);
        Locale locale = new Locale(languageID, "");
        try {
            response = demandeBusiness.checkAllRequestInProgress(request, locale);
            if (response.isHasError()) {
                log.info(String.format("Erreur| code: {} -  message: {}", response.getStatus().getCode(), response.getStatus().getMessage()));
                return response;
            }
            log.info(String.format("code: {} -  message: {}", StatusCode.SUCCESS, StatusMessage.SUCCESS));
        } catch (CannotCreateTransactionException e) {
            exceptionUtils.CANNOT_CREATE_TRANSACTION_EXCEPTION(response, locale, e);
        } catch (TransactionSystemException e) {
            exceptionUtils.TRANSACTION_SYSTEM_EXCEPTION(response, locale, e);
        } catch (RuntimeException e) {
            exceptionUtils.RUNTIME_EXCEPTION(response, locale, e);
        } catch (Exception e) {
            exceptionUtils.EXCEPTION(response, locale, e);
        }
        return response;
    }

    @RequestMapping(value = "/allDemandeInchorente", method = RequestMethod.POST, consumes = {"application/json"}, produces = {"application/json"})
    public Response<DemandeDto> allDemandeInchorente(@RequestBody Request<DemandeDto> request) {
        Response<DemandeDto> response = new Response<DemandeDto>();
        String languageID = (String) requestBasic.getAttribute("CURRENT_LANGUAGE_IDENTIFIER");
        log.info("la langue " + languageID);
        Locale locale = new Locale(languageID, "");
        try {
            response = demandeBusiness.requestInconsistentList(request, locale);
            if (response.isHasError()) {
                log.info(String.format("Erreur| code: {} -  message: {}", response.getStatus().getCode(), response.getStatus().getMessage()));
                return response;
            }
            log.info(String.format("code: {} -  message: {}", StatusCode.SUCCESS, StatusMessage.SUCCESS));
        } catch (CannotCreateTransactionException e) {
            exceptionUtils.CANNOT_CREATE_TRANSACTION_EXCEPTION(response, locale, e);
        } catch (TransactionSystemException e) {
            exceptionUtils.TRANSACTION_SYSTEM_EXCEPTION(response, locale, e);
        } catch (RuntimeException e) {
            exceptionUtils.RUNTIME_EXCEPTION(response, locale, e);
        } catch (Exception e) {
            exceptionUtils.EXCEPTION(response, locale, e);
        }
        return response;
    }


    @RequestMapping(value = "/allDemandeValide", method = RequestMethod.POST, consumes = {"application/json"}, produces = {"application/json"})
    public Response<DemandeDto> allDemandeValide(@RequestBody Request<DemandeDto> request) {
        Response<DemandeDto> response = new Response<DemandeDto>();
        String languageID = (String) requestBasic.getAttribute("CURRENT_LANGUAGE_IDENTIFIER");
        log.info("la langue " + languageID);
        Locale locale = new Locale(languageID, "");
        try {
            response = demandeBusiness.requestValidatedList(request, locale);
            if (response.isHasError()) {
                log.info(String.format("Erreur| code: {} -  message: {}", response.getStatus().getCode(), response.getStatus().getMessage()));
                return response;
            }
            log.info(String.format("code: {} -  message: {}", StatusCode.SUCCESS, StatusMessage.SUCCESS));
        } catch (CannotCreateTransactionException e) {
            exceptionUtils.CANNOT_CREATE_TRANSACTION_EXCEPTION(response, locale, e);
        } catch (TransactionSystemException e) {
            exceptionUtils.TRANSACTION_SYSTEM_EXCEPTION(response, locale, e);
        } catch (RuntimeException e) {
            exceptionUtils.RUNTIME_EXCEPTION(response, locale, e);
        } catch (Exception e) {
            exceptionUtils.EXCEPTION(response, locale, e);
        }
        return response;
    }


    @RequestMapping(value = "/allDemandeEnAttenteDeValidation", method = RequestMethod.POST, consumes = {"application/json"}, produces = {"application/json"})
    public Response<DemandeDto> allDemandeEnAttenteDeValidation(@RequestBody Request<DemandeDto> request) {
        Response<DemandeDto> response = new Response<DemandeDto>();
        String languageID = (String) requestBasic.getAttribute("CURRENT_LANGUAGE_IDENTIFIER");
        log.info("la langue " + languageID);
        Locale locale = new Locale(languageID, "");
        try {
            response = demandeBusiness.requestWaitingValidationList(request, locale);
            if (response.isHasError()) {
                log.info(String.format("Erreur| code: {} -  message: {}", response.getStatus().getCode(), response.getStatus().getMessage()));
                return response;
            }
            log.info(String.format("code: {} -  message: {}", StatusCode.SUCCESS, StatusMessage.SUCCESS));
        } catch (CannotCreateTransactionException e) {
            exceptionUtils.CANNOT_CREATE_TRANSACTION_EXCEPTION(response, locale, e);
        } catch (TransactionSystemException e) {
            exceptionUtils.TRANSACTION_SYSTEM_EXCEPTION(response, locale, e);
        } catch (RuntimeException e) {
            exceptionUtils.RUNTIME_EXCEPTION(response, locale, e);
        } catch (Exception e) {
            exceptionUtils.EXCEPTION(response, locale, e);
        }
        return response;
    }


    @RequestMapping(value = "/toForceDemandeToValidate", method = RequestMethod.PUT, consumes = {"application/json"}, produces = {"application/json"})
    public Response<DemandeDto> toForceDemandeToValidate(@RequestBody Request<DemandeDto> request) {
        Response<DemandeDto> response = new Response<DemandeDto>();
        String languageID = (String) requestBasic.getAttribute("CURRENT_LANGUAGE_IDENTIFIER");
        log.info("la langue " + languageID);
        Locale locale = new Locale(languageID, "");
        try {
            response = demandeBusiness.forceRequestValidation(request, locale);
            if (response.isHasError()) {
                log.info(String.format("Erreur| code: {} -  message: {}", response.getStatus().getCode(), response.getStatus().getMessage()));
                return response;
            }
            log.info(String.format("code: {} -  message: {}", StatusCode.SUCCESS, StatusMessage.SUCCESS));
        } catch (CannotCreateTransactionException e) {
            exceptionUtils.CANNOT_CREATE_TRANSACTION_EXCEPTION(response, locale, e);
        } catch (TransactionSystemException e) {
            exceptionUtils.TRANSACTION_SYSTEM_EXCEPTION(response, locale, e);
        } catch (RuntimeException e) {
            exceptionUtils.RUNTIME_EXCEPTION(response, locale, e);
        } catch (Exception e) {
            exceptionUtils.EXCEPTION(response, locale, e);
        }
        return response;
    }


    @RequestMapping(value = "/generateApBatchFile", method = RequestMethod.POST, consumes = {"application/json"}, produces = {"application/json"})
    public Response<DemandeDto> generate(@RequestBody Request<DemandeDto> request) {
        Response<DemandeDto> response = new Response<DemandeDto>();
        String languageID = (String) requestBasic.getAttribute("CURRENT_LANGUAGE_IDENTIFIER");
        Locale locale = new Locale(languageID, "");
        try {
            response = demandeBusiness.generateApBatchFile(request, locale);
            if (response.isHasError()) {
                log.info(String.format("Erreur| code: {} -  message: {}", response.getStatus().getCode(), response.getStatus().getMessage()));
                return response;
            }
            log.info(String.format("code: {} -  message: {}", StatusCode.SUCCESS, StatusMessage.SUCCESS));
        } catch (CannotCreateTransactionException e) {
            exceptionUtils.CANNOT_CREATE_TRANSACTION_EXCEPTION(response, locale, e);
        } catch (TransactionSystemException e) {
            exceptionUtils.TRANSACTION_SYSTEM_EXCEPTION(response, locale, e);
        } catch (RuntimeException e) {
            exceptionUtils.RUNTIME_EXCEPTION(response, locale, e);
        } catch (Exception e) {
            exceptionUtils.EXCEPTION(response, locale, e);
        }
        return response;
    }

    @RequestMapping(value = "/listApFile", method = RequestMethod.POST, consumes = {"application/json"}, produces = {"application/json"})
    public Response<ApFileDto> generateApBatchFile(@RequestBody Request<ApFileDto> request) {
        Response<ApFileDto> response = new Response<ApFileDto>();
        String languageID = (String) requestBasic.getAttribute("CURRENT_LANGUAGE_IDENTIFIER");
        Locale locale = new Locale(languageID, "");
        try {
            response = demandeBusiness.getApFile(request, locale);
            if (response.isHasError()) {
                log.info(String.format("Erreur| code: {} -  message: {}", response.getStatus().getCode(), response.getStatus().getMessage()));
                return response;
            }
            log.info(String.format("code: {} -  message: {}", StatusCode.SUCCESS, StatusMessage.SUCCESS));
        } catch (CannotCreateTransactionException e) {
            exceptionUtils.CANNOT_CREATE_TRANSACTION_EXCEPTION(response, locale, e);
        } catch (TransactionSystemException e) {
            exceptionUtils.TRANSACTION_SYSTEM_EXCEPTION(response, locale, e);
        } catch (RuntimeException e) {
            exceptionUtils.RUNTIME_EXCEPTION(response, locale, e);
        } catch (Exception e) {
            exceptionUtils.EXCEPTION(response, locale, e);
        }
        return response;
    }


    @RequestMapping(value = "/getApFile", method = RequestMethod.POST, consumes = {"application/json"}, produces = {"application/json"})
    public Response<ApFileDto> getApFile(@RequestBody Request<ApFileDto> request) {
        Response<ApFileDto> response = new Response<ApFileDto>();
        String languageID = (String) requestBasic.getAttribute("CURRENT_LANGUAGE_IDENTIFIER");
        Locale locale = new Locale(languageID, "");
        try {
            response = apFileBusiness.getByCriteria(request, locale);
            if (response.isHasError()) {
                log.info(String.format("Erreur| code: {} -  message: {}", response.getStatus().getCode(), response.getStatus().getMessage()));
                return response;
            }
            log.info(String.format("code: {} -  message: {}", StatusCode.SUCCESS, StatusMessage.SUCCESS));
        } catch (CannotCreateTransactionException e) {
            exceptionUtils.CANNOT_CREATE_TRANSACTION_EXCEPTION(response, locale, e);
        } catch (TransactionSystemException e) {
            exceptionUtils.TRANSACTION_SYSTEM_EXCEPTION(response, locale, e);
        } catch (RuntimeException e) {
            exceptionUtils.RUNTIME_EXCEPTION(response, locale, e);
        } catch (Exception e) {
            exceptionUtils.EXCEPTION(response, locale, e);
        }
        return response;
    }

    @RequestMapping(value = "/validateApBatch", method = RequestMethod.POST, consumes = {"application/json"}, produces = {"application/json"})
    public Response<ApFileDto> validateApBatch(@RequestBody Request<ApFileDto> request) {
        Response<ApFileDto> response = new Response<ApFileDto>();
        String languageID = (String) requestBasic.getAttribute("CURRENT_LANGUAGE_IDENTIFIER");
        Locale locale = new Locale(languageID, "");
        try {
            response = demandeBusiness.validateApBatch(request, locale);
            if (response.isHasError()) {
                log.info(String.format("Erreur| code: {} -  message: {}", response.getStatus().getCode(), response.getStatus().getMessage()));
                return response;
            }
            log.info(String.format("code: {} -  message: {}", StatusCode.SUCCESS, StatusMessage.SUCCESS));
        } catch (CannotCreateTransactionException e) {
            exceptionUtils.CANNOT_CREATE_TRANSACTION_EXCEPTION(response, locale, e);
        } catch (TransactionSystemException e) {
            exceptionUtils.TRANSACTION_SYSTEM_EXCEPTION(response, locale, e);
        } catch (RuntimeException e) {
            exceptionUtils.RUNTIME_EXCEPTION(response, locale, e);
        } catch (Exception e) {
            exceptionUtils.EXCEPTION(response, locale, e);
        }
        return response;
    }

}
