package ci.sgabs.gs.souscriptionApp.business;

import ci.sgabs.gs.souscriptionApp.dao.entity.TypeCarte;
import ci.sgabs.gs.souscriptionApp.dao.entity.TypeCompteTypeCarte;
import ci.sgabs.gs.souscriptionApp.dao.repository.TypeCarteRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.TypeCompteTypeCarteRepository;
import ci.sgabs.gs.souscriptionApp.helper.contrat.IBasicBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.enums.TypeEnum;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.errors.TechnicalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.helper.validation.Validate;
import ci.sgabs.gs.souscriptionApp.utils.authentification.SecurityConstants;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.*;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.TypeCarteTransformer;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.TypeCompteTypeCarteTransformer;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Log
@Component
public class TypeCarteBusiness implements IBasicBusiness<Request<TypeCarteDto>, Response<TypeCarteDto>> {

    private Response<TypeCarteDto> response;
    @Autowired
    private TypeCarteRepository typeCarteRepository;
    @Autowired
    private UsersBusiness usersBusiness;
    @Autowired
    private TypeCompteTypeCarteRepository typeCompteTypeCarteRepository;
    @Autowired
    private TypeCompteTypeCarteBusiness typeCompteTypeCarteBusiness;
    @Autowired
    private FunctionalError functionalError;
    @Autowired
    private TechnicalError technicalError;
    @Autowired
    private ExceptionUtils exceptionUtils;
    @Autowired
    private EntityManager em;
    private final SimpleDateFormat dateFormat;
    private final SimpleDateFormat dateTimeFormat;

    public TypeCarteBusiness() {
        dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    }

    @Override
    public Response<TypeCarteDto> create(Request<TypeCarteDto> request, Locale locale) throws Exception {
        log.info("----begin create TypeCarte-----");
        Response<TypeCarteDto> response = new Response<TypeCarteDto>();
        List<TypeCarte> items = new ArrayList<TypeCarte>();
        if(request.getDatas() == null || request.getDatas().isEmpty()){
            response.setStatus(functionalError.DATA_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_CARD_TYPE_CREATE);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas créer un type de carte.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        //Verification des champs obligatoires
        List<TypeCarteDto> itemsDtos = Collections.synchronizedList(new ArrayList<TypeCarteDto>());
        for(TypeCarteDto dto: request.getDatas()){
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("code", dto.getCode());
            fieldsToVerify.put("typeGen", dto.getTypeGen());
            fieldsToVerify.put("codeProduit", dto.getCodeProduit());
            fieldsToVerify.put("identifiantProduit", dto.getIdentifiantProduit());
            fieldsToVerify.put("identifiantGroupe", dto.getIdentifiantGroupe());
            fieldsToVerify.put("codeTarif", dto.getCodeTarif());
            fieldsToVerify.put("accCountry", dto.getAccCountry());
            fieldsToVerify.put("bin", dto.getBin());
            fieldsToVerify.put("typeCarte", dto.getTypeCarte());
            fieldsToVerify.put("produit", dto.getProduit());
            fieldsToVerify.put("codeBanque", dto.getCodeBanque());
            fieldsToVerify.put("identifiantInstitution", dto.getIdentifiantInstitution());
            fieldsToVerify.put("business", dto.getBusiness());
            fieldsToVerify.put("devise", dto.getDevise());
            fieldsToVerify.put("pays", dto.getPays());
            fieldsToVerify.put("type", dto.getType());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            if(itemsDtos.stream().anyMatch(a->a.getCode().equalsIgnoreCase(dto.getCode()))){
                response.setStatus(functionalError.DATA_DUPLICATE("Duplication de code", locale));
                response.setHasError(true);
                return response;
            }
            itemsDtos.add(dto);
        }
        //Verification
        for(TypeCarteDto dto : request.getDatas()){
            if(!TypeEnum.isValidTag(dto.getType())){
                response.setStatus(functionalError.DATA_NOT_EXIST("Les valeurs possible du champ type sont : PUCE ou PISTE -> " + dto.getCode(), locale));
                response.setHasError(true);
                return response;
            }
            //Transformation
            TypeCarte entityToSave = TypeCarteTransformer.INSTANCE.toEntity(dto);
            entityToSave.setIsDeleted(false);
            entityToSave.setCreatedAt(Utilities.getCurrentDate());
            entityToSave.setCreatedBy(request.userID);
            TypeCarte entitySaved = typeCarteRepository.save(entityToSave);
            items.add(entitySaved);
        }
        if(items == null || items.isEmpty()){
            response.setStatus(functionalError.DATA_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }
        //TRansformation
        List<TypeCarteDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                                    ? TypeCarteTransformer.INSTANCE.toLiteDtos(items)
                                    : TypeCarteTransformer.INSTANCE.toDtos(items);
        //Envoie de la reponse
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end create TypeCarte-----");
        return response;
    }

    @Override
    public Response<TypeCarteDto> update(Request<TypeCarteDto> request, Locale locale) throws ParseException {

        log.info("----begin update TypeCarte-----");
        Response<TypeCarteDto> response = new Response<TypeCarteDto>();
        List<TypeCarte> items = new ArrayList<TypeCarte>();
        if(request.getDatas() == null || request.getDatas().isEmpty()){
            response.setStatus(functionalError.DATA_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_CARD_TYPE_UPDATE);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas modifier un type de carte.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        //Verification des champs obligatoires
        List<TypeCarteDto> itemsDtos = Collections.synchronizedList(new ArrayList<TypeCarteDto>());
        for(TypeCarteDto dto: request.getDatas()){
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            if(itemsDtos.stream().anyMatch(a->a.getId().equals(dto.getId()))){
                response.setStatus(functionalError.DATA_DUPLICATE("Duplication de l'id", locale));
                response.setHasError(true);
                return response;
            }
            itemsDtos.add(dto);
        }
        //Verification
        for(TypeCarteDto dto : request.getDatas()){
            //Verification de doublon
            TypeCarte entityToSave = null;
            entityToSave = typeCarteRepository.findOne(dto.getId(), false);
            if (entityToSave == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("TypeCarte id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }
            //Verification du code , s'il existe
            if (Utilities.isNotBlank(dto.getCode()) && !dto.getCode().equals(entityToSave.getCode())) { //verify code
                entityToSave.setCode(dto.getCode());
            }
            if (Utilities.isNotBlank(dto.getLibelle()) && !dto.getLibelle().equals(entityToSave.getLibelle())) {
                entityToSave.setLibelle(dto.getLibelle());
            }
            if (Utilities.isNotBlank(dto.getDescription()) && !dto.getDescription().equals(entityToSave.getDescription())) {
                entityToSave.setDescription(dto.getDescription());
            }
            if(Utilities.isNotBlank(dto.getType())){
                if(!TypeEnum.isValidTag(dto.getType())){
                    response.setStatus(functionalError.DATA_NOT_EXIST("Les valeurs possible du champ type sont : PUCE ou PISTE -> " + dto.getCode(), locale));
                    response.setHasError(true);
                    return response;
                }
            }
            if(Utilities.isNotBlank(dto.getTypeGen())){
                  entityToSave.setTypeGen(dto.getTypeGen());
            }
            if(Utilities.isNotBlank(dto.getTypeCarte())){
                       entityToSave.setTypeCarte(dto.getTypeCarte());
            }
            if(Utilities.isNotBlank(dto.getProduit())){
                  entityToSave.setProduit(dto.getProduit());
            }
            if(Utilities.isNotBlank(dto.getCodeBanque())){
                  entityToSave.setCodeBanque(dto.getCodeBanque());
            }
            if(Utilities.isNotBlank(dto.getIdentifiantProduit())){
                 entityToSave.setIdentifiantProduit(dto.getIdentifiantProduit());
            }
            if(Utilities.isNotBlank(dto.getIdentifiantGroupe())){
                      entityToSave.setIdentifiantGroupe(dto.getIdentifiantGroupe());
            }
            if(Utilities.isNotBlank(dto.getIdentifiantInstitution())){
                     entityToSave.setIdentifiantInstitution(dto.getIdentifiantInstitution());
            }
            if(Utilities.isNotBlank(dto.getBusiness())){
                  entityToSave.setBusiness(dto.getBusiness());
            }
            if(Utilities.isNotBlank(dto.getCodeProduit())){
                    entityToSave.setCodeProduit(dto.getProduit());
            }
            if(Utilities.isNotBlank(dto.getCodeTarif())){
                 entityToSave.setCodeTarif(dto.getCodeTarif());
            }
            entityToSave.setUpdatedAt(Utilities.getCurrentDate());
            entityToSave.setUpdatedBy(request.userID);
            items.add(entityToSave);
        }
        //Verification
        if(items ==  null || items.isEmpty()){
            response.setStatus(functionalError.DATA_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }
        //Transformation
        List<TypeCarteDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                                    ? TypeCarteTransformer.INSTANCE.toLiteDtos(items)
                                    : TypeCarteTransformer.INSTANCE.toDtos(items);
        //Envoie de la reponse
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end update TypeCarte-----");
        return response;
    }

    @Override
    public Response<TypeCarteDto> delete(Request<TypeCarteDto> request, Locale locale) {

        log.info("----begin delete TypeCarte-----");
        Response<TypeCarteDto> response = new Response<TypeCarteDto>();
        List<TypeCarte> items = new ArrayList<TypeCarte>();
        if(request.getDatas() == null || request.getDatas().isEmpty()){
            response.setStatus(functionalError.DATA_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_CARD_TYPE_DELETE);
            if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas supprimer un type de carte.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        //Verification du champ obligatoire
        List<TypeCarteDto> itemsDtos = Collections.synchronizedList(new ArrayList<TypeCarteDto>()) ;
        for(TypeCarteDto dto: request.getDatas()){
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            if(itemsDtos.stream().anyMatch(a->a.getId().equals(dto.getId()))){
                response.setStatus(functionalError.DATA_DUPLICATE("Duplication de l'identifiant", locale));
                response.setHasError(true);
                return response;
            }
            itemsDtos.add(dto);
        }
        //Verification
        for(TypeCarteDto dto : request.getDatas()){
            TypeCarte existingEntity = null;
            existingEntity = typeCarteRepository.findOne(dto.getId(), false);
            if (existingEntity == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("TypeCarte id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }
            existingEntity.setIsDeleted(true);
            existingEntity.setDeletedAt(Utilities.getCurrentDate());
            existingEntity.setDeletedBy(request.userID);
            items.add(existingEntity);
        }
        if(items == null || items.isEmpty()){
            response.setStatus(functionalError.DATA_EMPTY("Liste vide ", locale));
            response.setHasError(true);
            return response;
        }
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end delete User-----");
        return response;
    }

    @Override
    public Response<TypeCarteDto> forceDelete(Request<TypeCarteDto> request, Locale locale) throws ParseException {

        log.info("----begin Forcedelete TypeCarte-----");
        Response<TypeCarteDto> response = new Response<TypeCarteDto>();
        List<TypeCarte> items = new ArrayList<TypeCarte>();
        if(request.getDatas() == null || request.getDatas().isEmpty()){
            response.setStatus(functionalError.DATA_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_CARD_TYPE_DELETE);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas supprimer un type de carte.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        //Verification du champ obligatoire
        List<TypeCarteDto> itemsDtos = Collections.synchronizedList(new ArrayList<TypeCarteDto>()) ;
        for(TypeCarteDto dto: request.getDatas()){
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            if(itemsDtos.stream().anyMatch(a->a.getId().equals(dto.getId()))){
                response.setStatus(functionalError.DATA_DUPLICATE("Duplication de l'identifiant", locale));
                response.setHasError(true);
                return response;
            }
            itemsDtos.add(dto);
        }
        for(TypeCarteDto dto : request.getDatas()){
            TypeCarte existingEntity = null;
            existingEntity = typeCarteRepository.findOne(dto.getId(), false);
            if (existingEntity == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("TypeCarte id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }
            List<TypeCompteTypeCarte> listOfTypeCompteTypeCarte = typeCompteTypeCarteRepository.findByTypeCarteId(existingEntity.getId(), false);
            if (listOfTypeCompteTypeCarte != null && !listOfTypeCompteTypeCarte.isEmpty()) {
                Request<TypeCompteTypeCarteDto> deleteRequest = new Request<TypeCompteTypeCarteDto>();
                deleteRequest.setDatas(TypeCompteTypeCarteTransformer.INSTANCE.toDtos(listOfTypeCompteTypeCarte));
                Response<TypeCompteTypeCarteDto> deleteResponse = typeCompteTypeCarteBusiness.delete(deleteRequest, locale);
                if (deleteResponse.isHasError()) {
                    response.setStatus(deleteResponse.getStatus());
                    response.setHasError(true);
                    return response;
                }
            }
            existingEntity.setIsDeleted(true);
            existingEntity.setDeletedAt(Utilities.getCurrentDate());
            existingEntity.setDeletedBy(request.userID);
            items.add(existingEntity);
        }
        if(items == null || items.isEmpty()){
            response.setStatus(functionalError.DATA_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end Forcedelete TypeCarte-----");
        return response;
    }

    @Override
    public Response<TypeCarteDto> getByCriteria(Request<TypeCarteDto> request, Locale locale) throws Exception {
        log.info("----begin getByCriteria TypeCarte-----");

        Response<TypeCarteDto> response = new Response<TypeCarteDto>();
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_CARD_TYPE_LIST);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas lister les types de carte.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        if (Utilities.blank(request.getData().getOrderField())) {
            request.getData().setOrderField("");
        }
        if (Utilities.blank(request.getData().getOrderDirection())) {
            request.getData().setOrderDirection("asc");
        }
        List<TypeCarte> items = typeCarteRepository.getByCriteria(request, em, locale);
        if (Utilities.isEmpty(items)) {
            response.setStatus(functionalError.DATA_EMPTY("TypeCarte", locale));
            response.setHasError(false);
            return response;
        }
        //Transformation
        List<TypeCarteDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                                ? TypeCarteTransformer.INSTANCE.toLiteDtos(items)
                                : TypeCarteTransformer.INSTANCE.toDtos(items);
        //Envoie la reponse
        response.setItems(itemsDto);
        response.setCount(typeCarteRepository.count(request, em, locale));
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        log.info("----end getByCriteria TypeCarte-----");
        return response;
    }
}
