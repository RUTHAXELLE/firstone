package ci.sgabs.gs.souscriptionApp.business;

import ci.sgabs.gs.souscriptionApp.dao.entity.Demande;
import ci.sgabs.gs.souscriptionApp.dao.entity.HistoriqueDemande;
import ci.sgabs.gs.souscriptionApp.dao.entity.Status;
import ci.sgabs.gs.souscriptionApp.dao.repository.DemandeRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.HistoriqueDemandeRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.StatusRepository;
import ci.sgabs.gs.souscriptionApp.helper.contrat.IBasicBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.errors.TechnicalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.helper.validation.Validate;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.HistoriqueDemandeDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.HistoriqueDemandeTransformer;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Log
@Component
public class HistoriqueDemandeBusiness implements IBasicBusiness<Request<HistoriqueDemandeDto>, Response<HistoriqueDemandeDto>> {

    private Response<HistoriqueDemandeDto> response;
    @Autowired
    private HistoriqueDemandeRepository historiqueDemandeRepository;

    @Autowired
    private DemandeRepository demandeRepository;

    @Autowired
    private StatusRepository statusRepository;

    @Autowired
    private FunctionalError functionalError;

    @Autowired
    private TechnicalError technicalError;

    @Autowired
    private ExceptionUtils exceptionUtils;

    @Autowired
    private EntityManager em;

    private final SimpleDateFormat dateFormat;
    private final SimpleDateFormat dateTimeFormat;

    public HistoriqueDemandeBusiness() {
        dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    }
    
    @Override
    public Response<HistoriqueDemandeDto> create(Request<HistoriqueDemandeDto> request, Locale locale) throws ParseException {

        log.info("----begin create HistoriqueDemande-----");

        Response<HistoriqueDemandeDto> response = new Response<HistoriqueDemandeDto>();
        List<HistoriqueDemande> items = new ArrayList<HistoriqueDemande>();

        //Verificatioon de la liste de données recues
        if(request.getDatas().isEmpty() || request.getDatas() == null){
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ",locale));
            response.setHasError(true);
            return response;
        }

        //Verification des parametres obligatoires & des duplications de donn�es
        List<HistoriqueDemandeDto> itemsDtos =  Collections.synchronizedList(new ArrayList<HistoriqueDemandeDto>());
        for(HistoriqueDemandeDto dto: request.getDatas() ) {

            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            //fieldsToVerify.put("code", dto.getCode());
            //fieldsToVerify.put("libelle", dto.getLibelle());
            fieldsToVerify.put("demandeId", dto.getDemandeId());
            fieldsToVerify.put("statusId", dto.getStatusId());

            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            /*if(itemsDtos.stream().anyMatch(a->a.getCode().equalsIgnoreCase(dto.getCode()))){
                response.setStatus(functionalError.DATA_DUPLICATE("Tentative de duplication du code '" + dto.getCode() + "' pour les agences", locale));
                response.setHasError(true);
                return response;
            }*/

            itemsDtos.add(dto);

        }

        //Verification
        for(HistoriqueDemandeDto dto : request.getDatas()){

            //Verification de doublon
            HistoriqueDemande existingEntity = null;
            existingEntity = historiqueDemandeRepository.findByCode(dto.getCode(), false);

            if (existingEntity != null) {
                response.setStatus(functionalError.DATA_EXIST("HistoriqueDemande code -> " + dto.getCode(), locale));
                response.setHasError(true);
                return response;
            }

            //Verification de la demande attachée
            Demande existingDemande = null;
            if (Utilities.isValidID(dto.getDemandeId())) {

                existingDemande = demandeRepository.findOne(dto.getDemandeId(), false);

                if (existingDemande == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("Demande DemandeID -> " + dto.getDemandeId(), locale));
                    response.setHasError(true);
                    return response;
                }

            }

            //Verification du status attaché
            Status existingStatus = null;

            if (Utilities.isValidID(dto.getStatusId())) {
                existingStatus = statusRepository.findOne(dto.getStatusId(), false);
                if (existingStatus == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("Status StatusID -> " + dto.getStatusId(), locale));
                    response.setHasError(true);
                    return response;
                }

            }

            //Transformation
            HistoriqueDemande entityToSave = HistoriqueDemandeTransformer
                        .INSTANCE.toEntity(dto, existingDemande, existingStatus);

            entityToSave.setIsDeleted(false);
            entityToSave.setCreatedAt(Utilities.getCurrentDate());
            entityToSave.setCreatedBy(request.userID);

            items.add(entityToSave);

        }


        if(items == null ||items.isEmpty()){
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ",locale));
            response.setHasError(true);
            return response;
        }

        //Persistence
        List<HistoriqueDemande> itemsSaved = null;
        itemsSaved = historiqueDemandeRepository.saveAll((Iterable<HistoriqueDemande>) items);

        if (itemsSaved == null) {
            response.setStatus(functionalError.SAVE_FAIL("HistoriqueDemande", locale));
            response.setHasError(true);
            return response;
        }

        //Transformation
        List<HistoriqueDemandeDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                                ? HistoriqueDemandeTransformer.INSTANCE.toLiteDtos(itemsSaved)
                                : HistoriqueDemandeTransformer.INSTANCE.toDtos(itemsSaved);

        //Envoie de la reponse
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        log.info("----end create HistoriqueDemande-----");
        return response;

    }

    @Override
    public Response<HistoriqueDemandeDto> update(Request<HistoriqueDemandeDto> request, Locale locale) throws ParseException {

        log.info("----begin update HistoriqueDemande -----");

        Response<HistoriqueDemandeDto> response = new Response<HistoriqueDemandeDto>();
        List<HistoriqueDemande> items = new ArrayList<HistoriqueDemande>();

        //Verificatioon de la liste de données recues
        if(request.getDatas() == null  || request.getDatas().isEmpty()){
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ",locale));
            response.setHasError(true);
            return response;
        }

        //Verification des parametres obligatoires
        for(HistoriqueDemandeDto dto: request.getDatas() ) {

            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());

            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }

        }

        //Verification
        for(HistoriqueDemandeDto dto : request.getDatas()){

            HistoriqueDemande entityToSave = null;
            entityToSave = historiqueDemandeRepository.findOne(dto.getId(), false);

            if (entityToSave == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("HistoriqueDemande id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }

            //Verification de la demande attachée
            Demande existingDemande = null;

            if (Utilities.isValidID(dto.getDemandeId()) && !entityToSave.getDemande().getId().equals(dto.getDemandeId())) {

                existingDemande = demandeRepository.findOne(dto.getDemandeId(), false);
                if (existingDemande == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("Demande DemandeId -> " + dto.getDemandeId(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setDemande(existingDemande);
            }

            //Verification du status attaché
            Status existingStatus = null;

            if (Utilities.isValidID(dto.getStatusId()) && !entityToSave.getStatus().getId().equals(dto.getStatusId())) {

                existingStatus = statusRepository.findOne(dto.getStatusId(), false);

                if (existingStatus == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("Status StatusId -> " + dto.getStatusId(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setStatus(existingStatus);
            }

            //Verification du code
            if (Utilities.isNotBlank(dto.getCode()) && !dto.getCode().equals(entityToSave.getCode())) { //verify code

                HistoriqueDemande existingEntity = historiqueDemandeRepository.findByCode(dto.getCode(), false);

                if (existingEntity != null && !existingEntity.getId().equals(entityToSave.getId())) {
                    response.setStatus(functionalError.DATA_EXIST("HistoriqueDemande -> " + dto.getCode(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setCode(dto.getCode());
            }
            if (Utilities.isNotBlank(dto.getLibelle()) && !dto.getLibelle().equals(entityToSave.getLibelle())) {
                entityToSave.setLibelle(dto.getLibelle());
            }

            entityToSave.setUpdatedAt(Utilities.getCurrentDate());
            entityToSave.setUpdatedBy(request.userID);
            items.add(entityToSave);
        }

        if (items == null || items.isEmpty()) {
            response.setHasError(false);
            response.setStatus(functionalError.SUCCESS("", locale));
        }

        //Persistence
        List<HistoriqueDemande> itemsSaved = null;
        itemsSaved = historiqueDemandeRepository.saveAll((Iterable<HistoriqueDemande>) items);

        if (itemsSaved == null) {
                response.setStatus(functionalError.SAVE_FAIL("HistoriqueDemande", locale));
                response.setHasError(true);
                return response;
        }

        //Transformation
        List<HistoriqueDemandeDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                                    ? HistoriqueDemandeTransformer.INSTANCE.toLiteDtos(itemsSaved)
                                    : HistoriqueDemandeTransformer.INSTANCE.toDtos(itemsSaved);

        //Envoie de la reponse
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("end HistoriqueDemande update");
        return response;
    }

    @Override
    public Response<HistoriqueDemandeDto> delete(Request<HistoriqueDemandeDto> request, Locale locale) {

        log.info("----begin delete HistoriqueDemande-----");

        Response<HistoriqueDemandeDto> response = new Response<HistoriqueDemandeDto>();
        List<HistoriqueDemande> items = new ArrayList<HistoriqueDemande>();

        //Verificatioon de la liste de données recues
        if(request.getDatas() == null  || request.getDatas().isEmpty()){
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ",locale));
            response.setHasError(true);
            return response;
        }

        //Verification des parametres obligatoires
        for(HistoriqueDemandeDto dto: request.getDatas() ) {

            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());

            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
        }

        //Verification
        for(HistoriqueDemandeDto dto : request.getDatas()){

            //Verification de doublon
            HistoriqueDemande existingEntity = null;
            existingEntity = historiqueDemandeRepository.findOne(dto.getId(), false);

            if (existingEntity == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("HistoriqueDemande id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }

            existingEntity.setIsDeleted(true);
            existingEntity.setDeletedAt(Utilities.getCurrentDate());
            existingEntity.setDeletedBy(request.userID);
            items.add(existingEntity);
        }

        if (items == null || items.isEmpty()) {
            response.setHasError(false);
            response.setStatus(functionalError.SUCCESS("", locale));
        }

        //Envoie de la reponse
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        return response;

    }

    @Override
    public Response<HistoriqueDemandeDto> forceDelete(Request<HistoriqueDemandeDto> request, Locale locale) throws ParseException {
        return null;
    }

    @Override
    public Response<HistoriqueDemandeDto> getByCriteria(Request<HistoriqueDemandeDto> request, Locale locale) throws Exception {

        log.info("----begin get HistoriqueDemande-----");

        Response<HistoriqueDemandeDto> response = new Response<HistoriqueDemandeDto>();

        //verification si le parametre d'ordre à été fourni, sinon nous mettons le paramètre à vide
        if (Utilities.blank(request.getData().getOrderField())) {
            request.getData().setOrderField("");
        }

        //verification si le parametre direction à été fourni, sinon nous mettons le paramètre ascendant( du plus ancien au plus ressent)
        if (Utilities.blank(request.getData().getOrderDirection())) {
            request.getData().setOrderDirection("asc");
        }

        //recuperation des entités en base
        List<HistoriqueDemande> items = historiqueDemandeRepository.getByCriteria(request, em, locale);

        if (Utilities.isEmpty(items)) {
            response.setStatus(functionalError.DATA_EMPTY("HistoriqueDemande", locale));
            response.setHasError(false);
            return response;
        }

        //Transformation
        List<HistoriqueDemandeDto> itemsDto = HistoriqueDemandeTransformer.INSTANCE.toDtos(items);

        //Envoie de la reponse
        response.setItems(itemsDto);
        response.setCount(historiqueDemandeRepository.count(request, em, locale));
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        log.info("----end get HistoriqueDemande-----");

        return response;

    }
}
