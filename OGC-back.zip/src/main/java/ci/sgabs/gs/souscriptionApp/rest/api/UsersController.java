package ci.sgabs.gs.souscriptionApp.rest.api;

import ci.sgabs.gs.souscriptionApp.business.UsersBusiness;
import ci.sgabs.gs.souscriptionApp.business.fact.UsersBusinessFactory;
import ci.sgabs.gs.souscriptionApp.dao.entity.Users;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.enums.FunctionalityEnum;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.status.StatusCode;
import ci.sgabs.gs.souscriptionApp.helper.status.StatusMessage;
import ci.sgabs.gs.souscriptionApp.rest.fact.ControllerFactory;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.DemandeDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.UserPasswordDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.UsersDto;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.CannotCreateTransactionException;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Locale;


@Log
@CrossOrigin("*")
@RestController
@RequestMapping(value="/users")
public class UsersController {

    @Autowired
    private ControllerFactory<UsersDto> controllerFactory;
    @Autowired
    private UsersBusiness usersBusiness;
    @Autowired
    private FunctionalError functionalError;
    @Autowired
    private ExceptionUtils exceptionUtils;
    @Autowired
    private HttpServletRequest requestBasic;
    @Autowired
    private ci.sgabs.gs.souscriptionApp.business.UsersBusiness UsersBusiness;

    @RequestMapping(value="",method= RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<UsersDto> create(@RequestBody Request<UsersDto> request) {
        log.info("start method /Users/create");
        Response<UsersDto> response = controllerFactory.create(UsersBusiness, request, FunctionalityEnum.CREATE_USER);
        log.info("end method /Users/create");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.PUT,consumes = {"application/json"},produces={"application/json"})
    public Response<UsersDto> update(@RequestBody Request<UsersDto> request) {
        log.info("start method /Users/update");
        Response<UsersDto> response = controllerFactory.update(UsersBusiness, request, FunctionalityEnum.UPDATE_USER);
        log.info("end method /Users/update");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.DELETE,consumes = {"application/json"},produces={"application/json"})
    public Response<UsersDto> delete(@RequestBody Request<UsersDto> request) {
        log.info("start method /Users/delete");
        Response<UsersDto> response = controllerFactory.delete(UsersBusiness, request, FunctionalityEnum.DELETE_USER);
        log.info("end method /Users/delete");
        return response;
    }

    @RequestMapping(value="/getByCriteria",method=RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<UsersDto> getByCriteria(@RequestBody Request<UsersDto> request) {
        log.info("start method /Users/getByCriteria");
        Response<UsersDto> response = controllerFactory.getByCriteria(UsersBusiness, request, FunctionalityEnum.VIEW_USER);
        log.info("end method /Users/getByCriteria");
        return response;
    }

    @RequestMapping(value="/login",method=RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<UsersDto> login(@RequestBody Request<UsersDto> request) {
        log.info("start method /login");
        Response<UsersDto> response = controllerFactory.login(UsersBusiness, request, FunctionalityEnum.VIEW_USER);
        log.info("end method /login");
        return response;
    }

    @RequestMapping(value = "/resetPassWordUser", method = RequestMethod.POST, consumes = {"application/json"}, produces = {"application/json"})
    public Response<UsersDto> resetPassWordUser(@RequestBody Request<UserPasswordDto> request) {
        Response<UsersDto> response = new Response<UsersDto>();
        String languageID = (String) requestBasic.getAttribute("CURRENT_LANGUAGE_IDENTIFIER");
        log.info("la langue " + languageID);
        Locale locale = new Locale(languageID, "");
        try {
            response = usersBusiness.resetPassWordUser(request, locale);
            if (response.isHasError()) {
                log.info(String.format("Erreur| code: {} -  message: {}", response.getStatus().getCode(), response.getStatus().getMessage()));
                return response;
            }
            log.info(String.format("code: {} -  message: {}", StatusCode.SUCCESS, StatusMessage.SUCCESS));
        } catch (CannotCreateTransactionException e) {
            exceptionUtils.CANNOT_CREATE_TRANSACTION_EXCEPTION(response, locale, e);
        } catch (TransactionSystemException e) {
            exceptionUtils.TRANSACTION_SYSTEM_EXCEPTION(response, locale, e);
        } catch (RuntimeException e) {
            exceptionUtils.RUNTIME_EXCEPTION(response, locale, e);
        } catch (Exception e) {
            exceptionUtils.EXCEPTION(response, locale, e);
        }
        return response;
    }


}
