package ci.sgabs.gs.souscriptionApp.rest.api;

import ci.sgabs.gs.souscriptionApp.business.AttributionBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.enums.FunctionalityEnum;
import ci.sgabs.gs.souscriptionApp.rest.fact.ControllerFactory;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.AttributionDto;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Log
@CrossOrigin("*")
@RestController
@RequestMapping(value="/attributions")
public class AttributionController {

    @Autowired
    private ControllerFactory<AttributionDto> controllerFactory;
    @Autowired
    private AttributionBusiness attributionBusiness;

    @RequestMapping(value="",method= RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<AttributionDto> create(@RequestBody Request<AttributionDto> request) {
        log.info("start method /Attribution/create");
        Response<AttributionDto> response = controllerFactory.create(attributionBusiness, request, FunctionalityEnum.CREATE_ATTRIBUTION);
        log.info("end method /Attribution/create");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.PUT,consumes = {"application/json"},produces={"application/json"})
    public Response<AttributionDto> update(@RequestBody Request<AttributionDto> request) {
        log.info("start method /Attributions/update");
        Response<AttributionDto> response = controllerFactory.update(attributionBusiness, request, FunctionalityEnum.UPDATE_ATTRIBUTION);
        log.info("end method /Attribution/update");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.DELETE,consumes = {"application/json"},produces={"application/json"})
    public Response<AttributionDto> delete(@RequestBody Request<AttributionDto> request) {
        log.info("start method /attribution/delete");
        Response<AttributionDto> response = controllerFactory.delete(attributionBusiness, request, FunctionalityEnum.DELETE_ATTRIBUTION);
        log.info("end method /attribution/delete");
        return response;
    }

    @RequestMapping(value="/forceDelete",method=RequestMethod.DELETE,consumes = {"application/json"},produces={"application/json"})
    public Response<AttributionDto> forceDelete(@RequestBody Request<AttributionDto> request) {
        log.info("start method /Attribution/forceDelete");
        Response<AttributionDto> response = controllerFactory.forceDelete(attributionBusiness, request, FunctionalityEnum.DELETE_ATTRIBUTION);
        log.info("end method /Attribution/forceDelete");
        return response;
    }

    @RequestMapping(value="/getByCriteria",method=RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<AttributionDto> getByCriteria(@RequestBody Request<AttributionDto> request) {
        log.info("start method /Attribution/getByCriteria");
        Response<AttributionDto> response = controllerFactory.getByCriteria(attributionBusiness, request, FunctionalityEnum.VIEW_ATTRIBUTION);
        log.info("end method /Attribution/getByCriteria");
        return response;
    }

}
