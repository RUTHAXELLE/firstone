package ci.sgabs.gs.souscriptionApp.business;

import ci.sgabs.gs.souscriptionApp.dao.entity.Functionality;
import ci.sgabs.gs.souscriptionApp.dao.entity.RoleFunctionality;
import ci.sgabs.gs.souscriptionApp.dao.repository.FunctionalityRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.RoleFunctionalityRepository;
import ci.sgabs.gs.souscriptionApp.helper.contrat.IBasicBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.errors.TechnicalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.helper.validation.Validate;
import ci.sgabs.gs.souscriptionApp.utils.authentification.SecurityConstants;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.FunctionalityDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.RoleFunctionalityDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.FunctionalityTransformer;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.RoleFunctionalityTransformer;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Log
@Component
public class FunctionalityBusiness implements IBasicBusiness<Request<FunctionalityDto>, Response<FunctionalityDto>> {

    private Response<FunctionalityDto> response;
    @Autowired
    private FunctionalityRepository functionalityRepository;
    @Autowired
    private UsersBusiness usersBusiness;
    @Autowired
    private RoleFunctionalityRepository roleFunctionalityRepository;
    @Autowired
    private FunctionalError functionalError;
    @Autowired
    private TechnicalError technicalError;
    @Autowired
    private ExceptionUtils exceptionUtils;
    @Autowired
    private EntityManager em;

    @Autowired
    private RoleFunctionalityBusiness roleFunctionalityBusiness;
    private final SimpleDateFormat dateFormat;
    private final SimpleDateFormat dateTimeFormat;

    public FunctionalityBusiness() {
        dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    }
    
    @Override
    public Response<FunctionalityDto> create(Request<FunctionalityDto> request, Locale locale) throws ParseException {
        log.info("----begin create Functionality-----");
        Response<FunctionalityDto> response = new Response<FunctionalityDto>();
        List<Functionality> items = new ArrayList<Functionality>();
        List<FunctionalityDto>itemsDtos =  Collections.synchronizedList(new ArrayList<FunctionalityDto>());
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_FEATURE_CREATE);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas créer des fonctionalités.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        Response<FunctionalityDto> response1 = blockDuplicationData(request, locale, response, itemsDtos);
        for(FunctionalityDto dto : request.getDatas()){
            Functionality  existingEntity = functionalityRepository.findByCode(dto.getCode(), false);
            if (existingEntity != null) {
                response.setStatus(functionalError.DATA_EXIST("Functionality code -> " + dto.getCode(), locale));
                response.setHasError(true);
                return response;
            }
            Functionality entityToSave = FunctionalityTransformer.INSTANCE.toEntity(dto);
            entityToSave.setIsDeleted(false);
            entityToSave.setCreatedAt(Utilities.getCurrentDate());
            entityToSave.setCreatedBy(request.userID);
            items.add(entityToSave);
        }
        if (!items.isEmpty()) {
            List<Functionality> itemsSaved = functionalityRepository.saveAll((Iterable<Functionality>) items);
            if (itemsSaved == null) {
                response.setStatus(functionalError.SAVE_FAIL("Functionality", locale));
                response.setHasError(true);
                return response;
            }
            List<FunctionalityDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading())) ? FunctionalityTransformer.INSTANCE.toLiteDtos(itemsSaved) : FunctionalityTransformer.INSTANCE.toDtos(itemsSaved);
            response.setItems(itemsDto);
            response.setHasError(false);
            response.setStatus(functionalError.SUCCESS("", locale));
        }
        log.info("----end create Functionality-----");
        return response;
    }

    private Response<FunctionalityDto> blockDuplicationData(Request<FunctionalityDto> request, Locale locale, Response<FunctionalityDto> response, List<FunctionalityDto> itemsDtos) {
        for(FunctionalityDto dto: request.getDatas() ) {
            // Definir les parametres obligatoires
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("code", dto.getCode());
            fieldsToVerify.put("libelle", dto.getLibelle());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            if(itemsDtos.stream().anyMatch(a->a.getCode().equalsIgnoreCase(dto.getCode()))){
                response.setStatus(functionalError.DATA_DUPLICATE("Tentative de duplication du code '" + dto.getCode() + "' pour les rôles", locale));
                response.setHasError(true);
                return response;
            }
            if(itemsDtos.stream().anyMatch(a->a.getLibelle().equalsIgnoreCase(dto.getLibelle()))){
                response.setStatus(functionalError.DATA_DUPLICATE("Tentative de duplication du libelle '" + dto.getLibelle() + "' pour les rôles", locale));
                response.setHasError(true);
                return response;
            }
            itemsDtos.add(dto);
        }
        return null;
    }

    private Response<FunctionalityDto> blockDuplicationDataUpdate(Request<FunctionalityDto> request, Locale locale, Response<FunctionalityDto> response, List<FunctionalityDto> itemsDtos) {
        for(FunctionalityDto dto: request.getDatas() ) {
            // Definir les parametres obligatoires
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            if(itemsDtos.stream().anyMatch(a->a.getId().equals(dto.getId()))){
                response.setStatus(functionalError.DATA_DUPLICATE("Tentative de duplication de l'id '" + dto.getCode() + "' pour les fonctionnalités", locale));
                response.setHasError(true);
                return response;
            }
            if(Utilities.isNotBlank(dto.getCode())){
                itemsDtos = itemsDtos.stream().filter(a-> Utilities.isNotBlank(a.getCode())).collect(Collectors.toList());
                if(Utilities.isNotEmpty(itemsDtos)){
                    if(itemsDtos.stream().anyMatch(a->a.getCode().equals(dto.getCode()))){
                        response.setStatus(functionalError.DATA_DUPLICATE("Tentative de duplication du code '" + dto.getCode() + "' pour les fonctionnalités", locale));
                        response.setHasError(true);
                        return response;
                    }
                }
            }
            itemsDtos.add(dto);
        }
        return null;
    }

    @Override
    public Response<FunctionalityDto> update(Request<FunctionalityDto> request, Locale locale) throws ParseException {

        log.info("----begin update Functionality-----");
        Response<FunctionalityDto> response = new Response<FunctionalityDto>();
        List<Functionality> items = new ArrayList<Functionality>();
        List<FunctionalityDto>itemsDtos =  Collections.synchronizedList(new ArrayList<FunctionalityDto>());
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_FEATURE_UPDATE);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas modifier des fonctionalités.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        //empêcher la duplication des données
        Response<FunctionalityDto> response1 = blockDuplicationDataUpdate(request, locale, response, itemsDtos);
        for(FunctionalityDto dto : request.getDatas()){
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            Functionality entityToSave = null;
            entityToSave = functionalityRepository.findOne(dto.getId(), false);
            if (entityToSave == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Functionality id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }
            Integer entityToSaveId = entityToSave.getId();
            if (Utilities.isNotBlank(dto.getCode()) && !dto.getCode().equals(entityToSave.getCode())) {
                Functionality existingEntity = functionalityRepository.findByCode(dto.getCode(), false);
                if (existingEntity != null && !existingEntity.getId().equals(entityToSave.getId())) {
                    response.setStatus(functionalError.DATA_EXIST("Functionality -> " + dto.getCode(), locale));
                    response.setHasError(true);
                    return response;
                }
                if (items.stream().anyMatch(a -> a.getCode().equalsIgnoreCase(dto.getCode()) && !a.getId().equals(entityToSaveId))) {
                    response.setStatus(functionalError.DATA_DUPLICATE("Tentative de duplication du code '" + dto.getCode() + "' pour les Functionality", locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setCode(dto.getCode());
            }
            if (Utilities.isNotBlank(dto.getLibelle()) && !dto.getLibelle().equals(entityToSave.getLibelle())) {
                Functionality existingEntity = functionalityRepository.findByLibelle(dto.getLibelle(), false);
                if (existingEntity != null && !existingEntity.getId().equals(entityToSave.getId())) {
                    response.setStatus(functionalError.DATA_EXIST("Functionality -> " + dto.getLibelle(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setLibelle(dto.getLibelle());
            }
            entityToSave.setUpdatedAt(Utilities.getCurrentDate());
            entityToSave.setUpdatedBy(request.userID);
            items.add(entityToSave);
        }
        if (!items.isEmpty()) {
            List<Functionality> itemsSaved = null;
            itemsSaved = functionalityRepository.saveAll((Iterable<Functionality>) items);
            if (itemsSaved == null) {
                response.setStatus(functionalError.SAVE_FAIL("Functionality", locale));
                response.setHasError(true);
                return response;
            }
            List<FunctionalityDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading())) ? FunctionalityTransformer.INSTANCE.toLiteDtos(itemsSaved) : FunctionalityTransformer.INSTANCE.toDtos(itemsSaved);
            response.setItems(itemsDto);
            response.setHasError(false);
            response.setStatus(functionalError.SUCCESS("", locale));
        }
        log.info("----end create Functionality-----");
        return response;
    }

    @Override
    public Response<FunctionalityDto> delete(Request<FunctionalityDto> request, Locale locale) {
        log.info("----begin update Functionality-----");
        Response<FunctionalityDto> response = new Response<FunctionalityDto>();
        List<Functionality> items = new ArrayList<Functionality>();
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_FEATURE_DELETE);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas supprimer des fonctionalités.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        List<RoleFunctionality> rolesFonc = Collections.synchronizedList(new ArrayList<RoleFunctionality>());
        for(FunctionalityDto dto : request.getDatas()){
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            Functionality existingEntity = null;
            existingEntity = functionalityRepository.findOne(dto.getId(), false);
            if (existingEntity == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Functionality id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }
            existingEntity.setIsDeleted(true); // element de suppression, ici nous soomme dans un context de persistance donc le set permet d'enregistrer en base
            existingEntity.setDeletedAt(Utilities.getCurrentDate());
            existingEntity.setDeletedBy(request.userID);// a modifier
            List<RoleFunctionality> roleFunctionalities = roleFunctionalityRepository.findByFunctionalityId(dto.getId(), Boolean.FALSE);
            if(Utilities.isNotEmpty(roleFunctionalities)){
                  roleFunctionalities.forEach(rf->{
                           rf.setIsDeleted(Boolean.TRUE);
                      rf.setDeletedAt(Utilities.getCurrentDate());
                      if(Utilities.isValidID(request.userID)){
                             rf.setDeletedBy(request.userID);
                      }
                  });
                rolesFonc.addAll(roleFunctionalities);
            }
            items.add(existingEntity);
        }
        if(Utilities.isNotEmpty(rolesFonc)){
                 roleFunctionalityRepository.saveAll(rolesFonc);
        }
        if (!items.isEmpty()) {
            response.setHasError(false);
            response.setStatus(functionalError.SUCCESS("", locale));
        }
        log.info("----end delete User-----");
        return response;
    }

    @Override
    public Response<FunctionalityDto> forceDelete(Request<FunctionalityDto> request, Locale locale) throws ParseException { // cette methode permet de supprimer l'entité ainsi que tout les autres entité rattachées à elle
        log.info("----begin update Functionality-----");
        Response<FunctionalityDto> response = new Response<FunctionalityDto>();
        List<Functionality> items = new ArrayList<Functionality>();
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_FEATURE_DELETE);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas supprimer des fonctionalités.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        //Suppresssions forcée
        for(FunctionalityDto dto : request.getDatas()){
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            Functionality existingEntity = null;
            existingEntity = functionalityRepository.findOne(dto.getId(), false);
            if (existingEntity == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Functionality id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }
            List<RoleFunctionality> listOfRoleFunctionality = roleFunctionalityRepository.findByFunctionalityId(existingEntity.getId(), false);
            if (listOfRoleFunctionality != null && !listOfRoleFunctionality.isEmpty()) {
                Request<RoleFunctionalityDto> deleteRequest = new Request<RoleFunctionalityDto>();
                deleteRequest.setDatas(RoleFunctionalityTransformer.INSTANCE.toDtos(listOfRoleFunctionality));
                Response<RoleFunctionalityDto> deleteResponse = roleFunctionalityBusiness.delete(deleteRequest, locale);
                if (deleteResponse.isHasError()) {
                    response.setStatus(deleteResponse.getStatus());
                    response.setHasError(true);
                    return response;
                }
            }
            existingEntity.setIsDeleted(true);
            existingEntity.setDeletedAt(Utilities.getCurrentDate());
            existingEntity.setDeletedBy(request.userID);// a modifier
            items.add(existingEntity);
        }
        if (!items.isEmpty()) {
            response.setHasError(false);
            response.setStatus(functionalError.SUCCESS("", locale));
        }
        log.info("----end delete User-----");
        return response;
    }

    @Override
    public Response<FunctionalityDto> getByCriteria(Request<FunctionalityDto> request, Locale locale) throws Exception {

        log.info("----begin get Functionality-----");
        Response<FunctionalityDto> response = new Response<FunctionalityDto>();
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_FEATURE_LIST);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas lister les fonctionalités.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        if (Utilities.blank(request.getData().getOrderField())) {
            request.getData().setOrderField("");
        }
        if (Utilities.blank(request.getData().getOrderDirection())) {
            request.getData().setOrderDirection("asc");
        }
        List<Functionality> items = functionalityRepository.getByCriteria(request, em, locale);
        if (Utilities.isEmpty(items)) {
            response.setStatus(functionalError.DATA_EMPTY("Functionality", locale));
            response.setHasError(false);
            return response;
        }
        List<FunctionalityDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading())) ? FunctionalityTransformer.INSTANCE.toLiteDtos(items) : FunctionalityTransformer.INSTANCE.toDtos(items);
        response.setItems(itemsDto);
        response.setCount(functionalityRepository.count(request, em, locale));
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end get Functionality-----");
        return response;
    }

}
