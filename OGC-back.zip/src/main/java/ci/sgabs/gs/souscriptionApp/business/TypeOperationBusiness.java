package ci.sgabs.gs.souscriptionApp.business;

import ci.sgabs.gs.souscriptionApp.dao.entity.TypeOperation;
import ci.sgabs.gs.souscriptionApp.dao.repository.TypeOperationRepository;
import ci.sgabs.gs.souscriptionApp.helper.contrat.IBasicBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.errors.TechnicalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.helper.validation.Validate;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.StatusDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.TypeOperationDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.TypeOperationTransformer;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Log
@Component
public class TypeOperationBusiness implements IBasicBusiness<Request<TypeOperationDto>, Response<TypeOperationDto>> {

    private Response<StatusDto> response;

    @Autowired
    private TypeOperationRepository typeOperationRepository;
    @Autowired
    private FunctionalError functionalError;
    @Autowired
    private TechnicalError technicalError;
    @Autowired
    private ExceptionUtils exceptionUtils;
    @Autowired
    private EntityManager em;

    private final SimpleDateFormat dateFormat;

    private final SimpleDateFormat dateTimeFormat;

    public TypeOperationBusiness() {
        dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    }
    
    @Override
    public Response<TypeOperationDto> create(Request<TypeOperationDto> request, Locale locale) throws Exception {

        log.info("----begin create Status-----");

        Response<TypeOperationDto> response = new Response<TypeOperationDto>();
        List<TypeOperation> items = new ArrayList<TypeOperation>();

        //Verificatioon de la liste de données recues
        if(request.getDatas().isEmpty() || request.getDatas() == null){
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ",locale));
            response.setHasError(true);
            return response;
        }

        //Verification des parametres obligatoires & des duplications de donn�es
        List<TypeOperationDto>itemsDtos =  Collections.synchronizedList(new ArrayList<TypeOperationDto>());
        for(TypeOperationDto dto: request.getDatas() ) {

            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("code", dto.getCode());
            fieldsToVerify.put("description", dto.getDescription());

            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }

            if(itemsDtos.stream().anyMatch(a->a.getCode().equalsIgnoreCase(dto.getCode()))){
                response.setStatus(functionalError.DATA_DUPLICATE("Tentative de duplication du code '" + dto.getCode() + "' pour les types operation", locale));
                response.setHasError(true);
                return response;
            }
            itemsDtos.add(dto);
        }

        //Verification
        for(TypeOperationDto dto : request.getDatas()){

            //Verification doublon
            TypeOperation existingEntity = null;
            existingEntity = typeOperationRepository.findTypeOperationByCode(dto.getCode(), false); //verification en base
            if (existingEntity != null) {
                response.setStatus(functionalError.DATA_EXIST("TypeOperation  code -> " + dto.getCode(), locale));
                response.setHasError(true);
                return response;
            }

            //Transformation StatusDto en Status
            TypeOperation entityToSave = TypeOperationTransformer.INSTANCE.toEntity(dto);
            entityToSave.setIsDeleted(false);
            entityToSave.setCreatedAt(Utilities.getCurrentDate());
            entityToSave.setCreatedBy(request.userID);

            items.add(entityToSave);

        }

        if(items == null ||items.isEmpty()){
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ",locale));
            response.setHasError(true);
            return response;
        }

        //Persistence des status
        List<TypeOperation> itemsSaved = null;
        itemsSaved = typeOperationRepository.saveAll((Iterable<TypeOperation>) items);
        if (itemsSaved == null) {
            response.setStatus(functionalError.SAVE_FAIL("Status", locale));
            response.setHasError(true);
            return response;
        }

        //Transformation
        List<TypeOperationDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                        ? TypeOperationTransformer.INSTANCE.toLiteDtos(itemsSaved)
                        : TypeOperationTransformer.INSTANCE.toDtos(itemsSaved);

        //Envoie de la reponse
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        log.info("----end create Status-----");
        return response;

    }

    @Override
    public Response<TypeOperationDto> update(Request<TypeOperationDto> request, Locale locale) throws ParseException {

        log.info("----begin update Status-----");

        Response<TypeOperationDto> response = new Response<TypeOperationDto>();
        List<TypeOperation> items = new ArrayList<TypeOperation>();

        //Verificatioon de la liste de données recues
        if(request.getDatas() == null  || request.getDatas().isEmpty()){
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ",locale));
            response.setHasError(true);
            return response;
        }

        //Verification des parametres obligatoires
        for(TypeOperationDto dto: request.getDatas() ) {
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
        }

        //Verification
        for(TypeOperationDto dto : request.getDatas()){

            TypeOperation entityToSave = null;
            entityToSave = typeOperationRepository.findTypeOperationById(dto.getId(), false);
            if (entityToSave == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Status id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }

            //Verification du code
            if (Utilities.isNotBlank(dto.getCode()) && !dto.getCode().equals(entityToSave.getCode())) {
                TypeOperation existingEntity = typeOperationRepository.findTypeOperationByCode(dto.getCode(), false);
                if (existingEntity != null && !existingEntity.getId().equals(entityToSave.getId())) {
                    response.setStatus(functionalError.DATA_EXIST("Status code -> " + dto.getCode(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setCode(dto.getCode());
            }

            //Verification de la description
            if (Utilities.isNotBlank(dto.getDescription()) && !dto.getDescription().equals(entityToSave.getDescription())) {
                entityToSave.setDescription(dto.getDescription());
            }
            //Historisation
            entityToSave.setUpdatedAt(Utilities.getCurrentDate());
            entityToSave.setUpdatedBy(request.userID);
            items.add(entityToSave);
        }

        //Verificatioon de la liste de données recues
        if(items == null  || items.isEmpty()){
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ",locale));
            response.setHasError(true);
            return response;
        }

        //Transformation
        List<TypeOperationDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                        ? TypeOperationTransformer.INSTANCE.toLiteDtos(items)
                        : TypeOperationTransformer.INSTANCE.toDtos(items);

        //Envoie de la reponse
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end update Status-----");
        return response;
    }

    @Override
    public Response<TypeOperationDto> delete(Request<TypeOperationDto> request, Locale locale) {

        log.info("----begin delete Status-----");

        Response<TypeOperationDto> response = new Response<TypeOperationDto>();
        List<TypeOperation> items = new ArrayList<TypeOperation>();

        //Verification
        if(request.getDatas().isEmpty() || request.getDatas() == null){
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ",locale));
            response.setHasError(true);
            return response;
        }

        //Verification des champs obligatoires
        for(TypeOperationDto dto : request.getDatas()) {
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
        }

        //Suppression logique des status
        for(TypeOperationDto dto : request.getDatas()){
            TypeOperation existingEntity = null;
            existingEntity = typeOperationRepository.findTypeOperationById(dto.getId(), false);
            if (existingEntity == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Status id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }
            //Historisation
            existingEntity.setIsDeleted(true);
            existingEntity.setDeletedAt(Utilities.getCurrentDate());
            existingEntity.setDeletedBy(request.userID);

            items.add(existingEntity);
        }

        //Verification
        if(items == null  || items.isEmpty()){
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ",locale));
            response.setHasError(true);
            return response;
        }

        //Envoie de la reponse
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end delete Status-----");
        return response;
    }

    @Override
    public Response<TypeOperationDto> forceDelete(Request<TypeOperationDto> request, Locale locale) throws ParseException {
        return null;
    }

    @Override
    public Response<TypeOperationDto> getByCriteria(Request<TypeOperationDto> request, Locale locale) throws Exception {

        log.info("----begin get Status-----");

        Response<TypeOperationDto> response = new Response<TypeOperationDto>();

        //****** verification si le parametre d'ordre à été fourni, sinon nous mettons le paramètre à vide
        if (Utilities.blank(request.getData().getOrderField())) {
            request.getData().setOrderField("");
        }

        //verification si le parametre direction à été fourni, sinon nous mettons le paramètre ascendant( du plus ancien au plus ressent)
        if (Utilities.blank(request.getData().getOrderDirection())) {
            request.getData().setOrderDirection("asc");
        }

        //recuperation des entités en base
        List<TypeOperation> items = typeOperationRepository.getByCriteria(request, em, locale);

        if (Utilities.isEmpty(items)) {
            response.setStatus(functionalError.DATA_EMPTY("TypeOperation", locale));
            response.setHasError(false);
            return response;
        }

        //Transformation
        List<TypeOperationDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                                ? TypeOperationTransformer.INSTANCE.toLiteDtos(items)
                                : TypeOperationTransformer.INSTANCE.toDtos(items);

        //Envoie de la reponse
        response.setItems(itemsDto);
        response.setCount(typeOperationRepository.count(request, em, locale));
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        log.info("----end get Status-----");
        return response;
    }


}
