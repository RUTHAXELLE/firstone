package ci.sgabs.gs.souscriptionApp.rest.api;

import ci.sgabs.gs.souscriptionApp.business.StatusBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.enums.FunctionalityEnum;
import ci.sgabs.gs.souscriptionApp.rest.fact.ControllerFactory;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.StatusDto;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Log
@CrossOrigin("*")
@RestController
@RequestMapping(value="/status")
public class StatusController {


    @Autowired
    private ControllerFactory<StatusDto> controllerFactory;
    @Autowired
    private StatusBusiness statusBusiness;

    @RequestMapping(value="",method= RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<StatusDto> create(@RequestBody Request<StatusDto> request) {
        log.info("start method /Status/create");
        Response<StatusDto> response = controllerFactory.create(statusBusiness, request, FunctionalityEnum.CREATE_STATUS);
        log.info("end method /Status/create");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.PUT,consumes = {"application/json"},produces={"application/json"})
    public Response<StatusDto> update(@RequestBody Request<StatusDto> request) {
        log.info("start method /Statuss/update");
        Response<StatusDto> response = controllerFactory.update(statusBusiness, request, FunctionalityEnum.UPDATE_STATUS);
        log.info("end method /Status/update");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.DELETE,consumes = {"application/json"},produces={"application/json"})
    public Response<StatusDto> delete(@RequestBody Request<StatusDto> request) {
        log.info("start method /Status/delete");
        Response<StatusDto> response = controllerFactory.delete(statusBusiness, request, FunctionalityEnum.DELETE_STATUS);
        log.info("end method /Status/delete");
        return response;
    }

    @RequestMapping(value="/forceDelete",method=RequestMethod.DELETE,consumes = {"application/json"},produces={"application/json"})
    public Response<StatusDto> forceDelete(@RequestBody Request<StatusDto> request) {
        log.info("start method /Status/forceDelete");
        Response<StatusDto> response = controllerFactory.forceDelete(statusBusiness, request, FunctionalityEnum.DELETE_STATUS);
        log.info("end method /Status/forceDelete");
        return response;
    }

    @RequestMapping(value="/getByCriteria",method=RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<StatusDto> getByCriteria(@RequestBody Request<StatusDto> request) {
        log.info("start method /Status/getByCriteria");
        Response<StatusDto> response = controllerFactory.getByCriteria(statusBusiness, request, FunctionalityEnum.VIEW_STATUS);
        log.info("end method /Status/getByCriteria");
        return response;
    }

}
