package ci.sgabs.gs.souscriptionApp.utils.dto.transformer;

import ci.sgabs.gs.souscriptionApp.dao.entity.*;
import ci.sgabs.gs.souscriptionApp.helper.contrat.FullTransformerQualifier;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.DemandeDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.DemandeMaintenanceDto;
import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

@Mapper
public interface DemandeMaintenanceTransformer {

    DemandeMaintenanceTransformer INSTANCE = Mappers.getMapper(DemandeMaintenanceTransformer.class);

    @FullTransformerQualifier
    @Mappings({
            @Mapping(source = "entity.id", target = "id"),
            @Mapping(source = "entity.noms", target = "noms"),
            @Mapping(source = "entity.prenom", target = "prenom"),
            @Mapping(source = "entity.codeAgence", target = "codeAgence"),
            @Mapping(source = "entity.libelleTypeCarte", target = "libelleTypeCarte"),
            @Mapping(source = "entity.agent", target = "agent"),
            @Mapping(source = "entity.produit", target = "produit"),
            @Mapping(source = "entity.numeroCompte", target = "numeroCompte"),
            @Mapping(source = "entity.codeTypeCarte", target = "codeTypeCarte"),
            @Mapping(source = "entity.status.id", target = "statusId"),
            @Mapping(source = "entity.typeOperation.id", target = "typeOperationId"),
            @Mapping(source = "entity.carte.id", target = "carteId"),
            @Mapping(source = "entity.typeOperation.code", target = "codeTypeOperation"),
            @Mapping(source = "entity.carte.code", target = "numberCard"),
            @Mapping(source = "entity.login", target = "login"),

            @Mapping(source = "entity.isGenreatedContrat", target = "isGenreatedContrat"),
            @Mapping(source = "entity.isForced", target = "isForced"),

            @Mapping(source = "entity.updatedAt", dateFormat = "dd/MM/yyyy", target = "updatedAt"),
            @Mapping(source = "entity.createdAt", dateFormat = "dd/MM/yyyy", target = "createdAt"),
            @Mapping(source = "entity.deletedAt", dateFormat = "dd/MM/yyyy", target = "deletedAt"),
            @Mapping(source = "entity.updatedBy", target = "updatedBy"),
            @Mapping(source = "entity.createdBy", target = "createdBy"),
            @Mapping(source = "entity.deletedBy", target = "deletedBy"),
            @Mapping(source = "entity.isDeleted", target = "isDeleted"),
    })
    DemandeMaintenanceDto toDto(DemandeMaintenance entity);

    @IterableMapping(qualifiedBy = {FullTransformerQualifier.class})
    List<DemandeMaintenanceDto> toDtos(List<DemandeMaintenance> entities) throws ParseException;

    public default DemandeMaintenanceDto toLiteDto(DemandeMaintenance entity) {
        if (entity == null) {
            return null;
        }

        DemandeMaintenanceDto dto = new DemandeMaintenanceDto();

        dto.setId(entity.getId());
        dto.setNumeroCompte(entity.getNumeroCompte());
        dto.setCodeAgence(entity.getCodeAgence());
        dto.setNoms(entity.getNoms());
        dto.setPrenom(entity.getPrenom());
        dto.setAgent(entity.getAgent());

        return dto;
    }

    public default List<DemandeMaintenanceDto> toLiteDtos(List<DemandeMaintenance> entities) {
        if (entities == null || entities.stream().allMatch(o -> o == null)) {
            return null;
        }
        List<DemandeMaintenanceDto> dtos = new ArrayList<DemandeMaintenanceDto>();
        for (DemandeMaintenance entity : entities) {
            dtos.add(toLiteDto(entity));
        }
        return dtos;
    }

    @Mappings({
            @Mapping(source = "dto.id", target = "id"),
            @Mapping(source = "dto.noms", target = "noms"),
            @Mapping(source = "dto.prenom", target = "prenom"),
            @Mapping(source = "dto.codeAgence", target = "codeAgence"),
            @Mapping(source = "dto.libelleTypeCarte", target = "libelleTypeCarte"),
            @Mapping(source = "dto.agent", target = "agent"),
            @Mapping(source = "dto.produit", target = "produit"),
            @Mapping(source = "dto.numeroCompte", target = "numeroCompte"),
            @Mapping(source = "dto.codeTypeCarte", target = "codeTypeCarte"),
            @Mapping(source = "dto.login", target = "login"),

            @Mapping(source = "dto.isGenreatedContrat", target = "isGenreatedContrat"),
            @Mapping(source = "dto.isForced", target = "isForced"),

            @Mapping(source = "dto.updatedAt", dateFormat = "dd/MM/yyyy", target = "updatedAt"),
            @Mapping(source = "dto.createdAt", dateFormat = "dd/MM/yyyy", target = "createdAt"),
            @Mapping(source = "dto.deletedAt", dateFormat = "dd/MM/yyyy", target = "deletedAt"),
            @Mapping(source = "dto.updatedBy", target = "updatedBy"),
            @Mapping(source = "dto.createdBy", target = "createdBy"),
            @Mapping(source = "dto.deletedBy", target = "deletedBy"),
            @Mapping(source = "dto.isDeleted", target = "isDeleted"),

            @Mapping(source = "typeOperation", target = "typeOperation"),
            @Mapping(source = "carte", target = "carte"),
            @Mapping(source = "status", target = "status")
    })
    DemandeMaintenance toEntity(DemandeMaintenanceDto dto, TypeOperation typeOperation, Carte carte, Status status);

}
