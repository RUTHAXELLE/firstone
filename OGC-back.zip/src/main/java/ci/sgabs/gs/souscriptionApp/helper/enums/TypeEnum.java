package ci.sgabs.gs.souscriptionApp.helper.enums;

import java.util.stream.Stream;

public enum TypeEnum {
    PUCE, PISTE;
    //values makke recognize values set
    public static boolean isValidTag(String tag) {
        return Stream.of(values()).anyMatch(t -> t.name().equals(tag));
    }
}
