package ci.sgabs.gs.souscriptionApp.utils.authentification;



public class SecurityConstants {

    //Variables constantes authentication
    public static final String SESSION_TOKEN_FIELD_SECRET_PHRASE = "asdfSFS34wfsdfsdfSDSD32dfsddDDerQSNCK34SOWEK5354fdgdf4";
    public static final String SESSION_TOKEN_FILED_USER_ID = "id";
    public static final String SESSION_TOKEN_FILED_USER_LOGIN = "login";
    public static final String SESSION_TOKEN_FILED_USER_ROLE = "role";

    //Variables constantes des permissions
    public static final String PERMISSION_LOGIN = "ROLE_LOGIN"; // Connexion
    public static final String PERMISSION_LOGOUT = "ROLE_LOGOUT"; // Déconnexion
    public static final String PERMISSION_PROFILE_CREATE = "ROLE_PROFILE_CREATE"; //creer un role
    public static final String PERMISSION_PROFILE_UPDATE = "ROLE_PROFILE_UPDATE";//mettre à jour les roles
    public static final String PERMISSION_PROFILE_DELETE = "ROLE_PROFILE_DELETE";  // Supprimer un role
    public static final String PERMISSION_PROFILE_LIST = "ROLE_PROFILE_LIST"; // Consulter la liste des roles
    public static final String PERMISSION_USER_CREATE = "ROLE_USER_CREATE"; // Creer un utilisateur
    public static final String PERMISSION_USER_UPDATE = "ROLE_USER_UPDATE"; // Mettre a jour un utilisateur
    public static final String PERMISSION_USER_LIST = "ROLE_USER_LIST"; // Consulter la liste de utilisateur
    public static final String PERMISSION_FEATURE_CREATE = "ROLE_FEATURE_CREATE"; // Créer une permission
    public static final String PERMISSION_FEATURE_UPDATE = "ROLE_FEATURE_UPDATE"; // Créer une permission
    public static final String PERMISSION_FEATURE_LIST = "ROLE_FEATURE_LIST"; // Consulter la liste des permission
    public static final String PERMISSION_FEATURE_DELETE = "ROLE_FEATURE_DELETE"; // Supprimer un permission
    public static final String PERMISSION_REQUEST_CREATE = "ROLE_REQUEST_CREATE"; // Creer une demande
    public static final String PERMISSION_REQUEST_UPDATE = "ROLE_REQUEST_UPDATE"; // Modifier une demande
    public static final String PERMISSION_REQUEST_DELETE = "ROLE_REQUEST_DELETE"; // Supprimer une demande
    public static final String PERMISSION_CARD_TYPE_CREATE = "ROLE_CARD_TYPE_CREATE"; // Creer un type de carte
    public static final String PERMISSION_CARD_TYPE_UPDATE = "ROLE_CARD_TYPE_UPDATE"; // Modifier un type de carte
    public static final String PERMISSION_CARD_TYPE_DELETE = "ROLE_CARD_TYPE_DELETE"; // Modifier un type de carte
    public static final String PERMISSION_CARD_TYPE_LIST = "ROLE_CARD_TYPE_LIST"; // Consulter la liste des types de carte
    public static final String PERMISSION_REQUEST_CHECK = "ROLE_REQUEST_CHECK"; // Controler les demandes de cartes
    public static final String PERMISSION_REQUEST_LIST = "ROLE_REQUEST_LIST"; // Consulter la liste des demandes
    public static final String PERMISSION_INVALID_REQUEST_LIST = "ROLE_INVALID_REQUEST_LIST"; // Consulter la liste des demandes invalides
    public static final String PERMISSION_VALID_REQUEST_LIST = "ROLE_VALID_REQUEST_LIST"; // Consulter la liste des demandes valides
    public static final String PERMISSION_INVALID_REQUEST_VALIDATE = "ROLE_INVALID_REQUEST_VALIDATE"; // Forcer la validation des demandes invalides
    public static final String PERMISSION_MAINTENANCE_OPERATION_DELETE = "ROLE_MAINTENANCE_OPERATION_DELETE"; // Supprimer une opération de maintenance
    public static final String PERMISSION_MAINTENANCE_OPERATION_CREATE = "ROLE_MAINTENANCE_OPERATION_CREATE"; // creation une opération de maintenance
    public static final String PERMISSION_MAINTENANCE_OPERATION_UPDATE = "ROLE_MAINTENANCE_OPERATION_UPDATE"; // modification une opération de maintenance
    public static final String PERMISSION_MAINTENANCE_OPERATION_LIST = "ROLE_MAINTENANCE_OPERATION_LIST"; //TODO A creer au front-end
    public static final String PERMISSION_LAST_GENERATION = "ROLE_LAST_GENERATION";
    public static final String PERMISSION_COMMAND_APBATCH_GENERATION = "ROLE_APBATCH_COMMAND_GENERATE"; // Générer APBATCH de commande
    public static final String PERMISSION_MAINTENANCE_APBATCH_GENERATION = "ROLE_APBATCH_MAINTENANCE_GENERATE"; // Générer APBATCH de maintenance
    public static final String PERMISSION_COMMAND_APBATCH_VALIDATION = "ROLE_APBATCH_COMMAND_VALIDATE"; // Valider APBATCH de commande
    public static final String PERMISSION_MAINTENANCE_APBATCH_VALIDATION = "ROLE_APBATCH_MAINTENANCE_VALIDATE"; // Valider APBATCH de maintenance
    //Variables constantes portant sur ls différents profils
    public static final String PROFIL_ADMIN = "PROFILE_ADMIN";
    public static final String PROFIL_RA = "PROFILE_RA";
    public static final String PROFIL_CC = "PROFILE_CC";
    //Password default
    public static final String USER_PASSWORD_DEFAULT="0123456789";

}
