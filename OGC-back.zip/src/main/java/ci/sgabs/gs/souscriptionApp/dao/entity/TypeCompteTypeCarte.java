package ci.sgabs.gs.souscriptionApp.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Data
@Table( name = "type_compte_type_carte")
@NoArgsConstructor
@AllArgsConstructor
public class TypeCompteTypeCarte implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "type_compte_id")
    private TypeCompte typeCompte;

    @ManyToOne
    @JoinColumn(name = "type_carte_id")
    private TypeCarte typeCarte;

    private Boolean isDeleted;

    private Date createdAt;
    private Date updatedAt;
    private Date deletedAt;

    private Integer createdBy;
    private Integer updatedBy;
    private Integer deletedBy;

}
