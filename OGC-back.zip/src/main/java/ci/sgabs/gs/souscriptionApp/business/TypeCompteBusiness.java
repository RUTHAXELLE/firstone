package ci.sgabs.gs.souscriptionApp.business;

import ci.sgabs.gs.souscriptionApp.dao.entity.TypeCarte;
import ci.sgabs.gs.souscriptionApp.dao.entity.TypeCompte;
import ci.sgabs.gs.souscriptionApp.dao.entity.TypeCompteTypeCarte;
import ci.sgabs.gs.souscriptionApp.dao.repository.TypeCarteRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.TypeCompteRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.TypeCompteTypeCarteRepository;
import ci.sgabs.gs.souscriptionApp.helper.contrat.IBasicBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.errors.TechnicalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.helper.validation.Validate;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.TypeCarteDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.TypeCompteDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.TypeCarteTransformer;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.TypeCompteTransformer;
import lombok.extern.java.Log;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Log
@Component
public class TypeCompteBusiness implements IBasicBusiness<Request<TypeCompteDto>, Response<TypeCompteDto>> {

    private Response<TypeCompteDto> response;
    @Autowired
    private TypeCompteRepository typeCompteRepository;
    @Autowired
    private TypeCompteTypeCarteRepository typeCompteTypeCarteRepository;
    @Autowired
    private TypeCompteTypeCarteBusiness typeCompteTypeCarteBusiness;
    @Autowired
    private TypeCarteRepository typeCarteRepository;
    @Autowired
    private FunctionalError functionalError;
    @Autowired
    private TechnicalError technicalError;
    @Autowired
    private ExceptionUtils exceptionUtils;
    @Autowired
    private EntityManager em;
    private final SimpleDateFormat dateFormat;
    private final SimpleDateFormat dateTimeFormat;

    public TypeCompteBusiness() {
        dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    }


    @Override
    public Response<TypeCompteDto> create(Request<TypeCompteDto> request, Locale locale) throws Exception {
        log.info("----begin create TypeCompte-----");
        Response<TypeCompteDto> response = new Response<TypeCompteDto>();
        List<TypeCompte> items = new ArrayList<TypeCompte>();

        if(request.getDatas() == null || request.getDatas().isEmpty()){
            response.setStatus(functionalError.DATA_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }
        //Verification des champs obligatoires
        List<TypeCompteDto> itemsDtos = Collections.synchronizedList(new ArrayList<TypeCompteDto>());
        for(TypeCompteDto dto: request.getDatas()){
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("code", dto.getCode());
            fieldsToVerify.put("libelle", dto.getLibelle());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            if(itemsDtos.stream().anyMatch(a->a.getCode().equalsIgnoreCase(dto.getCode()))){
                response.setStatus(functionalError.DATA_DUPLICATE("Duplication de code", locale));
                response.setHasError(true);
                return response;
            }
            itemsDtos.add(dto);
        }

        //Verification
        for(TypeCompteDto dto : request.getDatas()){
            //Verification de doublon
            TypeCompte existingEntity = null;
            existingEntity = typeCompteRepository.findByCode(dto.getCode(), false); //verification en base
            if (existingEntity != null) {
                response.setStatus(functionalError.DATA_EXIST("TypeCompte code -> " + dto.getCode(), locale));
                response.setHasError(true);
                return response;
            }
            //Transformation
            TypeCompte entityToSave = TypeCompteTransformer.INSTANCE.toEntity(dto);
            entityToSave.setIsDeleted(false);
            entityToSave.setCreatedAt(Utilities.getCurrentDate());
            entityToSave.setCreatedBy(request.userID);
            items.add(entityToSave);
        }

        if(items == null || items.isEmpty()){
            response.setStatus(functionalError.DATA_EMPTY("Liste vide" , locale));
            response.setHasError(true);
            return response;
        }

        //Persistence
        List<TypeCompte> itemsSaved = null;
        itemsSaved = typeCompteRepository.saveAll((Iterable<TypeCompte>) items);

        if (itemsSaved == null) {
            response.setStatus(functionalError.SAVE_FAIL("TypeCompte", locale));
            response.setHasError(true);
            return response;
        }

        //Transformation
        List<TypeCompteDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                                    ? TypeCompteTransformer.INSTANCE.toLiteDtos(itemsSaved)
                                    : TypeCompteTransformer.INSTANCE.toDtos(itemsSaved);

        //Envoie de la reponse
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end create TypeCompte-----");
        return response;
    }

    @Override
    public Response<TypeCompteDto> update(Request<TypeCompteDto> request, Locale locale) throws ParseException {

        log.info("----begin update TypeCompte-----");

        Response<TypeCompteDto> response = new Response<TypeCompteDto>();
        List<TypeCompte> items = new ArrayList<TypeCompte>();

        if(request.getDatas() == null || request.getDatas().isEmpty()){
            response.setStatus(functionalError.DATA_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }

        //Verification du champ obligatoire
        List<TypeCompteDto> itemsDtos = Collections.synchronizedList(new ArrayList<TypeCompteDto>()) ;
        for(TypeCompteDto dto: request.getDatas()){

            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            if(itemsDtos.stream().anyMatch(a->a.getId().equals(dto.getId()))){
                response.setStatus(functionalError.DATA_DUPLICATE("Duplication de l'identifiant", locale));
                response.setHasError(true);
                return response;
            }
            itemsDtos.add(dto);
        }

        //Verification
        for(TypeCompteDto dto : itemsDtos){

            //Verification s'il existe un TypeCompte en base avec l'id fourni

            TypeCompte entityToSave = null;
            entityToSave = typeCompteRepository.findOne(dto.getId(), false);

            if (entityToSave == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("TypeCompte id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }

            //Verification du code
            if (Utilities.isNotBlank(dto.getCode()) && !dto.getCode().equals(entityToSave.getCode())) { //verify code
                TypeCompte existingEntity = typeCompteRepository.findByCode(dto.getCode(), false);
                if (existingEntity != null && !existingEntity.getId().equals(entityToSave.getId())) {
                    response.setStatus(functionalError.DATA_EXIST("TypeCompte code -> " + dto.getCode(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setCode(dto.getCode());
            }

            //Verification et modification des autres attributs fournis

            if (Utilities.isNotBlank(dto.getLibelle()) && !dto.getLibelle().equals(entityToSave.getLibelle())) {
                entityToSave.setLibelle(dto.getLibelle());
            }
            if (Utilities.isNotBlank(dto.getDescription()) && !dto.getDescription().equals(entityToSave.getDescription())) {
                entityToSave.setDescription(dto.getDescription());
            }

            entityToSave.setUpdatedAt(Utilities.getCurrentDate());
            entityToSave.setUpdatedBy(request.userID);
            items.add(entityToSave);

        }

        if(items == null || items.isEmpty()) {
            response.setStatus(functionalError.DATA_EMPTY("Liste vide" , locale));
            response.setHasError(true);
            return response;
        }

        //Transformation
        List<TypeCompteDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                                    ? TypeCompteTransformer.INSTANCE.toLiteDtos(items)
                                    : TypeCompteTransformer.INSTANCE.toDtos(items);
        //Envoie de la reponse
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end update TypeCompte-----");
        return response;
    }

    @Override
    public Response<TypeCompteDto> delete(Request<TypeCompteDto> request, Locale locale) {

        log.info("----begin delete TypeCompte-----");

        Response<TypeCompteDto> response = new Response<TypeCompteDto>();
        List<TypeCompte> items = new ArrayList<TypeCompte>();

        if(request.getDatas() == null || request.getDatas().isEmpty()){
            response.setStatus(functionalError.DATA_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }

        //Verification des champs obligatoires
        List<TypeCompteDto> itemsDtos = Collections.synchronizedList(new ArrayList<TypeCompteDto>());
        for(TypeCompteDto dto: request.getDatas()){

            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            if(itemsDtos.stream().anyMatch(a->a.getId().equals(dto.getId()))){
                response.setStatus(functionalError.DATA_DUPLICATE("Duplication de code", locale));
                response.setHasError(true);
                return response;
            }
            itemsDtos.add(dto);
        }

        //Verification
        for(TypeCompteDto dto : itemsDtos){

            TypeCompte existingEntity = null;
            existingEntity = typeCompteRepository.findOne(dto.getId(), false);

            if (existingEntity == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("TypeCompte id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }

            existingEntity.setIsDeleted(true);
            existingEntity.setDeletedAt(Utilities.getCurrentDate());
            existingEntity.setDeletedBy(request.userID);
            items.add(existingEntity);
        }

        if(items == null || items.isEmpty()){
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste vide " , locale));
            response.setHasError(true);
            return response;
        }

        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end delete User-----");
        return response;

    }

    @Override
    public Response<TypeCompteDto> forceDelete(Request<TypeCompteDto> request, Locale locale) throws ParseException {
        log.info("----end Forcedelete TypeCarte-----");
        return null;
    }

    @Override
    public Response<TypeCompteDto> getByCriteria(Request<TypeCompteDto> request, Locale locale) throws Exception {

        log.info("----begin getByCriteria TypeCompte-----");

        Response<TypeCompteDto> response = new Response<TypeCompteDto>();

        //****** verification si le parametre d'ordre à été fourni, sinon nous mettons le paramètre à vide ********//

        if (Utilities.blank(request.getData().getOrderField())) {
            request.getData().setOrderField("");
        }

        //****** verification si le parametre direction à été fourni, sinon nous mettons le paramètre ascendant( du plus ancien au plus ressent) ********//

        if (Utilities.blank(request.getData().getOrderDirection())) {
            request.getData().setOrderDirection("asc");
        }

        //****** recuperation des entités en base *******//

        List<TypeCompte> items = typeCompteRepository.getByCriteria(request, em, locale);

        if (Utilities.isEmpty(items)) {
            response.setStatus(functionalError.DATA_EMPTY("TypeCompte", locale));
            response.setHasError(false);
            return response;
        }

        //Transformation
        List<TypeCompteDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                                    ? TypeCompteTransformer.INSTANCE.toLiteDtos(items)
                                    : TypeCompteTransformer.INSTANCE.toDtos(items);

        final int size = items.size();

        List<String> listOfError = Collections.synchronizedList(new ArrayList<String>());
        itemsDto.parallelStream().forEach(dto -> {
            try {
                dto = getFullInfos(dto, size, request.getIsSimpleLoading(), locale);
            } catch (Exception e) {
                listOfError.add(e.getMessage());
                e.printStackTrace();
            }
        });
        if (Utilities.isNotEmpty(listOfError)) {
            Object[] objArray = listOfError.stream().distinct().toArray();
            throw new RuntimeException(StringUtils.join(objArray, ", "));
        }

        response.setItems(itemsDto);
        response.setCount(typeCompteRepository.count(request, em, locale));
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        log.info("----end getByCriteria TypeCompte-----");
        return response;
    }


    private TypeCompteDto getFullInfos(TypeCompteDto dto, Integer size, Boolean isSimpleLoading, Locale locale) throws Exception {
        // put code here

        List<TypeCompteTypeCarte> listTypeCompteTypeCarte = typeCompteTypeCarteRepository.findByTypeCompteId(dto.getId(), false);

        List<TypeCarte> listTypeCarte = new ArrayList<TypeCarte>();

        if( Utilities.isNotEmpty(listTypeCompteTypeCarte)){

            for(TypeCompteTypeCarte item: listTypeCompteTypeCarte){
                TypeCarte typeCarte = typeCarteRepository.findOne(item.getTypeCarte().getId(), false);
                listTypeCarte.add(typeCarte);
            }

        }
        List<TypeCarteDto> listTypeCarteDto =  TypeCarteTransformer.INSTANCE.toLiteDtos(listTypeCarte);
        dto.setTypeCarte(listTypeCarteDto);

        return dto;
    }
}
