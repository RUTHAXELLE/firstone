package ci.sgabs.gs.souscriptionApp.dao.repository;

import ci.sgabs.gs.souscriptionApp.dao.entity.ApFile;
import ci.sgabs.gs.souscriptionApp.dao.entity.ApFileMaintenance;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.searchFunctions.CriteriaUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.ApFileDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.ApFileMaintenanceDto;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import java.util.*;

public interface ApFileMaintenanceRepository extends JpaRepository<ApFileMaintenance, Integer> {

    @Query("select e from ApFileMaintenance e where e.id= :id and e.isDeleted= :isDeleted")
    ApFileMaintenance findOne(@Param("id") Integer id, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from ApFileMaintenance e where e.code= :code and e.isDeleted= :isDeleted")
    ApFileMaintenance findByCode(@Param("code") String code, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from ApFileMaintenance e where e.libelle= :libelle and e.isDeleted= :isDeleted")
    ApFileMaintenance findByLibelle(@Param("libelle") String libelle, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from ApFileMaintenance e where e.isDeleted= :isDeleted")
    List<ApFileMaintenance> findByIsDeleted(@Param("isDeleted") Boolean isDeleted);

    @Query("select e from ApFileMaintenance e where e.updatedAt = :updatedAt and e.isDeleted = :isDeleted")
    List<ApFileMaintenance> findByUpdatedAt(@Param("updatedAt") Date updatedAt, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from ApFileMaintenance e where e.updatedBy = :updatedBy and e.isDeleted = :isDeleted")
    List<ApFileMaintenance> findByUpdatedBy(@Param("updatedBy") Long updatedBy, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from ApFileMaintenance e where e.createdAt = :createdAt and e.isDeleted = :isDeleted")
    List<ApFileMaintenance> findByCreatedAt(@Param("createdAt") Date createdAt, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from ApFileMaintenance e where e.createdBy = :createdBy and e.isDeleted = :isDeleted")
    List<ApFileMaintenance> findByCreatedBy(@Param("createdBy") Long createdBy, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from ApFileMaintenance e where e.deletedAt = :deletedAt and e.isDeleted = :isDeleted")
    List<ApFileMaintenance> findByDeletedAt(@Param("deletedAt") Date deletedAt, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from ApFileMaintenance e where e.deletedBy = :deletedBy and e.isDeleted = :isDeleted")
    List<ApFileMaintenance> findByDeletedBy(@Param("deletedBy") Long deletedBy, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from ApFileMaintenance e where e.typeOperation = :typeOperation and e.isDeleted= :isDeleted")
    List<ApFileMaintenance> getApFile(@Param("typeOperation") String typeOperation, @Param("isDeleted") Boolean isDeleted, Pageable pageable);



    @Query("select e from ApFileMaintenance e where e.typeOperation = :typeOperation and e.isCompte = true and e.isAgence = false and e.isDeleted= :isDeleted order by e.id desc")
    List<ApFileMaintenance> getApFileMiseAjourCompte(@Param("typeOperation") String typeOperation, @Param("isDeleted") Boolean isDeleted, Pageable pageable);

    @Query("select e from ApFileMaintenance e where e.typeOperation = :typeOperation and e.isAgence = true and e.isCa = true and isCh = false and e.isDeleted= :isDeleted order by e.id desc")
    List<ApFileMaintenance> getApFileMiseAjourAgenceCa(@Param("typeOperation") String typeOperation, @Param("isDeleted") Boolean isDeleted, Pageable pageable);

    @Query("select e from ApFileMaintenance e where e.typeOperation = :typeOperation and e.isAgence = true and e.isCa = false and isCh = true  and e.isDeleted= :isDeleted order by e.id desc")
    List<ApFileMaintenance> getApFileMiseAjourAgenceCh(@Param("typeOperation") String typeOperation, @Param("isDeleted") Boolean isDeleted, Pageable pageable);

    @Query("select count(*) from ApFileMaintenance e where e.isDeleted= :isDeleted")
    long countApFile(@Param("isDeleted") Boolean isDeleted);


    @Query("select e from ApFileMaintenance e where e.id<> :id and e.isValidated = :isValidated and e.isDeleted= :isDeleted")
    List<ApFileMaintenance> getDifferent(@Param("id") Integer id, @Param("isValidated") Boolean isValidated, @Param("isDeleted") Boolean isDeleted);


    // criteria search//

    // criteria search//
    public default List<ApFileMaintenance> getByCriteria(Request<ApFileMaintenanceDto> request, EntityManager em, Locale locale) throws DataAccessException, Exception {
        String req = "select e from ApFileMaintenance e where e IS NOT NULL";
        HashMap<String, Object> param = new HashMap<String, Object>();
        req += getWhereExpression(request, param, locale);
        TypedQuery<ApFileMaintenance> query = em.createQuery(req, ApFileMaintenance.class);
        for (Map.Entry<String, Object> entry : param.entrySet()) {
            query.setParameter(entry.getKey(), entry.getValue());
        }
        if (request.getIndex() != null && request.getSize() != null) {
            query.setFirstResult(request.getIndex() * request.getSize());
            query.setMaxResults(request.getSize());
        }
        return query.getResultList();
    }

    public default Long count(Request<ApFileMaintenanceDto> request, EntityManager em, Locale locale) throws DataAccessException, Exception {
        String req = "select count(*) from ApFileMaintenance e where e IS NOT NULL";
        HashMap<String, Object> param = new HashMap<String, Object>();
        req += getWhereExpressionCount(request, param, locale);
        javax.persistence.Query query = em.createQuery(req);
        for (Map.Entry<String, Object> entry : param.entrySet()) {
            query.setParameter(entry.getKey(), entry.getValue());
        }
        Long count = (Long) query.getResultList().get(0);
        return count;
    }

    /**
     * get where expression
     *
     * @param request
     * @param param
     * @param locale
     * @return
     * @throws Exception
     */
    default String getWhereExpression(Request<ApFileMaintenanceDto> request, HashMap<String, Object> param, Locale locale) throws Exception {
        // main query
        ApFileMaintenanceDto dto = request.getData() != null ? request.getData() : new ApFileMaintenanceDto();
        dto.setIsDeleted(false);
        String mainReq = generateCriteria(dto, param, 0, locale);
        // others query
        String othersReq = "";
        if (request.getDatas() != null && !request.getDatas().isEmpty()) {
            Integer index = 1;
            for (ApFileMaintenanceDto elt : request.getDatas()) {
                elt.setIsDeleted(false);
                String eltReq = generateCriteria(elt, param, index, locale);
                if (request.getIsAnd() != null && request.getIsAnd()) {
                    othersReq += "and (" + eltReq + ") ";
                } else {
                    othersReq += "or (" + eltReq + ") ";
                }
                index++;
            }
        }
        String req = "";
        if (!mainReq.isEmpty()) {
            req += " and (" + mainReq + ") ";
        }
        req += othersReq;

        //order
        if (Sort.Direction.fromOptionalString(dto.getOrderDirection()).orElse(null) != null && Utilities.notBlank(dto.getOrderField())) {
            req += " order by e." + dto.getOrderField() + " " + dto.getOrderDirection();
        } else {
            req += " order by  e.id desc";
        }
        return req;
    }


    default String getWhereExpressionCount(Request<ApFileMaintenanceDto> request, HashMap<String, Object> param, Locale locale) throws Exception {
        // main query
        ApFileMaintenanceDto dto = request.getData() != null ? request.getData() : new ApFileMaintenanceDto();
        dto.setIsDeleted(false);
        String mainReq = generateCriteria(dto, param, 0, locale);
        // others query
        String othersReq = "";
        if (request.getDatas() != null && !request.getDatas().isEmpty()) {
            Integer index = 1;
            for (ApFileMaintenanceDto elt : request.getDatas()) {
                elt.setIsDeleted(false);
                String eltReq = generateCriteria(elt, param, index, locale);
                if (request.getIsAnd() != null && request.getIsAnd()) {
                    othersReq += "and (" + eltReq + ") ";
                } else {
                    othersReq += "or (" + eltReq + ") ";
                }
                index++;
            }
        }
        String req = "";
        if (!mainReq.isEmpty()) {
            req += " and (" + mainReq + ") ";
        }
        req += othersReq;
        return req;
    }

    /**
     * generate sql query for dto
     *
     * @param dto
     * @param param
     * @param index
     * @param locale
     * @return
     * @throws Exception
     */
    default String generateCriteria(ApFileMaintenanceDto dto, HashMap<String, Object> param, Integer index, Locale locale) throws Exception {
        List<String> listOfQuery = new ArrayList<String>();
        if (dto != null) {
            if (dto.getId() != null || Utilities.searchParamIsNotEmpty(dto.getIdParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("id", dto.getId(), "e.id", "Integer", dto.getIdParam(), param, index, locale));
            }
            if (Utilities.isNotBlank(dto.getCode()) || Utilities.searchParamIsNotEmpty(dto.getCodeParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("code", dto.getCode(), "e.code", "String", dto.getCodeParam(), param, index, locale));
            }
            if (Utilities.isNotBlank(dto.getLibelle()) || Utilities.searchParamIsNotEmpty(dto.getLibelleParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("libelle", dto.getLibelle(), "e.role.libelle", "String", dto.getLibelleParam(), param, index, locale));
            }
            if (Utilities.isNotBlank(dto.getUpdatedAt()) || Utilities.searchParamIsNotEmpty(dto.getUpdatedAtParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("updatedAt", dto.getUpdatedAt(), "e.updatedAt", "Date", dto.getUpdatedAtParam(), param, index, locale));
            }
            if (dto.getIsDeleted() != null || Utilities.searchParamIsNotEmpty(dto.getIsDeletedParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("isDeleted", dto.getIsDeleted(), "e.isDeleted", "Boolean", dto.getIsDeletedParam(), param, index, locale));
            }
            if (dto.getUpdatedBy() != null || Utilities.searchParamIsNotEmpty(dto.getUpdatedByParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("updatedBy", dto.getUpdatedBy(), "e.updatedBy", "Long", dto.getUpdatedByParam(), param, index, locale));
            }
            if (Utilities.isNotBlank(dto.getCreatedAt()) || Utilities.searchParamIsNotEmpty(dto.getCreatedAtParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("createdAt", dto.getCreatedAt(), "e.createdAt", "Date", dto.getCreatedAtParam(), param, index, locale));
            }
            if (dto.getCreatedBy() != null || Utilities.searchParamIsNotEmpty(dto.getCreatedByParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("createdBy", dto.getCreatedBy(), "e.createdBy", "Long", dto.getCreatedByParam(), param, index, locale));
            }
            if (Utilities.isNotBlank(dto.getDeletedAt()) || Utilities.searchParamIsNotEmpty(dto.getDeletedAtParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("deletedAt", dto.getDeletedAt(), "e.deletedAt", "Date", dto.getDeletedAtParam(), param, index, locale));
            }
            if (dto.getDeletedBy() != null || Utilities.searchParamIsNotEmpty(dto.getDeletedByParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("deletedBy", dto.getDeletedBy(), "e.deletedBy", "Long", dto.getDeletedByParam(), param, index, locale));
            }

            if (dto.getIsValidated() != null || Utilities.searchParamIsNotEmpty(dto.getIsValidatedParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("isValidated", dto.getIsDeleted(), "e.isValidated", "Boolean", dto.getIsValidatedParam(), param, index, locale));
            }
            if (Utilities.isNotBlank(dto.getTypeOperation()) || Utilities.searchParamIsNotEmpty(dto.getTypeOperationParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("typeOperation", dto.getTypeOperation(), "e.typeOperation", "String", dto.getTypeOperationParam(), param, index, locale));
            }
        }
        return CriteriaUtils.getCriteriaByListOfQuery(listOfQuery);
    }

}
