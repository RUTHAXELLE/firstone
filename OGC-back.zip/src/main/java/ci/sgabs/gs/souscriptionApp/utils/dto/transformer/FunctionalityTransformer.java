package ci.sgabs.gs.souscriptionApp.utils.dto.transformer;

import ci.sgabs.gs.souscriptionApp.dao.entity.Functionality;
import ci.sgabs.gs.souscriptionApp.helper.contrat.FullTransformerQualifier;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.FunctionalityDto;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
@Mapper
public interface FunctionalityTransformer {

    FunctionalityTransformer INSTANCE = Mappers.getMapper(FunctionalityTransformer.class);

    @FullTransformerQualifier
    @Mappings({
            @Mapping(source = "entity.id", target = "id"),
            @Mapping(source = "entity.code", target = "code"),
            @Mapping(source = "entity.libelle", target = "libelle"),
            @Mapping(source="entity.updatedAt", dateFormat="dd/MM/yyyy HH:mm:ss",target="updatedAt"),
            @Mapping(source="entity.createdAt", dateFormat="dd/MM/yyyy HH:mm:ss",target="createdAt"),
            @Mapping(source="entity.deletedAt", dateFormat="dd/MM/yyyy HH:mm:ss",target="deletedAt"),
            @Mapping(source="entity.updatedBy",target="updatedBy"),
            @Mapping(source="entity.createdBy", target="createdBy"),
            @Mapping(source="entity.deletedBy", target="deletedBy"),
    })
    FunctionalityDto toDto(Functionality entity);

    @IterableMapping(qualifiedBy = {FullTransformerQualifier.class})
    List<FunctionalityDto> toDtos(List<Functionality> entities) throws ParseException;

    public default FunctionalityDto toLiteDto(Functionality entity) {
        if (entity == null) {
            return null;
        }
        FunctionalityDto dto = new FunctionalityDto();
        dto.setCode( entity.getCode() );
        dto.setLibelle(entity.getLibelle());
        dto.setId( entity.getId() );
        return dto;
    }

    public default List<FunctionalityDto> toLiteDtos(List<Functionality> entities) {
        if (entities == null || entities.stream().allMatch(o -> o == null)) {
            return null;
        }
        List<FunctionalityDto> dtos = new ArrayList<FunctionalityDto>();
        for (Functionality entity : entities) {
            dtos.add(toLiteDto(entity));
        }
        return dtos;
    }

    @Mappings({
            @Mapping(source = "dto.id", target = "id"),
            @Mapping(source = "dto.code", target = "code"),
            @Mapping(source = "dto.libelle", target = "libelle"),
            @Mapping(source="dto.updatedAt", dateFormat="dd/MM/yyyy HH:mm:ss",target="updatedAt"),
            @Mapping(source="dto.createdAt", dateFormat="dd/MM/yyyy HH:mm:ss",target="createdAt"),
            @Mapping(source="dto.deletedAt", dateFormat="dd/MM/yyyy HH:mm:ss",target="deletedAt"),
            @Mapping(source="dto.updatedBy",target="updatedBy"),
            @Mapping(source="dto.createdBy", target="createdBy"),
            @Mapping(source="dto.deletedBy", target="deletedBy"),
            @Mapping(source="dto.isDeleted", target="isDeleted"),
    })
    Functionality toEntity(FunctionalityDto dto);
}
