package ci.sgabs.gs.souscriptionApp.dao.repository;

import ci.sgabs.gs.souscriptionApp.dao.entity.ApFileDemande;
import ci.sgabs.gs.souscriptionApp.dao.entity.ApFileMaintenanceDemandeMaintenance;
import ci.sgabs.gs.souscriptionApp.dao.entity.Demande;
import ci.sgabs.gs.souscriptionApp.dao.entity.DemandeMaintenance;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ApFileMaintenanceDemandeMaintenanceRepository extends JpaRepository<ApFileMaintenanceDemandeMaintenance, Integer> {

    @Query("select e from ApFileMaintenanceDemandeMaintenance e where e.id= :id and e.isDeleted= :isDeleted")
    ApFileMaintenanceDemandeMaintenance findOne(@Param("id") Integer id, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from ApFileMaintenanceDemandeMaintenance e where e.apFile.id= :apFileId and e.isDeleted= :isDeleted")
    List<ApFileMaintenanceDemandeMaintenance> findByApFileId(@Param("apFileId") Integer apFileId, @Param("isDeleted") Boolean isDeleted);

    @Query("select e.demandeMaintenance from ApFileMaintenanceDemandeMaintenance e where e.apFile.id= :apFileId and e.isDeleted= :isDeleted")
    List<DemandeMaintenance> getDemandeByApFileId(@Param("apFileId") Integer apFileId, @Param("isDeleted") Boolean isDeleted);

    @Query("select count(*) from ApFileMaintenanceDemandeMaintenance e where e.apFile.id= :apFileId and e.isDeleted= :isDeleted")
    long countDemandeByApFileId(@Param("apFileId") Integer apFileId, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from ApFileMaintenanceDemandeMaintenance e where e.demandeMaintenance.id= :demandeId and e.isDeleted= :isDeleted")
    List<ApFileMaintenanceDemandeMaintenance> findByDemandeId(@Param("demandeId") Integer demandeId, @Param("isDeleted") Boolean isDeleted);


    @Query("select e from ApFileMaintenanceDemandeMaintenance e where e.demandeMaintenance.id= :demandeId and e.isDeleted= :isDeleted")
    List<ApFileMaintenanceDemandeMaintenance> getByDemandeId(@Param("demandeId") Integer demandeId, @Param("isDeleted") Boolean isDeleted, Pageable pageable);


}
