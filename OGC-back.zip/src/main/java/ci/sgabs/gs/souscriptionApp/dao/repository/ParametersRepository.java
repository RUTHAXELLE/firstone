package ci.sgabs.gs.souscriptionApp.dao.repository;

import ci.sgabs.gs.souscriptionApp.dao.entity.Agence;
import ci.sgabs.gs.souscriptionApp.dao.entity.Parameters;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.searchFunctions.CriteriaUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.AgenceDto;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import java.util.*;

public interface ParametersRepository extends JpaRepository<Parameters, Integer> {


    @Query("select a from  Parameters a where a.id = :id and a.isDeleted= :isDeleted")
    Parameters findOne(@Param("id") Integer id, @Param("isDeleted") Boolean isDeleted);

    @Query("select a from Parameters a where a.code = :code and a.isDeleted= :isDeleted")
    Parameters findByCode(@Param("code") String code, @Param("isDeleted") Boolean isDeleted);

    @Query("select a from Parameters a where a.isDeleted= :isDeleted")
    List<Agence> findByIsDeleted(@Param("isDeleted") Boolean isDeleted);

    @Query("select a from Parameters a where a.updatedAt = :updatedAt and a.isDeleted = :isDeleted")
    List<Parameters> findByUpdatedAt(@Param("updatedAt") Date updatedAt, @Param("isDeleted")Boolean isDeleted);

    @Query("select a from Parameters a where a.updatedBy = :updatedBy and a.isDeleted = :isDeleted")
    List<Parameters> findByUpdatedBy(@Param("updatedBy")Long updatedBy, @Param("isDeleted")Boolean isDeleted);

    @Query("select a from Parameters a where a.createdAt = :createdAt and a.isDeleted = :isDeleted")
    List<Parameters> findByCreatedAt(@Param("createdAt")Date createdAt, @Param("isDeleted")Boolean isDeleted);

    @Query("select a from Parameters a where a.createdBy = :createdBy and a.isDeleted = :isDeleted")
    List<Parameters> findByCreatedBy(@Param("createdBy")Long createdBy, @Param("isDeleted")Boolean isDeleted);

    @Query("select a from Parameters a where a.deletedAt = :deletedAt and a.isDeleted = :isDeleted")
    List<Parameters> findByDeletedAt(@Param("deletedAt")Date deletedAt, @Param("isDeleted")Boolean isDeleted);

    @Query("select a from Parameters a where a.deletedBy = :deletedBy and a.isDeleted = :isDeleted")
    List<Parameters> findByDeletedBy(@Param("deletedBy")Long deletedBy, @Param("isDeleted")Boolean isDeleted);

}
