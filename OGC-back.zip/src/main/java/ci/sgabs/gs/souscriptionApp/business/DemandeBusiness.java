package ci.sgabs.gs.souscriptionApp.business;

import ci.sgabs.gs.souscriptionApp.dao.entity.*;
import ci.sgabs.gs.souscriptionApp.dao.repository.*;
import ci.sgabs.gs.souscriptionApp.helper.contrat.IBasicBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.errors.TechnicalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.helper.validation.Validate;
import ci.sgabs.gs.souscriptionApp.utils.ParamsUtils;
import ci.sgabs.gs.souscriptionApp.utils.authentification.SecurityConstants;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.*;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.ApFileTransformer;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.DemandeTransformer;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * @author Alzouma Moussa Mahamadou
 * Modification de la classe en prenant en consideration , les nouveaux champs de la classe Entité Demande
 * @Date Modif : 03/06/2022
 */
@Log
@Component
public class DemandeBusiness implements IBasicBusiness<Request<DemandeDto>, Response<DemandeDto>> {

    private Response<DemandeDto> response;

    @Autowired
    private DemandeRepository demandeRepository;

    @Autowired
    private TypeCarteRepository typeCarteRepository;

    @Autowired
    private StatusRepository statusRepository;

    @Autowired
    private HistoriqueDemandeRepository historiqueDemandeRepository;

    @Autowired
    private CompteRepository compteRepository;

    @Autowired
    private AttributionRepository attributionRepository;


    @Autowired
    private FunctionalError functionalError;
    @Autowired
    private TechnicalError technicalError;
    @Autowired
    private ExceptionUtils exceptionUtils;
    @Autowired
    private HistoriqueDemandeBusiness historiqueDemandeBusiness;
    @Autowired
    private ParamsUtils paramsUtils;
    @Autowired
    private ParametersRepository parametersRepository;
    @Autowired
    UsersBusiness usersBusiness;
    @Autowired
    EntityManager entityManager;

    //Declaration des constants

    public static final String DEMANDETATUSENCOURS = "EnCours";
    public static final String DEMANDESTATUSVALIDE = "Valide";
    public static final String DEMANDESTATUSINCOHERENT = "Incoherent";
    public static final String APPBATCHSTATUSVALIDE = "AppBatchValide";

    @Autowired
    private EntityManager em;
    private final SimpleDateFormat dateFormat;
    private final SimpleDateFormat dateTimeFormat;
    @Autowired
    private ApFileDemandeRepository apFileDemandeRepository;
    @Autowired
    private ApFileRepository apFileRepository;
    @Autowired
    private UsersRepository usersRepository;
    @Autowired
    private CarteRepository carteRepository;

    public DemandeBusiness() {
        dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    }
    @Override
    public Response<DemandeDto> create(Request<DemandeDto> request, Locale locale) throws Exception {

        log.info("----begin create Demande-----");

        Response<DemandeDto> response = new Response<DemandeDto>();
        List<Demande> items = new ArrayList<Demande>();
        if (request.getDatas() == null || request.getDatas().isEmpty()) {
            response.setStatus(functionalError.DATA_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_REQUEST_CREATE);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas créer une demande de carte.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        //Verification des champs obligatoires
        Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
        List<DemandeDto> itemsDtos = new ArrayList<DemandeDto>();
        for (DemandeDto dto : request.getDatas()) {
            fieldsToVerify.put("matricule", dto.getMatricule());
            fieldsToVerify.put("noms", dto.getNoms());
            fieldsToVerify.put("prenom", dto.getPrenom());
            fieldsToVerify.put("telephone", dto.getTelephone());
            fieldsToVerify.put("intitule", dto.getIntitule());
            fieldsToVerify.put("numeroCompte", dto.getNumeroCompte());
            fieldsToVerify.put("typeCarteId", dto.getTypeCarteId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            if (itemsDtos.stream().anyMatch(a -> a.getMatricule().equalsIgnoreCase(dto.getMatricule()))) {
                response.setStatus(functionalError.DATA_DUPLICATE(" Matricule ", locale));
                response.setHasError(true);
                return response;
            }
            if (itemsDtos.stream().anyMatch(a -> a.getTelephone().equalsIgnoreCase(dto.getTelephone()))) {
                response.setStatus(functionalError.DATA_DUPLICATE(" Telephone ", locale));
                response.setHasError(true);
                return response;
            }
            if (itemsDtos.stream().anyMatch(a -> a.getNumeroCompte().equalsIgnoreCase(dto.getNumeroCompte()))) {
                response.setStatus(functionalError.DATA_DUPLICATE(" Numéro de compte ", locale));
                response.setHasError(true);
                return response;
            }
            itemsDtos.add(dto);
        }
        //Verification
        for (DemandeDto dto : request.getDatas()) {
            //Verification de doublon
            Demande existingEntity = null;
            existingEntity = demandeRepository.findByCode(dto.getCode(), false); //verification du code
            if (existingEntity != null) {
                response.setStatus(functionalError.DATA_EXIST("Demande code -> " + dto.getCode(), locale));
                response.setHasError(true);
                return response;
            }
            //Verification du compte attaché à la demande
            Compte existingCompte = null;
            String codeAgence = null;
            if (Utilities.notBlank(dto.getNumeroCompte())) {
                existingCompte = compteRepository.findByNumeroCompte(dto.getNumeroCompte(), false);
                if (existingCompte == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("Le compte ayant le numéro  -> " + dto.getNumeroCompte() + "n'existe", locale));
                    response.setHasError(true);
                    return response;
                }
                if (existingCompte.getAgence() == null || existingCompte.getAgence().getCode() == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("L'agence à laquelle est rattaché le compte de la demande n'existe pas  -> " + dto.getNumeroCompte(), locale));
                    response.setHasError(true);
                    return response;
                }
                codeAgence = existingCompte.getAgence().getCode();
                dto.setAgence(codeAgence);
            }
            //Verification du type de carte attaché à la demande
            TypeCarte existingTypeCarte = null;
            String produit = null;
            if (Utilities.isValidID(dto.getTypeCarteId())) {
                existingTypeCarte = typeCarteRepository.findOne(dto.getTypeCarteId(), false);
                if (existingTypeCarte == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("TypeCarte TypeCarteID -> " + dto.getTypeCarteId(), locale));
                    response.setHasError(true);
                    return response;
                }
                produit = existingTypeCarte.getTypeCarte();
                dto.setProduit(produit);
            }
            //Récuperation
            Status status = null;
            status = statusRepository.findByCode(DEMANDETATUSENCOURS, false);
            if (status == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Status n'existe pas", locale));
                response.setHasError(true);
                return response;
            }
            if (dto.getIsBeneficiary() != null && dto.getIsBeneficiary()) {
                dto.setNomBeneficiaire(dto.getNoms());
                dto.setPrenomBeneficiaire(dto.getPrenom());
            }
            //Transformation
            Demande entityToSave = DemandeTransformer.INSTANCE.toEntity(dto, existingTypeCarte, existingCompte, status);
            entityToSave.setIsDeleted(false);
            entityToSave.setCreatedAt(Utilities.getCurrentDate());
            entityToSave.setCreatedBy(request.userID);
            Users users=usersRepository.findOne(request.userID,false);
            entityToSave.setLogin(users.getLogin()!=null?users.getLogin():null);
            //Persistence
            Demande entitySaved = demandeRepository.save(entityToSave);
            items.add(entitySaved);
            if (entitySaved == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Liste vide ", locale));
                response.setHasError(true);
                return response;
            }
            //Initialisation HistoriqueDemande
            List<HistoriqueDemandeDto> datasHistoriqueDemande = new ArrayList<HistoriqueDemandeDto>();
            HistoriqueDemandeDto historiqueDemandeDto = new HistoriqueDemandeDto();
            historiqueDemandeDto.setDemandeId(entitySaved.getId());
            historiqueDemandeDto.setStatusId(status.getId());
            datasHistoriqueDemande.add(historiqueDemandeDto);
            //Appel à la classe HistoriqueDemandeBusiness
            Request<HistoriqueDemandeDto> subRequest = new Request<HistoriqueDemandeDto>();
            subRequest.setDatas(datasHistoriqueDemande);
            Response<HistoriqueDemandeDto> subResponse = historiqueDemandeBusiness.create(subRequest, locale);
            if (subResponse.isHasError()) {
                response.setStatus(subResponse.getStatus());
                response.setHasError(true);
                return response;
            }
        }
        if (items == null || items.isEmpty()) {
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste vide ", locale));
            response.setHasError(true);
            return response;
        }
        //Transformation
        List<DemandeDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                ? DemandeTransformer.INSTANCE.toLiteDtos(items)
                : DemandeTransformer.INSTANCE.toDtos(items);

        //Envoie de la reponse
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end create Demande-----");
        return response;

    }
    @Override
    public Response<DemandeDto> update(Request<DemandeDto> request, Locale locale) throws ParseException {
        log.info("----begin update Demande -----");
        Response<DemandeDto> response = new Response<DemandeDto>();
        List<Demande> items = new ArrayList<Demande>();
        if (request.getDatas() == null || request.getDatas().isEmpty()) {
            response.setStatus(functionalError.FIELD_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_REQUEST_UPDATE);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas modifier une demande de carte.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        //Traitement portant sur la modification
        List<DemandeDto> itemsDtos = new ArrayList<DemandeDto>();
        for (DemandeDto dto : request.getDatas()) {
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            if (itemsDtos.stream().anyMatch(a -> a.getId().equals(dto.getId()))) {
                response.setStatus(functionalError.DATA_DUPLICATE("Liste vide", locale));
                response.setHasError(true);
                return response;
            }
            itemsDtos.add(dto);
        }
        //Verification
        for (DemandeDto dto : itemsDtos) {
            //Vérification des contraintes
            Demande entityToSave = demandeRepository.findOne(dto.getId(), false);
            if (entityToSave == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Cette demande ayant " + dto.getId() + " n'existe pas", locale));
                response.setHasError(true);
                return response;
            }
            if (entityToSave.getStatus() == null || entityToSave.getStatus().getCode() == null
                    || Utilities.blank(entityToSave.getStatus().getCode())) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Cette demande ayant " + dto.getId() + " n'a aucun statut associé", locale));
                response.setHasError(true);
                return response;
            }
            if (!(entityToSave.getStatus().getCode().equals(DemandeBusiness.DEMANDETATUSENCOURS)
                    || entityToSave.getStatus().getCode().equals(DemandeBusiness.DEMANDESTATUSINCOHERENT))) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Cette demande ayant " + dto.getId() + "ne peut être modifiée car elle est " + entityToSave.getStatus().getCode(), locale));
                response.setHasError(true);
                return response;
            }
            //Verification du compte attaché à la demande
            Compte existingCompte = null;
            if (Utilities.isNotBlank(dto.getNumeroCompte()) && !entityToSave.getCompte().getNumero().equals(dto.getNumeroCompte())) {
                existingCompte = compteRepository.findByNumeroCompte(dto.getNumeroCompte(), false);
                if (existingCompte == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("Compte ayant le numéro-> " + dto.getNumeroCompte() + " n'existe pas", locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setNumeroCompte(existingCompte.getNumero());
                entityToSave.setCompte(existingCompte);
                //Vérifier egalement l'agence du compte
                String codeAgence = null;
                if (existingCompte.getAgence() == null || existingCompte.getAgence().getCode() == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("L'agence à laquelle est rattaché le compte de la demande n'existe pas  -> " + dto.getCompteId(), locale));
                    response.setHasError(true);
                    return response;
                }
                codeAgence = existingCompte.getAgence().getCode();
                entityToSave.setAgence(codeAgence);
            }
            //Verification du type de la carte attaché à la demande
            TypeCarte existingTypeCarte = null;
            if (Utilities.isValidID(dto.getTypeCarteId()) && !entityToSave.getTypeCarte().getId().equals(dto.getTypeCarteId())) {
                existingTypeCarte = typeCarteRepository.findOne(dto.getTypeCarteId(), false);
                if (existingTypeCarte == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("TypeCarte TypeCarteID -> " + dto.getTypeCarteId(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setTypeCarte(existingTypeCarte);
                //on renseigne le type de carte dans le champ produit
                entityToSave.setProduit(existingTypeCarte.getTypeCarte() != null ? existingTypeCarte.getTypeCarte() : null);
            }
            //Verification du Matricule
            if (Utilities.isNotBlank(dto.getMatricule()) && !dto.getMatricule().equals(entityToSave.getMatricule())) { //verify code
                Demande existingEntity = demandeRepository.findByMatricule(dto.getMatricule(), false);
                if (existingEntity != null && !existingEntity.getId().equals(entityToSave.getId())) {
                    response.setStatus(functionalError.DATA_EXIST("Demande -> " + dto.getCode(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setMatricule(dto.getMatricule());
            }
            //***** Verification et modification des autres attributs fournis *********//
            if (Utilities.isNotBlank(dto.getNoms()) && !dto.getNoms().equals(entityToSave.getNoms())) {
                entityToSave.setNoms(dto.getNoms());
            }
            if (Utilities.isNotBlank(dto.getPrenom()) && !dto.getPrenom().equals(entityToSave.getPrenom())) {
                entityToSave.setPrenom(dto.getPrenom());
            }
            if (Utilities.isNotBlank(dto.getIntitule()) && !dto.getIntitule().equals(entityToSave.getIntitule())) {
                entityToSave.setIntitule(dto.getIntitule());
            }
            if (Utilities.isNotBlank(dto.getTelephone()) && !dto.getTelephone().equals(entityToSave.getTelephone())) {
                entityToSave.setTelephone(dto.getTelephone());
            }
            if (dto.getIsGenreatedContrat() != null && !dto.getIsGenreatedContrat().equals(entityToSave.getIsGenreatedContrat())) {
                entityToSave.setIsGenreatedContrat(dto.getIsGenreatedContrat());
            }
            if (dto.getIsPlafondBas() != null && !dto.getIsPlafondBas().equals(entityToSave.getIsPlafondBas())) {
                entityToSave.setIsPlafondBas(dto.getIsPlafondBas());
            }
            if (dto.getIsPlafondHaut() != null && !dto.getIsPlafondHaut().equals(entityToSave.getIsPlafondHaut())) {
                entityToSave.setIsPlafondHaut(dto.getIsPlafondHaut());
            }
            if (dto.getIsPlafondMoyen() != null && !dto.getIsPlafondMoyen().equals(entityToSave.getIsPlafondMoyen())) {
                entityToSave.setIsPlafondMoyen(dto.getIsPlafondMoyen());
            }
            if (dto.getIsForced() != null && !dto.getIsForced().equals(entityToSave.getIsForced())) {
                entityToSave.setIsForced(dto.getIsForced());
            }
            if (Utilities.isNotBlank(dto.getNomBeneficiaire())) {
                entityToSave.setNomBeneficiaire(dto.getNomBeneficiaire());
            }
            if (Utilities.isNotBlank(dto.getPrenomBeneficiaire())) {
                entityToSave.setPrenomBeneficiaire(dto.getNomBeneficiaire());
            }
            if (dto.getIsBeneficiary() != null) {
                entityToSave.setIsBeneficiary(dto.getIsBeneficiary());
            }
            if (entityToSave.getStatus().getCode().equals(DemandeBusiness.DEMANDESTATUSINCOHERENT)) {
                Status status = statusRepository.findByCode(DemandeBusiness.DEMANDETATUSENCOURS, false);
                if (status == null) {
                    response.setStatus(functionalError.DATA_EXIST("Le status ayant le code suivant: -> " + dto.getCode() + " non trouvé", locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setStatus(status);
                entityToSave.setMotif("");
                removeHistorisation(entityToSave);
                //Initialisation HistoriqueDemande
                Response<DemandeDto> response1 = initialisationHistorique(locale, response, entityToSave, status);
                if (response1 != null) return response1;
            }
            if(dto.getLogin()!=null && !dto.getLogin().equals(entityToSave.getLogin())){
                Users userExisting = usersRepository.findOne(request.userID,false);
                if(userExisting==null){
                        response.setStatus(functionalError.DATA_EMPTY("Utilisateur authentifié non trouvé", locale));
                        response.setHasError(true);
                        return response;
                }
                entityToSave.setLogin(userExisting.getLogin());
            }
            entityToSave.setUpdatedAt(Utilities.getCurrentDate());
            entityToSave.setUpdatedBy(request.userID);
            items.add(entityToSave);
        }
        if (items == null || items.isEmpty()) {
            response.setStatus(functionalError.DATA_EMPTY("Liste vide ", locale));
            response.setHasError(true);
            return response;
        }
        //Transformation
        List<DemandeDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                ? DemandeTransformer.INSTANCE.toLiteDtos(items)
                : DemandeTransformer.INSTANCE.toDtos(items);
        //Envoie de la reponse
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("end Demande update");
        return response;
    }
    private Response<DemandeDto> initialisationHistorique(Locale locale, Response<DemandeDto> response, Demande entityToSave, Status status) throws ParseException {
        List<HistoriqueDemandeDto> datasHistoriqueDemande = new ArrayList<HistoriqueDemandeDto>();
        HistoriqueDemandeDto historiqueDemandeDto = new HistoriqueDemandeDto();
        historiqueDemandeDto.setDemandeId(entityToSave.getId());
        historiqueDemandeDto.setStatusId(status.getId());
        datasHistoriqueDemande.add(historiqueDemandeDto);
        //Appel à la classe HistoriqueDemandeBusiness
        Request<HistoriqueDemandeDto> subRequest = new Request<HistoriqueDemandeDto>();
        subRequest.setDatas(datasHistoriqueDemande);
        Response<HistoriqueDemandeDto> subResponse = historiqueDemandeBusiness.create(subRequest, locale);
        if (subResponse.isHasError()) {
            response.setStatus(subResponse.getStatus());
            response.setHasError(true);
            return response;
        }
        return null;
    }
    private void removeHistorisation(Demande entityToSave) {
        List<HistoriqueDemande> demandes = historiqueDemandeRepository.findByDemandeId(entityToSave.getId(), Boolean.FALSE);
        if (Utilities.isNotEmpty(demandes)) {
            for (HistoriqueDemande historiqueDemande : demandes) {
                historiqueDemande.setIsDeleted(Boolean.TRUE);
                historiqueDemande.setDeletedAt(Utilities.getCurrentDate());
            }
            historiqueDemandeRepository.saveAll(demandes);
        }
    }
    @Override
    public Response<DemandeDto> delete(Request<DemandeDto> request, Locale locale) {

        log.info("----begin update Demande-----");
        Response<DemandeDto> response = new Response<DemandeDto>();
        List<Demande> items = new ArrayList<Demande>();
        if (request.getDatas() == null || request.getDatas().isEmpty()) {
            response.setStatus(functionalError.FIELD_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_REQUEST_DELETE);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas supprimer une demande de carte.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        //Verification des parametres obligatoires
        for (DemandeDto dto : request.getDatas()) {
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
        }
        //Verification du champ obligatoire id
        for (DemandeDto dto : request.getDatas()) {
            Demande existingEntity = null;
            existingEntity = demandeRepository.findOne(dto.getId(), false);
            if (existingEntity == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Demande id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }
            existingEntity.setIsDeleted(true);
            existingEntity.setDeletedAt(Utilities.getCurrentDate());
            existingEntity.setDeletedBy(request.userID);
            items.add(existingEntity);
        }
        if (items == null || items.isEmpty()) {
            response.setStatus(functionalError.FIELD_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end delete User-----");
        return response;
    }
    @Override
    public Response<DemandeDto> forceDelete(Request<DemandeDto> request, Locale locale) throws ParseException {
        return null;
    }
    @Override
    public Response<DemandeDto> getByCriteria(Request<DemandeDto> request, Locale locale) throws Exception {

        log.info("----begin get Demande-----");
        Response<DemandeDto> response = new Response<DemandeDto>();
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_REQUEST_DELETE);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas lister les demandes de carte.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        //Verification si le parametre d'ordre à été fourni, sinon nous mettons le paramètre à vide
        if (Utilities.blank(request.getData().getOrderField())) {
            request.getData().setOrderField("");
        }
        //Verification si le parametre direction à été fourni, sinon nous mettons le paramètre ascendant( du plus ancien au plus ressent)
        if (Utilities.blank(request.getData().getOrderDirection())) {
            request.getData().setOrderDirection("asc");
        }
        //Recuperation des entités en base
        List<Demande> items = demandeRepository.getByCriteria(request, em, locale);
        if (Utilities.isEmpty(items)) {
            response.setStatus(functionalError.DATA_EMPTY("Demande", locale));
            response.setHasError(false);
            return response;
        }
        List<DemandeDto> itemsDto = DemandeTransformer.INSTANCE.toDtos(items);
        response.setItems(itemsDto);
        response.setCount(demandeRepository.count(request, em, locale));
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end get Demande-----");
        return response;
    }
    public Response<ApFileDto> getApFile(Request<ApFileDto> request, Locale locale) throws Exception {
        Response<ApFileDto> response = new Response<ApFileDto>();
        log.info("----begin list getApFile-----");
        try {
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("index", request.getIndex());
            fieldsToVerify.put("size", request.getSize());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            List<ApFile> apFiles = apFileRepository.getApFile(Boolean.FALSE, PageRequest.of(request.getIndex(), request.getSize()));
            long countAppFile = apFileRepository.countApFile(Boolean.FALSE);
            response.setHasError(Boolean.FALSE);
            if (Utilities.isNotEmpty(apFiles)) {
                response.setItems(ApFileTransformer.INSTANCE.toDtos(apFiles));
                response.setCount(countAppFile);
            } else {
                response.setItems(new ArrayList<>());
                response.setCount(0L);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        log.info("----end get list getApFile-----");
        return response;
    }
    public Response<ApFileDto> validateApBatch(Request<ApFileDto> request, Locale locale) throws Exception {
        Response<ApFileDto> response = new Response<ApFileDto>();
        log.info("----begin validateApBatch-----");
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_COMMAND_APBATCH_VALIDATION);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas valider le fichier APPBATCH des demandes de carte.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        try {
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", request.getData().getId());
            fieldsToVerify.put("isValidated", request.getData().getIsValidated());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            ApFile apFile = apFileRepository.findOne(request.getData().getId(), Boolean.FALSE);
            if (apFile == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("api batch inexistant", locale));
                response.setHasError(false);
                return response;
            }
            List<HistoriqueDemande> historiqueDemandes = Collections.synchronizedList(new ArrayList<>());
            apFile.setIsValidated(request.getData().getIsValidated());
            apFile.setUpdatedAt(Utilities.getCurrentDate());
            apFileRepository.save(apFile);
            //zipping file
            zippingToCftFolder(apFile);
            //if true change status of demande
            logicToValidateApBatchFile(request, apFile, historiqueDemandes);
            response.setStatus(functionalError.SUCCESS("", locale));
            response.setHasError(Boolean.FALSE);
        } catch (Exception e) {
            response.setHasError(Boolean.TRUE);
            ci.sgabs.gs.souscriptionApp.helper.status.Status status = new ci.sgabs.gs.souscriptionApp.helper.status.Status();
            status.setCode("804");
            status.setMessage(e.getMessage());
            response.setStatus(status);
            e.printStackTrace();
            return response;
        }
        log.info("----end validateApBatch-----");
        return response;
    }

    private void logicToValidateApBatchFile(Request<ApFileDto> request, ApFile apFile, List<HistoriqueDemande> historiqueDemandes) {
        if (request.getData().getIsValidated()) {
            Status status = statusRepository.findByCode(DemandeBusiness.APPBATCHSTATUSVALIDE, Boolean.FALSE);
            List<Demande> demandes = apFileDemandeRepository.getDemandeByApFileId(apFile.getId(), Boolean.FALSE);
            if (Utilities.isNotEmpty(demandes) && status != null) {
                List<Carte> cartes = Collections.synchronizedList(new ArrayList<Carte>());
                for (Demande r : demandes) {
                    r.setStatus(status);
                    r.setUpdatedAt(Utilities.getCurrentDate());
                    HistoriqueDemande historiqueDemande = new HistoriqueDemande();
                    historiqueDemande.setDemande(r);
                    historiqueDemande.setStatus(status);
                    historiqueDemande.setIsDeleted(Boolean.FALSE);
                    historiqueDemande.setCreatedAt(Utilities.getCurrentDate());
                    historiqueDemandes.add(historiqueDemande);
                    //création de cartes
                    Carte carte = new Carte();
                    generateCardNumber(carte);
                    carte.setTypeCarte(r.getTypeCarte());
                    carte.setCreatedAt(Utilities.getCurrentDate());
                    carte.setIsDeleted(Boolean.FALSE);
                    //le type de la carte
                    carte.setLibelle(r.getTypeCarte().getTypeCarte());
                    if (Utilities.isNotBlank(r.getNumeroCompte())) {
                        Compte compte = compteRepository.findByNumeroCompte(r.getNumeroCompte(), Boolean.FALSE);
                        if (compte != null) {
                            carte.setCompte(compte);
                            carte.setNoms(compte.getClient().getNom());
                            carte.setPrenom(compte.getClient().getPrenoms());
                        }
                    }
                    carteRepository.save(carte);
                }
                demandeRepository.saveAll(demandes);
            }
            //historisation
            if (Utilities.isNotEmpty(historiqueDemandes)) {
                historiqueDemandeRepository.saveAll(historiqueDemandes);
            }
            //suprress older
            List<ApFile> filesOld = apFileRepository.getDifferent(apFile.getId(), Boolean.FALSE, Boolean.FALSE);
            if (Utilities.isNotEmpty(filesOld)) {
                filesOld.forEach(f -> {
                    f.setIsDeleted(Boolean.TRUE);
                    f.setDeletedAt(Utilities.getCurrentDate());
                });
                apFileRepository.saveAll(filesOld);
            }
        }
    }

    private void generateCardNumber(Carte carte) {
        if (carteRepository.countIsDeleted(Boolean.FALSE) > 0) {
            Carte last = carteRepository
                    .getByIsDeleted(Boolean.FALSE, PageRequest.of(0, 1, Sort.by(Sort.Direction.DESC, "id"))).get(0);
            if (last != null) {
                carte.setCode(Utilities.codeUnderNdigits(last.getId() + 1, 11));
            } else {
                carte.setCode(Utilities.codeUnderNdigits(1, 11));
            }
        } else {
            carte.setCode(Utilities.codeUnderNdigits(1, 11));
        }
    }

    private void zippingToCftFolder(ApFile apFile) throws IOException {
        String sourceFile = apFile.getLibelle();
        FileOutputStream fos = new FileOutputStream(paramsUtils.getZipApBatchFile().concat(apFile.getFileName()).concat(".zip"));
        ZipOutputStream zipOut = new ZipOutputStream(fos);
        File fileToZip = new File(sourceFile);
        FileInputStream fis = new FileInputStream(fileToZip);
        ZipEntry zipEntry = new ZipEntry(fileToZip.getName());
        zipOut.putNextEntry(zipEntry);
        byte[] bytes = new byte[1024];
        int length;
        while ((length = fis.read(bytes)) >= 0) {
            zipOut.write(bytes, 0, length);
        }
        zipOut.close();
        fis.close();
        fos.close();
    }

    public Response<DemandeDto> generateApBatchFile(Request<DemandeDto> request, Locale locale) throws Exception {
        log.info("----begin generateApBatchFile-----");
        Response<DemandeDto> response = new Response<DemandeDto>();
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_COMMAND_APBATCH_GENERATION);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas générer le fichier APPBATCH des commandes de carte.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        try {
            SimpleDateFormat checkFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            List<ApFile> apFiles = apFileRepository.findByCreatedAt(checkFormat.parse(checkFormat.format(Utilities.getCurrentDate())), Boolean.FALSE);
            if (Utilities.isNotEmpty(apFiles)) {
                response.setStatus(functionalError.DATA_EMPTY("Generation impossible car une génération a déjà eu lieu dans cette même minute", locale));
                response.setHasError(false);
                return response;
            }
            SimpleDateFormat simpleDateFormatAMJ = new SimpleDateFormat("yyyyMMdd");
            String header = generateHeader();
            String fullInfo = "";
            String fileName = generateFileName();
            Path completedFileName = Path.of(paramsUtils.getPathApBatchFile().concat(fileName));
            fullInfo += header.concat("\n");
            // Writing into the file
            Date currentDate = Utilities.getCurrentDate();
            SimpleDateFormat yyMonth = new SimpleDateFormat("yyMM");
            GregorianCalendar calendar = new GregorianCalendar();
            calendar.setTime(currentDate);
            // à parametrer
            calendar.add(Calendar.YEAR, +2);
            List<Demande> demandesValides = demandeRepository.findByStatusCode(DemandeBusiness.DEMANDESTATUSVALIDE, Boolean.FALSE);
            if (Utilities.isNotEmpty(demandesValides)) {
                int i = 1;
                for (Demande demande : demandesValides) {
                    //CH client details
                    String recordGroupingId = Utilities.codeUnderNdigits(i, 24);
                    String recordType = "CH"; // 2 caractères
                    String fileUpdateCode = "5"; //Add 1 caractère
                    String cardProductId = null;
                    if(Utilities.isNotBlank(demande.getTypeCarte().getCodeProduit()) && demande.getTypeCarte().getCodeProduit().length() < 3){
                        cardProductId = rightPadding(demande.getTypeCarte().getCodeProduit(), ' ', 3);
                    }else{
                         cardProductId = demande.getTypeCarte().getCodeProduit().substring(0, 3); //3 caractères
                    }
                    String pan = leftPadding(" ", '0', 19); //card number
                    String plasticNumber = leftPadding(" ", ' ', 5); //plasticNumber
                    String institutionId = getInstitutionId().substring(0, 10);
                    String cardStatus = leftPadding(" ", ' ', 2); // normal card
                    String pinAuthFlag = "01";
                    String pinAuthValue = leftPadding(" ", ' ', 16);
                    String pinFailCountReset = "Y";
                    String limitGroupId = demande.getTypeCarte().getIdentifiantGroupe().substring(0, 6);
                    String expirationDate = yyMonth.format(calendar.getTime());
                    String cardActivationFlag = "N"; // card not active
                    String cardConditionFlag = "0"; //normal
                    String autoIssueFlag = "Y";
                    //check type corporate or retail
                    String embrossingLineBusinessName = null;
                    String address1 = null;
                    String address2 = null;
                    String city = null;
                    String state = null;
                    String postalCode = null;
                    String homePhonePrefix = null;
                    String homePhone = null;
                    String activationMethod = "P";
                    String activationTimeStamp = null;
                    String previousExpirationDate = null;
                    String previousCardActivation = null;
                    String fraudCustomerSince = null;
                    String fraudLastAddressChange = null;
                    String fraudLastPinChange = null;
                    String primaryMemberNumber = "01";
                    String branchNumber = leftPadding(" ", ' ', 6);
                    String clientId1 = null;
                    String clientId2 = leftPadding(" ", ' ', 24);
                    String clientId3 = leftPadding(" ", ' ', 24);
                    String clientId4 = recordGroupingId;
                    String cardholderNamePrefix = null;
                    String cardholderFirstName = null;
                    String cardholderMiddleInitial = null;
                    String cardholderLastName = null;
                    String cardholderNameSuffix = leftPadding(" ", ' ', 6);
                    String embosingName = null;
                    String birthDate = null;
                    String socialSecurityNumber = null;
                    String workPhonePrefix = null;
                    String workPhone = null;
                    String altPhonePrefix = leftPadding(" ", ' ', 6);
                    String altPhone = leftPadding(" ", ' ', 10);
                    String motherMaidenName = leftPadding(" ", ' ', 17);
                    String securityQuestionCode = leftPadding(" ", ' ', 2);
                    String securityAnswer = leftPadding(" ", ' ', 20);
                    String cardOrderTypeFlag = "B";
                    String cardOrderStatusFlag = "3"; //order created
                    String cardOrderStatusUpdateDate = leftPadding(" ", ' ', 8);
                    String cardIssueReasonFlag = "1";
                    String cardRemplacementIndicator = "Y";
                    String dateCardOriginallyIssued = leftPadding(" ", ' ', 8);
                    String dateCardLastIssued = leftPadding(" ", ' ', 8);
                    String photoCardFlag = leftPadding(" ", ' ', 1);
                    String cardStyleType = leftPadding(" ", ' ', 3);
                    String additionalData1 = leftPadding(" ", ' ', 30);
                    String additionalData2 = leftPadding(" ", ' ', 30);
                    String countryName = leftPadding(" ", ' ', 15);
                    String letterType = leftPadding(" ", ' ', 10);
                    String filler = leftPadding(" ", ' ', 5);
                    String cardServiceCode = leftPadding(" ", ' ', 3);
                    String protectedCardFlag = leftPadding(" ", ' ', 1);
                    String feeGroupId = null;
                    String lastInformation = leftPadding(" ", ' ', 133);
                    if (Utilities.isNotBlank(demande.getNumeroCompte())) {
                        Compte compte = compteRepository.findByNumeroCompte(demande.getNumeroCompte(), Boolean.FALSE);
                        if (compte != null) {
                            if (compte.getClient() != null) {
                                if (compte.getClient().getTypeClient() != null) {
                                    if (Utilities.isNotBlank(compte.getClient().getTypeClient().getCode())) {
                                        if (compte.getClient().getTypeClient().getCode().equalsIgnoreCase("RETAILS")) {
                                            embrossingLineBusinessName = leftPadding(" ", ' ', 30);
                                        } else {
                                            if (compte.getClient().getTypeClient().getCode().equalsIgnoreCase("CORPORATE")) {
                                                embrossingLineBusinessName = rightPadding(compte.getClient().getNom(), ' ', 30);
                                            }
                                        }
                                    }
                                }
                                if (Utilities.isNotBlank(compte.getClient().getAdressPostale1())) {
                                    address1 = rightPadding(compte.getClient().getAdressPostale1(), ' ', 30);
                                } else {
                                    address1 = rightPadding(("BP"), ' ', 30);
                                }

                                if (Utilities.isNotBlank(compte.getClient().getAdressPostale2())) {
                                    address2 = rightPadding(compte.getClient().getAdressPostale2(), ' ', 30);
                                } else {
                                    address2 = rightPadding(("BP"), ' ', 30);
                                }
                                if (Utilities.isNotBlank(compte.getClient().getCity())) {
                                    city = rightPadding(compte.getClient().getCity(), ' ', 19);
                                }
                                state = "**";
                                clientId1 = rightPadding(compte.getClient().getCode(), ' ', 24);
                                birthDate = simpleDateFormatAMJ.format(compte.getClient().getDateBirth());
                            }
                            postalCode = leftPadding(" ", ' ', 9);
                            homePhonePrefix = leftPadding(" ", ' ', 6);
                            homePhone = leftPadding(" ", ' ', 10);
                            activationTimeStamp = leftPadding(" ", ' ', 8);
                            previousExpirationDate = leftPadding(" ", ' ', 4);
                            previousCardActivation = leftPadding(" ", ' ', 1);
                            fraudCustomerSince = leftPadding(" ", ' ', 8);
                            fraudLastAddressChange = leftPadding(" ", ' ', 8);
                            fraudLastPinChange = leftPadding(" ", ' ', 8);
                            cardholderNamePrefix = rightPadding(compte.getClient().getCivilite(), ' ', 6);
                            cardholderFirstName = rightPadding(compte.getClient().getPrenoms(), ' ', 40);
                            cardholderMiddleInitial = leftPadding(" ", ' ', 1);
                            cardholderLastName = rightPadding(compte.getClient().getNom(), ' ', 40);
                            embosingName = rightPadding(compte.getClient().getCivilite().concat(" ").concat(compte.getClient().getPrenoms()).concat(" ").concat(compte.getClient().getNom()), ' ', 30);
                            socialSecurityNumber = leftPadding(" ", ' ', 9);
                            workPhonePrefix = rightPadding(compte.getClient().getIndicatifPays(), ' ', 6);
                            workPhone = rightPadding(compte.getClient().getContact(), ' ', 10);
                        }
                    }
                    feeGroupId = demande.getTypeCarte().getCodeTarif().substring(0, 2);
                    fullInfo += recordGroupingId.concat(recordType).concat(fileUpdateCode).concat(cardProductId).concat(pan).concat(plasticNumber).concat(institutionId).concat(cardStatus)
                            .concat(pinAuthFlag).concat(pinAuthValue).concat(pinFailCountReset).concat(limitGroupId).concat(expirationDate).concat(cardActivationFlag).concat(cardConditionFlag)
                            .concat(autoIssueFlag).concat(embrossingLineBusinessName).concat(address1).concat(address2).concat(city).concat(state).concat(postalCode).concat(homePhonePrefix).
                            concat(homePhone).concat(activationMethod).concat(activationTimeStamp).concat(previousExpirationDate).concat(previousCardActivation).concat(fraudCustomerSince).
                            concat(fraudLastAddressChange).concat(fraudLastPinChange).concat(primaryMemberNumber).concat(branchNumber).concat(clientId1).concat(clientId2).concat(clientId3).
                            concat(clientId4).concat(cardholderNamePrefix).concat(cardholderFirstName).concat(cardholderMiddleInitial).concat(cardholderLastName).concat(cardholderNameSuffix).concat(embosingName).
                            concat(birthDate).concat(socialSecurityNumber).concat(workPhonePrefix).concat(workPhone).concat(altPhonePrefix).concat(altPhone).concat(motherMaidenName).
                            concat(securityQuestionCode).concat(securityAnswer).concat(cardOrderTypeFlag).concat(cardOrderStatusFlag).concat(cardOrderStatusUpdateDate).concat(cardIssueReasonFlag).
                            concat(cardRemplacementIndicator).concat(dateCardOriginallyIssued).concat(dateCardLastIssued).concat(photoCardFlag).concat(cardStyleType).concat(additionalData1).concat(additionalData2).
                            concat(countryName).concat(letterType).concat(filler).concat(cardServiceCode).concat(protectedCardFlag).concat(feeGroupId).concat(lastInformation).concat("\n");
                    //CA card details
                    String recordTypeCa = "CA";
                    String recordGroupingIdRecordTypeFileUpdateCodePanInstitutionId = recordGroupingId.concat(recordTypeCa).concat(fileUpdateCode).concat(pan).concat(plasticNumber).concat(institutionId);
                    String accountType = rightPadding("DDA", ' ', 4);
                    String accountNumber = rightPadding(demande.getNumeroCompte(), ' ', 28);
                    String oarSelect = "DDA";
                    String accountDescription = rightPadding(demande.getTypeCarte().getTypeGen(), ' ', 20);
                    String primaryIndicator = "Y";
                    String fundingAccountIndicator = "Y";
                    String spaces = leftPadding(" ", ' ', 48);
                    String accountCurrencyCode = "950";
                    String endWhiteSpace = leftPadding(" ", ' ', 679);
                    fullInfo += recordGroupingIdRecordTypeFileUpdateCodePanInstitutionId.concat(accountType).concat(accountNumber).concat(oarSelect).concat(accountDescription).concat(primaryIndicator).
                            concat(fundingAccountIndicator).concat(spaces).concat(accountCurrencyCode).concat(endWhiteSpace).concat("\n");
                    i++;
                }
                //add trailer
                String trailFilter = leftPadding(" ", ' ', 24);
                String trailRecordType = "TR";
                String instiutionId = getInstitutionId();
                String controlNumber = null;
                Parameters parametersNbreGeneration = parametersRepository.findByCode("nbreGeneration", Boolean.FALSE);
                if (parametersNbreGeneration != null) {
                    String recupLastValue = String.valueOf((Integer.parseInt(parametersNbreGeneration.getValeur())));
                    controlNumber = Utilities.codeUnderNdigits(Integer.parseInt(recupLastValue), 3);
                }
                String totalRecordNumber = leftPadding(String.valueOf(demandesValides.size() * 2), '0', 11);
                String hastTotal = leftPadding(" ", '0', 10);
                String trailFilterEnd = leftPadding(" ", ' ', 788);
                fullInfo += trailFilter.concat(trailRecordType).concat(instiutionId).concat(controlNumber).concat(totalRecordNumber).concat(hastTotal).concat(trailFilterEnd);
            } else {
                response.setStatus(functionalError.DATA_EMPTY("aucune demandes validées", locale));
                response.setHasError(false);
                return response;
            }
            Files.writeString(completedFileName, fullInfo);
//            String fileContent = Files.readString(completedFileName);
//            System.out.println(fileContent);
            ApFile apFile = new ApFile();
            apFile.setLibelle(paramsUtils.getPathApBatchFile().concat(fileName));
            apFile.setCode(paramsUtils.getLinkApBatchFile().concat(fileName));
            apFile.setFileName(fileName);
            apFile.setCreatedAt(Utilities.getCurrentDate());
            apFile.setIsDeleted(Boolean.FALSE);
            apFile.setIsValidated(Boolean.FALSE);
            ApFile apFileSaved = apFileRepository.save(apFile);
            List<ApFileDemande> apFileDemandes = Collections.synchronizedList(new ArrayList<ApFileDemande>());
            if (Utilities.isNotEmpty(demandesValides)) {
                for (Demande demande : demandesValides) {
                    ApFileDemande apFileDemande = new ApFileDemande();
                    apFileDemande.setDemande(demande);
                    apFileDemande.setApFile(apFileSaved);
                    apFileDemande.setIsDeleted(Boolean.FALSE);
                    apFileDemande.setCreatedAt(Utilities.getCurrentDate());
                    apFileDemandes.add(apFileDemande);
                }
            }
            if (Utilities.isNotEmpty(apFileDemandes)) {
                apFileDemandeRepository.saveAll(apFileDemandes);
            }
            response.setHasError(Boolean.FALSE);
            response.setStatus(functionalError.SUCCESS("", locale));
            response.setFilePath(apFile.getCode());
        } catch (Exception e) {
            e.printStackTrace();
        }
        log.info("----end generateApBatchFile-----");
        return response;
    }
    public static String
    leftPadding(String input, char ch, int L) {
        String result = String.format("%" + L + "s", input).replace(' ', ch);
        return result;
    }
    // Function to perform right padding
    public static String
    rightPadding(String input, char ch, int L) {
        String result = String.format("%" + (-L) + "s", input).replace(' ', ch);
        return result;
    }

    @Transactional(rollbackFor = {RuntimeException.class, Exception.class})
    public Response<DemandeDto> checkAllRequestInProgress(Request<DemandeDto> request, Locale locale) throws Exception {

        Response<DemandeDto> response = new Response<DemandeDto>();
        List<Demande> demandeEnCoursList = new ArrayList<Demande>();
        List<Status> statusList = null;
        List<HistoriqueDemandeDto> historiqueDemandeDtos = new ArrayList<HistoriqueDemandeDto>();
        Status status = null;

        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_REQUEST_CHECK);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas contrôler les demandes de carte.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        //Verification de disponibilité de demande de carte en cours
        demandeEnCoursList = historiqueDemandeRepository.findAllRequestInProgress(DEMANDETATUSENCOURS, false);
        if (Utilities.isEmpty(demandeEnCoursList)) {
            response.setStatus(functionalError.DATA_EMPTY("Aucune demande en cours de traitement disponible", locale));
            response.setHasError(false);
            return response;
        }
        log.info("_590 Affichage des demandes en cours de traitement=" + demandeEnCoursList.size());
        for (Demande demande : demandeEnCoursList) {
            if (demande != null) {
                HistoriqueDemandeDto historiqueDemandeDto = new HistoriqueDemandeDto();
                if (demande.getCompte() != null && demande.getCompte().getId() != null) {
                    String motif = null;
                    Compte entityCompte = null;
                    entityCompte = compteRepository.findCompteActif(demande.getCompte().getId(), true, false);
                    List<Carte> carteList = null;
                    carteList = attributionRepository.findCarteByCompte(demande.getCompte().getId(), false);
                    List<HistoriqueDemande> demandeByTypeCarteByCodeStatusExiste = new ArrayList<HistoriqueDemande>();
                    demandeByTypeCarteByCodeStatusExiste = historiqueDemandeRepository.findRequestByTypeCardByAccount(demande.getTypeCarte().getId(), demande.getNumeroCompte(), DEMANDETATUSENCOURS, false);
                    if (entityCompte == null) {
                        status = statusRepository.findByCode(DemandeBusiness.DEMANDESTATUSINCOHERENT, false);
                        if (status == null) {
                            response.setStatus(functionalError.DATA_EMPTY("Erreur de controle de demandes ", locale));
                            response.setHasError(false);
                            return response;
                        }
                        historiqueDemandeDto.setDemandeId(demande.getId());
                        historiqueDemandeDto.setStatusId(status.getId());
                        motif = "Le compte de la demande est fermé ou en instance de fermeture";
                        demande.setStatus(status);
                    } else if (entityCompte != null && Utilities.isNotEmpty(demandeByTypeCarteByCodeStatusExiste)) {
                        log.info("_957 Verification d'une demande portant sur le même type de carte"); //TODO
                        status = statusRepository.findByCode(DemandeBusiness.DEMANDESTATUSINCOHERENT, false);
                        if (status == null) {
                            response.setStatus(functionalError.DATA_EMPTY("Erreur de controle de demandes ", locale));
                            response.setHasError(false);
                            return response;
                        }
                        historiqueDemandeDto.setDemandeId(demande.getId());
                        historiqueDemandeDto.setStatusId(status.getId());
                        motif = "Le compte de la demande dipose déjà d'une carte";
                        demande.setStatus(status);
                    } else if (entityCompte != null && Utilities.isNotEmpty(carteList)) {
                        status = statusRepository.findByCode(DemandeBusiness.DEMANDESTATUSINCOHERENT, false);
                        if (status == null) {
                            response.setStatus(functionalError.DATA_EMPTY("Erreur de controle de demandes ", locale));
                            response.setHasError(false);
                            return response;
                        }
                        historiqueDemandeDto.setDemandeId(demande.getId());
                        historiqueDemandeDto.setStatusId(status.getId());
                        motif = "Le compte de la demande dispose déjà d'au moins d'une carte valide";
                        demande.setStatus(status);
                    } else if (entityCompte != null && Utilities.isEmpty(carteList)) {
                        status = statusRepository.findByCode(DemandeBusiness.DEMANDESTATUSVALIDE, false);
                        if (status == null) {
                            response.setStatus(functionalError.DATA_EMPTY("Erreur de controle de demandes ", locale));
                            response.setHasError(false);
                            return response;
                        }
                        historiqueDemandeDto.setDemandeId(demande.getId());
                        historiqueDemandeDto.setStatusId(status.getId());
                        motif = "Aucune erreur trouvée.Demande valide. !!!!!";
                        demande.setStatus(status);
                    } else {
                        //Ajout message d'erreurs
                    }
                    demande.setMotif(motif);
                    historiqueDemandeDtos.add(historiqueDemandeDto);
                }
            }
        }
        //Verifie la vartiable historiqueDemandeDtos
        if (Utilities.isEmpty(historiqueDemandeDtos)) {
            response.setStatus(functionalError.DATA_EMPTY("Erreur de controle de demandes ", locale));
            response.setHasError(false);
            return response;
        }
        //Peristence la variable HistoriqueDemandeList
        Request<HistoriqueDemandeDto> subRequest = new Request<HistoriqueDemandeDto>();
        subRequest.setDatas(historiqueDemandeDtos);
        Response<HistoriqueDemandeDto> subResponse = historiqueDemandeBusiness.create(subRequest, locale);
        if (subResponse.isHasError()) {
            response.setStatus(subResponse.getStatus());
            response.setHasError(true);
            return response;
        }
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("Touutes les demandes en cours, ont été bien contrôlées", locale));
        return response;
    }

    @Transactional(rollbackFor = {RuntimeException.class, Exception.class})
    public Response<DemandeDto> requestInconsistentList(Request<DemandeDto> request, Locale locale) throws Exception {

        Response<DemandeDto> response = new Response<DemandeDto>();
        List<Demande> requestInconsistentList = new ArrayList<Demande>();
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_REQUEST_LIST);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas lister les demandes de carte incoherentes.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        //Verification des champs obligatoires
        Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
        fieldsToVerify.put("index", request.getIndex());
        fieldsToVerify.put("size", request.getSize());
        if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
            response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
            response.setHasError(true);
            return response;
        }
        Long count=0L;
        int index=request.getIndex();
        int size=request.getSize();
        count=historiqueDemandeRepository.countRequestByActualStatus(DemandeBusiness.DEMANDESTATUSINCOHERENT, false);
        Role userAuthenticatedRole=usersBusiness.getRoleUserAuthenticated(Request.userID);
        if(userAuthenticatedRole==null || userAuthenticatedRole.getCode()==null){
            response.setStatus(functionalError.DATA_EMPTY("L'utilisateur authentifié ne dispose d'aucun rôle", locale));
            response.setHasError(false);
            return response;
        }
        if(userAuthenticatedRole.getCode()!=null && userAuthenticatedRole.getCode().equals(SecurityConstants.PROFIL_CC)){
            requestInconsistentList=historiqueDemandeRepository.findRequestByActualStatus1(DemandeBusiness.DEMANDESTATUSINCOHERENT,Request.userID, false,PageRequest.of(index,size));
        }else if(userAuthenticatedRole.getCode()!=null && userAuthenticatedRole.getCode().equals(SecurityConstants.PROFIL_RA)) {
            //Recuperation de l'agence de l'utilisateur authentifie
            Agence userAuthentificatedAgence=null;
            userAuthentificatedAgence=usersBusiness.getAgenceUserAuthenticated(Request.userID);
            if(userAuthentificatedAgence==null || userAuthentificatedAgence.getId() == null){
                response.setStatus(functionalError.DATA_EMPTY("L'utilisateur authentifié n'est rattaché à aucune agence", locale));
                response.setHasError(false);
                return response;
            }
            String codeAgence=userAuthentificatedAgence.getCode();
            requestInconsistentList=historiqueDemandeRepository.findRequestByActualStatus2(DemandeBusiness.DEMANDESTATUSINCOHERENT,codeAgence,false,PageRequest.of(index,size));
        }else{
            requestInconsistentList=historiqueDemandeRepository.findRequestByActualStatus(DemandeBusiness.DEMANDESTATUSINCOHERENT, false,PageRequest.of(index,size));
        }
        if (Utilities.isEmpty(requestInconsistentList)) {
            response.setStatus(functionalError.DATA_EMPTY("Aucune demande incohérente disponible", locale));
            response.setHasError(false);
            return response;
        }
        //Ttransofrmation en dtos
        List<DemandeDto> itemsDto = DemandeTransformer.INSTANCE.toDtos(requestInconsistentList);

        response.setCount(count);
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        return response;
    }

    @Transactional(rollbackFor = {RuntimeException.class, Exception.class})
    public Response<DemandeDto> requestValidatedList(Request<DemandeDto> request, Locale locale) throws Exception {

        Response<DemandeDto> response = new Response<DemandeDto>();
        List<Demande> requestValidatedList = new ArrayList<Demande>();
        //Verifications des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_VALID_REQUEST_LIST);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas lister les demandes validées.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        //Vérification des champs obligatoires
        Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
        fieldsToVerify.put("index", request.getIndex());
        fieldsToVerify.put("size", request.getSize());
        if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
            response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
            response.setHasError(true);
            return response;
        }
        int index=request.getIndex();
        int size=request.getSize();
        Long count=0L;
        count=historiqueDemandeRepository.countRequestByActualStatus(DemandeBusiness.DEMANDESTATUSVALIDE, false);
        Role userAuthenticatedRole=usersBusiness.getRoleUserAuthenticated(Request.userID);
        if(userAuthenticatedRole==null || userAuthenticatedRole.getCode()==null){
            response.setStatus(functionalError.DATA_EMPTY("L'utilisateur authentifié ne dispose d'aucun rôle", locale));
            response.setHasError(false);
            return response;
        }
        if(userAuthenticatedRole.getCode()!=null && userAuthenticatedRole.getCode().equals(SecurityConstants.PROFIL_CC)){
            requestValidatedList=historiqueDemandeRepository.findRequestByActualStatus1(DemandeBusiness.DEMANDESTATUSVALIDE,Request.userID, false,PageRequest.of(index,size));
        }else if(userAuthenticatedRole.getCode()!=null && userAuthenticatedRole.getCode().equals(SecurityConstants.PROFIL_RA)) {
            Agence userAuthenticatedAgency=null;
            userAuthenticatedAgency=usersBusiness.getAgenceUserAuthenticated(Request.userID);
            if(userAuthenticatedAgency==null || userAuthenticatedAgency.getId() == null){
                response.setStatus(functionalError.DATA_EMPTY("L'utilisateur authentifié n'est rattaché à aucune agence", locale));
                response.setHasError(false);
                return response;
            }
            String codeAgence=userAuthenticatedAgency.getCode();
            requestValidatedList=historiqueDemandeRepository.findRequestByActualStatus2(DemandeBusiness.DEMANDESTATUSVALIDE,codeAgence,false,PageRequest.of(index,size));
        }else{
            requestValidatedList=historiqueDemandeRepository.findRequestByActualStatus(DemandeBusiness.DEMANDESTATUSVALIDE, false,PageRequest.of(index,size));
        }
        if (Utilities.isEmpty(requestValidatedList)) {
            response.setStatus(functionalError.DATA_EMPTY("Aucune demande valide disponible", locale));
            response.setHasError(false);
            return response;
        }
        //Ttransofrmation en dtos
        List<DemandeDto> itemsDto = DemandeTransformer.INSTANCE.toDtos(requestValidatedList);
        response.setCount(count);
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        return response;
    }

    @Transactional(rollbackFor = {RuntimeException.class, Exception.class})
    public Response<DemandeDto> requestWaitingValidationList(Request<DemandeDto> request, Locale locale) throws Exception {
        Response<DemandeDto> response = new Response<DemandeDto>();

        //Verifications des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_INVALID_REQUEST_LIST);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas lister les demandes de carte en attente validation.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        //Verification des champs obligatoires
        Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
        fieldsToVerify.put("index", request.getIndex());
        fieldsToVerify.put("size", request.getSize());
        if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
            response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
            response.setHasError(true);
            return response;
        }
        Long count=0L;
        int index=request.getIndex();
        int size=request.getSize();
        List<Demande> requestWaitingValidationList = null;
        count=historiqueDemandeRepository.countRequestByActualStatus(DemandeBusiness.DEMANDETATUSENCOURS, false);
        Role userAuthenticatedRole=usersBusiness.getRoleUserAuthenticated(Request.userID);
        if(userAuthenticatedRole==null || userAuthenticatedRole.getCode()==null){
            response.setStatus(functionalError.DATA_EMPTY("L'utilisateur authentifié ne dispose d'aucun rôle", locale));
            response.setHasError(false);
            return response;
        }
        if(userAuthenticatedRole.getCode().equals(SecurityConstants.PROFIL_CC)){
            requestWaitingValidationList=historiqueDemandeRepository.findRequestByActualStatus1(DemandeBusiness.DEMANDETATUSENCOURS,Request.userID, false,PageRequest.of(index,size));
        }else if(userAuthenticatedRole.getCode().equals(SecurityConstants.PROFIL_RA)) {
            //Recuperation de l'agence de l'utilisateur authentifie
            Agence userAuthentificatedAgence=null;
            userAuthentificatedAgence=usersBusiness.getAgenceUserAuthenticated(Request.userID);
            if(userAuthentificatedAgence==null || userAuthentificatedAgence.getId() == null){
                response.setStatus(functionalError.DATA_EMPTY("L'utilisateur authentifié n'est rattaché à aucune agence", locale));
                response.setHasError(false);
                return response;
            }
            String codeAgence=userAuthentificatedAgence.getCode();
            requestWaitingValidationList=historiqueDemandeRepository.findRequestByActualStatus2(DemandeBusiness.DEMANDETATUSENCOURS,codeAgence,false,PageRequest.of(index,size));
        }else{
            requestWaitingValidationList=historiqueDemandeRepository.findRequestByActualStatus(DemandeBusiness.DEMANDETATUSENCOURS, false,PageRequest.of(index,size));
        }
        if (Utilities.isEmpty(requestWaitingValidationList)) {
            response.setStatus(functionalError.DATA_EMPTY("Aucune saisie de demande en cours de traitement disponible", locale));
            response.setHasError(false);
            return response;
        }
        //Ttransofrmation en dtos
        List<DemandeDto> itemsDto = DemandeTransformer.INSTANCE.toDtos(requestWaitingValidationList);
        response.setCount(count);
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        return response;
    }

    @Transactional(rollbackFor = {RuntimeException.class, Exception.class})
    public Response<DemandeDto> forceRequestValidation(Request<DemandeDto> request, Locale locale) throws Exception {

        Response<DemandeDto> response = new Response<DemandeDto>();
        List<Demande> items = new ArrayList<Demande>();
        if (request.getDatas() == null || request.getDatas().isEmpty()) {
            response.setStatus(functionalError.FIELD_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }
        //Verifications des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_INVALID_REQUEST_LIST);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas effectuer une validation forcée des demandes de carte.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        //Verification des parametres obligatoires
        List<DemandeDto> itemsDtos = Collections.synchronizedList(new ArrayList<DemandeDto>());
        for (DemandeDto dto : request.getDatas()) {
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            itemsDtos.add(dto);
        }
        List<HistoriqueDemandeDto> historiqueDemandeDtos = new ArrayList<HistoriqueDemandeDto>();
        for (DemandeDto dto : itemsDtos) {
            //Vérification de doublon
            Demande entityToSave = null;
            entityToSave = demandeRepository.findOne(dto.getId(), false);
            if (entityToSave == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("La demande ayant l'identifiant suivant -> " + dto.getId() + " n'existe pas !!!", locale));
                response.setHasError(true);
                return response;
            }
            //Verification portant sur le compte de la demande
            Compte account=entityToSave.getCompte();
            Compte existingAccount=compteRepository.findOne(account.getId(), false);
            if (existingAccount == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Le compte de la demande à forcer n'existe pas" + dto.getId() , locale));
                response.setHasError(true);
                return response;
            }
            if(existingAccount.getIsActif()==false){
                response.setStatus(functionalError.SAVE_FAIL("La demande ne pourra pas être forcée car le compte est fermé ou en instance de fermeture", locale));
                response.setHasError(true);
                return response;
            }
            //Forcage de la demande
            entityToSave.setMotif("Demande forcée pour être validée");
            entityToSave.setIsForced(true);
            //Recuperer l'identifiant du statut Valide
            Status status = statusRepository.findByCode(DemandeBusiness.DEMANDESTATUSVALIDE, false);
            if (status==null) {
                response.setStatus(functionalError.DATA_EMPTY("Statut indisponible", locale));
                response.setHasError(false);
                return response;
            }
            entityToSave.setStatus(status);
            HistoriqueDemandeDto historiqueDemandeDto = new HistoriqueDemandeDto();
            historiqueDemandeDto.setDemandeId(dto.getId());
            historiqueDemandeDto.setStatusId(status.getId());
            historiqueDemandeDtos.add(historiqueDemandeDto);
        }
        //Verifie la vartiable historiqueDemandeDtos
        if (Utilities.isEmpty(historiqueDemandeDtos)) {
            response.setStatus(functionalError.DATA_EMPTY("Erreur de controle de demandes ", locale));
            response.setHasError(false);
            return response;
        }
        Request<HistoriqueDemandeDto> subRequest = new Request<HistoriqueDemandeDto>();
        subRequest.setDatas(historiqueDemandeDtos);
        Response<HistoriqueDemandeDto> subResponse = historiqueDemandeBusiness.create(subRequest, locale);
        if (subResponse.isHasError()) {
            response.setStatus(subResponse.getStatus());
            response.setHasError(true);
            return response;
        }
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("Operation reussie.Forcage effectué !!!", locale));
        return response;
    }

    public String generateFileName() {
        SimpleDateFormat simpleDateFormatMM = new SimpleDateFormat("yyMMddHHmm");
        String fileName = null;
        String paramFiliale = null;
        Parameters parameterFiliale = parametersRepository.findByCode("filiale", Boolean.FALSE);
        if (parameterFiliale != null) {
            paramFiliale = parameterFiliale.getValeur();
        }
        fileName = "CARD".concat(simpleDateFormatMM.format(Utilities.getCurrentDate())).concat(paramFiliale);
        return fileName;
    }

    public String generateFileNameUpdate(Date actuallyDate) {
        SimpleDateFormat simpleDateFormatMM = new SimpleDateFormat("yyMMddHHmm");
        String fileName = null;
        String paramFiliale = null;
        Parameters parameterFiliale = parametersRepository.findByCode("filiale", Boolean.FALSE);
        if (parameterFiliale != null) {
            paramFiliale = parameterFiliale.getValeur();
        }
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(actuallyDate);
        calendar.add(Calendar.MINUTE, +1);
        fileName = "CARD".concat(simpleDateFormatMM.format(calendar.getTime())).concat(paramFiliale);
        return fileName;
    }

    public String generateHeader() {
        //24 spaces
        String filter = leftPadding(" ", ' ', 24);
        String recordType = "HD";
        String institutionId = getInstitutionId();
        //String text = "Welcome to geekforgeeks\nHappy Learning!";
        String controlNumber = null;
        Parameters parametersNbreGeneration = parametersRepository.findByCode("nbreGeneration", Boolean.FALSE);
        if (parametersNbreGeneration != null) {
            String recupLastValueAddOne = String.valueOf((Integer.parseInt(parametersNbreGeneration.getValeur()) + 1));
            //new persistence
            parametersNbreGeneration.setValeur(recupLastValueAddOne);
            parametersRepository.save(parametersNbreGeneration);
            controlNumber = Utilities.codeUnderNdigits(Integer.parseInt(recupLastValueAddOne), 3);
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yy");
        SimpleDateFormat simpleDateFormatDD = new SimpleDateFormat("ddd");
        Date currentDate = Utilities.getCurrentDate();
        String yy = simpleDateFormat.format(currentDate);
        String ddd = simpleDateFormatDD.format(currentDate);
        String julianDate = yy.concat(ddd);
        String filter804 = leftPadding(" ", ' ', 804);
        String header = filter.concat(recordType).concat(institutionId).concat(controlNumber).concat(julianDate).concat(filter804);
        return header;
    }

    public String generateHeaderMaintenance() {
        //24 spaces
        String filter = leftPadding(" ", ' ', 24);
        String recordType = "HD";
        String institutionId = getInstitutionId();
        //String text = "Welcome to geekforgeeks\nHappy Learning!";
        String controlNumber = null;
        Parameters parametersNbreGeneration = parametersRepository.findByCode("nbreGenerationMaintenance", Boolean.FALSE);
        if (parametersNbreGeneration != null) {
            String recupLastValueAddOne = String.valueOf((Integer.parseInt(parametersNbreGeneration.getValeur()) + 1));
            //new persistence
            parametersNbreGeneration.setValeur(recupLastValueAddOne);
            parametersRepository.save(parametersNbreGeneration);
            controlNumber = Utilities.codeUnderNdigits(Integer.parseInt(recupLastValueAddOne), 3);
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yy");
        SimpleDateFormat simpleDateFormatDD = new SimpleDateFormat("ddd");
        Date currentDate = Utilities.getCurrentDate();
        String yy = simpleDateFormat.format(currentDate);
        String ddd = simpleDateFormatDD.format(currentDate);
        String julianDate = yy.concat(ddd);
        String filter804 = leftPadding(" ", ' ', 804);
        String header = filter.concat(recordType).concat(institutionId).concat(controlNumber).concat(julianDate).concat(filter804);
        return header;
    }
    public String generateHeaderMaintenanceUpdate(Date actuallyDate) {
        //24 spaces
        String filter = leftPadding(" ", ' ', 24);
        String recordType = "HD";
        String institutionId = getInstitutionId();
        //String text = "Welcome to geekforgeeks\nHappy Learning!";
        String controlNumber = null;
        Parameters parametersNbreGeneration = parametersRepository.findByCode("nbreGenerationMaintenance", Boolean.FALSE);
        if (parametersNbreGeneration != null) {
            String recupLastValueAddOne = String.valueOf((Integer.parseInt(parametersNbreGeneration.getValeur()) + 1));
            //new persistence
            parametersNbreGeneration.setValeur(recupLastValueAddOne);
            parametersRepository.save(parametersNbreGeneration);
            controlNumber = Utilities.codeUnderNdigits(Integer.parseInt(recupLastValueAddOne), 3);
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yy");
        SimpleDateFormat simpleDateFormatDD = new SimpleDateFormat("ddd");
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(actuallyDate);
        calendar.add(Calendar.MINUTE, +1);
        Date currentDate = calendar.getTime();
        String yy = simpleDateFormat.format(currentDate);
        String ddd = simpleDateFormatDD.format(currentDate);
        String julianDate = yy.concat(ddd);
        String filter804 = leftPadding(" ", ' ', 804);
        String header = filter.concat(recordType).concat(institutionId).concat(controlNumber).concat(julianDate).concat(filter804);
        return header;
    }
    public String getInstitutionId() {
        String institutionId = null;
        Parameters parameters = parametersRepository.findByCode("institutionId", Boolean.FALSE);
        if (parameters != null && Utilities.isNotBlank(parameters.getValeur())) {
            institutionId = parameters.getValeur();
        }
        return institutionId;
    }

}
