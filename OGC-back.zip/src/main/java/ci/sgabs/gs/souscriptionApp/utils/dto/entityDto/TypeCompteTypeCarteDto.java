package ci.sgabs.gs.souscriptionApp.utils.dto.entityDto;

import ci.sgabs.gs.souscriptionApp.helper.searchFunctions.SearchParam;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;
import lombok.ToString;

import java.util.List;

@Data
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL) @JsonPropertyOrder(alphabetic = true)
public class TypeCompteTypeCarteDto {

    private Integer id;

    private Integer typeCompteId;

    private String typeCompteLibelle;

    private String typeCompteCode;

    private Integer typeCarteId;

    private String typeCarteLibelle;

    private String typeCarteCode;

    private Boolean isDeleted;

    private String createdAt;
    private String updatedAt;
    private String deletedAt;

    private Integer createdBy;
    private Integer updatedBy;
    private Integer deletedBy;

    /// SEARCH PARAM//

    private SearchParam<Integer> IdParam;
    private SearchParam<Integer> typeCompteIdParam;
    private SearchParam<String>  typeCompteCodeParam;
    private SearchParam<Integer>  typeCarteIdParam;
    private SearchParam<String>  typeCarteCodeParam;
    private SearchParam<Boolean> isDeletedParam;
    private SearchParam<String> createdAtParam;
    private SearchParam<String> updatedAtParam;
    private SearchParam<String> deletedAtParam;
    private SearchParam<Integer> createdByParam;
    private SearchParam<Integer> updatedByParam;
    private SearchParam<Integer> deletedByParam;

    // order param
    private String orderField;
    private String orderDirection;
    private List<TypeCarteDto> datasTypeCarte;
}
