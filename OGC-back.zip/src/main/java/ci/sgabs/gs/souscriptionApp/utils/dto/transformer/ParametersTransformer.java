package ci.sgabs.gs.souscriptionApp.utils.dto.transformer;

import ci.sgabs.gs.souscriptionApp.dao.entity.Agence;
import ci.sgabs.gs.souscriptionApp.dao.entity.Parameters;
import ci.sgabs.gs.souscriptionApp.helper.contrat.FullTransformerQualifier;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.AgenceDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.ParametersDto;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

@Mapper
public interface ParametersTransformer {

    ParametersTransformer INSTANCE = Mappers.getMapper(ParametersTransformer.class);

    @FullTransformerQualifier
    @Mappings({
            @Mapping(source = "entity.id", target = "id"),
            @Mapping(source = "entity.code", target = "code"),
            @Mapping(source = "entity.valeur", target = "valeur"),
            @Mapping(source="entity.updatedAt", dateFormat="dd/MM/yyyy HH:mm:ss",target="updatedAt"),
            @Mapping(source="entity.createdAt", dateFormat="dd/MM/yyyy HH:mm:ss",target="createdAt"),
            @Mapping(source="entity.deletedAt", dateFormat="dd/MM/yyyy HH:mm:ss",target="deletedAt"),
            @Mapping(source="entity.updatedBy",target="updatedBy"),
            @Mapping(source="entity.createdBy", target="createdBy"),
            @Mapping(source="entity.deletedBy", target="deletedBy"),
            @Mapping(source="entity.isDeleted", target="isDeleted"),
    })
    ParametersDto toDto(Parameters entity);

    @IterableMapping(qualifiedBy = {FullTransformerQualifier.class})
    List<ParametersDto> toDtos(List<Parameters> entities) throws ParseException;

    public default ParametersDto toLiteDto(Parameters entity) {
        if (entity == null) {
            return null;
        }
        ParametersDto dto = new ParametersDto();
        dto.setId( entity.getId() );
        dto.setCode( entity.getCode() );
        dto.setValeur(entity.getValeur());
        return dto;
    }

    public default List<ParametersDto> toLiteDtos(List<Parameters> entities) {
        if (entities == null || entities.stream().allMatch(o -> o == null)) {
            return null;
        }
        List<ParametersDto> dtos = new ArrayList<ParametersDto>();
        for (Parameters entity : entities) {
            dtos.add(toLiteDto(entity));
        }
        return dtos;
    }
    @InheritInverseConfiguration
    Parameters toEntity(ParametersDto dto);
}
