package ci.sgabs.gs.souscriptionApp.utils.dto.transformer;

import ci.sgabs.gs.souscriptionApp.dao.entity.Functionality;
import ci.sgabs.gs.souscriptionApp.dao.entity.Role;
import ci.sgabs.gs.souscriptionApp.dao.entity.RoleFunctionality;
import ci.sgabs.gs.souscriptionApp.helper.contrat.FullTransformerQualifier;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.RoleFunctionalityDto;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

@Mapper
public interface RoleFunctionalityTransformer {

    RoleFunctionalityTransformer INSTANCE = Mappers.getMapper(RoleFunctionalityTransformer.class);

    @FullTransformerQualifier
    @Mappings({
            @Mapping(source = "entity.id", target = "id"),
            @Mapping(source = "entity.role.id", target = "roleId"),
            @Mapping(source = "entity.role.libelle", target = "roleLibelle"),
            @Mapping(source = "entity.functionality.id", target = "functionalityId"),
            @Mapping(source = "entity.functionality.libelle", target = "functionalityLibelle"),
            @Mapping(source="entity.updatedAt", dateFormat="dd/MM/yyyy",target="updatedAt"),
            @Mapping(source="entity.createdAt", dateFormat="dd/MM/yyyy",target="createdAt"),
            @Mapping(source="entity.deletedAt", dateFormat="dd/MM/yyyy",target="deletedAt"),
            @Mapping(source="entity.updatedBy",target="updatedBy"),
            @Mapping(source="entity.createdBy", target="createdBy"),
            @Mapping(source="entity.deletedBy", target="deletedBy"),
    })
    RoleFunctionalityDto toDto(RoleFunctionality entity);

    @IterableMapping(qualifiedBy = {FullTransformerQualifier.class})
    List<RoleFunctionalityDto> toDtos(List<RoleFunctionality> entities) throws ParseException;

    public default RoleFunctionalityDto toLiteDto(RoleFunctionality entity) {
        if (entity == null) {
            return null;
        }
        RoleFunctionalityDto dto = new RoleFunctionalityDto();
        dto.setId( entity.getId() );
        dto.setRoleId( entity.getRole().getId() );
        dto.setRoleLibelle(entity.getRole().getLibelle());
        dto.setFunctionalityId(entity.getFunctionality().getId());
        dto.setFunctionalityLibelle(entity.getFunctionality().getLibelle());
        return dto;
    }

    public default List<RoleFunctionalityDto> toLiteDtos(List<RoleFunctionality> entities) {
        if (entities == null || entities.stream().allMatch(o -> o == null)) {
            return null;
        }
        List<RoleFunctionalityDto> dtos = new ArrayList<RoleFunctionalityDto>();
        for (RoleFunctionality entity : entities) {
            dtos.add(toLiteDto(entity));
        }
        return dtos;
    }

    @Mappings({
            @Mapping(source = "dto.id", target = "id"),
            @Mapping(source = "role", target = "role"),
            @Mapping(source = "functionality", target = "functionality"),
            @Mapping(source="dto.updatedAt", dateFormat="dd/MM/yyyy",target="updatedAt"),
            @Mapping(source="dto.createdAt", dateFormat="dd/MM/yyyy",target="createdAt"),
            @Mapping(source="dto.deletedAt", dateFormat="dd/MM/yyyy",target="deletedAt"),
            @Mapping(source="dto.updatedBy",target="updatedBy"),
            @Mapping(source="dto.createdBy", target="createdBy"),
            @Mapping(source="dto.deletedBy", target="deletedBy"),
            @Mapping(source="dto.isDeleted", target="isDeleted"),
    })
    RoleFunctionality toEntity(RoleFunctionalityDto dto, Functionality functionality, Role role);
}
