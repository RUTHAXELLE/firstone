package ci.sgabs.gs.souscriptionApp.utils.dto.transformer;

import ci.sgabs.gs.souscriptionApp.dao.entity.*;
import ci.sgabs.gs.souscriptionApp.helper.contrat.FullTransformerQualifier;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.CarteDto;
import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

@Mapper
public interface CarteTransformer {

    CarteTransformer INSTANCE = Mappers.getMapper(CarteTransformer.class);

    @FullTransformerQualifier
    @Mappings({
            @Mapping(source = "entity.id", target = "id"),
            @Mapping(source = "entity.code", target = "code"),
            @Mapping(source = "entity.numeroCarte", target = "numeroCarte"),
            @Mapping(source = "entity.noms", target = "noms"),
            @Mapping(source = "entity.prenom", target = "prenom"),
            @Mapping(source = "entity.libelle", target = "libelle"),
            @Mapping(source = "entity.codeAgenceCarte", target = "codeAgenceCarte"),
            @Mapping(source = "entity.typeCarteLibelle", target = "typeCarteLibelle"),
            @Mapping(source = "entity.typeCarte.id", target = "typeCarteId"),
            @Mapping(source = "entity.groupe.id", target = "groupeId"),
            @Mapping(source = "entity.compte.id", target = "compteId"),
            @Mapping(source = "entity.compte.numero", target = "numeroCompte"),
            @Mapping(source = "entity.typeCarte.code", target = "codeTypeCarte"),
            @Mapping(source = "entity.groupe.code", target = "codeGroupe"),

            @Mapping(source="entity.updatedAt", dateFormat="dd/MM/yyyy",target="updatedAt"),
            @Mapping(source="entity.createdAt", dateFormat="dd/MM/yyyy",target="createdAt"),
            @Mapping(source="entity.deletedAt", dateFormat="dd/MM/yyyy",target="deletedAt"),
            @Mapping(source="entity.updatedBy",target="updatedBy"),
            @Mapping(source="entity.createdBy", target="createdBy"),
            @Mapping(source="entity.deletedBy", target="deletedBy"),
            @Mapping(source="entity.isDeleted", target="isDeleted"),
    })
    CarteDto toDto(Carte entity);
    @IterableMapping(qualifiedBy = {FullTransformerQualifier.class})
    List<CarteDto> toDtos(List<Carte> entities) throws ParseException;

    public default CarteDto toLiteDto(Carte entity) {
        if (entity == null) {
            return null;
        }
        CarteDto dto = new CarteDto();
        dto.setId( entity.getId() );
        dto.setCode( entity.getCode() );
        dto.setTypeCarteLibelle(entity.getTypeCarteLibelle());
        dto.setLibelle(entity.getLibelle());
        return dto;
    }

    public default List<CarteDto> toLiteDtos(List<Carte> entities) {
        if (entities == null || entities.stream().allMatch(o -> o == null)) {
            return null;
        }
        List<CarteDto> dtos = new ArrayList<CarteDto>();
        for (Carte entity : entities) {
            dtos.add(toLiteDto(entity));
        }
        return dtos;
    }

    @Mappings({
            @Mapping(source = "dto.id", target = "id"),
            @Mapping(source = "dto.code", target = "code"),
            @Mapping(source = "dto.numeroCarte", target = "numeroCarte"),
            @Mapping(source = "dto.noms", target = "noms"),
            @Mapping(source = "dto.prenom", target = "prenom"),
            @Mapping(source = "dto.libelle", target = "libelle"),
            @Mapping(source = "dto.codeAgenceCarte", target = "codeAgenceCarte"),
            @Mapping(source = "dto.typeCarteLibelle", target = "typeCarteLibelle"),

            @Mapping(source="dto.updatedAt", dateFormat="dd/MM/yyyy",target="updatedAt"),
            @Mapping(source="dto.createdAt", dateFormat="dd/MM/yyyy",target="createdAt"),
            @Mapping(source="dto.deletedAt", dateFormat="dd/MM/yyyy",target="deletedAt"),
            @Mapping(source="dto.updatedBy",target="updatedBy"),
            @Mapping(source="dto.createdBy", target="createdBy"),
            @Mapping(source="dto.deletedBy", target="deletedBy"),
            @Mapping(source="dto.isDeleted", target="isDeleted"),

            @Mapping(source = "typeCarte", target = "typeCarte"),
            @Mapping(source = "groupe", target = "groupe")
    })
    Carte toEntity(CarteDto dto, TypeCarte typeCarte, Groupe groupe,Compte compte);
}
