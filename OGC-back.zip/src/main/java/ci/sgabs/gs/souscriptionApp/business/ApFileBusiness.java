package ci.sgabs.gs.souscriptionApp.business;

import ci.sgabs.gs.souscriptionApp.dao.entity.ApFile;
import ci.sgabs.gs.souscriptionApp.dao.entity.Functionality;
import ci.sgabs.gs.souscriptionApp.dao.repository.ApFileRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.RoleFunctionalityRepository;
import ci.sgabs.gs.souscriptionApp.helper.contrat.IBasicBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.errors.TechnicalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.ApFileDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.FunctionalityDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.RoleDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.ApFileTransformer;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.FunctionalityTransformer;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Log
@Component
public class ApFileBusiness implements IBasicBusiness<Request<ApFileDto>, Response<ApFileDto>> {

    private Response<RoleDto> response;
    @Autowired
    private ApFileRepository apFileRepository;

    @Autowired
    private RoleFunctionalityRepository roleFunctionalityRepository;
    @Autowired
    private FunctionalError functionalError;
    @Autowired
    private TechnicalError technicalError;
    @Autowired
    private ExceptionUtils exceptionUtils;
    @Autowired
    private EntityManager em;
    @Autowired
    private RoleFunctionalityBusiness roleFunctionalityBusiness;
    private final SimpleDateFormat dateFormat;
    private final SimpleDateFormat dateTimeFormat;

    public ApFileBusiness() {

        dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    }

    @Override
    public Response<ApFileDto> create(Request<ApFileDto> request, Locale locale) throws ParseException {
        return null;
    }


    private Response<ApFileDto> blockDuplicationData(Request<ApFileDto> request, Locale locale, Response<RoleDto> response, List<RoleDto> itemsDtos) {
        return null;
    }


    @Override
    public Response<ApFileDto> update(Request<ApFileDto> request, Locale locale) throws ParseException {
        return null;
    }


    @Override
    public Response<ApFileDto> delete(Request<ApFileDto> request, Locale locale) {
        return null;
    }


    @Override
    public Response<ApFileDto> forceDelete(Request<ApFileDto> request, Locale locale) throws ParseException {

        return null;
    }

    @Override
    public Response<ApFileDto> getByCriteria(Request<ApFileDto> request, Locale locale) throws Exception {
        log.info("----begin get Role-----");
        Response<ApFileDto> response = new Response<ApFileDto>();
                //****** verification si le parametre d'ordre à été fourni, sinon nous mettons le paramètre à vide ********//
        if (Utilities.blank(request.getData().getOrderField())) {
            request.getData().setOrderField("");
        }
                //****** verification si le parametre direction à été fourni, sinon nous mettons le paramètre ascendant( du plus ancien au plus ressent) ********//
        if (Utilities.blank(request.getData().getOrderDirection())) {
            request.getData().setOrderDirection("asc");
        }
                //****** recuperation des entités en base *******//
        List<ApFile> items = apFileRepository.getByCriteria(request, em, locale);
        if (Utilities.isEmpty(items)) {
            response.setStatus(functionalError.DATA_EMPTY("Role", locale));
            response.setHasError(false);
            return response;
        }
        List<ApFileDto> itemsDto = Collections.synchronizedList(new ArrayList<ApFileDto>());
         itemsDto = (Utilities.isTrue(request.getIsSimpleLoading())) ? ApFileTransformer.INSTANCE.toLiteDtos(items) : ApFileTransformer.INSTANCE.toDtos(items);
        response.setItems(itemsDto);
        response.setCount(apFileRepository.count(request, em, locale));
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end get Role-----");
        return response;
    }

    private RoleDto getFullInfos(RoleDto dto, Integer size, Boolean isSimpleLoading,Locale locale) throws Exception {
        // put code here
          List<Functionality> functionalities = roleFunctionalityRepository.findFunctionalityByRoleId(dto.getId(), Boolean.FALSE);
          if(Utilities.isNotEmpty(functionalities)){
                  List<FunctionalityDto> functionalityDtos = FunctionalityTransformer.INSTANCE.toDtos(functionalities);
                  dto.setDatasFunctionalities(functionalityDtos);
          }
        if (Utilities.isTrue(isSimpleLoading)) {
            return dto;
        }
        if (size > 1) {
            return dto;
        }
        return dto;
    }
    
}
