package ci.sgabs.gs.souscriptionApp.utils.dto.entityDto;

import ci.sgabs.gs.souscriptionApp.helper.searchFunctions.SearchParam;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;
import lombok.ToString;

import java.util.Collection;
import java.util.List;

@Data
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL) @JsonPropertyOrder(alphabetic = true)
public class TypeCarteDto {

    private Integer id;
    private String code;
    private String libelle;
    private String description;
    private Boolean isDeleted;
    private String createdAt;
    private String updatedAt;
    private String deletedAt;
    private Integer createdBy;
    private Integer updatedBy;
    private Integer deletedBy;
    private String typeGen;
    private String codeProduit;
    private String identifiantProduit;
    private String identifiantGroupe;
    private String codeTarif;
    private String accCountry;
    private String bin;
    private String typeCarte;
    private String produit;
    private String codeBanque;
    private String identifiantInstitution;
    private String business;
    private String devise;
    private String pays;
    private String type;




    /// SEARCH PARAM//
    private SearchParam<Integer> idParam;
    private SearchParam<String> codeParam;
    private SearchParam<String>   libelleParam;
    private SearchParam<Boolean> isDeletedParam;
    private SearchParam<String> createdAtParam;
    private SearchParam<String> updatedAtParam;
    private SearchParam<String> deletedAtParam;
    private SearchParam<Integer> createdByParam;
    private SearchParam<Integer> updatedByParam;
    private SearchParam<Integer> deletedByParam;

    private SearchParam<String> typeGenParam;
    private SearchParam<String> codeProduitParam;
    private SearchParam<String> identifiantProduitParam;
    private SearchParam<String> identifiantGroupeParam;
    private SearchParam<String> codeTarifParam;
    private SearchParam<String> accCountryParam;
    private SearchParam<String> binParam;
    private SearchParam<String> typeCarteParam;
    private SearchParam<String> produitParam;
    private SearchParam<String> codeBanqueParam;
    private SearchParam<String> identifiantInstitutionParam;
    private SearchParam<String> businessParam;
    private SearchParam<String> deviseParam;
    private SearchParam<String> paysParam;
    private SearchParam<String> typeParam;
    // order param
    private String orderField;
    private String orderDirection;
    private List<TypeCompteDto> datasTypeCompte;

}
