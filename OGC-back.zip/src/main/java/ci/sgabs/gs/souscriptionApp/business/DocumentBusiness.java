package ci.sgabs.gs.souscriptionApp.business;

import ci.sgabs.gs.souscriptionApp.dao.entity.Client;
import ci.sgabs.gs.souscriptionApp.dao.entity.Document;
import ci.sgabs.gs.souscriptionApp.dao.repository.ClientRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.DocumentRepository;
import ci.sgabs.gs.souscriptionApp.helper.contrat.IBasicBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.errors.TechnicalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.helper.validation.Validate;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.DocumentDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.DocumentTransformer;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Log
@Component
public class DocumentBusiness implements IBasicBusiness<Request<DocumentDto>, Response<DocumentDto>> {

    private Response<DocumentDto> response;
    @Autowired
    private DocumentRepository documentRepository;
    @Autowired
    private ClientRepository clientRepository;
    @Autowired
    private FunctionalError functionalError;
    @Autowired
    private TechnicalError technicalError;
    @Autowired
    private ExceptionUtils exceptionUtils;
    @Autowired
    private EntityManager em;
    private final SimpleDateFormat dateFormat;
    private final SimpleDateFormat dateTimeFormat;

    public DocumentBusiness() {
        dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    }
    
    @Override
    public Response<DocumentDto> create(Request<DocumentDto> request, Locale locale) throws Exception {

        log.info("----begin create Document-----");

        Response<DocumentDto> response = new Response<DocumentDto>();
        List<Document> items = new ArrayList<Document>();

        for(DocumentDto dto : request.getDatas()){

            //******* Definition et verification des parametres obligatoires ******//

            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("code", dto.getCode());
            fieldsToVerify.put("naturePiece", dto.getNaturePiece());
            fieldsToVerify.put("piece", dto.getPiece());
            fieldsToVerify.put("clientId", dto.getClientId());
            
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                
                return response;
            }

            //***** Verification s'il existe deja un document en base avec le meme code *********//

            Document existingEntity = null;
            existingEntity = documentRepository.findByCode(dto.getCode(), false); //verification du code
            
            if (existingEntity != null) {
                
                response.setStatus(functionalError.DATA_EXIST("Document code -> " + dto.getCode(), locale));
                response.setHasError(true);
                
                return response;
            }


            //***** Verification s'il existe un client en base avec le clientId fourni *********//

            Client existingClient = null;
            
            if (Utilities.isValidID(dto.getClientId())) {
                
                existingClient = clientRepository.findOne(dto.getClientId(), false);
                
                if (existingClient == null) {
                    
                    response.setStatus(functionalError.DATA_NOT_EXIST("Client ClientID -> " + dto.getClientId(), locale));
                    response.setHasError(true);
                    
                    return response;
                }
                
            }

            //***** Verification si dans la liste à inséré il n'y a pas de duplication de code *********//

            if (items.stream().anyMatch(a -> a.getCode().equalsIgnoreCase(dto.getCode()))) { //verification code
                
                response.setStatus(functionalError.DATA_DUPLICATE(" code ", locale));
                response.setHasError(true);
                
                return response;
            }
            

            Document entityToSave = DocumentTransformer.INSTANCE.toEntity(dto, existingClient);
            entityToSave.setIsDeleted(false);
            entityToSave.setCreatedAt(Utilities.getCurrentDate());
            entityToSave.setCreatedBy(request.userID);
            items.add(entityToSave);
        }

        //***** insertion en base de données *********//

        if (!items.isEmpty()) {
            
            List<Document> itemsSaved = null;
            itemsSaved = documentRepository.saveAll((Iterable<Document>) items);
            
            if (itemsSaved == null) {
                
                response.setStatus(functionalError.SAVE_FAIL("Document", locale));
                response.setHasError(true);
                
                return response;
            }
            
            List<DocumentDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading())) ? DocumentTransformer.INSTANCE.toLiteDtos(itemsSaved) : DocumentTransformer.INSTANCE.toDtos(itemsSaved);

            response.setItems(itemsDto);
            response.setHasError(false);
            response.setStatus(functionalError.SUCCESS("", locale));
        }
        
        log.info("----end create Document-----");
        
        return response;
    }

    @Override
    public Response<DocumentDto> update(Request<DocumentDto> request, Locale locale) throws ParseException {

        log.info("----begin update Document -----");

        Response<DocumentDto> response = new Response<DocumentDto>();
        List<Document> items = new ArrayList<Document>();

        for(DocumentDto dto : request.getDatas()){

            //******* Definition et verification des parametres obligatoires ******//

            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                
                return response;
            }

            //***** Verification s'il existe un document en base avec l'id fourni *********//

            Document entityToSave = null;
            entityToSave = documentRepository.findOne(dto.getId(), false);
            
            if (entityToSave == null) {
                
                response.setStatus(functionalError.DATA_NOT_EXIST("Document id -> " + dto.getId(), locale));
                response.setHasError(true);
                
                return response;
            }
            //***** Verification s'il existe deja un document en base ou dans la liste à inséré, avec le meme code *********//

            Integer entityToSaveId = entityToSave.getId();
            DocumentDto entityToSaveDto = DocumentTransformer.INSTANCE.toDto(entityToSave);
            if (Utilities.isNotBlank(dto.getCode()) && !dto.getCode().equals(entityToSave.getCode())) { //verify code
                
                Document existingEntity = documentRepository.findByCode(dto.getCode(), false);
                
                if (existingEntity != null && !existingEntity.getId().equals(entityToSave.getId())) {
                    
                    response.setStatus(functionalError.DATA_EXIST("Document -> " + dto.getCode(), locale));
                    response.setHasError(true);
                    
                    return response;
                }
                
                if (items.stream().anyMatch(a -> a.getCode().equalsIgnoreCase(dto.getCode()) && !a.getId().equals(entityToSaveId))) {
                    
                    response.setStatus(functionalError.DATA_DUPLICATE("Tentative de duplication du code '" + dto.getCode() + "' pour les Document", locale));
                    response.setHasError(true);
                    
                    return response;
                }
                
                entityToSaveDto.setCode(dto.getCode());
            }

            //***** Verification et modification des autres attributs fournis *********//
            if (Utilities.isNotBlank(dto.getNaturePiece()) && !dto.getNaturePiece().equals(entityToSave.getNaturePiece())) {
                entityToSaveDto.setNaturePiece(dto.getNaturePiece());
            }
            if (Utilities.isNotBlank(dto.getPiece()) && !dto.getPiece().equals(entityToSave.getPiece())) {
                entityToSaveDto.setPiece(dto.getPiece());
            }

            //***** Verification s'il existe un client en base avec le clientId fourni *********//

            Client existingClient = null;

            if (Utilities.isValidID(dto.getClientId()) && !entityToSave.getClient().getId().equals(dto.getClientId())) {

                existingClient = clientRepository.findOne(dto.getClientId(), false);

                if (existingClient == null) {

                    response.setStatus(functionalError.DATA_NOT_EXIST("Client ClientID -> " + dto.getClientId(), locale));
                    response.setHasError(true);

                    return response;
                }

            }
            

            Document userEntity = DocumentTransformer.INSTANCE.toEntity(entityToSaveDto, existingClient);
            userEntity.setUpdatedAt(Utilities.getCurrentDate());
            userEntity.setUpdatedBy(request.userID);
            items.add(userEntity);
        }

        //***** insertion en base de données *********//

        if (!items.isEmpty()) {
            
            List<Document> itemsSaved = null;
            itemsSaved = documentRepository.saveAll((Iterable<Document>) items);
            
            if (itemsSaved == null) {
                
                response.setStatus(functionalError.SAVE_FAIL("Document", locale));
                response.setHasError(true);
                
                return response;
            }
            
            List<DocumentDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading())) ? DocumentTransformer.INSTANCE.toLiteDtos(itemsSaved) : DocumentTransformer.INSTANCE.toDtos(itemsSaved);

            response.setItems(itemsDto);
            response.setHasError(false);
            response.setStatus(functionalError.SUCCESS("", locale));
        }
        
        log.info("end Document update");
        
        return response;
    }

    @Override
    public Response<DocumentDto> delete(Request<DocumentDto> request, Locale locale) {

        log.info("----begin update Document-----");

        Response<DocumentDto> response = new Response<DocumentDto>();
        List<Document> items = new ArrayList<Document>();

        for(DocumentDto dto : request.getDatas()){

            //******* Definition et verification des parametres obligatoires ******//

            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());

            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {

                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);

                return response;
            }

            //***** Verification s'il existe un utilisateur en base avec l'id fourni *********//

            Document existingEntity = null;
            existingEntity = documentRepository.findOne(dto.getId(), false);

            if (existingEntity == null) {

                response.setStatus(functionalError.DATA_NOT_EXIST("Document id -> " + dto.getId(), locale));
                response.setHasError(true);

                return response;
            }

            existingEntity.setIsDeleted(true);
            existingEntity.setDeletedAt(Utilities.getCurrentDate());
            existingEntity.setDeletedBy(request.userID);
            items.add(existingEntity);
        }

        if (!items.isEmpty()) {

            response.setHasError(false);
            response.setStatus(functionalError.SUCCESS("", locale));
        }

        log.info("----end delete User-----");

        return response;
    }

    @Override
    public Response<DocumentDto> forceDelete(Request<DocumentDto> request, Locale locale) throws ParseException {
        return null;
    }

    @Override
    public Response<DocumentDto> getByCriteria(Request<DocumentDto> request, Locale locale) throws Exception {

        log.info("----begin get Document-----");

        Response<DocumentDto> response = new Response<DocumentDto>();

        //****** verification si le parametre d'ordre à été fourni, sinon nous mettons le paramètre à vide ********//

        if (Utilities.blank(request.getData().getOrderField())) {
            request.getData().setOrderField("");
        }

        //****** verification si le parametre direction à été fourni, sinon nous mettons le paramètre ascendant( du plus ancien au plus ressent) ********//

        if (Utilities.blank(request.getData().getOrderDirection())) {
            request.getData().setOrderDirection("asc");
        }

        //****** recuperation des entités en base *******//

        List<Document> items = documentRepository.getByCriteria(request, em, locale);

        if (Utilities.isEmpty(items)) {

            response.setStatus(functionalError.DATA_EMPTY("Document", locale));
            response.setHasError(false);

            return response;
        }

        List<DocumentDto> itemsDto = DocumentTransformer.INSTANCE.toDtos(items);


        response.setItems(itemsDto);
        response.setCount(documentRepository.count(request, em, locale));
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        log.info("----end get Document-----");

        return response;
    }
}
