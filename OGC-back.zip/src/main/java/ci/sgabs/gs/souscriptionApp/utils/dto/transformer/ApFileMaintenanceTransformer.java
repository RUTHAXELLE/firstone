package ci.sgabs.gs.souscriptionApp.utils.dto.transformer;

import ci.sgabs.gs.souscriptionApp.dao.entity.ApFile;
import ci.sgabs.gs.souscriptionApp.dao.entity.ApFileMaintenance;
import ci.sgabs.gs.souscriptionApp.dao.entity.Role;
import ci.sgabs.gs.souscriptionApp.helper.contrat.FullTransformerQualifier;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.ApFileDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.ApFileMaintenanceDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.RoleDto;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

@Mapper
public interface ApFileMaintenanceTransformer {

    ApFileMaintenanceTransformer INSTANCE = Mappers.getMapper(ApFileMaintenanceTransformer.class);

    @FullTransformerQualifier
    @Mappings({
            @Mapping(source = "entity.id", target = "id"),
            @Mapping(source = "entity.code", target = "code"),
            @Mapping(source = "entity.libelle", target = "libelle"),
            @Mapping(source = "entity.fileName", target = "fileName"),
            @Mapping(source = "entity.updatedAt", dateFormat = "dd/MM/yyyy HH:mm:ss", target = "updatedAt"),
            @Mapping(source = "entity.createdAt", dateFormat = "dd/MM/yyyy HH:mm", target = "createdAt"),
            @Mapping(source = "entity.deletedAt", dateFormat = "dd/MM/yyyy HH:mm:ss", target = "deletedAt"),
            @Mapping(source = "entity.updatedBy", target = "updatedBy"),
            @Mapping(source = "entity.createdBy", target = "createdBy"),
            @Mapping(source = "entity.typeOperation", target = "typeOperation"),
            @Mapping(source = "entity.deletedBy", target = "deletedBy"),
    })
    ApFileMaintenanceDto toDto(ApFileMaintenance entity);

    @IterableMapping(qualifiedBy = {FullTransformerQualifier.class})
    List<ApFileMaintenanceDto> toDtos(List<ApFileMaintenance> entities) throws ParseException;

    public default ApFileMaintenanceDto toLiteDto(ApFileMaintenance entity) {
        if (entity == null) {
            return null;
        }
        ApFileMaintenanceDto dto = new ApFileMaintenanceDto();
        dto.setId(entity.getId());
        dto.setCode(entity.getCode());
        dto.setLibelle(entity.getLibelle());
        return dto;
    }

    public default List<ApFileMaintenanceDto> toLiteDtos(List<ApFileMaintenance> entities) {
        if (entities == null || entities.stream().allMatch(o -> o == null)) {
            return null;
        }
        List<ApFileMaintenanceDto> dtos = new ArrayList<ApFileMaintenanceDto>();
        for (ApFileMaintenance entity : entities) {
            dtos.add(toLiteDto(entity));
        }
        return dtos;
    }

    @InheritInverseConfiguration
    Role toEntity(RoleDto dto);
}
