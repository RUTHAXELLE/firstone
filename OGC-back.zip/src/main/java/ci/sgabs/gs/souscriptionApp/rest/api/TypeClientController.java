package ci.sgabs.gs.souscriptionApp.rest.api;

import ci.sgabs.gs.souscriptionApp.business.TypeClientBusiness;
import ci.sgabs.gs.souscriptionApp.business.TypeCompteBusiness;
import ci.sgabs.gs.souscriptionApp.business.TypeCompteTypeCarteBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.enums.FunctionalityEnum;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.status.StatusCode;
import ci.sgabs.gs.souscriptionApp.helper.status.StatusMessage;
import ci.sgabs.gs.souscriptionApp.rest.fact.ControllerFactory;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.TypeClientDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.TypeCompteDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.TypeCompteTypeCarteDto;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.CannotCreateTransactionException;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Locale;

@Log
@CrossOrigin("*")
@RestController
@RequestMapping(value="/typeClients")
public class TypeClientController {

    @Autowired
    private ControllerFactory<TypeClientDto> controllerFactory;
    @Autowired
    private TypeClientBusiness typeClientBusiness;


    @Autowired
    private FunctionalError functionalError;
    @Autowired
    private ExceptionUtils exceptionUtils;
    @Autowired
    private HttpServletRequest requestBasic;
    @Autowired
    private TypeCompteTypeCarteBusiness typeCompteTypeCarteBusiness;



    @RequestMapping(value="",method= RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<TypeClientDto> create(@RequestBody Request<TypeClientDto> request) {
        log.info("start method /TypeClient/create");
        Response<TypeClientDto> response = controllerFactory.create(typeClientBusiness, request, FunctionalityEnum.CREATE_TYPECOMPTE);
        log.info("end method /TypeCompte/create");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.PUT,consumes = {"application/json"},produces={"application/json"})
    public Response<TypeClientDto> update(@RequestBody Request<TypeClientDto> request) {
        log.info("start method /TypeClient/update");
        Response<TypeClientDto> response = controllerFactory.update(typeClientBusiness, request, FunctionalityEnum.UPDATE_TYPECOMPTE);
        log.info("end method /TypeClient/update");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.DELETE,consumes = {"application/json"},produces={"application/json"})
    public Response<TypeClientDto> delete(@RequestBody Request<TypeClientDto> request) {
        log.info("start method /TypeClient/delete");
        Response<TypeClientDto> response = controllerFactory.delete(typeClientBusiness, request, FunctionalityEnum.DELETE_TYPECOMPTE);
        log.info("end method /TypeClient/delete");
        return response;
    }

    @RequestMapping(value="/getByCriteria",method=RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<TypeClientDto> getByCriteria(@RequestBody Request<TypeClientDto> request) {
        log.info("start method /TypeClient/getByCriteria");
        Response<TypeClientDto> response = controllerFactory.getByCriteria(typeClientBusiness, request, FunctionalityEnum.VIEW_TYPECOMPTE);
        log.info("end method /TypeClient/getByCriteria");
        return response;
    }

}
