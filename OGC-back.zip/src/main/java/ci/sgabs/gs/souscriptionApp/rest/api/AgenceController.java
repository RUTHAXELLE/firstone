package ci.sgabs.gs.souscriptionApp.rest.api;

import ci.sgabs.gs.souscriptionApp.business.AgenceBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.enums.FunctionalityEnum;
import ci.sgabs.gs.souscriptionApp.rest.fact.ControllerFactory;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.AgenceDto;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@Log
@CrossOrigin("*")
@RestController
@RequestMapping(value="/agences")
public class AgenceController {

    @Autowired
    private ControllerFactory<AgenceDto> controllerFactory;
    @Autowired
    private AgenceBusiness agenceBusiness ;


    @RequestMapping(value="",method= RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<AgenceDto> create(@RequestBody Request<AgenceDto> request) {
        log.info("start method create");
        Response<AgenceDto> response = controllerFactory.create(agenceBusiness, request, FunctionalityEnum.CREATE_USER);
        log.info("end method create");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.PUT,consumes = {"application/json"},produces={"application/json"})
    public Response<AgenceDto> update(@RequestBody Request<AgenceDto> request) {
        log.info("start method update");
        Response<AgenceDto> response = controllerFactory.update(agenceBusiness, request, FunctionalityEnum.UPDATE_USER);
        log.info("end method update");
        return response;
    }


    @RequestMapping(value="",method=RequestMethod.DELETE,consumes = {"application/json"},produces={"application/json"})
    public Response<AgenceDto> delete(@RequestBody Request<AgenceDto> request) {
        log.info("start method delete");
        Response<AgenceDto> response = controllerFactory.delete(agenceBusiness, request, FunctionalityEnum.DELETE_USER);
        log.info("end method delete");
        return response;
    }


    @RequestMapping(value="/getByCriteria",method=RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<AgenceDto> getByCriteria(@RequestBody Request<AgenceDto> request) {
        log.info("start method /agences/getByCriteria");
        Response<AgenceDto> response = controllerFactory.getByCriteria(agenceBusiness, request, FunctionalityEnum.VIEW_USER);
        log.info("end method /agences/getByCriteria");
        return response;
    }


}
