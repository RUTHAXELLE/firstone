package ci.sgabs.gs.souscriptionApp.helper.validation;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

@Data
@ToString
@NoArgsConstructor
public class Validate {

    private String field;
    private boolean good;
    private static Validate validate = new Validate();
    private static Logger slf4jLogger = LoggerFactory.getLogger(Validate.class);

    public static Validate getValidate() {
        return validate;
    }


    public static Validate RequiredValue(Map<String, Object> listAverifier) {
        for (Map.Entry<String, Object> item : listAverifier.entrySet()) {
            if (item.getValue() instanceof List<?>) {
                validate.setGood(((List<?>) item.getValue()) == null ? false
                        : ((List<?>) item.getValue()).stream().anyMatch(v -> v != null && !v.toString().isEmpty()));
            } else {
                validate.setGood(item.getValue() == null ? false : !item.getValue().toString().isEmpty());
            }
            if (!validate.isGood()) {
                validate.setField(item.getKey());
                break;
            }
        }
        return validate;
    }

}
