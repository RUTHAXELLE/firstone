package ci.sgabs.gs.souscriptionApp.rest.api;

import ci.sgabs.gs.souscriptionApp.business.CarteBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.enums.FunctionalityEnum;
import ci.sgabs.gs.souscriptionApp.rest.fact.ControllerFactory;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.CarteDto;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Log
@CrossOrigin("*")
@RestController
@RequestMapping(value="/cartes")
public class CarteController {


    @Autowired
    private ControllerFactory<CarteDto> controllerFactory;
    @Autowired
    private CarteBusiness carteBusiness;

    @RequestMapping(value="",method= RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<CarteDto> create(@RequestBody Request<CarteDto> request) {
        log.info("start method /Carte/create");
        Response<CarteDto> response = controllerFactory.create(carteBusiness, request, FunctionalityEnum.CREATE_CARTE);
        log.info("end method /Carte/create");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.PUT,consumes = {"application/json"},produces={"application/json"})
    public Response<CarteDto> update(@RequestBody Request<CarteDto> request) {
        log.info("start method /Cartes/update");
        Response<CarteDto> response = controllerFactory.update(carteBusiness, request, FunctionalityEnum.UPDATE_CARTE);
        log.info("end method /Carte/update");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.DELETE,consumes = {"application/json"},produces={"application/json"})
    public Response<CarteDto> delete(@RequestBody Request<CarteDto> request) {
        log.info("start method /Carte/delete");
        Response<CarteDto> response = controllerFactory.delete(carteBusiness, request, FunctionalityEnum.DELETE_CARTE);
        log.info("end method /Carte/delete");
        return response;
    }

    @RequestMapping(value="/forceDelete",method=RequestMethod.DELETE,consumes = {"application/json"},produces={"application/json"})
    public Response<CarteDto> forceDelete(@RequestBody Request<CarteDto> request) {
        log.info("start method /Carte/forceDelete");
        Response<CarteDto> response = controllerFactory.forceDelete(carteBusiness, request, FunctionalityEnum.DELETE_CARTE);
        log.info("end method /Carte/forceDelete");
        return response;
    }

    @RequestMapping(value="/getByCriteria",method=RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<CarteDto> getByCriteria(@RequestBody Request<CarteDto> request) {
        log.info("start method /Carte/getByCriteria");
        Response<CarteDto> response = controllerFactory.getByCriteria(carteBusiness, request, FunctionalityEnum.VIEW_CARTE);
        log.info("end method /Carte/getByCriteria");
        return response;
    }

}
