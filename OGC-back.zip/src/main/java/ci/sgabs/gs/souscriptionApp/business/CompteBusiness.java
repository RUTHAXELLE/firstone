package ci.sgabs.gs.souscriptionApp.business;

import ci.sgabs.gs.souscriptionApp.dao.entity.Agence;
import ci.sgabs.gs.souscriptionApp.dao.entity.Client;
import ci.sgabs.gs.souscriptionApp.dao.entity.Compte;
import ci.sgabs.gs.souscriptionApp.dao.entity.TypeCompte;
import ci.sgabs.gs.souscriptionApp.dao.repository.AgenceRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.ClientRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.CompteRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.TypeCompteRepository;
import ci.sgabs.gs.souscriptionApp.helper.contrat.IBasicBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.errors.TechnicalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.helper.validation.Validate;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.CompteDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.CompteTransformer;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Log
@Component
public class CompteBusiness implements IBasicBusiness<Request<CompteDto>, Response<CompteDto>> {

    private Response<CompteDto> response;
    
    @Autowired
    private CompteRepository compteRepository;
    @Autowired
    private TypeCompteRepository typeCompteRepository;
    @Autowired
    private AgenceRepository agenceRepository;
    @Autowired
    private ClientRepository clientRepository;
    @Autowired
    private FunctionalError functionalError;
    @Autowired
    private TechnicalError technicalError;
    @Autowired
    private ExceptionUtils exceptionUtils;
    
    @Autowired
    private EntityManager em;
    
    private final SimpleDateFormat dateFormat;
    private final SimpleDateFormat dateTimeFormat;

    public CompteBusiness() {
        dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    }
    
    @Override
    public Response<CompteDto> create(Request<CompteDto> request, Locale locale) throws Exception {
        log.info("----begin create Compte-----");
        Response<CompteDto> response = new Response<CompteDto>();
        List<Compte> items = new ArrayList<Compte>();
        //Verififcation des champs obligatoires
        List<CompteDto> itemsDtos =  Collections.synchronizedList(new ArrayList<CompteDto>());
        for(CompteDto dto: request.getDatas()){
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("numero", dto.getNumero());
          //  fieldsToVerify.put("description", dto.getDescription());
            fieldsToVerify.put("clientId", dto.getClientId());
            fieldsToVerify.put("agenceId", dto.getAgenceId());
            fieldsToVerify.put("typeCompteId", dto.getTypeCompteId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            if (itemsDtos.stream().anyMatch(a -> a.getNumero().equalsIgnoreCase(dto.getNumero()))) { //verification numero
                response.setStatus(functionalError.DATA_DUPLICATE(" numero ", locale));
                response.setHasError(true);
                return response;
            }
            itemsDtos.add(dto);
        }
        //Verification de doublon et existence des entités attachées au compte
        for(CompteDto dto : itemsDtos){
            Compte existingEntity = null;
            existingEntity = compteRepository.findByNumero(dto.getNumero(), false);
            if (existingEntity != null) {
                response.setStatus(functionalError.DATA_EXIST("Compte numero -> " + dto.getNumero(), locale));
                response.setHasError(true);
                return response;
            }
            //Verification du client attaché
            Client existingClient = null;
            if (Utilities.isValidID(dto.getClientId())) {
                existingClient = clientRepository.findOne(dto.getClientId(), false);
                if (existingClient == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("Client ClientID -> " + dto.getClientId(), locale));
                    response.setHasError(true);
                    return response;
                }
            }
            //Verification de l'agence attachée
            Agence existingAgence = null;
            if (Utilities.isValidID(dto.getAgenceId())) {
                existingAgence = agenceRepository.findOne(dto.getAgenceId(), false);
                if (existingAgence == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("Agence AgenceID -> " + dto.getAgenceId(), locale));
                    response.setHasError(true);
                    return response;
                }
            }
            //Verification du type compte attaché
            TypeCompte existingTypeCompte = null;
            if (Utilities.isValidID(dto.getTypeCompteId())) {
                existingTypeCompte = typeCompteRepository.findOne(dto.getTypeCompteId(), false);
                if (existingTypeCompte == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("TypeCompte TypeCompteID -> " + dto.getTypeCompteId(), locale));
                    response.setHasError(true);
                    return response;
                }
            }
            //Transformation du CompteDto en compte entity
            Compte entityToSave = CompteTransformer.INSTANCE.toEntity(dto, existingClient, existingTypeCompte, existingAgence);
            entityToSave.setIsDeleted(false);
            entityToSave.setCreatedAt(Utilities.getCurrentDate());
            entityToSave.setCreatedBy(request.userID);
            entityToSave.setIsActif(Boolean.TRUE);
            items.add(entityToSave);
        }

        //Verification des items
        if(items == null || items.isEmpty()){
            response.setStatus(functionalError.DATA_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }

        //Persistence
        List<Compte> itemsSaved = null;
        itemsSaved = compteRepository.saveAll((Iterable<Compte>) items);

        if (itemsSaved == null) {
            response.setStatus(functionalError.SAVE_FAIL("Compte", locale));
            response.setHasError(true);
            return response;
        }

        //Transformtation des Comptes crées en CompteDto
        List<CompteDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                            ? CompteTransformer.INSTANCE.toLiteDtos(itemsSaved)
                            : CompteTransformer.INSTANCE.toDtos(itemsSaved);

        //Envoie de la reponse
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        return response;

    }

    @Override
    public Response<CompteDto> update(Request<CompteDto> request, Locale locale) throws ParseException {
        log.info("----begin update Compte -----");
        Response<CompteDto> response = new Response<CompteDto>();
        List<Compte> items = new ArrayList<Compte>();
        //Verification des datas
        if (request.getDatas() == null || request.getDatas().isEmpty()){
            response.setStatus(functionalError.DATA_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }
        //Verification des champs obligatoires
        List<CompteDto> itemsDtos = Collections.synchronizedList(new ArrayList<CompteDto>());
        for(CompteDto dto : request.getDatas()) {
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            if (itemsDtos.stream().anyMatch(a -> a.getId().equals(dto.getId()))) { //verification numero
                response.setStatus(functionalError.DATA_DUPLICATE(" id ", locale));
                response.setHasError(true);
                return response;
            }
            itemsDtos.add(dto);
        }

        //Verification des entités attachées
        for(CompteDto dto : request.getDatas()){
            Compte entityToSave = null;
            entityToSave = compteRepository.findOne(dto.getId(), false);
            if (entityToSave == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Compte id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }
            //Verification du client attaché
            Client existingClient = null;
            if (Utilities.isValidID(dto.getClientId()) && !entityToSave.getClient().getId().equals(dto.getClientId())) {
                existingClient = clientRepository.findOne(dto.getClientId(), false);
                if (existingClient == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("Client ClientID -> " + dto.getClientId(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setClient(existingClient);
            }
            // Verification de l'agence attachée
            Agence existingAgence = null;
            if (Utilities.isValidID(dto.getAgenceId()) && !entityToSave.getAgence().getId().equals(dto.getAgenceId())) {

                existingAgence = agenceRepository.findOne(dto.getAgenceId(), false);
                if (existingAgence == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("Agence AgenceID -> " + dto.getAgenceId(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setAgence(existingAgence);
            }

            //Verification du compte type attaché
            TypeCompte existingTypeCompte = null;
            if (Utilities.isValidID(dto.getTypeCompteId())&& !entityToSave.getTypeCompte().getId().equals(dto.getTypeCompteId())) {

                existingTypeCompte = typeCompteRepository.findOne(dto.getTypeCompteId(), false);
                if (existingTypeCompte == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("TypeCompte TypeCompteID -> " + dto.getTypeCompteId(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setTypeCompte(existingTypeCompte);
            }

            //Verficationn et modification des champs du compte
            if (Utilities.isNotBlank(dto.getNumero()) && !dto.getNumero().equals(entityToSave.getNumero())) { //verify numero=
                Compte existingEntity = compteRepository.findByNumero(dto.getNumero(), false);
                if (existingEntity != null && !existingEntity.getId().equals(entityToSave.getId())) {
                    response.setStatus(functionalError.DATA_EXIST("Compte -> " + dto.getNumero(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setNumero(dto.getNumero());
            }
            if(dto.getIsActif() != null){
                   entityToSave.setIsActif(dto.getIsActif());
            }
            //Propriété description
            if (Utilities.isNotBlank(dto.getDescription()) && !dto.getDescription().equals(entityToSave.getDescription())) {
                entityToSave.setDescription(dto.getDescription());
            }
            entityToSave.setUpdatedAt(Utilities.getCurrentDate());
            entityToSave.setUpdatedBy(request.userID);
            items.add(entityToSave);
        }
        //Verification des items
       if(Utilities.isNotEmpty(items)){
           List<Compte> comptes = compteRepository.saveAll(items);
           //Envoie de la reponse
           List<CompteDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                   ? CompteTransformer.INSTANCE.toLiteDtos(items)
                   : CompteTransformer.INSTANCE.toDtos(items);
           response.setItems(itemsDto);
           response.setHasError(false);
           response.setStatus(functionalError.SUCCESS("", locale));
       }else{
            response.setStatus(functionalError.DATA_EXIST("",locale));
       }
        log.info("end Compte update");
        return response;
    }

    @Override
    public Response<CompteDto> delete(Request<CompteDto> request, Locale locale) {

        log.info("----begin delete Compte-----");

        Response<CompteDto> response = new Response<CompteDto>();
        List<Compte> items = new ArrayList<Compte>();

        //Verification des datas
        if (request.getDatas() == null || request.getDatas().isEmpty()){
            response.setStatus(functionalError.DATA_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }

        //Verification des champs obligatoires
        for(CompteDto dto : request.getDatas()) {

            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());

            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }

        }

        //Supression logique des comptes
        for(CompteDto dto : request.getDatas()){

            Compte existingEntity = null;
            existingEntity = compteRepository.findOne(dto.getId(), false);

            if (existingEntity == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Compte id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }

            //Informations d'historisation
            existingEntity.setIsDeleted(true);
            existingEntity.setDeletedAt(Utilities.getCurrentDate());
            existingEntity.setDeletedBy(request.userID);

            items.add(existingEntity);

        }

        //Verification des items
        if(items == null || items.isEmpty()){
            response.setStatus(functionalError.DATA_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }

        //ENvoie de la reponse
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        log.info("----end delete Compte-----");

        return response;

    }

    @Override
    public Response<CompteDto> forceDelete(Request<CompteDto> request, Locale locale) throws ParseException {
        return null;
    }

    @Override
    public Response<CompteDto> getByCriteria(Request<CompteDto> request, Locale locale) throws Exception {

        log.info("----begin get Compte-----");

        Response<CompteDto> response = new Response<CompteDto>();

        //verification si le parametre d'ordre à été fourni, sinon nous mettons le paramètre à vide
        if (Utilities.blank(request.getData().getOrderField())) {
            request.getData().setOrderField("");
        }

        //verification si le parametre direction à été fourni, sinon nous mettons le paramètre ascendant( du plus ancien au plus ressent)
        if (Utilities.blank(request.getData().getOrderDirection())) {
            request.getData().setOrderDirection("asc");
        }

        //recuperation des entités en base
        List<Compte> items = compteRepository.getByCriteria(request, em, locale);
        if (Utilities.isEmpty(items)) {
            response.setStatus(functionalError.DATA_EMPTY("Compte", locale));
            response.setHasError(false);
            return response;
        }
        //Transformation
        List<CompteDto> itemsDto = CompteTransformer.INSTANCE.toDtos(items);
        //Envoie de la reponse
        response.setItems(itemsDto);
        response.setCount(compteRepository.count(request, em, locale));
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        return response;

    }

}
