package ci.sgabs.gs.souscriptionApp.rest.api;

import ci.sgabs.gs.souscriptionApp.business.CompteBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.enums.FunctionalityEnum;
import ci.sgabs.gs.souscriptionApp.rest.fact.ControllerFactory;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.CompteDto;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Log
@CrossOrigin("*")
@RestController
@RequestMapping(value="/comptes")
public class CompteController {


    @Autowired
    private ControllerFactory<CompteDto> controllerFactory;
    @Autowired
    private CompteBusiness compteBusiness;

    @RequestMapping(value="",method= RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<CompteDto> create(@RequestBody Request<CompteDto> request) {
        log.info("start method /Compte/create");
        Response<CompteDto> response = controllerFactory.create(compteBusiness, request, FunctionalityEnum.CREATE_COMPTE);
        log.info("end method /Compte/create");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.PUT,consumes = {"application/json"},produces={"application/json"})
    public Response<CompteDto> update(@RequestBody Request<CompteDto> request) {
        log.info("start method /Comptes/update");
        Response<CompteDto> response = controllerFactory.update(compteBusiness, request, FunctionalityEnum.UPDATE_COMPTE);
        log.info("end method /Compte/update");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.DELETE,consumes = {"application/json"},produces={"application/json"})
    public Response<CompteDto> delete(@RequestBody Request<CompteDto> request) {
        log.info("start method /Compte/delete");
        Response<CompteDto> response = controllerFactory.delete(compteBusiness, request, FunctionalityEnum.DELETE_COMPTE);
        log.info("end method /Compte/delete");
        return response;
    }

    @RequestMapping(value="/forceDelete",method=RequestMethod.DELETE,consumes = {"application/json"},produces={"application/json"})
    public Response<CompteDto> forceDelete(@RequestBody Request<CompteDto> request) {
        log.info("start method /Compte/forceDelete");
        Response<CompteDto> response = controllerFactory.forceDelete(compteBusiness, request, FunctionalityEnum.DELETE_COMPTE);
        log.info("end method /Compte/forceDelete");
        return response;
    }

    @RequestMapping(value="/getByCriteria",method=RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<CompteDto> getByCriteria(@RequestBody Request<CompteDto> request) {
        log.info("start method /Compte/getByCriteria");
        Response<CompteDto> response = controllerFactory.getByCriteria(compteBusiness, request, FunctionalityEnum.VIEW_COMPTE);
        log.info("end method /Compte/getByCriteria");
        return response;
    }


}
