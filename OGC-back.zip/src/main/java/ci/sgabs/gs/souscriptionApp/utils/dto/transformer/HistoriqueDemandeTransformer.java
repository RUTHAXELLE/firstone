package ci.sgabs.gs.souscriptionApp.utils.dto.transformer;

import ci.sgabs.gs.souscriptionApp.dao.entity.*;
import ci.sgabs.gs.souscriptionApp.helper.contrat.FullTransformerQualifier;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.AttributionDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.HistoriqueDemandeDto;
import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

@Mapper
public interface HistoriqueDemandeTransformer {

    HistoriqueDemandeTransformer INSTANCE = Mappers.getMapper(HistoriqueDemandeTransformer.class);

    @FullTransformerQualifier
    @Mappings({
            @Mapping(source = "entity.id", target = "id"),
            @Mapping(source = "entity.code", target = "code"),
            @Mapping(source = "entity.libelle", target = "libelle"),
            @Mapping(source = "entity.demande.id", target = "demandeId"),
            @Mapping(source = "entity.status.id", target = "statusId"),
            @Mapping(source = "entity.demande.code", target = "codeDemande"),
            @Mapping(source = "entity.status.code", target = "codeStatus"),

            @Mapping(source="entity.updatedAt", dateFormat="dd/MM/yyyy",target="updatedAt"),
            @Mapping(source="entity.createdAt", dateFormat="dd/MM/yyyy",target="createdAt"),
            @Mapping(source="entity.deletedAt", dateFormat="dd/MM/yyyy",target="deletedAt"),
            @Mapping(source="entity.updatedBy",target="updatedBy"),
            @Mapping(source="entity.createdBy", target="createdBy"),
            @Mapping(source="entity.deletedBy", target="deletedBy"),
            @Mapping(source="entity.isDeleted", target="isDeleted"),
    })
    HistoriqueDemandeDto toDto(HistoriqueDemande entity);
    @IterableMapping(qualifiedBy = {FullTransformerQualifier.class})
    List<HistoriqueDemandeDto> toDtos(List<HistoriqueDemande> entities) throws ParseException;

    public default HistoriqueDemandeDto toLiteDto(HistoriqueDemande entity) {
        if (entity == null) {
            return null;
        }
        HistoriqueDemandeDto dto = new HistoriqueDemandeDto();
        dto.setId( entity.getId() );
        dto.setCode( entity.getCode() );
        dto.setLibelle(entity.getLibelle());

        return dto;
    }

    public default List<HistoriqueDemandeDto> toLiteDtos(List<HistoriqueDemande> entities) {
        if (entities == null || entities.stream().allMatch(o -> o == null)) {
            return null;
        }
        List<HistoriqueDemandeDto> dtos = new ArrayList<HistoriqueDemandeDto>();
        for (HistoriqueDemande entity : entities) {
            dtos.add(toLiteDto(entity));
        }
        return dtos;
    }

    @Mappings({
            @Mapping(source = "dto.id", target = "id"),
            @Mapping(source = "dto.code", target = "code"),
            @Mapping(source = "dto.libelle", target = "libelle"),


            @Mapping(source="dto.updatedAt", dateFormat="dd/MM/yyyy",target="updatedAt"),
            @Mapping(source="dto.createdAt", dateFormat="dd/MM/yyyy",target="createdAt"),
            @Mapping(source="dto.deletedAt", dateFormat="dd/MM/yyyy",target="deletedAt"),
            @Mapping(source="dto.updatedBy",target="updatedBy"),
            @Mapping(source="dto.createdBy", target="createdBy"),
            @Mapping(source="dto.deletedBy", target="deletedBy"),
            @Mapping(source="dto.isDeleted", target="isDeleted"),

            @Mapping(source = "demande", target = "demande"),
            @Mapping(source = "status", target = "status")
    })
    HistoriqueDemande toEntity(HistoriqueDemandeDto dto, Demande demande, Status status);
}
