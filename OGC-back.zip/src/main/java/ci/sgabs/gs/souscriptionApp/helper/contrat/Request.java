package ci.sgabs.gs.souscriptionApp.helper.contrat;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@Data
@NoArgsConstructor
@ToString
@XmlRootElement
@JsonInclude(JsonInclude.Include.NON_NULL) //permet d'ignoré les valeurs nulls
public class Request<T> extends RequestBase{
    private T data;
    private List<T> datas;
}
