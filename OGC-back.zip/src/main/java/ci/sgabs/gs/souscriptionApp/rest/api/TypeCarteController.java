package ci.sgabs.gs.souscriptionApp.rest.api;

import ci.sgabs.gs.souscriptionApp.business.TypeCarteBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.enums.FunctionalityEnum;
import ci.sgabs.gs.souscriptionApp.rest.fact.ControllerFactory;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.TypeCarteDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.TypeCarteDto;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Log
@CrossOrigin("*")
@RestController
@RequestMapping(value="/typeCartes")
public class TypeCarteController {

    @Autowired
    private ControllerFactory<TypeCarteDto> controllerFactory;
    @Autowired
    private TypeCarteBusiness typeCarteBusiness;

    @RequestMapping(value="",method= RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<TypeCarteDto> create(@RequestBody Request<TypeCarteDto> request) {
        log.info("start method /TypeCarte/create");
        Response<TypeCarteDto> response = controllerFactory.create(typeCarteBusiness, request, FunctionalityEnum.CREATE_TYPECARTE);
        log.info("end method /TypeCarte/create");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.PUT,consumes = {"application/json"},produces={"application/json"})
    public Response<TypeCarteDto> update(@RequestBody Request<TypeCarteDto> request) {
        log.info("start method /TypeCarte/update");
        Response<TypeCarteDto> response = controllerFactory.update(typeCarteBusiness, request, FunctionalityEnum.UPDATE_TYPECARTE);
        log.info("end method /TypeCarte/update");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.DELETE,consumes = {"application/json"},produces={"application/json"})
    public Response<TypeCarteDto> delete(@RequestBody Request<TypeCarteDto> request) {
        log.info("start method /TypeCarte/delete");
        Response<TypeCarteDto> response = controllerFactory.delete(typeCarteBusiness, request, FunctionalityEnum.DELETE_TYPECARTE);
        log.info("end method /TypeCarte/delete");
        return response;
    }

    @RequestMapping(value="/forceDelete",method=RequestMethod.DELETE,consumes = {"application/json"},produces={"application/json"})
    public Response<TypeCarteDto> forceDelete(@RequestBody Request<TypeCarteDto> request) {
        log.info("start method /TypeCarte/forceDelete");
        Response<TypeCarteDto> response = controllerFactory.forceDelete(typeCarteBusiness, request, FunctionalityEnum.DELETE_TYPECARTE);
        log.info("end method /TypeCarte/forceDelete");
        return response;
    }

    @RequestMapping(value="/getByCriteria",method=RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<TypeCarteDto> getByCriteria(@RequestBody Request<TypeCarteDto> request) {
        log.info("start method /TypeCarte/getByCriteria");
        Response<TypeCarteDto> response = controllerFactory.getByCriteria(typeCarteBusiness, request, FunctionalityEnum.VIEW_TYPECARTE);
        log.info("end method /TypeCarte/getByCriteria");
        return response;
    }

}
