package ci.sgabs.gs.souscriptionApp.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity @Data
@NoArgsConstructor
@AllArgsConstructor
public class Document implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @Column(nullable = true, length = 64)
    private String code;
    @Column(nullable = true, length = 64)
    private String naturePiece;
    @Column(nullable = true, length = 64)
    private String piece;
    @ManyToOne(fetch = FetchType.EAGER)
    private Client client;

    @Column(name="is_deleted")
    private Boolean isDeleted;

    private Date createdAt;
    private Date updatedAt;
    private Date deletedAt;

    private Integer createdBy;
    private Integer updatedBy;
    private Integer deletedBy;
}
