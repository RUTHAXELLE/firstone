package ci.sgabs.gs.souscriptionApp.business;

import ci.sgabs.gs.souscriptionApp.dao.entity.Functionality;
import ci.sgabs.gs.souscriptionApp.dao.entity.Role;
import ci.sgabs.gs.souscriptionApp.dao.entity.RoleFunctionality;
import ci.sgabs.gs.souscriptionApp.dao.repository.FunctionalityRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.RoleFunctionalityRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.RoleRepository;
import ci.sgabs.gs.souscriptionApp.helper.contrat.IBasicBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.errors.TechnicalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.helper.validation.Validate;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.RoleFunctionalityDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.RoleFunctionalityTransformer;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Log
@Component
public class RoleFunctionalityBusiness implements IBasicBusiness<Request<RoleFunctionalityDto>, Response<RoleFunctionalityDto>> {

    private Response<RoleFunctionalityDto> response;

    @Autowired
    private RoleFunctionalityRepository roleFunctionalityRepository;
    @Autowired
    private RoleRepository roleRepository;
    @Autowired
    private FunctionalityRepository functionalityRepository;
    @Autowired
    private FunctionalError functionalError;
    @Autowired
    private TechnicalError technicalError;
    @Autowired
    private ExceptionUtils exceptionUtils;
    @Autowired
    private EntityManager em;
    private final SimpleDateFormat dateFormat;
    private final SimpleDateFormat dateTimeFormat;

    public RoleFunctionalityBusiness() {
        dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    }

    @Override
    public Response<RoleFunctionalityDto> create(Request<RoleFunctionalityDto> request, Locale locale) throws ParseException {

        log.info("----begin create RoleFunctionality-----");

        Response<RoleFunctionalityDto> response = new Response<RoleFunctionalityDto>();
        List<RoleFunctionality> items = new ArrayList<RoleFunctionality>();

        for(RoleFunctionalityDto dto : request.getDatas()){

                    //******* Definition et verification des parametres obligatoires ******//

            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("roleId", dto.getRoleId());
            fieldsToVerify.put("functionalityId", dto.getFunctionalityId());

            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
                    //********** Verification s'il existe une entité RoleFunctionality en base avec les mêmes informations ***********//

            RoleFunctionality existingEntity = null;
            existingEntity = roleFunctionalityRepository.findByRoleAndFunctionalityId(dto.getRoleId(),dto.getFunctionalityId(), false);

            if (existingEntity != null) {
                response.setStatus(functionalError.DATA_EXIST("RoleFunctionality roleId -> " + dto.getRoleId() + "RoleFunctionality FunctionalityId -> " + dto.getFunctionalityId(), locale));
                response.setHasError(true);
                return response;
            }

                    //***** Verification s'il existe un role en base avec l'id fourni *********//
            Role existingRole = roleRepository.findOne(dto.getRoleId(), false);
            if (existingRole == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Role roleId -> " + dto.getRoleId(), locale));
                response.setHasError(true);
                return response;
            }

                    //***** Verification s'il existe une Functionality en base avec l'id fourni *********//
            Functionality  existingFunctionality = functionalityRepository.findOne(dto.getFunctionalityId(), false);
            if (existingFunctionality == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Functionality FunctionalityId -> " + dto.getFunctionalityId() , locale));
                response.setHasError(true);
                return response;
            }
            RoleFunctionality entityToSave = RoleFunctionalityTransformer.INSTANCE.toEntity(dto, existingFunctionality, existingRole);
            entityToSave.setIsDeleted(false);
            entityToSave.setCreatedAt(Utilities.getCurrentDate());
            if(Utilities.isValidID(request.userID)){
                entityToSave.setCreatedBy(request.userID);
            }
            items.add(entityToSave);
        }

                //***** insertion en base de données *********//

        if (!items.isEmpty()) {
            List<RoleFunctionality> itemsSaved = null;
            itemsSaved = roleFunctionalityRepository.saveAll((Iterable<RoleFunctionality>) items);
            if (itemsSaved == null) {
                response.setStatus(functionalError.SAVE_FAIL("RoleFunctionality", locale));
                response.setHasError(true);
                return response;
            }
            List<RoleFunctionalityDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading())) ? RoleFunctionalityTransformer.INSTANCE.toLiteDtos(itemsSaved) : RoleFunctionalityTransformer.INSTANCE.toDtos(itemsSaved);

            response.setItems(itemsDto);
            response.setHasError(false);
            response.setStatus(functionalError.SUCCESS("", locale));
        }
        log.info("----end create Role-----");
        return response;
    }

    @Override
    public Response<RoleFunctionalityDto> update(Request<RoleFunctionalityDto> request, Locale locale) throws ParseException {

        log.info("----begin update role functionalities -----");

        Response<RoleFunctionalityDto> response = new Response<RoleFunctionalityDto>();
        List<RoleFunctionality> items = new ArrayList<RoleFunctionality>();

        for(RoleFunctionalityDto dto : request.getDatas()){

                    //******* Definition et verification des parametres obligatoires ******//

            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }

                    //***** Verification s'il existe une entité RoleFunctionality en base avec l'id fourni *********//

            RoleFunctionality entityToSave = null;
            entityToSave = roleFunctionalityRepository.findOne(dto.getId(), false);

            if (entityToSave == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("RoleFunctionality id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }
            //***** Verification s'il existe un role en base avec l'id fourni *********//
            Integer entityToSaveId = entityToSave.getId();
            RoleFunctionalityDto entityToSaveDto = RoleFunctionalityTransformer.INSTANCE.toDto(entityToSave);

            Role existingRole = entityToSave.getRole();
            if (Utilities.isValidID(dto.getRoleId()) && !entityToSave.getRole().getId().equals(dto.getRoleId())) {
                existingRole = roleRepository.findOne(dto.getRoleId(), false);

                if (existingRole == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("role roleId -> " + dto.getRoleId(), locale));
                    response.setHasError(true);
                    return response;
                }
            }

                    //***** Verification s'il existe une Functionality en base avec l'id fourni *********//

            Functionality existingFunctionality = entityToSave.getFunctionality();

            if (Utilities.isValidID(dto.getFunctionalityId()) && !entityToSave.getFunctionality().getId().equals(dto.getFunctionalityId())) {
                existingFunctionality = functionalityRepository.findOne(dto.getFunctionalityId(), false);

                if (existingFunctionality == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("functionality functionalityId -> " + dto.getFunctionalityId(), locale));
                    response.setHasError(true);
                    return response;
                }
            }
            RoleFunctionality roleFunctionalityEntity = RoleFunctionalityTransformer.INSTANCE.toEntity(entityToSaveDto, existingFunctionality, existingRole);
            roleFunctionalityEntity.setUpdatedAt(Utilities.getCurrentDate());
            roleFunctionalityEntity.setUpdatedBy(request.userID);
            items.add(roleFunctionalityEntity);
        }

                //***** insertion en base de données *********//

        if (!items.isEmpty()) {
            List<RoleFunctionality> itemsSaved = null;
            itemsSaved = roleFunctionalityRepository.saveAll((Iterable<RoleFunctionality>) items);
            if (itemsSaved == null) {
                response.setStatus(functionalError.SAVE_FAIL("RoleFunctionality", locale));
                response.setHasError(true);
                return response;
            }
            List<RoleFunctionalityDto> itemsDto =  RoleFunctionalityTransformer.INSTANCE.toDtos(itemsSaved);

            response.setItems(itemsDto);
            response.setHasError(false);
            response.setStatus(functionalError.SUCCESS("", locale));
        }
        log.info("end RoleFunctionality update");
        return response;
    }

    @Override
    public Response<RoleFunctionalityDto> delete(Request<RoleFunctionalityDto> request, Locale locale) {

        log.info("----begin delete RoleFunctionality-----");

        Response<RoleFunctionalityDto> response = new Response<RoleFunctionalityDto>();
        List<RoleFunctionality> items = new ArrayList<RoleFunctionality>();

        for(RoleFunctionalityDto dto : request.getDatas()){

                    //******* Definition et verification des parametres obligatoires ******//

            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }

                    //******* Verification s'il existe une entité RoleFunctionality en base avec l'id fourni *********//

            RoleFunctionality existingEntity = null;
            existingEntity = roleFunctionalityRepository.findOne(dto.getId(), false);

            if (existingEntity == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("RoleFunctionality id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }

            existingEntity.setIsDeleted(true);
            existingEntity.setDeletedAt(Utilities.getCurrentDate());
            existingEntity.setDeletedBy(request.userID);
            items.add(existingEntity);
        }

                //***** envoi de la reponse *********//

        if (!items.isEmpty()) {
            response.setHasError(false);
            response.setStatus(functionalError.SUCCESS("", locale));
        }

        log.info("----end delete RoleFunctionality-----");
        return response;
    }

    @Override
    public Response<RoleFunctionalityDto> forceDelete(Request<RoleFunctionalityDto> request, Locale locale) {

        log.info("----begin forcedelete RoleFunctionality-----");

        Response<RoleFunctionalityDto> response = new Response<RoleFunctionalityDto>();
        List<RoleFunctionality> items = new ArrayList<RoleFunctionality>();

        for(RoleFunctionalityDto dto : request.getDatas()){

                    //******* Definition et verification des parametres obligatoires ******//

            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }

                    //******* Verification s'il existe une entité RoleFunctionality en base avec l'id fourni *********//

            RoleFunctionality existingEntity = null;
            existingEntity = roleFunctionalityRepository.findOne(dto.getId(), false);

            if (existingEntity == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("RoleFunctionality id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }

            existingEntity.setIsDeleted(true);
            existingEntity.setDeletedAt(Utilities.getCurrentDate());
            existingEntity.setDeletedBy(request.userID);
            items.add(existingEntity);
        }

                //***** envoi de la reponse *********//

        if (!items.isEmpty()) {
            response.setHasError(false);
            response.setStatus(functionalError.SUCCESS("", locale));
        }

        log.info("----end forcedelete RoleFunctionality-----");
        return response;
    }

    @Override
    public Response<RoleFunctionalityDto> getByCriteria(Request<RoleFunctionalityDto> request, Locale locale) throws Exception {

        log.info("----begin get RoleFunctionality-----");

        Response<RoleFunctionalityDto> response = new Response<RoleFunctionalityDto>();

                //****** verification si le parametre d'ordre à été fourni, sinon nous mettons le paramètre à vide ********//

        if (Utilities.blank(request.getData().getOrderField())) {
            request.getData().setOrderField("");
        }

                //****** verification si le parametre direction à été fourni, sinon nous mettons le paramètre ascendant( du plus ancien au plus ressent) ********//

        if (Utilities.blank(request.getData().getOrderDirection())) {
            request.getData().setOrderDirection("asc");
        }

                //****** recuperation des entités en base *******//

        List<RoleFunctionality> items = roleFunctionalityRepository.getByCriteria(request, em, locale);

        if (Utilities.isEmpty(items)) {
            response.setStatus(functionalError.DATA_EMPTY("RoleFunctionality", locale));
            response.setHasError(false);
            return response;
        }

        List<RoleFunctionalityDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading())) ? RoleFunctionalityTransformer.INSTANCE.toLiteDtos(items) : RoleFunctionalityTransformer.INSTANCE.toDtos(items);


        response.setItems(itemsDto);
        response.setCount(roleFunctionalityRepository.count(request, em, locale));
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        log.info("----end get RoleFunctionality-----");
        return response;
    }
}
