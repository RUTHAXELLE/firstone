package ci.sgabs.gs.souscriptionApp.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TypeCarte implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    @Column(name="code", length=255)
    private String code;
    @Column(name="libelle", length=255)
    private String libelle;
    @Column(name="description", length=255)
    private String description;

    @Column(name="type_gen", length=255)
    private String typeGen;
    @Column(name="code_produit", length=255)
    private String codeProduit;
    @Column(name="identifiant_produit", length=255)
    private String identifiantProduit;

    @Column(name="identifiant_groupe", length=255)
    private String identifiantGroupe;
    @Column(name="code_tarif", length=255)
    private String codeTarif;
    @Column(name="acc_country", length=255)
    private String accCountry;
    @Column(name="bin", length=255)
    private String bin;
    @Column(name="type_carte", length=255)
    private String typeCarte;

    @Column(name="produit", length=255)
    private String produit;
    @Column(name="code_banque", length=255)
    private String codeBanque;
    @Column(name="identifiant_institution", length=255)
    private String identifiantInstitution;
    @Column(name="business", length=255)
    private String business;

    @Column(name="devise", length=255)
    private String devise;
    @Column(name="pays", length=255)
    private String pays;

    @Column(name="type", length=255)
    private String type;


    @Column(name="is_deleted")
    private Boolean isDeleted;

    private Date createdAt;
    private Date updatedAt;
    private Date deletedAt;

    private Integer createdBy;
    private Integer updatedBy;
    private Integer deletedBy;

}
