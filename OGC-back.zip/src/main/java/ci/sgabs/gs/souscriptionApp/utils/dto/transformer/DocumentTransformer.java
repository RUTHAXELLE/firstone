package ci.sgabs.gs.souscriptionApp.utils.dto.transformer;

import ci.sgabs.gs.souscriptionApp.dao.entity.*;
import ci.sgabs.gs.souscriptionApp.helper.contrat.FullTransformerQualifier;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.CompteDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.DocumentDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.RoleDto;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

@Mapper
public interface DocumentTransformer {

    DocumentTransformer INSTANCE = Mappers.getMapper(DocumentTransformer.class);

    @FullTransformerQualifier
    @Mappings({
            @Mapping(source = "entity.id", target = "id"),
            @Mapping(source = "entity.code", target = "code"),
            @Mapping(source = "entity.naturePiece", target = "naturePiece"),
            @Mapping(source = "entity.piece", target = "piece"),
            @Mapping(source = "entity.client.id", target = "clientId"),
            @Mapping(source = "entity.client.code", target = "codeClient"),

            @Mapping(source="entity.updatedAt", dateFormat="dd/MM/yyyy",target="updatedAt"),
            @Mapping(source="entity.createdAt", dateFormat="dd/MM/yyyy",target="createdAt"),
            @Mapping(source="entity.deletedAt", dateFormat="dd/MM/yyyy",target="deletedAt"),
            @Mapping(source="entity.updatedBy",target="updatedBy"),
            @Mapping(source="entity.createdBy", target="createdBy"),
            @Mapping(source="entity.deletedBy", target="deletedBy"),
    })
    DocumentDto toDto(Document entity);
    @IterableMapping(qualifiedBy = {FullTransformerQualifier.class})
    List<DocumentDto> toDtos(List<Document> entities) throws ParseException;

    public default DocumentDto toLiteDto(Document entity) {
        if (entity == null) {
            return null;
        }
        DocumentDto dto = new DocumentDto();
        dto.setCode( entity.getCode() );
        dto.setNaturePiece(entity.getNaturePiece());
        dto.setPiece(entity.getPiece());
        dto.setId( entity.getId() );
        return dto;
    }

    public default List<DocumentDto> toLiteDtos(List<Document> entities) {
        if (entities == null || entities.stream().allMatch(o -> o == null)) {
            return null;
        }
        List<DocumentDto> dtos = new ArrayList<DocumentDto>();
        for (Document entity : entities) {
            dtos.add(toLiteDto(entity));
        }
        return dtos;
    }

    @Mappings({
            @Mapping(source = "dto.id", target = "id"),
            @Mapping(source = "dto.code", target = "code"),
            @Mapping(source = "dto.naturePiece", target = "naturePiece"),
            @Mapping(source = "dto.piece", target = "piece"),

            @Mapping(source="dto.updatedAt", dateFormat="dd/MM/yyyy",target="updatedAt"),
            @Mapping(source="dto.createdAt", dateFormat="dd/MM/yyyy",target="createdAt"),
            @Mapping(source="dto.deletedAt", dateFormat="dd/MM/yyyy",target="deletedAt"),
            @Mapping(source="dto.updatedBy",target="updatedBy"),
            @Mapping(source="dto.createdBy", target="createdBy"),
            @Mapping(source="dto.deletedBy", target="deletedBy"),
            @Mapping(source="dto.isDeleted", target="isDeleted"),

            @Mapping(source = "client", target = "client")
    })
    Document toEntity(DocumentDto dto, Client client);
}
