package ci.sgabs.gs.souscriptionApp.business;

import ci.sgabs.gs.souscriptionApp.dao.entity.Agence;
import ci.sgabs.gs.souscriptionApp.dao.repository.AgenceRepository;
import ci.sgabs.gs.souscriptionApp.helper.contrat.IBasicBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.errors.TechnicalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.helper.validation.Validate;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.AgenceDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.AgenceTransformer;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Cette classe traite les operations portant sur les agences
 *
 * @author Alzouma Moussa Mahamadou
 * @date 09/05/2022
 */
@Log
@Component
public class AgenceBusiness implements IBasicBusiness<Request<AgenceDto>, Response<AgenceDto>> {


    private Response<AgenceDto> response;
    @Autowired
    private AgenceRepository agenceRepository;
    @Autowired
    private FunctionalError functionalError;
    @Autowired
    private TechnicalError technicalError;
    @Autowired
    private ExceptionUtils exceptionUtils;
    @Autowired
    private EntityManager em;

    private final SimpleDateFormat dateFormat;
    private final SimpleDateFormat dateTimeFormat;

    public AgenceBusiness() {
        dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    }


    @Override
    public Response<AgenceDto> create(Request<AgenceDto> request, Locale locale) throws ParseException {

        //Reception et traitement des données du front-edn (classe AgenceDTO)
        log.info("_67 debut de creation d'une liste d'agences"); //TODO A effacer
        Response<AgenceDto> response = new Response<AgenceDto>();
        List<Agence> items = new ArrayList<Agence>();
        //Verificatioon de la liste de données recues
        if (request.getDatas() == null || request.getDatas().isEmpty()) {
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ", locale));
            response.setHasError(true);
            return response;
        }

        //Verification des parametres obligatoires & des duplications de donn�es
        List<AgenceDto> itemsDtos = Collections.synchronizedList(new ArrayList<AgenceDto>());
        for (AgenceDto dto : request.getDatas()) {
            // Definir les parametres obligatoires
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("address", dto.getAddress());
            fieldsToVerify.put("code", dto.getCode());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            if (itemsDtos.stream().anyMatch(a -> a.getCode().equalsIgnoreCase(dto.getCode()))) {
                response.setStatus(functionalError.DATA_DUPLICATE("Tentative de duplication du code '" + dto.getCode() + "' pour les agences", locale));
                response.setHasError(true);
                return response;
            }
            itemsDtos.add(dto);
        }

        for (AgenceDto itemDto : itemsDtos) {
            // verify unique code in db
            Agence existingEntity = null;
            existingEntity = agenceRepository.findByCode(itemDto.getCode(), false);
            if (existingEntity != null) {
                response.setStatus(functionalError.DATA_EXIST("L'agence ayant  pour code -> " + itemDto.getCode() + ", existe déjà", locale));
                response.setHasError(true);
                return response;
            }
            //Transformation d'un itemDto en entity Agence
            Agence entityToSave = AgenceTransformer.INSTANCE.toEntity(itemDto);
            //Hsitorisation
            entityToSave.setIsDeleted(false);
            entityToSave.setCreatedAt(Utilities.getCurrentDate());
            entityToSave.setCreatedBy(request.userID); // à modifier

            items.add(entityToSave);
        }
        //Historisation
        List<Agence> itemsSaved = null;
        itemsSaved = agenceRepository.saveAll((Iterable<Agence>) items);
        if (itemsSaved == null) {
            response.setStatus(functionalError.SAVE_FAIL("Erreuer de creation de la liste des agences", locale));
            response.setHasError(true);
            return response;
        }

        //Tranformation d'une liste d'entités agences en dto
        List<AgenceDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                ? AgenceTransformer.INSTANCE.toLiteDtos(itemsSaved)
                : AgenceTransformer.INSTANCE.toDtos(itemsSaved);

        //Envoie de la reponse
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        return response;

    }

    @Override
    public Response<AgenceDto> update(Request<AgenceDto> request, Locale locale) throws ParseException {
        Response<AgenceDto> response = new Response<AgenceDto>();
        List<Agence> items = new ArrayList<Agence>();
        //Verificatioon de la liste de données recues
        if (request.getDatas() == null || request.getDatas().isEmpty()) {
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ", locale));
            response.setHasError(true);
            return response;
        }
        //Verification des parametres obligatoires
        List<AgenceDto> itemsDtos = Collections.synchronizedList(new ArrayList<AgenceDto>());
        for (AgenceDto dto : request.getDatas()) {
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            itemsDtos.add(dto);
        }
        //Verification
        for (AgenceDto dto : itemsDtos) {
            Agence entityToSave = agenceRepository.findOne(dto.getId(), false);
            if (entityToSave == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("L'agence ayant l'identifiant suivant -> " + dto.getId() + ", n'existe pas", locale));
                response.setHasError(true);
                return response;
            }
            //verify code
            if (Utilities.isNotBlank(dto.getCode()) && !dto.getCode().equals(entityToSave.getCode())) {
                Agence existingEntity = agenceRepository.findByCode(dto.getCode(), false);
                //Verification de l'identifiant
                if (existingEntity != null && !existingEntity.getId().equals(entityToSave.getId())) {
                    response.setStatus(functionalError.DATA_EXIST("agence -> " + dto.getCode(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setCode(dto.getCode());
            }
            //Verification de l'adresse
            if (Utilities.isNotBlank(dto.getAddress()) && !dto.getAddress().equals(entityToSave.getAddress())) {
                Agence agence = agenceRepository.findByAddress(dto.getAddress(), Boolean.FALSE);
                if (agence != null && !agence.getId().equals(entityToSave.getId())) {
                    response.setStatus(functionalError.DATA_EXIST("une agence ayant cette adresse" + dto.getAddress() + "existe déjà", locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setAddress(dto.getAddress());
            }
            //TODO Verifier les autres champs au fur et à mesure
            entityToSave.setUpdatedAt(Utilities.getCurrentDate());
            entityToSave.setUpdatedBy(request.userID);
            items.add(entityToSave);
        }
        //Verificatioon de la liste de données recues
        if (items == null || items.isEmpty()) {
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ", locale));
            response.setHasError(true);
            return response;
        }
        //Transformation
        List<AgenceDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                ? AgenceTransformer.INSTANCE.toLiteDtos(items)
                : AgenceTransformer.INSTANCE.toDtos(items);
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end update agence-----");
        return response;
    }


    @Override
    public Response<AgenceDto> delete(Request<AgenceDto> request, Locale locale) {

        log.info("----begin delete agence-----");

        Response<AgenceDto> response = new Response<AgenceDto>();
        List<Agence> items = new ArrayList<Agence>();

        //Verification
        if (request.getDatas().isEmpty() || request.getDatas() == null) {
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ", locale));
            response.setHasError(true);
            return response;
        }

        //Verification des champs obligatoires
        for (AgenceDto dto : request.getDatas()) {
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
        }

        //Parcourir la liste
        for (AgenceDto dto : request.getDatas()) {

            // Verification du parametre identifiant
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }

            // Verify if Functionality  exist
            Agence existingEntity = null;
            existingEntity = agenceRepository.findOne(dto.getId(), false);
            if (existingEntity == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("L'agence ayant  id -> " + dto.getId() + ",n'existe pas", locale));
                response.setHasError(true);
                return response;
            }

            log.info("_413 Verification d'existence de l'objet" + existingEntity.toString()); //TODO A effacer

            //Suppression logique
            existingEntity.setIsDeleted(true);
            existingEntity.setDeletedAt(Utilities.getCurrentDate());
            existingEntity.setDeletedBy(request.userID);// a modifier

            items.add(existingEntity);

        }

        //Verificatioon de la liste de données recues
        if (items == null || items.isEmpty()) {
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ", locale));
            response.setHasError(true);
            return response;
        }

        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        return response;

    }


    @Override
    public Response<AgenceDto> forceDelete(Request<AgenceDto> request, Locale locale) throws ParseException {
        return null;
    }

    @Override
    public Response<AgenceDto> getByCriteria(Request<AgenceDto> request, Locale locale) throws Exception {


        log.info("----begin get agence-----");

        Response<AgenceDto> response = new Response<AgenceDto>();
        if (Utilities.blank(request.getData().getOrderField())) {
            request.getData().setOrderField("");
        }
        if (Utilities.blank(request.getData().getOrderDirection())) {
            request.getData().setOrderDirection("asc");
        }

        List<Agence> items = agenceRepository.getByCriteria(request, em, locale);
        if (Utilities.isEmpty(items)) {
            response.setStatus(functionalError.DATA_EMPTY("Aucune agence ne correspond aux critères de recherche definis", locale));
            response.setHasError(false);
            return response;
        }

        List<AgenceDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                ? AgenceTransformer.INSTANCE.toLiteDtos(items)
                : AgenceTransformer.INSTANCE.toDtos(items);


        response.setItems(itemsDto);
        response.setCount(agenceRepository.count(request, em, locale));
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        log.info("----end get agence-----");

        return response;

    }

}
