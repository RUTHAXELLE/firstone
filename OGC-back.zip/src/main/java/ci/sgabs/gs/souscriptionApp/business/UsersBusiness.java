package ci.sgabs.gs.souscriptionApp.business;

import ci.sgabs.gs.souscriptionApp.dao.entity.Agence;
import ci.sgabs.gs.souscriptionApp.dao.entity.Functionality;
import ci.sgabs.gs.souscriptionApp.dao.entity.Role;
import ci.sgabs.gs.souscriptionApp.dao.entity.Users;
import ci.sgabs.gs.souscriptionApp.dao.repository.AgenceRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.RoleFunctionalityRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.RoleRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.UsersRepository;
import ci.sgabs.gs.souscriptionApp.helper.contrat.IBasicBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.errors.TechnicalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.helper.validation.Validate;
import ci.sgabs.gs.souscriptionApp.utils.authentification.SecurityConstants;
import ci.sgabs.gs.souscriptionApp.utils.authentification.SecurityServices;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.UserPasswordDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.UsersDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.UsersTransformer;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Log
@Component
public class UsersBusiness implements IBasicBusiness<Request<UsersDto>, Response<UsersDto>> {

    private Response<UsersDto> response;
    @Autowired
    private UsersRepository usersRepository;
    @Autowired
    private RoleRepository roleRepository;
    @Autowired
    private RoleFunctionalityRepository roleFunctionalityRepository;
    @Autowired
    private FunctionalError functionalError;
    @Autowired
    private TechnicalError technicalError;
    @Autowired
    private ExceptionUtils exceptionUtils;
    @Autowired
    private AgenceRepository agenceRepository;
    @Autowired
    private EntityManager em;
    private final SimpleDateFormat dateFormat;
    private final SimpleDateFormat dateTimeFormat;

    public UsersBusiness() {
        dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    }

    @Transactional(rollbackFor = {RuntimeException.class, Exception.class})
    public Response<UsersDto> login(Request<UsersDto> request, Locale locale) throws Exception {
        log.info("----begin login-----");
        Response<UsersDto> response = new Response<UsersDto>();
        List<Users> items = new ArrayList<Users>();
        UsersDto dto = request.getData();
        //******* Definition et verification des parametres obligatoires ******//
        Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
        fieldsToVerify.put("login", dto.getLogin());
        fieldsToVerify.put("password", dto.getPassword());
        if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
            response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
            response.setHasError(true);
            return response;
        }
        //Verification s'il existe un utilisateur en base avec ces identifiants
        Users existingEntity = null;
        existingEntity = usersRepository.findByLoginAndPassword(dto.getLogin(), Utilities.encrypt(dto.getPassword()), false);
        if (existingEntity == null) {
            response.setStatus(functionalError.DATA_NOT_EXIST("login or password is not correct -> " + dto.getLogin() + " " + dto.getPassword(), locale));
            response.setHasError(true);
            return response;
        }
        //Incrementation de la propriété numberOfConnections
        if(existingEntity.getNumberOfConnections() == null){
            existingEntity.setNumberOfConnections(0);
        }
        if(existingEntity.getNumberOfConnections()>1){
            int compt=existingEntity.getNumberOfConnections() + 1 ;
            existingEntity.setNumberOfConnections(compt);
        }
        //Transformation
        UsersDto existingEntityDto = UsersTransformer.INSTANCE.toDto(existingEntity);
        if (existingEntityDto.getLastConnectionDate() != null && !existingEntityDto.getLastConnectionDate().isEmpty()) {
            existingEntityDto.setLastConnection(existingEntityDto.getLastConnectionDate());
        }
        //Set last connexion date
        existingEntity.setLastConnectionDate(Utilities.getCurrentDate());
        usersRepository.save(existingEntity);
        existingEntityDto.setToken(SecurityServices.createToken(existingEntity));
        response.setItem(existingEntityDto);
        response.setHasError(Boolean.FALSE);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end login-----");
        return response;
    }

    @Transactional(rollbackFor = {RuntimeException.class, Exception.class})
    public Response<UsersDto> resetPassWordUser(Request<UserPasswordDto> request, Locale locale) throws Exception {
        log.info("----begin resetPassWordUser-----");
        Response<UsersDto> response = new Response<UsersDto>();
        List<Users> items = new ArrayList<Users>();
        UserPasswordDto dto = request.getData();
        //Définition et vérification des champs obligatoires
        Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
        fieldsToVerify.put("id", dto.getId());
        fieldsToVerify.put("newPassWord", dto.getNewPassWord());
        fieldsToVerify.put("oldPassWord", dto.getOldPassWord());
        if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
            response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
            response.setHasError(true);
            return response;
        }
        //Remettre dans le contexte de persistence l'utilisateur en question
        Users existingEntity = null;
        existingEntity = usersRepository.findOne(dto.getId(), false); //
        if (existingEntity == null) {
            response.setStatus(functionalError.DATA_NOT_EXIST("L'utilisateur n'existe pas -> " + dto.getId(), locale));
            response.setHasError(true);
            return response;
        }
        //Vérification du nouveau mot de passe défini au mot de passe existant
        String oldPassWordEncryted=existingEntity.getPassword();
        if(!oldPassWordEncryted.equals(Utilities.encrypt(dto.getOldPassWord()))){
            response.setStatus(functionalError.SAVE_FAIL("Impossible d'effectuer la modification.Car,L'ancien mot de passe saisi ne correspond pas à celui qui existe ", locale));
            response.setHasError(true);
            return response;
        }
        String newPassWordEncryted=Utilities.encrypt(dto.getNewPassWord());
        if(oldPassWordEncryted.equals(newPassWordEncryted)){
            response.setStatus(functionalError.SAVE_FAIL("Impossible d'effectuer la modification.Car, l'ancien et le nouveau mot de passe saisis sont identiques", locale));
            response.setHasError(true);
            return response;
        }
        existingEntity.setPassword(newPassWordEncryted);
        //Incrementation du nombre de connections
        if(existingEntity.getNumberOfConnections()==0 && (Utilities.encrypt(SecurityConstants.USER_PASSWORD_DEFAULT).equals(oldPassWordEncryted))){
            existingEntity.setNumberOfConnections(existingEntity.getNumberOfConnections()+1);
        }
        //Persistence
        Users savinEntity=usersRepository.save(existingEntity);
        log.info("_144 resetPassWordUser :: Utilisateur modifie ="+savinEntity.toString());
        //Transformation
        UsersDto existingEntityDto = UsersTransformer.INSTANCE.toDto(savinEntity);
        if (existingEntityDto.getLastConnectionDate() != null && !existingEntityDto.getLastConnectionDate().isEmpty()) {
            existingEntityDto.setLastConnection(existingEntityDto.getLastConnectionDate());
        }
        response.setItem(existingEntityDto);
        response.setHasError(Boolean.FALSE);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end resetPassWordUser-----");
        return response;
    }

    @Override
    public Response<UsersDto> create(Request<UsersDto> request, Locale locale) throws Exception {
        log.info("----begin create Users-----");

        Response<UsersDto> response = new Response<UsersDto>();
        List<Users> items = new ArrayList<Users>();
        //Verifications de permission
        boolean isUserauthenticatedHaveFunctinality= checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_USER_CREATE);
        if(isUserauthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas créer des utilisateurs.Car vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        //Traitement de creation d'un user
        for (UsersDto dto : request.getDatas()) {
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("nom", dto.getNom());
            fieldsToVerify.put("prenoms", dto.getPrenoms());
            fieldsToVerify.put("login", dto.getLogin());
            fieldsToVerify.put("roleId", dto.getRoleId());
            fieldsToVerify.put("agenceId", dto.getAgenceId());
            fieldsToVerify.put("isActif", dto.getIsActif());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            if (items.stream().anyMatch(a -> a.getLogin().equalsIgnoreCase(dto.getLogin()))) { //verification login
                response.setStatus(functionalError.DATA_DUPLICATE(" login ", locale));
                response.setHasError(true);
                return response;
            }
            if(items.stream().anyMatch(a -> a.getMatricule().equalsIgnoreCase(dto.getMatricule()))) { //verification matricule
                response.setStatus(functionalError.DATA_DUPLICATE(" Matricule ", locale));
                response.setHasError(true);
                return response;
            }
            Users existingEntity = null;
            existingEntity = usersRepository.findByLogin(dto.getLogin(), false); //verification du login
            if (existingEntity != null) {
                response.setStatus(functionalError.DATA_EXIST("Users code -> " + dto.getLogin(), locale));
                response.setHasError(true);
                return response;
            }
            Agence agence = agenceRepository.findOne(dto.getAgenceId(), Boolean.FALSE);
            if (agence == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("agence agenceID -> " + dto.getRoleId(), locale));
                response.setHasError(true);
                return response;
            }
            Role existingRole = null;
            if (Utilities.isValidID(dto.getRoleId())) {
                existingRole = roleRepository.findOne(dto.getRoleId(), false);
                if (existingRole == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("role roleID -> " + dto.getRoleId(), locale));
                    response.setHasError(true);
                    return response;
                }
            }
            Users entityToSave = UsersTransformer.INSTANCE.toEntity(dto, existingRole, agence);
            entityToSave.setIsDeleted(false);
            entityToSave.setCreatedAt(Utilities.getCurrentDate());
            entityToSave.setIsFirst(Boolean.TRUE);
            entityToSave.setCreatedBy(request.userID);
            String generateNewPassword=SecurityServices.generateCode1();
            log.info("_151 New password generate="+generateNewPassword); //TODO A effacer
            try {
                entityToSave.setPassword(Utilities.encrypt("0123456789"));
            } catch (Exception e) {
                e.printStackTrace();
            }
            items.add(entityToSave);
        }
        if( items==null || items.isEmpty()){
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste vide", locale));
            response.setHasError(true);
            return response;
        }
        List<Users> itemsSaved = null;
        itemsSaved = usersRepository.saveAll((Iterable<Users>) items);
        if (itemsSaved == null) {
            response.setStatus(functionalError.SAVE_FAIL("Users", locale));
            response.setHasError(true);
            return response;
        }
        List<UsersDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading())) ? UsersTransformer.INSTANCE.toLiteDtos(itemsSaved) : UsersTransformer.INSTANCE.toDtos(itemsSaved);
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end create Users-----");
        return response;
    }

    @Override
    public Response<UsersDto> update(Request<UsersDto> request, Locale locale) throws ParseException {

        log.info("----begin update Users -----");
        Response<UsersDto> response = new Response<UsersDto>();
        List<Users> items = new ArrayList<Users>();
        //Verification des permissions
        boolean isUserauthenticatedHaveFunctinality= checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_USER_UPDATE);
        if(isUserauthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas modifier des utilisateurs.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        for (UsersDto dto : request.getDatas()) {
            //Definition et verification des parametres obligatoires
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            //Verification s'il existe un utilisateur en base avec l'id fourni
            Users entityToSave = null;
            entityToSave = usersRepository.findOne(dto.getId(), false);
            if (entityToSave == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Users id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }
            //Verification s'il existe deja un utilisateur en base ou dans la liste à inséré, avec les mêmes informations (login et matricule)
            Integer entityToSaveId = entityToSave.getId();
            if (Utilities.isNotBlank(dto.getLogin()) && !dto.getLogin().equals(entityToSave.getLogin())) { //verify login
                Users existingEntity = usersRepository.findByLogin(dto.getLogin(), false);
                if (existingEntity != null && !existingEntity.getId().equals(entityToSave.getId())) {
                    response.setStatus(functionalError.DATA_EXIST("Users -> " + dto.getLogin(), locale));
                    response.setHasError(true);
                    return response;
                }
                if (items.stream().anyMatch(a -> a.getLogin().equalsIgnoreCase(dto.getLogin()) && !a.getId().equals(entityToSaveId))) {
                    response.setStatus(functionalError.DATA_DUPLICATE("Tentative de duplication du login '" + dto.getLogin() + "' pour les users", locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setLogin(dto.getLogin());
            }
            if (Utilities.isNotBlank(dto.getMatricule()) && !dto.getMatricule().equals(entityToSave.getMatricule())) { //verify Matricule
                Users existingEntity = usersRepository.findByMatricule(dto.getMatricule(), false);
                if (existingEntity != null && !existingEntity.getId().equals(entityToSave.getId())) {
                    response.setStatus(functionalError.DATA_EXIST("Users -> " + dto.getMatricule(), locale));
                    response.setHasError(true);
                    return response;
                }
                if (items.stream().anyMatch(a -> a.getMatricule().equalsIgnoreCase(dto.getMatricule()) && !a.getId().equals(entityToSaveId))) {
                    response.setStatus(functionalError.DATA_DUPLICATE("Tentative de duplication du Matricule '" + dto.getMatricule() + "' pour les users", locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setMatricule(dto.getMatricule());
            }
            if (Utilities.isNotBlank(dto.getPassword()) && !dto.getPassword().equals(entityToSave.getPassword())) {
                try {
                    entityToSave.setPassword(Utilities.encrypt(dto.getPassword()));
                    if (entityToSave.getIsFirst() != null && entityToSave.getIsFirst()) {
                        entityToSave.setIsFirst(Boolean.FALSE);
                    }
                } catch (Exception e) {
                     e.printStackTrace();
                }
            }
            if (Utilities.isNotBlank(dto.getNom()) && !dto.getNom().equals(entityToSave.getNom())) {
                entityToSave.setNom(dto.getNom());
            }
            if (Utilities.isNotBlank(dto.getPrenoms()) && !dto.getPrenoms().equals(entityToSave.getPrenoms())) {
                entityToSave.setPrenoms(dto.getPrenoms());
            }
            if (dto.getIsActif() != null && !dto.getIsActif().equals(entityToSave.getIsActif())) {
                entityToSave.setIsActif(dto.getIsActif());
            }
            //Verification s'il existe un role en base avec le roleId fourni
            Role existingRole = null;
            if (Utilities.isValidID(dto.getRoleId()) && !entityToSave.getRole().getId().equals(dto.getRoleId())) {
                existingRole = roleRepository.findOne(dto.getRoleId(), false);
                if (existingRole == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("role roleId -> " + dto.getRoleId(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setRole(existingRole);
            }
            if(Utilities.isValidID(dto.getAgenceId()) && !dto.getAgenceId().equals(entityToSave.getAgence().getId())){
                Agence agenceExisting =  agenceRepository.findOne(dto.getAgenceId(),false);
                if(agenceExisting==null){
                    response.setStatus(functionalError.DATA_NOT_EXIST("agence agenceId -> " + dto.getRoleId(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setAgence(agenceExisting);
            }
            entityToSave.setUpdatedAt(Utilities.getCurrentDate());
            entityToSave.setUpdatedBy(request.userID);
            items.add(entityToSave);
        }
        if (!items.isEmpty()) {
            List<Users> itemsSaved = null;
            itemsSaved = usersRepository.saveAll((Iterable<Users>) items);
            if (itemsSaved == null) {
                response.setStatus(functionalError.SAVE_FAIL("Users", locale));
                response.setHasError(true);
                return response;
            }
            List<UsersDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading())) ? UsersTransformer.INSTANCE.toLiteDtos(itemsSaved) : UsersTransformer.INSTANCE.toDtos(itemsSaved);
            response.setItems(itemsDto);
            response.setHasError(false);
            response.setStatus(functionalError.SUCCESS("", locale));
        }
        log.info("end users update");
        return response;
    }

    @Override
    public Response<UsersDto> delete(Request<UsersDto> request, Locale locale) {
        log.info("----begin delete Users-----");
        Response<UsersDto> response = new Response<UsersDto>();
        List<Users> items = new ArrayList<Users>();
        //Verifications de permission
       /* boolean isUserauthenticatedHaveFunctinality=verifyIfUserAuthenticatedHaveThisFunctionnality(Request.userID, SecurityConstants.);
        if(isUserauthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas supprimer des utilisateurs.Car vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }*/
        for (UsersDto dto : request.getDatas()) {
            //******* Definition et verification des parametres obligatoires ******//
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            //***** Verification s'il existe un utilisateur en base avec l'id fourni *********//
            Users existingEntity = null;
            existingEntity = usersRepository.findOne(dto.getId(), false);
            if (existingEntity == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Users id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }
            existingEntity.setIsDeleted(true);
            existingEntity.setDeletedAt(Utilities.getCurrentDate());
            existingEntity.setDeletedBy(request.userID);
            items.add(existingEntity);
        }
        if (!items.isEmpty()) {
            response.setHasError(false);
            response.setStatus(functionalError.SUCCESS("", locale));
        }
        log.info("----end delete Users-----");
        return response;
    }

    @Override
    public Response<UsersDto> forceDelete(Request<UsersDto> request, Locale locale) {
        return null;
    }

    @Override
    public Response<UsersDto> getByCriteria(Request<UsersDto> request, Locale locale) throws Exception {
        log.info("----begin get Users-----");
        Response<UsersDto> response = new Response<UsersDto>();
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_USER_LIST);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas lister les utilisateurs.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        //verification si le parametre d'ordre à été fourni, sinon nous mettons le paramètre à vide
        if (Utilities.blank(request.getData().getOrderField())) {
            request.getData().setOrderField("");
        }
        //verification si le parametre direction à été fourni, sinon nous mettons le paramètre ascendant( du plus ancien au plus ressent)
        if (Utilities.blank(request.getData().getOrderDirection())) {
            request.getData().setOrderDirection("asc");
        }
        List<Users> items = usersRepository.getByCriteria(request, em, locale);
        if (Utilities.isEmpty(items)) {
            response.setStatus(functionalError.DATA_EMPTY("Users", locale));
            response.setHasError(false);
            return response;
        }
        List<UsersDto> itemsDto = UsersTransformer.INSTANCE.toDtos(items);
        response.setItems(itemsDto);
        response.setCount(usersRepository.count(request, em, locale));
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end get Users-----");
        return response;
    }
    public boolean checkIfUserAuthenticatedHasThisFunctionnality(int userID, String functionalityToVerify) {
        List<Functionality> functionalityList=Collections.synchronizedList(new ArrayList<Functionality>());
        Users usersAuthenticated=null;
        int usersAuthenticatedId=userID;
        usersAuthenticated=usersRepository.findOne(usersAuthenticatedId,false);
        if(usersAuthenticated==null){
            return false;
        }
        if(usersAuthenticated.getRole()==null){
            return false;
        }
        int roleID=usersAuthenticated.getRole().getId();
        functionalityList=roleFunctionalityRepository.findFunctionalityByRoleId(roleID,false);
        if(functionalityList==null){
            return false;
        }
        boolean isFound=false;
        for(Functionality functionality: functionalityList){
            if(functionality!=null && functionality.getCode()!=null
                                   && functionality.getCode().equals(functionalityToVerify)){
                isFound=true;
            }
        }
        return isFound;
    }
    public Role getRoleUserAuthenticated(int userID){
        int usersAuthenticatedId=userID;
        Users usersAuthenticated=null;
        Role userRole=null;
        usersAuthenticated=usersRepository.findOne(usersAuthenticatedId,false);
        if(usersAuthenticated==null){
            return null ;
        }
        userRole=usersAuthenticated.getRole()!=null?usersAuthenticated.getRole():null;
        return userRole;
    }
    public Agence getAgenceUserAuthenticated(int userID){
        int usersAuthenticatedId=userID;
        Users usersAuthenticated=null;
        Agence userAgency=null;
        usersAuthenticated=usersRepository.findOne(usersAuthenticatedId,false);
        if(usersAuthenticated==null){
            return null ;
        }
        userAgency=usersAuthenticated.getAgence()!=null?usersAuthenticated.getAgence():null;
        return userAgency;
    }
}
