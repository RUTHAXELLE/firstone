package ci.sgabs.gs.souscriptionApp.rest.api;

import ci.sgabs.gs.souscriptionApp.business.TypeOperationBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.enums.FunctionalityEnum;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.status.StatusCode;
import ci.sgabs.gs.souscriptionApp.helper.status.StatusMessage;
import ci.sgabs.gs.souscriptionApp.rest.fact.ControllerFactory;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.StatusDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.TypeOperationDto;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.CannotCreateTransactionException;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Locale;

@Log
@CrossOrigin("*")
@RestController
@RequestMapping(value="/typeOperations")
public class TypeOperationController {


    @Autowired
    private TypeOperationBusiness typeOperationBusiness;
    @Autowired
    private FunctionalError functionalError;
    @Autowired
    private ControllerFactory<TypeOperationDto> controllerFactory;
    @Autowired
    private ExceptionUtils exceptionUtils;

    @Autowired
    private HttpServletRequest requestBasic;


    @RequestMapping(value="",method= RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<TypeOperationDto> create(@RequestBody Request<TypeOperationDto> request) {
        log.info("start method /Status/create");
        Response<TypeOperationDto> response = controllerFactory.create(typeOperationBusiness, request, FunctionalityEnum.CREATE_STATUS);
        log.info("end method /Status/create");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.PUT,consumes = {"application/json"},produces={"application/json"})
    public Response<TypeOperationDto> update(@RequestBody Request<TypeOperationDto> request) {
        log.info("start method /Statuss/update");
        Response<TypeOperationDto> response = controllerFactory.update(typeOperationBusiness, request, FunctionalityEnum.UPDATE_STATUS);
        log.info("end method /Status/update");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.DELETE,consumes = {"application/json"},produces={"application/json"})
    public Response<TypeOperationDto> delete(@RequestBody Request<TypeOperationDto> request) {
        log.info("start method /Status/delete");
        Response<TypeOperationDto> response = controllerFactory.delete(typeOperationBusiness, request, FunctionalityEnum.DELETE_STATUS);
        log.info("end method /Status/delete");
        return response;
    }

    @RequestMapping(value="/getByCriteria",method=RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<TypeOperationDto> getByCriteria(@RequestBody Request<TypeOperationDto> request) {
        log.info("start method /Status/getByCriteria");
        Response<TypeOperationDto> response = controllerFactory.getByCriteria(typeOperationBusiness, request, FunctionalityEnum.VIEW_STATUS);
        log.info("end method /Status/getByCriteria");
        return response;
    }

}


