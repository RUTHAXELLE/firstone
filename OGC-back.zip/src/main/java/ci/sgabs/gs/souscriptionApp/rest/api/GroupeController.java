package ci.sgabs.gs.souscriptionApp.rest.api;

import ci.sgabs.gs.souscriptionApp.business.GroupeBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.enums.FunctionalityEnum;
import ci.sgabs.gs.souscriptionApp.rest.fact.ControllerFactory;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.GroupeDto;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Log
@CrossOrigin("*")
@RestController
@RequestMapping(value="/groupes")
public class GroupeController {


    @Autowired
    private ControllerFactory<GroupeDto> controllerFactory;
    @Autowired
    private GroupeBusiness groupeBusiness;

    @RequestMapping(value="",method= RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<GroupeDto> create(@RequestBody Request<GroupeDto> request) {
        log.info("start method /Groupe/create");
        Response<GroupeDto> response = controllerFactory.create(groupeBusiness, request, FunctionalityEnum.CREATE_GROUPE);
        log.info("end method /Groupe/create");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.PUT,consumes = {"application/json"},produces={"application/json"})
    public Response<GroupeDto> update(@RequestBody Request<GroupeDto> request) {
        log.info("start method /Groupes/update");
        Response<GroupeDto> response = controllerFactory.update(groupeBusiness, request, FunctionalityEnum.UPDATE_GROUPE);
        log.info("end method /Groupe/update");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.DELETE,consumes = {"application/json"},produces={"application/json"})
    public Response<GroupeDto> delete(@RequestBody Request<GroupeDto> request) {
        log.info("start method /Groupe/delete");
        Response<GroupeDto> response = controllerFactory.delete(groupeBusiness, request, FunctionalityEnum.DELETE_GROUPE);
        log.info("end method /Groupe/delete");
        return response;
    }

    @RequestMapping(value="/forceDelete",method=RequestMethod.DELETE,consumes = {"application/json"},produces={"application/json"})
    public Response<GroupeDto> forceDelete(@RequestBody Request<GroupeDto> request) {
        log.info("start method /Groupe/forceDelete");
        Response<GroupeDto> response = controllerFactory.forceDelete(groupeBusiness, request, FunctionalityEnum.DELETE_GROUPE);
        log.info("end method /Groupe/forceDelete");
        return response;
    }

    @RequestMapping(value="/getByCriteria",method=RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<GroupeDto> getByCriteria(@RequestBody Request<GroupeDto> request) {
        log.info("start method /Groupe/getByCriteria");
        Response<GroupeDto> response = controllerFactory.getByCriteria(groupeBusiness, request, FunctionalityEnum.VIEW_GROUPE);
        log.info("end method /Groupe/getByCriteria");
        return response;
    }
}
