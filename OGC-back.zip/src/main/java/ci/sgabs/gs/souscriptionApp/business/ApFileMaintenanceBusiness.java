package ci.sgabs.gs.souscriptionApp.business;

import ci.sgabs.gs.souscriptionApp.dao.entity.ApFile;
import ci.sgabs.gs.souscriptionApp.dao.entity.ApFileMaintenance;
import ci.sgabs.gs.souscriptionApp.dao.entity.Functionality;
import ci.sgabs.gs.souscriptionApp.dao.repository.ApFileMaintenanceRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.ApFileRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.RoleFunctionalityRepository;
import ci.sgabs.gs.souscriptionApp.helper.contrat.IBasicBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.errors.TechnicalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.ApFileDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.ApFileMaintenanceDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.FunctionalityDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.RoleDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.ApFileMaintenanceTransformer;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.ApFileTransformer;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.FunctionalityTransformer;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

@Log
@Component
public class ApFileMaintenanceBusiness implements IBasicBusiness<Request<ApFileMaintenanceDto>, Response<ApFileMaintenanceDto>> {

    private Response<RoleDto> response;
    @Autowired
    private ApFileMaintenanceRepository apFileMaintenanceRepository;

    @Autowired
    private RoleFunctionalityRepository roleFunctionalityRepository;
    @Autowired
    private FunctionalError functionalError;
    @Autowired
    private TechnicalError technicalError;
    @Autowired
    private ExceptionUtils exceptionUtils;
    @Autowired
    private EntityManager em;
    @Autowired
    private RoleFunctionalityBusiness roleFunctionalityBusiness;
    private final SimpleDateFormat dateFormat;
    private final SimpleDateFormat dateTimeFormat;

    public ApFileMaintenanceBusiness() {

        dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    }

    @Override
    public Response<ApFileMaintenanceDto> create(Request<ApFileMaintenanceDto> request, Locale locale) throws ParseException {
        return null;
    }


    private Response<ApFileMaintenanceDto> blockDuplicationData(Request<ApFileMaintenanceDto> request, Locale locale, Response<RoleDto> response, List<RoleDto> itemsDtos) {
        return null;
    }


    @Override
    public Response<ApFileMaintenanceDto> update(Request<ApFileMaintenanceDto> request, Locale locale) throws ParseException {
        return null;
    }


    @Override
    public Response<ApFileMaintenanceDto> delete(Request<ApFileMaintenanceDto> request, Locale locale) {
        return null;
    }


    @Override
    public Response<ApFileMaintenanceDto> forceDelete(Request<ApFileMaintenanceDto> request, Locale locale) throws ParseException {

        return null;
    }

    @Override
    public Response<ApFileMaintenanceDto> getByCriteria(Request<ApFileMaintenanceDto> request, Locale locale) throws Exception {
        log.info("----begin get ApFileMaintenance-----");
        Response<ApFileMaintenanceDto> response = new Response<ApFileMaintenanceDto>();
        //****** verification si le parametre d'ordre à été fourni, sinon nous mettons le paramètre à vide ********//
        if (Utilities.blank(request.getData().getOrderField())) {
            request.getData().setOrderField("");
        }
        //****** verification si le parametre direction à été fourni, sinon nous mettons le paramètre ascendant( du plus ancien au plus ressent) ********//
        if (Utilities.blank(request.getData().getOrderDirection())) {
            request.getData().setOrderDirection("asc");
        }
        //****** recuperation des entités en base *******//
        List<ApFileMaintenance> items = apFileMaintenanceRepository.getByCriteria(request, em, locale);
        if (Utilities.isEmpty(items)) {
            response.setStatus(functionalError.DATA_EMPTY("Role", locale));
            response.setHasError(false);
            return response;
        }
        List<ApFileMaintenanceDto> itemsDto = Collections.synchronizedList(new ArrayList<ApFileMaintenanceDto>());
        itemsDto = (Utilities.isTrue(request.getIsSimpleLoading())) ? ApFileMaintenanceTransformer.INSTANCE.toLiteDtos(items) : ApFileMaintenanceTransformer.INSTANCE.toDtos(items);
        response.setItems(itemsDto);
        response.setCount(apFileMaintenanceRepository.count(request, em, locale));
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end get ApFileMaintenance-----");
        return response;
    }

}
