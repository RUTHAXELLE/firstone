package ci.sgabs.gs.souscriptionApp.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

@Entity @Data @NoArgsConstructor @AllArgsConstructor
public class Users implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @Column(name="nom", length=255)
    private String nom;
    @Column(name="prenoms", length=255)
    private String prenoms;
    @Column(name="nom_prenoms", length=255)
    private String nomPrenoms;
    @Column(name="matricule", length=255)
    private String matricule;
    @Column(name="password", length=255)
    private String password;
    @Column(name="login", length=255)
    private String login;
    @ManyToOne(fetch = FetchType.EAGER)
    private Role role;
    @ManyToOne(fetch = FetchType.EAGER)
    private Agence agence;

    @Column(name="is_deleted")
    private Boolean isDeleted;
    @Column(name="is_actif")
    private Boolean isActif;
    @Column(name="is_first")
    private Boolean isFirst;
    @Column(name="number_of_connections")
    private Integer numberOfConnections; //Permet de compter le nombre de fois qu'un utilisateur s'est authentifié

    private Date createdAt;
    private Date updatedAt;
    private Date deletedAt;
    private  Date lastConnectionDate;

    private Integer createdBy;
    private Integer updatedBy;
    private Integer deletedBy;

}
