package ci.sgabs.gs.souscriptionApp.business;

import ci.sgabs.gs.souscriptionApp.dao.entity.Client;
import ci.sgabs.gs.souscriptionApp.dao.entity.TypeClient;
import ci.sgabs.gs.souscriptionApp.dao.repository.ClientRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.TypeClientRepository;
import ci.sgabs.gs.souscriptionApp.helper.contrat.IBasicBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.enums.CiviliteEnum;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.errors.TechnicalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.helper.validation.Validate;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.ClientDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.ClientTransformer;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Cette classe traite les operations portant sur les clients
 *
 * @author Alzouma Moussa Mahamadou
 * @date 12/05/2022
 */
@Log
@Component
public class ClientBusiness implements IBasicBusiness<Request<ClientDto>, Response<ClientDto>> {


    private Response<ClientDto> response;
    @Autowired
    private ClientRepository clientRepository;
    @Autowired
    private FunctionalError functionalError;
    @Autowired
    private TechnicalError technicalError;
    @Autowired
    private ExceptionUtils exceptionUtils;
    @Autowired
    private EntityManager em;
    @Autowired
    private TypeClientRepository typeClientRepository;

    private final SimpleDateFormat dateFormat;
    private final SimpleDateFormat dateTimeFormat;

    public ClientBusiness() {

        dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    }


    @Override
    public Response<ClientDto> create(Request<ClientDto> request, Locale locale) throws ParseException {


        //Reception et traitement des données du front-edn (classe AgenceDTO)
        Response<ClientDto> response = new Response<ClientDto>();
        List<Client> items = new ArrayList<Client>();

        //Verificatioon de la liste de données recues
        if (request.getDatas().isEmpty() || request.getDatas() == null) {
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ", locale));
            response.setHasError(true);
            return response;
        }

        //Verification des parametres obligatoires
        List<ClientDto> itemsDtos = Collections.synchronizedList(new ArrayList<ClientDto>());
        for (ClientDto dto : request.getDatas()) {
            // Definir les parametres obligatoires
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("code", dto.getCode());
            fieldsToVerify.put("prenoms", dto.getPrenoms());
            fieldsToVerify.put("nom", dto.getNom());
            fieldsToVerify.put("civilite", dto.getCivilite());
            fieldsToVerify.put("dateBirth", dto.getDateBirth());
            fieldsToVerify.put("typeClientId", dto.getTypeClientId());
            fieldsToVerify.put("adressPostale1", dto.getAdressPostale1());
            fieldsToVerify.put("indicatifPays", dto.getIndicatifPays());
            fieldsToVerify.put("city", dto.getCity());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            if (itemsDtos.stream().anyMatch(a -> a.getCode().equalsIgnoreCase(dto.getCode()))) {
                response.setStatus(functionalError.DATA_DUPLICATE("Tentative de duplication du code '" + dto.getCode() + "' pour les clients", locale));
                response.setHasError(true);
                return response;
            }
            itemsDtos.add(dto);
        }
        //Verification
        for (ClientDto dto : request.getDatas()) {
            if (!CiviliteEnum.isValidTag(dto.getCivilite())) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Les valeurs possible du champ civilité sont : Mr, Mme ou Mlle -> " + dto.getCode(), locale));
                response.setHasError(true);
                return response;
            }
            //Verification de doublon
            Client existingEntity = null;
            existingEntity = clientRepository.findByCode(dto.getCode(), false);
            if (existingEntity != null) {
                response.setStatus(functionalError.DATA_EXIST("Functionality code -> " + dto.getCode(), locale));
                response.setHasError(true);
                return response;
            }
            TypeClient typeClient = typeClientRepository.findOne(dto.getTypeClientId(), Boolean.FALSE);
            if (typeClient == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Ce type de client n'existe pas", locale));
                response.setHasError(true);
                return response;
            }
            //Transformer l'objet dto en entity
            Client entityToSave = ClientTransformer.INSTANCE.toEntity(dto, typeClient);
            entityToSave.setIsDeleted(false);
            entityToSave.setCreatedAt(Utilities.getCurrentDate());
            entityToSave.setCreatedBy(request.userID);
            entityToSave.setDateBirth(dateFormat.parse(dto.getDateBirth()));
            items.add(entityToSave);
        }

        //Verificatioon de la liste de données recues
        if (items == null || items.isEmpty()) {
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ", locale));
            response.setHasError(true);
            return response;
        }
        //Persistence des clients
        List<Client> itemsSaved = null;
        itemsSaved = clientRepository.saveAll((Iterable<Client>) items);
        if (itemsSaved == null) {
            response.setStatus(functionalError.SAVE_FAIL("Aucun client n'est crée", locale));
            response.setHasError(true);
            return response;
        }
        //Transformer une liste de clients en dto
        List<ClientDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                ? ClientTransformer.INSTANCE.toLiteDtos(itemsSaved)
                : ClientTransformer.INSTANCE.toDtos(itemsSaved);
        //Envoi de la reponse
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        return response;

    }


    @Override
    public Response<ClientDto> update(Request<ClientDto> request, Locale locale) throws ParseException {
        Response<ClientDto> response = new Response<ClientDto>();
        List<Client> items = new ArrayList<Client>();
        //Verificatioon de la liste de données recues
        if (request.getDatas().isEmpty() || request.getDatas() == null) {
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ", locale));
            response.setHasError(true);
            return response;
        }
        //Verification des parametres obligatoires
        List<ClientDto> itemsDtos = Collections.synchronizedList(new ArrayList<ClientDto>());
        for (ClientDto dto : request.getDatas()) {
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            itemsDtos.add(dto);
        }

        //Verification
        for (ClientDto dto : itemsDtos) {
            //Verification de doublon
            Client entityToSave = null;
            entityToSave = clientRepository.findOne(dto.getId(), false);
            if (entityToSave == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Le client ayant l'identifiant" + dto.getId() + ", n'existe pas", locale));
                response.setHasError(true);
                return response;
            }
            //Verification du code
            if (Utilities.isNotBlank(dto.getCode()) && !dto.getCode().equals(entityToSave.getCode())) {
                Client existingEntity = clientRepository.findByCode(dto.getCode(), false);
                //Verification de l'identifiant
                if (existingEntity != null && !existingEntity.getId().equals(entityToSave.getId())) {
                    response.setStatus(functionalError.DATA_EXIST("Functionality -> " + dto.getCode(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setCode(dto.getCode());

            }
            if (Utilities.isNotBlank(dto.getNom()) && !dto.getNom().equals(entityToSave.getNom())) {
                entityToSave.setNom(dto.getNom());
            }
            if (Utilities.isNotBlank(dto.getPrenoms()) && !dto.getPrenoms().equals(entityToSave.getPrenoms())) {
                entityToSave.setPrenoms(dto.getPrenoms());
            }
            if (Utilities.isNotBlank(dto.getContact())) {
                entityToSave.setContact(dto.getContact());
            }
            if (Utilities.isValidID(dto.getTypeClientId())) {
                TypeClient typeClient = typeClientRepository.findOne(dto.getTypeClientId(), Boolean.FALSE);
                if (typeClient == null) {
                    response.setStatus(functionalError.DATA_EXIST("typeClient -> " + dto.getTypeClientId(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setTypeClient(typeClient);
            }
            if(Utilities.isNotBlank(dto.getCivilite())){
                  entityToSave.setCivilite(dto.getCivilite());
            }
            if (Utilities.isNotBlank(dto.getDateBirth())) {
                entityToSave.setDateBirth(dateFormat.parse(dto.getDateBirth()));
            }
            if (Utilities.isNotBlank(dto.getIndicatifPays())) {
                entityToSave.setIndicatifPays(dto.getIndicatifPays());
            }
            if (Utilities.isNotBlank(dto.getCity())) {
                entityToSave.setCity(dto.getCity());
            }
            if (Utilities.isNotBlank(dto.getAdressPostale1())) {
                entityToSave.setAdressPostale1(dto.getAdressPostale1());
            }
            if (Utilities.isNotBlank(dto.getAdressPostale2())) {
                entityToSave.setAdressPostale2(dto.getAdressPostale2());
            }
            entityToSave.setUpdatedAt(Utilities.getCurrentDate());
            entityToSave.setUpdatedBy(request.userID);// a modifier
            items.add(entityToSave);
        }
        //Verificatioon de la liste de données recues
        if (items == null || items.isEmpty()) {
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ", locale));
            response.setHasError(true);
            return response;
        }
        //Transformation
        List<ClientDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                ? ClientTransformer.INSTANCE.toLiteDtos(items)
                : ClientTransformer.INSTANCE.toDtos(items);
        //Envoie de la reponse
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        return response;
    }


    @Override
    public Response<ClientDto> delete(Request<ClientDto> request, Locale locale) {


        log.info("----begin update Functionality-----");
        Response<ClientDto> response = new Response<ClientDto>();
        List<Client> items = new ArrayList<Client>();

        //Verification
        if (request.getDatas().isEmpty() || request.getDatas() == null) {
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ", locale));
            response.setHasError(true);
            return response;
        }

        //Verification du champ obligatoire
        for (ClientDto dto : request.getDatas()) {
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());

            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
        }

        //Suppression logique
        for (ClientDto dto : request.getDatas()) {

            //Verifier le client
            Client existingEntity = null;
            existingEntity = clientRepository.findOne(dto.getId(), false);

            if (existingEntity == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Functionality id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }

            //Suppression logique
            existingEntity.setIsDeleted(true);
            existingEntity.setDeletedAt(Utilities.getCurrentDate());
            existingEntity.setDeletedBy(request.userID);// a modifier

            items.add(existingEntity);

        }

        //Verificatioon de la liste de données recues
        if (items == null || items.isEmpty()) {
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de données est vide ", locale));
            response.setHasError(true);
            return response;
        }

        //Envoie de la reponse
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        return response;

    }

    @Override
    public Response<ClientDto> forceDelete(Request<ClientDto> request, Locale locale) throws ParseException {
        return null;
    }

    @Override
    public Response<ClientDto> getByCriteria(Request<ClientDto> request, Locale locale) throws Exception {


        log.info("----begin get Functionality-----");

        Response<ClientDto> response = new Response<ClientDto>();

        if (Utilities.blank(request.getData().getOrderField())) {
            request.getData().setOrderField("");
        }

        if (Utilities.blank(request.getData().getOrderDirection())) {
            request.getData().setOrderDirection("asc");
        }
        List<Client> items = clientRepository.getByCriteria(request, em, locale);
        if (Utilities.isEmpty(items)) {
            response.setStatus(functionalError.DATA_EMPTY("Functionality", locale));
            response.setHasError(false);
            return response;
        }
        List<ClientDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                ? ClientTransformer.INSTANCE.toLiteDtos(items)
                : ClientTransformer.INSTANCE.toDtos(items);
        response.setItems(itemsDto);
        response.setCount(clientRepository.count(request, em, locale));
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        log.info("----end get Functionality-----");

        return response;
    }


}
