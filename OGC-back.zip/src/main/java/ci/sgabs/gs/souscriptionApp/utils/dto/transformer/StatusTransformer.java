package ci.sgabs.gs.souscriptionApp.utils.dto.transformer;

import ci.sgabs.gs.souscriptionApp.dao.entity.Status;
import ci.sgabs.gs.souscriptionApp.helper.contrat.FullTransformerQualifier;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.StatusDto;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

@Mapper
public interface StatusTransformer {

    StatusTransformer INSTANCE = Mappers.getMapper(StatusTransformer.class);

    @FullTransformerQualifier
    @Mappings({
            @Mapping(source = "entity.id", target = "id"),
            @Mapping(source = "entity.code", target = "code"),
            @Mapping(source = "entity.description", target = "description"),

            @Mapping(source="entity.updatedAt", dateFormat="dd/MM/yyyy",target="updatedAt"),
            @Mapping(source="entity.createdAt", dateFormat="dd/MM/yyyy",target="createdAt"),
            @Mapping(source="entity.deletedAt", dateFormat="dd/MM/yyyy",target="deletedAt"),
            @Mapping(source="entity.updatedBy",target="updatedBy"),
            @Mapping(source="entity.createdBy", target="createdBy"),
            @Mapping(source="entity.deletedBy", target="deletedBy"),

    })
    StatusDto toDto(Status entity);

    @IterableMapping(qualifiedBy = {FullTransformerQualifier.class})
    List<StatusDto> toDtos(List<Status> entities) throws ParseException;

    public default StatusDto toLiteDto(Status entity) {
        if (entity == null) {
            return null;
        }
        StatusDto dto = new StatusDto();
        dto.setId( entity.getId() );
        dto.setCode( entity.getCode() );
        dto.setDescription(entity.getDescription());

        return dto;
    }

    public default List<StatusDto> toLiteDtos(List<Status> entities) {
        if (entities == null || entities.stream().allMatch(o -> o == null)) {
            return null;
        }
        List<StatusDto> dtos = new ArrayList<StatusDto>();
        for (Status entity : entities) {
            dtos.add(toLiteDto(entity));
        }
        return dtos;
    }

    @InheritInverseConfiguration
    Status toEntity(StatusDto dto);
}
