package ci.sgabs.gs.souscriptionApp.utils.dto.transformer;

import ci.sgabs.gs.souscriptionApp.dao.entity.Status;
import ci.sgabs.gs.souscriptionApp.dao.entity.TypeOperation;
import ci.sgabs.gs.souscriptionApp.helper.contrat.FullTransformerQualifier;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.StatusDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.TypeOperationDto;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

@Mapper
public interface TypeOperationTransformer {

    TypeOperationTransformer INSTANCE = Mappers.getMapper(TypeOperationTransformer.class);

    @FullTransformerQualifier
    @Mappings({
            @Mapping(source = "entity.id", target = "id"),
            @Mapping(source = "entity.code", target = "code"),
            @Mapping(source = "entity.description", target = "description"),

            @Mapping(source="entity.updatedAt", dateFormat="dd/MM/yyyy",target="updatedAt"),
            @Mapping(source="entity.createdAt", dateFormat="dd/MM/yyyy",target="createdAt"),
            @Mapping(source="entity.deletedAt", dateFormat="dd/MM/yyyy",target="deletedAt"),
            @Mapping(source="entity.updatedBy",target="updatedBy"),
            @Mapping(source="entity.createdBy", target="createdBy"),
            @Mapping(source="entity.deletedBy", target="deletedBy"),

    })
    TypeOperationDto toDto(TypeOperation entity);

    @IterableMapping(qualifiedBy = {FullTransformerQualifier.class})
    List<TypeOperationDto> toDtos(List<TypeOperation> entities) throws ParseException;

    public default TypeOperationDto toLiteDto(TypeOperation entity) {
        if (entity == null) {
            return null;
        }
        TypeOperationDto dto = new TypeOperationDto();
        dto.setId( entity.getId() );
        dto.setCode( entity.getCode() );
        dto.setDescription(entity.getDescription());

        return dto;
    }

    public default List<TypeOperationDto> toLiteDtos(List<TypeOperation> entities) {
        if (entities == null || entities.stream().allMatch(o -> o == null)) {
            return null;
        }
        List<TypeOperationDto> dtos = new ArrayList<TypeOperationDto>();
        for (TypeOperation entity : entities) {
            dtos.add(toLiteDto(entity));
        }
        return dtos;
    }

    @InheritInverseConfiguration
    TypeOperation toEntity(TypeOperationDto dto);
}
