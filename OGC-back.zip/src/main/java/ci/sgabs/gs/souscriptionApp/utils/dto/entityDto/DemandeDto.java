package ci.sgabs.gs.souscriptionApp.utils.dto.entityDto;

import ci.sgabs.gs.souscriptionApp.helper.searchFunctions.SearchParam;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;
import lombok.ToString;

import javax.persistence.Column;
import java.util.Collection;
import java.util.List;

@Data
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL) @JsonPropertyOrder(alphabetic = true)
public class DemandeDto {

    private Integer id;
    private String code;

    private String matricule ;
    private String noms;
    private String prenom;
    private String telephone;
    private String motif;
    private String intitule;
    private String agence ;
    private String produit ;
    private String numeroCompte ;

    private Integer typeCarteId;
    private Integer compteId;
    private String  codeTypeCarte;
    private Integer statusId;
    private String  codeStatus;
    private Boolean isDeleted;

    private Boolean isPlafondHaut;
    private Boolean isPlafondBas;
    private Boolean isPlafondMoyen;
    private Boolean isGenreatedContrat;
    private Boolean isForced;

    private String createdAt;
    private String updatedAt;
    private String deletedAt;

    private Integer createdBy;
    private String  login;
    private Integer updatedBy;
    private Integer deletedBy;
    private String nomBeneficiaire;
    private String prenomBeneficiaire;
    private Boolean isBeneficiary;


    /// SEARCH PARAM//

    private SearchParam<Integer> idParam;
    private SearchParam<String> codeParam;
    private SearchParam<Integer> typeCarteIdParam;
    private SearchParam<Integer> compteIdParam;
    private SearchParam<String>   codeTypeCarteParam;
    private SearchParam<Integer> statusIdParam;
    private SearchParam<String>   codeStatusParam;
    private SearchParam<String>   numeroCompteParam;
    private SearchParam<Boolean> isDeletedParam;
    private SearchParam<String> createdAtParam;
    private SearchParam<String> loginParam;
    private SearchParam<String> produitParam;
    private SearchParam<String> agenceParam;
    private SearchParam<String> updatedAtParam;
    private SearchParam<String> deletedAtParam;
    private SearchParam<Integer> createdByParam;
    private SearchParam<Integer> updatedByParam;
    private SearchParam<Integer> deletedByParam;
    private SearchParam<String> nomBeneficiaireParam;
    private SearchParam<String> prenomBeneficiaireParam;
    private SearchParam<Boolean> isBeneficiaryParam;

    // order param
    private String orderField;
    private String orderDirection;

    private List<StatusDto> datasStatus;

}
