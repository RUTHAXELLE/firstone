package ci.sgabs.gs.souscriptionApp.dao.repository;

import ci.sgabs.gs.souscriptionApp.dao.entity.Attribution;
import ci.sgabs.gs.souscriptionApp.dao.entity.Carte;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.searchFunctions.CriteriaUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.AttributionDto;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import java.util.*;

public interface AttributionRepository extends JpaRepository<Attribution, Integer> {

    @Query("select e from Attribution e where e.id= :id and e.isDeleted= :isDeleted")
    Attribution findOne(@Param("id") Integer id, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from Attribution e where e.code= :code and e.isDeleted= :isDeleted")
    Attribution findByCode(@Param("code") String code, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from Attribution e where e.demande.id= :demandeId and e.isDeleted= :isDeleted")
    Attribution findByDemandeId(@Param("demandeId") Integer demandeId, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from Attribution e where e.demande.code= :codeDemande and e.isDeleted= :isDeleted")
    Attribution findByCodeDemande(@Param("codeDemande") String codeDemande, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from Attribution e where e.carte.id= :carteId and e.isDeleted= :isDeleted")
    Attribution findByCarteId(@Param("carteId") Integer carteId, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from Attribution e where e.carte.code= :codeCarte and e.isDeleted= :isDeleted")
    Attribution findByCodeCarte(@Param("codeCarte") String codeCarte, @Param("isDeleted") Boolean isDeleted);

    @Query("select e.carte from Attribution e where e.demande.compte.id= :compteId and e.isDeleted= :isDeleted")
    List<Carte> findCarteByCompte(@Param("compteId") Integer compteId, @Param("isDeleted") Boolean isDeleted);


    // criteria search//
    public default List<Attribution> getByCriteria(Request<AttributionDto> request, EntityManager em, Locale locale) throws DataAccessException, Exception {
        String req = "select e from Attribution e where e IS NOT NULL";
        HashMap<String, Object> param = new HashMap<String, Object>();
        req += getWhereExpression(request, param, locale);
        TypedQuery<Attribution> query = em.createQuery(req, Attribution.class);
        for (Map.Entry<String, Object> entry : param.entrySet()) {
            query.setParameter(entry.getKey(), entry.getValue());
        }
        if (request.getIndex() != null && request.getSize() != null) {
            query.setFirstResult(request.getIndex() * request.getSize());
            query.setMaxResults(request.getSize());
        }
        return query.getResultList();
    }
    public default Long count(Request<AttributionDto> request, EntityManager em, Locale locale) throws DataAccessException, Exception  {
        String req = "select count(*) from Attribution e where e IS NOT NULL";
        HashMap<String, Object> param = new HashMap<String, Object>();
        req += getWhereExpressionCount(request, param, locale);
        javax.persistence.Query query = em.createQuery(req);
        for (Map.Entry<String, Object> entry : param.entrySet()) {
            query.setParameter(entry.getKey(), entry.getValue());
        }
        Long count = (Long) query.getResultList().get(0);
        return count;
    }

    /**
     * get where expression
     * @param request
     * @param param
     * @param locale
     * @return
     * @throws Exception
     */
    default String getWhereExpression(Request<AttributionDto> request, HashMap<String, Object> param, Locale locale) throws Exception {
        // main query
        AttributionDto dto = request.getData() != null ? request.getData() : new AttributionDto();
        dto.setIsDeleted(false);
        String mainReq = generateCriteria(dto, param, 0, locale);
        // others query
        String othersReq = "";
        if (request.getDatas() != null && !request.getDatas().isEmpty()) {
            Integer index = 1;
            for (AttributionDto elt : request.getDatas()) {
                elt.setIsDeleted(false);
                String eltReq = generateCriteria(elt, param, index, locale);
                if (request.getIsAnd() != null && request.getIsAnd()) {
                    othersReq += "and (" + eltReq + ") ";
                } else {
                    othersReq += "or (" + eltReq + ") ";
                }
                index++;
            }
        }
        String req = "";
        if (!mainReq.isEmpty()) {
            req += " and (" + mainReq + ") ";
        }
        req += othersReq;

        //order
        if(Sort.Direction.fromOptionalString(dto.getOrderDirection()).orElse(null) != null && Utilities.notBlank(dto.getOrderField())) {
            req += " order by e."+dto.getOrderField()+" "+dto.getOrderDirection();
        }
        else {
            req += " order by  e.id desc";
        }
        return req;
    }


    default String getWhereExpressionCount(Request<AttributionDto> request, HashMap<String, Object> param, Locale locale) throws Exception {
        // main query
        AttributionDto dto = request.getData() != null ? request.getData() : new AttributionDto();
        dto.setIsDeleted(false);
        String mainReq = generateCriteria(dto, param, 0, locale);
        // others query
        String othersReq = "";
        if (request.getDatas() != null && !request.getDatas().isEmpty()) {
            Integer index = 1;
            for (AttributionDto elt : request.getDatas()) {
                elt.setIsDeleted(false);
                String eltReq = generateCriteria(elt, param, index, locale);
                if (request.getIsAnd() != null && request.getIsAnd()) {
                    othersReq += "and (" + eltReq + ") ";
                } else {
                    othersReq += "or (" + eltReq + ") ";
                }
                index++;
            }
        }
        String req = "";
        if (!mainReq.isEmpty()) {
            req += " and (" + mainReq + ") ";
        }
        req += othersReq;
        return req;
    }
    /**
     * generate sql query for dto
     * @param dto
     * @param param
     * @param index
     * @param locale
     * @return
     * @throws Exception
     */
    default String generateCriteria(AttributionDto dto, HashMap<String, Object> param, Integer index, Locale locale) throws Exception{
        List<String> listOfQuery = new ArrayList<String>();
        if (dto != null) {
            if (dto.getId() != null || Utilities.searchParamIsNotEmpty(dto.getIdParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("id", dto.getId(), "e.id", "Integer", dto.getIdParam(), param, index, locale));
            }
            if (Utilities.isNotBlank(dto.getCode()) || Utilities.searchParamIsNotEmpty(dto.getCodeParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("code", dto.getCode(), "e.code", "String", dto.getCodeParam(), param, index, locale));
            }
            if (dto.getDemandeId() != null || Utilities.searchParamIsNotEmpty(dto.getDemandeIdParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("demandeId", dto.getDemandeId(), "e.demande.id", "Integer", dto.getDemandeIdParam(), param, index, locale));
            }
            if (Utilities.isNotBlank(dto.getCodeDemande()) || Utilities.searchParamIsNotEmpty(dto.getCodeDemandeParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("codeDemande", dto.getCodeDemande(), "e.demande.code", "String", dto.getCodeDemandeParam(), param, index, locale));
            }
            if (dto.getCarteId() != null || Utilities.searchParamIsNotEmpty(dto.getCarteIdParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("carteId", dto.getCarteId(), "e.carte.id", "Integer", dto.getCarteIdParam(), param, index, locale));
            }
            if (Utilities.isNotBlank(dto.getCodeCarte()) || Utilities.searchParamIsNotEmpty(dto.getCodeCarteParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("codeCarte", dto.getCodeCarte(), "e.carte.code", "String", dto.getCodeCarteParam(), param, index, locale));
            }

            if (Utilities.isNotBlank(dto.getUpdatedAt()) || Utilities.searchParamIsNotEmpty(dto.getUpdatedAtParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("updatedAt", dto.getUpdatedAt(), "e.updatedAt", "Date", dto.getUpdatedAtParam(), param, index, locale));
            }
            if (dto.getIsDeleted() != null || Utilities.searchParamIsNotEmpty(dto.getIsDeletedParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("isDeleted", dto.getIsDeleted(), "e.isDeleted", "Boolean", dto.getIsDeletedParam(), param, index, locale));
            }
            if (dto.getUpdatedBy() != null || Utilities.searchParamIsNotEmpty(dto.getUpdatedByParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("updatedBy", dto.getUpdatedBy(), "e.updatedBy", "Long", dto.getUpdatedByParam(), param, index, locale));
            }
            if (Utilities.isNotBlank(dto.getCreatedAt()) || Utilities.searchParamIsNotEmpty(dto.getCreatedAtParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("createdAt", dto.getCreatedAt(), "e.createdAt", "Date", dto.getCreatedAtParam(), param, index, locale));
            }
            if (dto.getCreatedBy() != null || Utilities.searchParamIsNotEmpty(dto.getCreatedByParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("createdBy", dto.getCreatedBy(), "e.createdBy", "Long", dto.getCreatedByParam(), param, index, locale));
            }
            if (Utilities.isNotBlank(dto.getDeletedAt()) || Utilities.searchParamIsNotEmpty(dto.getDeletedAtParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("deletedAt", dto.getDeletedAt(), "e.deletedAt", "Date", dto.getDeletedAtParam(), param, index, locale));
            }
            if (dto.getDeletedBy() != null || Utilities.searchParamIsNotEmpty(dto.getDeletedByParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("deletedBy", dto.getDeletedBy(), "e.deletedBy", "Long", dto.getDeletedByParam(), param, index, locale));
            }

        }
        return CriteriaUtils.getCriteriaByListOfQuery(listOfQuery);
    }
}
