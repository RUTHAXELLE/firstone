package ci.sgabs.gs.souscriptionApp.business;

import ci.sgabs.gs.souscriptionApp.dao.entity.Functionality;
import ci.sgabs.gs.souscriptionApp.dao.entity.Role;
import ci.sgabs.gs.souscriptionApp.dao.entity.RoleFunctionality;
import ci.sgabs.gs.souscriptionApp.dao.repository.RoleFunctionalityRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.RoleRepository;
import ci.sgabs.gs.souscriptionApp.helper.contrat.IBasicBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.errors.TechnicalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.helper.validation.Validate;
import ci.sgabs.gs.souscriptionApp.utils.authentification.SecurityConstants;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.FunctionalityDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.RoleDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.RoleFunctionalityDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.FunctionalityTransformer;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.RoleFunctionalityTransformer;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.RoleTransformer;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Log
@Component
public class RoleBusiness implements IBasicBusiness<Request<RoleDto>, Response<RoleDto>> {

    private Response<RoleDto> response;
    @Autowired
    private RoleRepository roleRepository;
    @Autowired
    private UsersBusiness usersBusiness;
    @Autowired
    private RoleFunctionalityRepository roleFunctionalityRepository;
    @Autowired
    private FunctionalError functionalError;
    @Autowired
    private TechnicalError technicalError;
    @Autowired
    private ExceptionUtils exceptionUtils;
    @Autowired
    private EntityManager em;
    @Autowired
    private RoleFunctionalityBusiness roleFunctionalityBusiness;
    private final SimpleDateFormat dateFormat;
    private final SimpleDateFormat dateTimeFormat;

    public RoleBusiness() {

        dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    }

    @Override
    public Response<RoleDto> create(Request<RoleDto> request, Locale locale) throws ParseException {

        log.info("----begin create Role-----");
        Response<RoleDto> response = new Response<RoleDto>();
        List<Role> items = new ArrayList<Role>();
        List<RoleDto>itemsDtos =  Collections.synchronizedList(new ArrayList<RoleDto>());
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_PROFILE_CREATE);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas créer un rôle.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        //empêcher la duplication des données
        Response<RoleDto> response1 = blockDuplicationData(request, locale, response, itemsDtos);
        if (response1 != null) return response1;
        //Creation role
        for(RoleDto dto : request.getDatas()){
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("code", dto.getCode());
            fieldsToVerify.put("libelle", dto.getLibelle());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            Role existingEntity = roleRepository.findByCode(dto.getCode(), false); //verification en base
            if (existingEntity != null) {
                response.setStatus(functionalError.DATA_EXIST("Role code -> " + dto.getCode(), locale));
                response.setHasError(true);
                return response;
            }
            Role entityToSave = RoleTransformer.INSTANCE.toEntity(dto);
            entityToSave.setIsDeleted(false);
            entityToSave.setCreatedAt(Utilities.getCurrentDate());
            if(Utilities.isValidID(request.userID)){
                entityToSave.setCreatedBy(request.userID);
            }
            Role entitySaved = roleRepository.save(entityToSave);
            items.add(entitySaved);
            if (Utilities.isNotEmpty(dto.getDatasFunctionalities())) {
                List<RoleFunctionalityDto> datasProfilFunctionality = new ArrayList<RoleFunctionalityDto>();
                dto.getDatasFunctionalities().forEach(f -> {
                    RoleFunctionalityDto roleFunctionalityDto = new RoleFunctionalityDto();
                    roleFunctionalityDto.setRoleId(entitySaved.getId());
                    roleFunctionalityDto.setFunctionalityId(f.getId());
                    datasProfilFunctionality.add(roleFunctionalityDto);
                });
                Request<RoleFunctionalityDto> subRequest = new Request<RoleFunctionalityDto>();
                subRequest.setDatas(datasProfilFunctionality);
                Response<RoleFunctionalityDto> subResponse = roleFunctionalityBusiness.create(subRequest, locale);
                if (subResponse.isHasError()) {
                    response.setStatus(subResponse.getStatus());
                    response.setHasError(true);
                    return response;
                }
            }
        }
       //Verification de la liste
        if (!items.isEmpty()) {
            List<Role>  itemsSaved = roleRepository.saveAll((Iterable<Role>) items);
            if (itemsSaved == null) {
                response.setStatus(functionalError.SAVE_FAIL("Role", locale));
                response.setHasError(true);
                return response;
            }
            List<RoleDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading())) ? RoleTransformer.INSTANCE.toLiteDtos(itemsSaved) : RoleTransformer.INSTANCE.toDtos(itemsSaved);
            response.setItems(itemsDto);
            response.setHasError(false);
            response.setStatus(functionalError.SUCCESS("", locale));
        }
        log.info("----end create Role-----");
        return response;
    }

    private Response<RoleDto> blockDuplicationData(Request<RoleDto> request, Locale locale, Response<RoleDto> response, List<RoleDto> itemsDtos) {
        for(RoleDto dto: request.getDatas() ) {
            // Definir les parametres obligatoires
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("code", dto.getCode());
            fieldsToVerify.put("libelle", dto.getLibelle());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            if(itemsDtos.stream().anyMatch(a->a.getCode().equalsIgnoreCase(dto.getCode()))){
                response.setStatus(functionalError.DATA_DUPLICATE("Tentative de duplication du code '" + dto.getCode() + "' pour les rôles", locale));
                response.setHasError(true);
                return response;
            }
            itemsDtos.add(dto);
        }
        return null;
    }

    @Override
    public Response<RoleDto> update(Request<RoleDto> request, Locale locale) throws ParseException {

        log.info("----begin update Role-----");
        Response<RoleDto> response = new Response<RoleDto>();
        List<Role> items = new ArrayList<Role>();
        List<RoleDto>itemsDtos =  Collections.synchronizedList(new ArrayList<RoleDto>());
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_PROFILE_UPDATE);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas modifier rôle.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        //empêcher la duplication des données
        Response<RoleDto> response1 = blockDuplicationDataUpdate(request, locale, response, itemsDtos);
        for(RoleDto dto : request.getDatas()){
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            Role entityToSave = null;
            entityToSave = roleRepository.findOne(dto.getId(), false);
            if (entityToSave == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Role id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }
            Integer entityToSaveId = entityToSave.getId();
            if (Utilities.isNotBlank(dto.getCode()) && !dto.getCode().equals(entityToSave.getCode())) { //verify code
                Role existingEntity = roleRepository.findByCode(dto.getCode(), false);
                if (existingEntity != null && !existingEntity.getId().equals(entityToSave.getId())) {
                    response.setStatus(functionalError.DATA_EXIST("Role code -> " + dto.getCode(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setCode(dto.getCode());
            }
            if (Utilities.isNotBlank(dto.getLibelle()) && !dto.getLibelle().equals(entityToSave.getLibelle())) { //verify libelle
                Role existingEntity = roleRepository.findByLibelle(dto.getLibelle(), false);
                if (existingEntity != null && !existingEntity.getId().equals(entityToSave.getId())) {
                    response.setStatus(functionalError.DATA_EXIST("Role -> " + dto.getLibelle(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setLibelle(dto.getLibelle());
            }
            if (Utilities.isNotEmpty(dto.getDatasFunctionalities())) {
                List<RoleFunctionality> list = roleFunctionalityRepository
                        .findByRoleId(entityToSaveId, false);
                if(Utilities.isNotEmpty(list)) {
                    for (RoleFunctionality rf : list) {
                        RoleFunctionalityDto itemsData = RoleFunctionalityTransformer.INSTANCE.toDto(rf);
                        Request<RoleFunctionalityDto> subRequest = new Request<RoleFunctionalityDto>();
                        subRequest.setDatas(Arrays.asList(itemsData));
                        Response<RoleFunctionalityDto> subResponse = roleFunctionalityBusiness.delete(subRequest, locale);
                        if (subResponse.isHasError()) {
                            response.setStatus(subResponse.getStatus());
                            response.setHasError(true);
                            return response;
                        }
                    }
                }
                for (FunctionalityDto f : dto.getDatasFunctionalities()) {
                    RoleFunctionalityDto roleFunctionalityDto = new RoleFunctionalityDto();
                    roleFunctionalityDto.setRoleId(entityToSaveId);
                    roleFunctionalityDto.setFunctionalityId(f.getId());
                    Request<RoleFunctionalityDto> subRequests = new Request<RoleFunctionalityDto>();
                    subRequests.setDatas(Arrays.asList(roleFunctionalityDto));
                    Response<RoleFunctionalityDto> subResponses = roleFunctionalityBusiness.create(subRequests,
                            locale);
                    if (subResponses.isHasError()) {
                        response.setStatus(subResponses.getStatus());
                        response.setHasError(true);
                        return response;
                    }
                }
            }
            entityToSave.setUpdatedAt(Utilities.getCurrentDate());
            entityToSave.setUpdatedBy(request.userID);
            items.add(entityToSave);
        }
        if (!items.isEmpty()) {
            List<Role> itemsSaved = null;
            // inserer les donnees en base de donnees
            itemsSaved = roleRepository.saveAll((Iterable<Role>) items);
            if (itemsSaved == null) {
                response.setStatus(functionalError.SAVE_FAIL("Role", locale));
                response.setHasError(true);
                return response;
            }
            List<RoleDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading())) ? RoleTransformer.INSTANCE.toLiteDtos(itemsSaved) : RoleTransformer.INSTANCE.toDtos(itemsSaved);
            for(RoleDto roleDto : itemsDto){
                try{
                    roleDto = getFullInfos(roleDto,1,Boolean.FALSE,locale);
                }catch (Exception e){
                     e.printStackTrace();
                }
            }
            response.setItems(itemsDto);
            response.setHasError(false);
            response.setStatus(functionalError.SUCCESS("", locale));
        }
        log.info("----end update Role-----");
        return response;
    }

    @Override
    public Response<RoleDto> delete(Request<RoleDto> request, Locale locale) {

        log.info("----begin delete Role-----");
        Response<RoleDto> response = new Response<RoleDto>();
        List<Role> items = new ArrayList<Role>();
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_PROFILE_DELETE);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas modifier rôle.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        //Suppression
        for(RoleDto dto : request.getDatas()){
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            Role existingEntity = null;
            existingEntity = roleRepository.findOne(dto.getId(), false);
            if (existingEntity == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Role id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }
            existingEntity.setIsDeleted(true);
            existingEntity.setDeletedAt(Utilities.getCurrentDate());
            existingEntity.setDeletedBy(request.userID);
            items.add(existingEntity);
        }
        if (!items.isEmpty()) {
            response.setHasError(false);
            response.setStatus(functionalError.SUCCESS("", locale));
        }
        log.info("----end delete Role-----");
        return response;
    }

    @Override
    public Response<RoleDto> forceDelete(Request<RoleDto> request, Locale locale) throws ParseException {

        log.info("----begin Forcedelete Role-----");
        Response<RoleDto> response = new Response<RoleDto>();
        List<Role> items = new ArrayList<Role>();
        for(RoleDto dto : request.getDatas()){
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            Role existingEntity = null;
            existingEntity = roleRepository.findOne(dto.getId(), false);
            if (existingEntity == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Role id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }
            List<RoleFunctionality> listOfRoleFunctionality = roleFunctionalityRepository.findByRoleId(existingEntity.getId(), false);
            if (listOfRoleFunctionality != null && !listOfRoleFunctionality.isEmpty()) {
                Request<RoleFunctionalityDto> deleteRequest = new Request<RoleFunctionalityDto>();
                deleteRequest.setDatas(RoleFunctionalityTransformer.INSTANCE.toDtos(listOfRoleFunctionality));
                Response<RoleFunctionalityDto> deleteResponse = roleFunctionalityBusiness.delete(deleteRequest, locale);
                if (deleteResponse.isHasError()) {
                    response.setStatus(deleteResponse.getStatus());
                    response.setHasError(true);
                    return response;
                }
            }
            existingEntity.setIsDeleted(true);
            existingEntity.setDeletedAt(Utilities.getCurrentDate());
            existingEntity.setDeletedBy(request.userID);
            items.add(existingEntity);
        }
        if (!items.isEmpty()) {
            response.setHasError(false);
            response.setStatus(functionalError.SUCCESS("", locale));
        }
        log.info("----end Forcedelete Role-----");
        return response;
    }

    private Response<RoleDto> blockDuplicationDataUpdate(Request<RoleDto> request, Locale locale, Response<RoleDto> response, List<RoleDto> itemsDtos) {
        for(RoleDto dto: request.getDatas() ) {
            // Definir les parametres obligatoires
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            if(itemsDtos.stream().anyMatch(a->a.getId().equals(dto.getId()))){
                response.setStatus(functionalError.DATA_DUPLICATE("Tentative de duplication de l'id '" + dto.getCode() + "' pour les fonctionnalités", locale));
                response.setHasError(true);
                return response;
            }
            if(Utilities.isNotBlank(dto.getCode())){
                itemsDtos = itemsDtos.stream().filter(a-> Utilities.isNotBlank(a.getCode())).collect(Collectors.toList());
                if(Utilities.isNotEmpty(itemsDtos)){
                    if(itemsDtos.stream().anyMatch(a->a.getCode().equals(dto.getCode()))){
                        response.setStatus(functionalError.DATA_DUPLICATE("Tentative de duplication du code '" + dto.getCode() + "' pour les fonctionnalités", locale));
                        response.setHasError(true);
                        return response;
                    }
                }
            }
            itemsDtos.add(dto);
        }
        return null;
    }

    @Override
    public Response<RoleDto> getByCriteria(Request<RoleDto> request, Locale locale) throws Exception {
        log.info("----begin get Role-----");
        Response<RoleDto> response = new Response<RoleDto>();
        //Verification des permissions
        boolean isUserAuthenticatedHaveFunctinality=usersBusiness.checkIfUserAuthenticatedHasThisFunctionnality(Request.userID, SecurityConstants.PERMISSION_PROFILE_LIST);
        if(isUserAuthenticatedHaveFunctinality==false){
            response.setStatus(functionalError.SAVE_FAIL("Vous ne pouvez pas lister les rôles.Car, vous n'avez pas les permissions nécessaires", locale));
            response.setHasError(true);
            return response;
        }
        if (Utilities.blank(request.getData().getOrderField())) {
            request.getData().setOrderField("");
        }
        if (Utilities.blank(request.getData().getOrderDirection())) {
            request.getData().setOrderDirection("asc");
        }
        List<Role> items = roleRepository.getByCriteria(request, em, locale);
        if (Utilities.isEmpty(items)) {
            response.setStatus(functionalError.DATA_EMPTY("Role", locale));
            response.setHasError(false);
            return response;
        }
        List<RoleDto> itemsDto = Collections.synchronizedList(new ArrayList<RoleDto>());
         itemsDto = (Utilities.isTrue(request.getIsSimpleLoading())) ? RoleTransformer.INSTANCE.toLiteDtos(items) : RoleTransformer.INSTANCE.toDtos(items);
         itemsDto.parallelStream().forEach(i->{
             try {
                 i=getFullInfos(i,items.size(), Boolean.FALSE,locale);
             } catch (Exception e) {
                 throw new RuntimeException(e);
             }
         });
        response.setItems(itemsDto);
        response.setCount(roleRepository.count(request, em, locale));
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end get Role-----");
        return response;
    }

    @Transactional(rollbackFor = {RuntimeException.class, Exception.class})
    public Response<FunctionalityDto> getFunctionalities(Request<RoleDto> request, Locale locale) throws Exception {
        Response<FunctionalityDto> response = new Response<FunctionalityDto>();
        if(request==null||request.getData()==null){
            response.setStatus(functionalError.FIELD_EMPTY("Aucune donnée", locale));
            response.setHasError(true);
            return response;
        }
        Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
        fieldsToVerify.put("code", request.getData().getCode());
        if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
            response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
            response.setHasError(true);
            return response;
        }
        String roleCode = request.getData().getCode();
        List<Functionality> functionalities = null;
        functionalities = roleFunctionalityRepository.findFunctionalityByRoleCode(roleCode , false);
        List<FunctionalityDto> functionalityDtos = FunctionalityTransformer.INSTANCE.toDtos(functionalities);
        response.setItems(functionalityDtos);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("",locale));
        log.info("----end get FUnctionalities by role-----");
        return response;
    }

    private RoleDto getFullInfos(RoleDto dto, Integer size, Boolean isSimpleLoading,Locale locale) throws Exception {
        // put code here
          List<Functionality> functionalities = roleFunctionalityRepository.findFunctionalityByRoleId(dto.getId(), Boolean.FALSE);
          if(Utilities.isNotEmpty(functionalities)){
                  List<FunctionalityDto> functionalityDtos = FunctionalityTransformer.INSTANCE.toDtos(functionalities);
                  dto.setDatasFunctionalities(functionalityDtos);
          }
          if (Utilities.isTrue(isSimpleLoading)) {
             return dto;
        }
        if (size > 1) {
            return dto;
        }

        return dto;
    }
    
}
