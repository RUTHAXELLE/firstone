package ci.sgabs.gs.souscriptionApp.utils.dto.transformer;

import ci.sgabs.gs.souscriptionApp.dao.entity.TypeClient;
import ci.sgabs.gs.souscriptionApp.dao.entity.TypeCompte;
import ci.sgabs.gs.souscriptionApp.helper.contrat.FullTransformerQualifier;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.TypeClientDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.TypeCompteDto;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

@Mapper
public interface TypeClientTransformer {

    TypeClientTransformer INSTANCE = Mappers.getMapper(TypeClientTransformer.class);

    @FullTransformerQualifier
    @Mappings({
            @Mapping(source = "entity.id", target = "id"),
            @Mapping(source = "entity.code", target = "code"),
            @Mapping(source = "entity.libelle", target = "libelle"),
            @Mapping(source = "entity.description", target = "description"),
            @Mapping(source="entity.updatedAt", dateFormat="dd/MM/yyyy",target="updatedAt"),
            @Mapping(source="entity.createdAt", dateFormat="dd/MM/yyyy",target="createdAt"),
            @Mapping(source="entity.deletedAt", dateFormat="dd/MM/yyyy",target="deletedAt"),
            @Mapping(source="entity.updatedBy",target="updatedBy"),
            @Mapping(source="entity.createdBy", target="createdBy"),
            @Mapping(source="entity.deletedBy", target="deletedBy"),

    })
    TypeClientDto toDto(TypeClient entity);

    @IterableMapping(qualifiedBy = {FullTransformerQualifier.class})
    List<TypeClientDto> toDtos(List<TypeClient> entities) throws ParseException;

    public default TypeClientDto toLiteDto(TypeClient entity) {
        if (entity == null) {
            return null;
        }
        TypeClientDto dto = new TypeClientDto();
        dto.setId( entity.getId() );
        dto.setCode( entity.getCode() );
        dto.setLibelle(entity.getLibelle());
        dto.setDescription( entity.getDescription() );

        return dto;
    }

    public default List<TypeClientDto> toLiteDtos(List<TypeClient> entities) {
        if (entities == null || entities.stream().allMatch(o -> o == null)) {
            return null;
        }
        List<TypeClientDto> dtos = new ArrayList<TypeClientDto>();
        for (TypeClient entity : entities) {
            dtos.add(toLiteDto(entity));
        }
        return dtos;
    }
    @InheritInverseConfiguration
    TypeClient toEntity(TypeClientDto dto);
}
