package ci.sgabs.gs.souscriptionApp.utils.dto.transformer;

import ci.sgabs.gs.souscriptionApp.dao.entity.Role;
import ci.sgabs.gs.souscriptionApp.dao.entity.TypeCarte;
import ci.sgabs.gs.souscriptionApp.helper.contrat.FullTransformerQualifier;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.RoleDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.TypeCarteDto;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

@Mapper
public interface TypeCarteTransformer {

    TypeCarteTransformer INSTANCE = Mappers.getMapper(TypeCarteTransformer.class);

    @FullTransformerQualifier
    @Mappings({
            @Mapping(source = "entity.id", target = "id"),
            @Mapping(source = "entity.code", target = "code"),
            @Mapping(source = "entity.libelle", target = "libelle"),
            @Mapping(source = "entity.description", target = "description"),

            @Mapping(source = "entity.typeGen", target = "typeGen"),
            @Mapping(source = "entity.codeProduit", target = "codeProduit"),
            @Mapping(source = "entity.identifiantProduit", target = "identifiantProduit"),
            @Mapping(source = "entity.identifiantGroupe", target = "identifiantGroupe"),

            @Mapping(source = "entity.codeTarif", target = "codeTarif"),
            @Mapping(source = "entity.accCountry", target = "accCountry"),
            @Mapping(source = "entity.bin", target = "bin"),
            @Mapping(source = "entity.typeCarte", target = "typeCarte"),

            @Mapping(source = "entity.produit", target = "produit"),
            @Mapping(source = "entity.codeBanque", target = "codeBanque"),
            @Mapping(source = "entity.identifiantInstitution", target = "identifiantInstitution"),
            @Mapping(source = "entity.business", target = "business"),

            @Mapping(source = "entity.devise", target = "devise"),
            @Mapping(source = "entity.pays", target = "pays"),
            @Mapping(source = "entity.type", target = "type"),

            @Mapping(source="entity.updatedAt", dateFormat="dd/MM/yyyy HH:mm:ss",target="updatedAt"),
            @Mapping(source="entity.createdAt", dateFormat="dd/MM/yyyy HH:mm:ss",target="createdAt"),
            @Mapping(source="entity.deletedAt", dateFormat="dd/MM/yyyy HH:mm:ss",target="deletedAt"),
            @Mapping(source="entity.updatedBy",target="updatedBy"),
            @Mapping(source="entity.createdBy", target="createdBy"),
            @Mapping(source="entity.deletedBy", target="deletedBy"),
    })
    TypeCarteDto toDto(TypeCarte entity);

    @IterableMapping(qualifiedBy = {FullTransformerQualifier.class})
    List<TypeCarteDto> toDtos(List<TypeCarte> entities) throws ParseException;

    public default TypeCarteDto toLiteDto(TypeCarte entity) {
        if (entity == null) {
            return null;
        }
        TypeCarteDto dto = new TypeCarteDto();
        dto.setId( entity.getId() );
        dto.setCode( entity.getCode() );
        dto.setLibelle(entity.getLibelle());
        dto.setDescription( entity.getDescription() );

        return dto;
    }

    public default List<TypeCarteDto> toLiteDtos(List<TypeCarte> entities) {
        if (entities == null || entities.stream().allMatch(o -> o == null)) {
            return null;
        }
        List<TypeCarteDto> dtos = new ArrayList<TypeCarteDto>();
        for (TypeCarte entity : entities) {
            dtos.add(toLiteDto(entity));
        }
        return dtos;
    }

    @InheritInverseConfiguration
    TypeCarte toEntity(TypeCarteDto dto);
}
