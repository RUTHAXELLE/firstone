package ci.sgabs.gs.souscriptionApp.utils.authentification;

import ci.sgabs.gs.souscriptionApp.dao.entity.Users;
import ci.sgabs.gs.souscriptionApp.dao.repository.UsersRepository;
import io.jsonwebtoken.*;
import io.jsonwebtoken.security.SignatureException;
import lombok.extern.java.Log;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import javax.crypto.spec.SecretKeySpec;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import java.security.Key;
import java.security.SecureRandom;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.Date;

import static org.springframework.http.HttpHeaders.AUTHORIZATION;

@Log
public class SecurityServices {


    private static String	defaultTenant = "null";
    private static String defaultLanguage = "fr";

    @Autowired
    UsersRepository usersRepository;


    public static String createToken(Users users){
        Key hmacKey = new SecretKeySpec(Base64.getDecoder().decode(SecurityConstants.SESSION_TOKEN_FIELD_SECRET_PHRASE),
                SignatureAlgorithm.HS256.getJcaName());
        Instant now = Instant.now();
        String jwtToken = Jwts.builder()
                .claim(SecurityConstants.SESSION_TOKEN_FILED_USER_ID, users.getId() != null ? users.getId() : null)
                .claim(SecurityConstants.SESSION_TOKEN_FILED_USER_LOGIN, users.getLogin() != null ? users.getLogin() : null)
                .claim(SecurityConstants.SESSION_TOKEN_FILED_USER_ROLE, users.getRole() != null ? users.getRole().getId() :  null)
                .setSubject(users.getNom())
                .setId(users.getId().toString())
                .setIssuedAt(Date.from(now))
                .setExpiration(Date.from(now.plus(3000l, ChronoUnit.MINUTES)))
                .signWith(hmacKey)
                .compact();
        return jwtToken;
    }

    public static Jws<Claims> decodeAndValidateToken(String token){
        if(token==null) return null ;
        Jws<Claims> jwt = null ;
       try{
            Key hmacKey = new SecretKeySpec(Base64.getDecoder().decode(SecurityConstants.SESSION_TOKEN_FIELD_SECRET_PHRASE),
                    SignatureAlgorithm.HS256.getJcaName());
             jwt = Jwts.parserBuilder()
                    .setSigningKey(hmacKey)
                    .build()
                    .parseClaimsJws(token);
             log.info("_85jwt="+jwt.toString());
       }catch (ExpiredJwtException eje){
            log.info("_84 Token invalide");
            return null ;
        }catch (SignatureException se){
            log.info("_87 Token invalide");
            return null ;
        }catch (MalformedJwtException mje){
            log.info("_90 Token mal formé");
            return null ;
        }
        return jwt;
    }

    public static String generateCode1(){
        String formatted = null;
        formatted = RandomStringUtils.randomAlphanumeric(8).toUpperCase();
        return formatted;
    }

    public static String generateCode2(){
        String formatted = null;
        SecureRandom secureRandom = new SecureRandom();
        int num = secureRandom.nextInt(100000000);
        formatted = String.format("%05d", num);
        return formatted;
    }

    public  boolean authenticateUser(Jws<Claims> token) {
        Integer userId = Integer.valueOf(token.getBody().getId());
        Users user = usersRepository.findOne(userId,false);
        if(user == null){
            return false;
        }
        return true;
    }


    public static String extractToken(HttpServletRequest servletResquest){
        if(servletResquest==null) return null;
        String token = servletResquest.getHeader(AUTHORIZATION);
        if(token==null) return null;
        String rtn = token.substring(("Bearer ".length()));
        return rtn == null || rtn.isEmpty() ? null : rtn;
    }

    public static void languageManager(HttpServletRequest req){
        String tenantValue = req.getHeader("tenantID");
        if (tenantValue != null) {
            req.setAttribute("CURRENT_TENANT_IDENTIFIER", tenantValue);
        } else {
            req.setAttribute("CURRENT_TENANT_IDENTIFIER", defaultTenant);
        }

        String langValue = req.getHeader("lang");
        if (langValue != null) {
            req.setAttribute("CURRENT_LANGUAGE_IDENTIFIER", langValue);
        } else {
            req.setAttribute("CURRENT_LANGUAGE_IDENTIFIER", defaultLanguage);
        }

    }

}
