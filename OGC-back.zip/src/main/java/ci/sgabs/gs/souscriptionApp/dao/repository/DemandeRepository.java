package ci.sgabs.gs.souscriptionApp.dao.repository;

import ci.sgabs.gs.souscriptionApp.dao.entity.Demande;
import ci.sgabs.gs.souscriptionApp.dao.entity.Demande;
import ci.sgabs.gs.souscriptionApp.dao.entity.Status;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.searchFunctions.CriteriaUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.DemandeDto;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import java.util.*;

public interface DemandeRepository extends JpaRepository<Demande, Integer> {

    @Query("select e from Demande e where e.id= :id and e.isDeleted= :isDeleted")
    Demande findOne(@Param("id") Integer id, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from Demande e where e.code= :code and e.isDeleted= :isDeleted")
    Demande findByCode(@Param("code") String code, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from Demande e where e.matricule= :matricule and e.isDeleted= :isDeleted")
    Demande findByMatricule(@Param("matricule") String matricule, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from Demande e where e.compte.id= :CompteId and e.isDeleted= :isDeleted")
    List<Demande> findByCompteId(@Param("CompteId") Integer CompteId, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from Demande e where e.typeCarte.id= :typeCarteId and e.isDeleted= :isDeleted")
    List<Demande> findByTypeCarteId(@Param("typeCarteId") Integer typeCarteId, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from Demande e where e.status.id= :statusId and e.isDeleted= :isDeleted")
    List<Demande> findByStatusId(@Param("statusId") Integer statusId, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from Demande e where e.compte.numero= :numeroCompte and e.isDeleted= :isDeleted")
    List<Demande> findByNumeroCompte(@Param("numeroCompte") String numeroCompte, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from Demande e where e.typeCarte.code= :codeTypeCarte and e.isDeleted= :isDeleted")
    List<Demande> findByTypeCarteCode(@Param("codeTypeCarte") String codeTypeCarte, @Param("isDeleted") Boolean isDeleted);

    @Query("select e from Demande e where e.status.code= :codeStatus and e.isDeleted= :isDeleted")
    List<Demande> findByStatusCode(@Param("codeStatus") String codeStatus, @Param("isDeleted") Boolean isDeleted);

    @Query("select d from Demande d where d.id= :id  and d.isDeleted= :isDeleted")
    Demande findDemandeByStatusActual(@Param("id") Integer id, @Param("isDeleted") Boolean isDeleted);


    // criteria search//
    public default List<Demande> getByCriteria(Request<DemandeDto> request, EntityManager em, Locale locale) throws DataAccessException, Exception {
        String req = "select e from Demande e where e IS NOT NULL";
        HashMap<String, Object> param = new HashMap<String, Object>();
        req += getWhereExpression(request, param, locale);
        TypedQuery<Demande> query = em.createQuery(req, Demande.class);
        for (Map.Entry<String, Object> entry : param.entrySet()) {
            query.setParameter(entry.getKey(), entry.getValue());
        }
        if (request.getIndex() != null && request.getSize() != null) {
            query.setFirstResult(request.getIndex() * request.getSize());
            query.setMaxResults(request.getSize());
        }
        return query.getResultList();
    }

    public default Long count(Request<DemandeDto> request, EntityManager em, Locale locale) throws DataAccessException, Exception {
        String req = "select count(*) from Demande e where e IS NOT NULL";
        HashMap<String, Object> param = new HashMap<String, Object>();
        req += getWhereExpressionCount(request, param, locale);
        javax.persistence.Query query = em.createQuery(req);
        for (Map.Entry<String, Object> entry : param.entrySet()) {
            query.setParameter(entry.getKey(), entry.getValue());
        }
        Long count = (Long) query.getResultList().get(0);
        return count;
    }

    /**
     * get where expression
     *
     * @param request
     * @param param
     * @param locale
     * @return
     * @throws Exception
     */
    default String getWhereExpression(Request<DemandeDto> request, HashMap<String, Object> param, Locale locale) throws Exception {
        // main query
        DemandeDto dto = request.getData() != null ? request.getData() : new DemandeDto();
        dto.setIsDeleted(false);
        String mainReq = generateCriteria(dto, param, 0, locale);
        // others query
        String othersReq = "";
        if (request.getDatas() != null && !request.getDatas().isEmpty()) {
            Integer index = 1;
            for (DemandeDto elt : request.getDatas()) {
                elt.setIsDeleted(false);
                String eltReq = generateCriteria(elt, param, index, locale);
                if (request.getIsAnd() != null && request.getIsAnd()) {
                    othersReq += "and (" + eltReq + ") ";
                } else {
                    othersReq += "or (" + eltReq + ") ";
                }
                index++;
            }
        }
        String req = "";
        if (!mainReq.isEmpty()) {
            req += " and (" + mainReq + ") ";
        }
        req += othersReq;

        //order
        if (Sort.Direction.fromOptionalString(dto.getOrderDirection()).orElse(null) != null && Utilities.notBlank(dto.getOrderField())) {
            req += " order by e." + dto.getOrderField() + " " + dto.getOrderDirection();
        } else {
            req += " order by  e.id desc";
        }
        return req;
    }


    default String getWhereExpressionCount(Request<DemandeDto> request, HashMap<String, Object> param, Locale locale) throws Exception {
        // main query
        DemandeDto dto = request.getData() != null ? request.getData() : new DemandeDto();
        dto.setIsDeleted(false);
        String mainReq = generateCriteria(dto, param, 0, locale);
        // others query
        String othersReq = "";
        if (request.getDatas() != null && !request.getDatas().isEmpty()) {
            Integer index = 1;
            for (DemandeDto elt : request.getDatas()) {
                elt.setIsDeleted(false);
                String eltReq = generateCriteria(elt, param, index, locale);
                if (request.getIsAnd() != null && request.getIsAnd()) {
                    othersReq += "and (" + eltReq + ") ";
                } else {
                    othersReq += "or (" + eltReq + ") ";
                }
                index++;
            }
        }
        String req = "";
        if (!mainReq.isEmpty()) {
            req += " and (" + mainReq + ") ";
        }
        req += othersReq;
        return req;
    }

    /**
     * generate sql query for dto
     *
     * @param dto
     * @param param
     * @param index
     * @param locale
     * @return
     * @throws Exception
     */
    default String generateCriteria(DemandeDto dto, HashMap<String, Object> param, Integer index, Locale locale) throws Exception {
        List<String> listOfQuery = new ArrayList<String>();
        if (dto != null) {
            if (dto.getId() != null || Utilities.searchParamIsNotEmpty(dto.getIdParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("id", dto.getId(), "e.id", "Integer", dto.getIdParam(), param, index, locale));
            }
            if (Utilities.isNotBlank(dto.getCode()) || Utilities.searchParamIsNotEmpty(dto.getCodeParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("code", dto.getCode(), "e.code", "String", dto.getCodeParam(), param, index, locale));
            }
            if (dto.getCompteId() != null || Utilities.searchParamIsNotEmpty(dto.getCompteIdParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("compteId", dto.getCompteId(), "e.compte.id", "Integer", dto.getCompteIdParam(), param, index, locale));
            }
            if (Utilities.isNotBlank(dto.getNumeroCompte()) || Utilities.searchParamIsNotEmpty(dto.getNumeroCompteParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("numeroCompte", dto.getNumeroCompte(), "e.compte.numero", "String", dto.getNumeroCompteParam(), param, index, locale));
            }
            if (dto.getTypeCarteId() != null || Utilities.searchParamIsNotEmpty(dto.getTypeCarteIdParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("typeCarteId", dto.getTypeCarteId(), "e.typeCarte.id", "Integer", dto.getTypeCarteIdParam(), param, index, locale));
            }
            if (Utilities.isNotBlank(dto.getCodeTypeCarte()) || Utilities.searchParamIsNotEmpty(dto.getCodeTypeCarteParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("codeTypeCarte", dto.getCodeTypeCarte(), "e.typeCarte.code", "String", dto.getCodeTypeCarteParam(), param, index, locale));
            }
            if (dto.getStatusId() != null || Utilities.searchParamIsNotEmpty(dto.getStatusIdParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("statusId", dto.getStatusId(), "e.status.id", "Integer", dto.getStatusIdParam(), param, index, locale));
            }
            if (Utilities.isNotBlank(dto.getCodeStatus()) || Utilities.searchParamIsNotEmpty(dto.getCodeStatusParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("codeStatus", dto.getCodeStatus(), "e.status.code", "String", dto.getCodeStatusParam(), param, index, locale));
            }

            if (Utilities.isNotBlank(dto.getNomBeneficiaire()) || Utilities.searchParamIsNotEmpty(dto.getNomBeneficiaireParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("nomBeneficiaire", dto.getNomBeneficiaire(), "e.nomBeneficiaire", "String", dto.getNomBeneficiaireParam(), param, index, locale));
            }
            if (Utilities.isNotBlank(dto.getPrenomBeneficiaire()) || Utilities.searchParamIsNotEmpty(dto.getPrenomBeneficiaireParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("prenomBeneficiaire", dto.getPrenomBeneficiaire(), "e.prenomBeneficiaire", "String", dto.getPrenomBeneficiaireParam(), param, index, locale));
            }

            if (Utilities.isNotBlank(dto.getUpdatedAt()) || Utilities.searchParamIsNotEmpty(dto.getUpdatedAtParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("updatedAt", dto.getUpdatedAt(), "e.updatedAt", "Date", dto.getUpdatedAtParam(), param, index, locale));
            }
            if (dto.getIsDeleted() != null || Utilities.searchParamIsNotEmpty(dto.getIsDeletedParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("isDeleted", dto.getIsDeleted(), "e.isDeleted", "Boolean", dto.getIsDeletedParam(), param, index, locale));
            }
            if (dto.getIsBeneficiary() != null || Utilities.searchParamIsNotEmpty(dto.getIsBeneficiaryParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("isBeneficiary", dto.getIsBeneficiary(), "e.isBeneficiary", "Boolean", dto.getIsBeneficiaryParam(), param, index, locale));
            }
            if (dto.getUpdatedBy() != null || Utilities.searchParamIsNotEmpty(dto.getUpdatedByParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("updatedBy", dto.getUpdatedBy(), "e.updatedBy", "Long", dto.getUpdatedByParam(), param, index, locale));
            }
            if (Utilities.isNotBlank(dto.getCreatedAt()) || Utilities.searchParamIsNotEmpty(dto.getCreatedAtParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("createdAt", dto.getCreatedAt(), "e.createdAt", "Date", dto.getCreatedAtParam(), param, index, locale));
            }
            if (dto.getCreatedBy() != null || Utilities.searchParamIsNotEmpty(dto.getCreatedByParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("createdBy", dto.getCreatedBy(), "e.createdBy", "Long", dto.getCreatedByParam(), param, index, locale));
            }
            if (Utilities.isNotBlank(dto.getDeletedAt()) || Utilities.searchParamIsNotEmpty(dto.getDeletedAtParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("deletedAt", dto.getDeletedAt(), "e.deletedAt", "Date", dto.getDeletedAtParam(), param, index, locale));
            }
            if (dto.getDeletedBy() != null || Utilities.searchParamIsNotEmpty(dto.getDeletedByParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("deletedBy", dto.getDeletedBy(), "e.deletedBy", "Long", dto.getDeletedByParam(), param, index, locale));
            }

            if (dto.getLogin() != null || Utilities.searchParamIsNotEmpty(dto.getLoginParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("login", dto.getLogin(), "e.login", "String", dto.getLoginParam(), param, index, locale));
            }

            if (dto.getAgence() != null || Utilities.searchParamIsNotEmpty(dto.getAgenceParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("agence", dto.getAgence(), "e.agence", "String", dto.getAgenceParam(), param, index, locale));
            }

            if (dto.getProduit() != null || Utilities.searchParamIsNotEmpty(dto.getProduitParam())) {
                listOfQuery.add(CriteriaUtils.generateCriteria("produit", dto.getProduit(), "e.typeCarte.typeCarte", "String", dto.getProduitParam(), param, index, locale));
            }

        }
        return CriteriaUtils.getCriteriaByListOfQuery(listOfQuery);
    }

}
