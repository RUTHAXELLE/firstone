package ci.sgabs.gs.souscriptionApp.utils.dto.entityDto;

import ci.sgabs.gs.souscriptionApp.helper.searchFunctions.SearchParam;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;
import lombok.ToString;

import java.util.List;

@Data
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL) @JsonPropertyOrder(alphabetic = true)
public class DemandeMaintenanceDto {



    private Integer id;

    private String noms;
    private String prenom;
    private String codeAgence ;
    private String agence ;
    private String agent;
    private String numeroCompte;
    private String produit ;
    private String codeTypeCarte;
    private Integer statusId;
    private Integer typeOperationId;
    private Integer carteId;
    private Integer codeCarte;
    private String  numberCard;
    private String  codeStatus;
    private String  libelleTypeCarte;
    private String  codeTypeOperation;
    private String login;

    private Boolean isDeleted;
    private Boolean isGenreatedContrat;
    private Boolean isForced;
    private Boolean isNewCompte ;
    private Boolean isNewAgence ;

    private String createdAt;
    private String updatedAt;
    private String deletedAt;

    private Integer createdBy;
    private Integer updatedBy;
    private Integer deletedBy;
    private Boolean isAction;


    /// SEARCH PARAM//
    private SearchParam<Integer> idParam;
    private SearchParam<String>  typeCarteParam;
    private SearchParam<String>  numeroCarteParam;
    private SearchParam<String>  codeAgenceParam;
    private SearchParam<Integer> statusIdParam;
    private SearchParam<String>  codeStatusParam;
    private SearchParam<String>  numeroCompteParam;
    private SearchParam<String>  produitParam;
    private SearchParam<String>  nomsParam;
    private SearchParam<String> loginParam;
    private SearchParam<String> agenceParam;
    private SearchParam<Boolean> isDeletedParam;
    private SearchParam<String>  createdAtParam;
    private SearchParam<String>  updatedAtParam;
    private SearchParam<String>  deletedAtParam;
    private SearchParam<Integer> createdByParam;
    private SearchParam<Integer> updatedByParam;
    private SearchParam<Integer> deletedByParam;
    private SearchParam<String>  codeTypeOperationParam;


    // order param
    private String orderField;
    private String orderDirection;

    private List<StatusDto> datasStatus;

}
