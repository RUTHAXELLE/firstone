package ci.sgabs.gs.souscriptionApp.business;

import ci.sgabs.gs.souscriptionApp.dao.entity.Attribution;
import ci.sgabs.gs.souscriptionApp.dao.entity.Carte;
import ci.sgabs.gs.souscriptionApp.dao.entity.Demande;
import ci.sgabs.gs.souscriptionApp.dao.repository.AttributionRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.CarteRepository;
import ci.sgabs.gs.souscriptionApp.dao.repository.DemandeRepository;
import ci.sgabs.gs.souscriptionApp.helper.contrat.IBasicBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.errors.FunctionalError;
import ci.sgabs.gs.souscriptionApp.helper.errors.TechnicalError;
import ci.sgabs.gs.souscriptionApp.helper.exception.ExceptionUtils;
import ci.sgabs.gs.souscriptionApp.helper.validation.Utilities;
import ci.sgabs.gs.souscriptionApp.helper.validation.Validate;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.AttributionDto;
import ci.sgabs.gs.souscriptionApp.utils.dto.transformer.AttributionTransformer;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Log
@Component
public class AttributionBusiness implements IBasicBusiness<Request<AttributionDto>, Response<AttributionDto>> {

    private Response<AttributionDto> response;
    @Autowired
    private AttributionRepository attributionRepository;

    @Autowired
    private DemandeRepository demandeRepository;

    @Autowired
    private CarteRepository carteRepository;
    
    @Autowired
    private FunctionalError functionalError;
    
    @Autowired
    private TechnicalError technicalError;
    
    @Autowired
    private ExceptionUtils exceptionUtils;
    
    @Autowired
    private EntityManager em;
    
    private final SimpleDateFormat dateFormat;
    private final SimpleDateFormat dateTimeFormat;

    public AttributionBusiness() {
        dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    }
    
    @Override
    public Response<AttributionDto> create(Request<AttributionDto> request, Locale locale) throws Exception {
        log.info("----begin create Attribution-----");
        Response<AttributionDto> response = new Response<AttributionDto>();
        List<Attribution> items = new ArrayList<Attribution>();

        //Verification
        if(request.getDatas() == null && request.getDatas().isEmpty()){
            response.setStatus(functionalError.DATA_EMPTY("Liste vide" , locale));
            response.setHasError(true);
            return response;
        }

        //Verification
        List<AttributionDto> itemsDtos = Collections.synchronizedList(new ArrayList<AttributionDto>()) ;
        for(AttributionDto dto: request.getDatas()){

            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("code", dto.getCode());
            fieldsToVerify.put("libelle", dto.getLibelle());
            fieldsToVerify.put("demandeId", dto.getDemandeId());
            fieldsToVerify.put("carteId", dto.getCarteId());

            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
            if (itemsDtos.stream().anyMatch(a -> a.getCode().equals(dto.getCode()))) { //verification code
                response.setStatus(functionalError.DATA_DUPLICATE(" Code ", locale));
                response.setHasError(true);
                return response;
            }
            if (itemsDtos.stream().anyMatch(a -> a.getDemandeId().equals(dto.getDemandeId()))) { //verification demande
                response.setStatus(functionalError.DATA_DUPLICATE(" Demande ", locale));
                response.setHasError(true);
                return response;
            }
            if (itemsDtos.stream().anyMatch(a -> a.getCarteId().equals(dto.getCarteId()))) { //verification carte
                response.setStatus(functionalError.DATA_DUPLICATE(" Carte ", locale));
                response.setHasError(true);
                return response;
            }
            itemsDtos.add(dto);
        }

        //Verification
        for(AttributionDto dto : itemsDtos){

            //Verification d'existence
            Attribution existingEntity = null;
            existingEntity = attributionRepository.findByCode(dto.getCode(), false); //verification du code
            
            if (existingEntity != null) {
                response.setStatus(functionalError.DATA_EXIST("Attribution code -> " + dto.getCode(), locale));
                response.setHasError(true);
                return response;
            }

            //Verification de la demande
            existingEntity = attributionRepository.findByDemandeId(dto.getDemandeId(), false);//verification de la demande
            if (existingEntity != null) {
                response.setStatus(functionalError.DATA_EXIST("la demande -> " + dto.getDemandeId()+ " à deja été attribuer", locale));
                response.setHasError(true);
                return response;
            }

            //Verificationde la carte
            existingEntity = attributionRepository.findByCarteId(dto.getCarteId(), false);//verification de la carte
            if (existingEntity != null) {
                response.setStatus(functionalError.DATA_EXIST("la carte -> " + dto.getCarteId()+ " à deja été attribuer", locale));
                response.setHasError(true);
                return response;
            }

            //Verification de la demande attachée
            Demande existingDemande = null;
            
            if (Utilities.isValidID(dto.getDemandeId())) {
                existingDemande = demandeRepository.findOne(dto.getDemandeId(), false);
                if (existingDemande == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("Demande DemandeID -> " + dto.getDemandeId(), locale));
                    response.setHasError(true);
                    return response;
                }
            }

            //Verification de la carte attachée
            Carte existingCarte = null;

            if (Utilities.isValidID(dto.getCarteId())) {
                existingCarte = carteRepository.findOne(dto.getCarteId(), false);
                if (existingCarte == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("Carte CarteID -> " + dto.getCarteId(), locale));
                    response.setHasError(true);
                    return response;
                }
            }

            //Transformation
            Attribution entityToSave = AttributionTransformer
                            .INSTANCE.toEntity(dto, existingDemande, existingCarte);

            entityToSave.setIsDeleted(false);
            entityToSave.setCreatedAt(Utilities.getCurrentDate());
            entityToSave.setCreatedBy(request.userID);
            items.add(entityToSave);
        }

        if(items == null && items.isEmpty()){
            response.setStatus(functionalError.DATA_EMPTY("La liste vide",locale));
            response.setHasError(true);
            return response;
        }

        List<Attribution> itemsSaved = null;
        itemsSaved = attributionRepository.saveAll((Iterable<Attribution>) items);
            
        if (itemsSaved == null) {
            response.setStatus(functionalError.SAVE_FAIL("Attribution", locale));
            response.setHasError(true);
            return response;
        }

        //Transformation
        List<AttributionDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                            ? AttributionTransformer.INSTANCE.toLiteDtos(itemsSaved)
                            : AttributionTransformer.INSTANCE.toDtos(itemsSaved);

        //Envoie de la reponse
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        log.info("----end create Attribution-----");
        return response;
    }

    @Override
    public Response<AttributionDto> update(Request<AttributionDto> request, Locale locale) throws ParseException {

        log.info("----begin update Attribution -----");

        Response<AttributionDto> response = new Response<AttributionDto>();
        List<Attribution> items = new ArrayList<Attribution>();

        //Verification
        if(request.getDatas() == null && request.getDatas().isEmpty()){
            response.setStatus(functionalError.DATA_EMPTY("Liste vide" , locale));
            response.setHasError(true);
            return response;
        }

        //Verification du champ obligatoire
        for(AttributionDto dto : request.getDatas()) {
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());
            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
        }

        //Verification et modification
        for(AttributionDto dto : request.getDatas()){

            Attribution entityToSave = null;
            entityToSave = attributionRepository.findOne(dto.getId(), false);

            if (entityToSave == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Attribution id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }


            //Verification de la demande
            Demande existingDemande = null;

            if (Utilities.isValidID(dto.getDemandeId()) && !entityToSave.getDemande().getId().equals(dto.getDemandeId())) {

                existingDemande = demandeRepository.findOne(dto.getDemandeId(), false);
                if (existingDemande == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("Demande DemandeId -> " + dto.getDemandeId(), locale));
                    response.setHasError(true);
                    return response;
                }
                Attribution existingDemandeAttribution = attributionRepository.findByDemandeId(existingDemande.getId(), false);//verification de la demande
                if (existingDemandeAttribution != null) {
                    response.setStatus(functionalError.DATA_EXIST("la demande -> " + dto.getDemandeId()+ " à deja été attribuer", locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setDemande(existingDemande);
            }

            //Verification de la carte attachée
            Carte existingCarte = null;

            if (Utilities.isValidID(dto.getCarteId()) && !entityToSave.getCarte().getId().equals(dto.getCarteId())) {

                existingCarte = carteRepository.findOne(dto.getCarteId(), false);
                if (existingCarte == null) {
                    response.setStatus(functionalError.DATA_NOT_EXIST("Carte CarteId -> " + dto.getCarteId(), locale));
                    response.setHasError(true);
                    return response;
                }
                Attribution existingCarteAttribution = attributionRepository.findByCarteId(existingCarte.getId(), false);//verification de la demande
                if (existingCarteAttribution != null) {
                    response.setStatus(functionalError.DATA_EXIST("la demande -> " + dto.getDemandeId()+ " à deja été attribuer", locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setCarte(existingCarte);
            }

            //Verification code
            if (Utilities.isNotBlank(dto.getCode()) && !dto.getCode().equals(entityToSave.getCode())) { //verify code
                
                Attribution existingEntity = attributionRepository.findByCode(dto.getCode(), false);
                
                if (existingEntity != null && !existingEntity.getId().equals(entityToSave.getId())) {
                    response.setStatus(functionalError.DATA_EXIST("Attribution -> " + dto.getCode(), locale));
                    response.setHasError(true);
                    return response;
                }
                entityToSave.setCode(dto.getCode());
            }

            //Verification du libellé
            if (Utilities.isNotBlank(dto.getLibelle()) && !dto.getLibelle().equals(entityToSave.getLibelle())) {
                entityToSave.setLibelle(dto.getLibelle());
            }

            entityToSave.setUpdatedAt(Utilities.getCurrentDate());
            entityToSave.setUpdatedBy(request.userID);
            items.add(entityToSave);
        }

        if(items == null && items.isEmpty()){
            response.setStatus(functionalError.DATA_EMPTY("Liste vide", locale));
            response.setHasError(true);
            return response;
        }

        //Transformation
        List<AttributionDto> itemsDto = (Utilities.isTrue(request.getIsSimpleLoading()))
                                ? AttributionTransformer.INSTANCE.toLiteDtos(items)
                                : AttributionTransformer.INSTANCE.toDtos(items);

        //Envoie de la reponse
        response.setItems(itemsDto);
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));

        log.info("end Attribution update");

        return response;
    }

    @Override
    public Response<AttributionDto> delete(Request<AttributionDto> request, Locale locale) {

        log.info("----begin delete Attribution-----");

        Response<AttributionDto> response = new Response<AttributionDto>();
        List<Attribution> items = new ArrayList<Attribution>();

        if(request.getDatas() == null && request.getDatas().isEmpty()){
            response.setStatus(functionalError.DATA_EMPTY("Liste de vide", locale));
            response.setHasError(true);
            return response;
        }

        //Verification du champs obligatoire
        for(AttributionDto dto: request.getDatas()){
            Map<String, Object> fieldsToVerify = new HashMap<String, Object>();
            fieldsToVerify.put("id", dto.getId());

            if (!Validate.RequiredValue(fieldsToVerify).isGood()) {
                response.setStatus(functionalError.FIELD_EMPTY(Validate.getValidate().getField(), locale));
                response.setHasError(true);
                return response;
            }
        }

        //Verification
        for(AttributionDto dto : request.getDatas()){

            //Verification
            Attribution existingEntity = null;
            existingEntity = attributionRepository.findOne(dto.getId(), false);

            if (existingEntity == null) {
                response.setStatus(functionalError.DATA_NOT_EXIST("Attribution id -> " + dto.getId(), locale));
                response.setHasError(true);
                return response;
            }

            existingEntity.setIsDeleted(true);
            existingEntity.setDeletedAt(Utilities.getCurrentDate());
            existingEntity.setDeletedBy(request.userID);
            items.add(existingEntity);
        }

        if(items == null && items.isEmpty()){
            response.setStatus(functionalError.DATA_NOT_EXIST("Liste de vide", locale));
            response.setHasError(true);
            return response;
        }

        //Envoie de la reponse
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end delete User-----");
        return response;
    }

    @Override
    public Response<AttributionDto> forceDelete(Request<AttributionDto> request, Locale locale) throws ParseException {
        return null;
    }

    @Override
    public Response<AttributionDto> getByCriteria(Request<AttributionDto> request, Locale locale) throws Exception {

        log.info("----begin get Attribution-----");

        Response<AttributionDto> response = new Response<AttributionDto>();

        //Verification si le parametre d'ordre à été fourni, sinon nous mettons le paramètre à vide
        if (Utilities.blank(request.getData().getOrderField())) {
            request.getData().setOrderField("");
        }

        //Verification si le parametre direction à été fourni, sinon nous mettons le paramètre ascendant( du plus ancien au plus ressent)
        if (Utilities.blank(request.getData().getOrderDirection())) {
            request.getData().setOrderDirection("asc");
        }

        //Recuperation des entités en base

        List<Attribution> items = attributionRepository.getByCriteria(request, em, locale);

        if (Utilities.isEmpty(items)) {
            response.setStatus(functionalError.DATA_EMPTY("Attribution", locale));
            response.setHasError(false);
            return response;
        }

        //Transformation
        List<AttributionDto> itemsDto = AttributionTransformer.INSTANCE.toDtos(items);

        //Envoie de la reponse
        response.setItems(itemsDto);
        response.setCount(attributionRepository.count(request, em, locale));
        response.setHasError(false);
        response.setStatus(functionalError.SUCCESS("", locale));
        log.info("----end get Attribution-----");
        return response;
    }
}
