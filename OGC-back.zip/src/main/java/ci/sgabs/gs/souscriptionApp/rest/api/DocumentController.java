package ci.sgabs.gs.souscriptionApp.rest.api;

import ci.sgabs.gs.souscriptionApp.business.DocumentBusiness;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Request;
import ci.sgabs.gs.souscriptionApp.helper.contrat.Response;
import ci.sgabs.gs.souscriptionApp.helper.enums.FunctionalityEnum;
import ci.sgabs.gs.souscriptionApp.rest.fact.ControllerFactory;
import ci.sgabs.gs.souscriptionApp.utils.dto.entityDto.DocumentDto;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Log
@CrossOrigin("*")
@RestController
@RequestMapping(value="/document")
public class DocumentController {


    @Autowired
    private ControllerFactory<DocumentDto> controllerFactory;
    @Autowired
    private DocumentBusiness documentBusiness;

    @RequestMapping(value="",method= RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<DocumentDto> create(@RequestBody Request<DocumentDto> request) {
        log.info("start method /Document/create");
        Response<DocumentDto> response = controllerFactory.create(documentBusiness, request, FunctionalityEnum.CREATE_DOCUMENT);
        log.info("end method /Document/create");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.PUT,consumes = {"application/json"},produces={"application/json"})
    public Response<DocumentDto> update(@RequestBody Request<DocumentDto> request) {
        log.info("start method /Documents/update");
        Response<DocumentDto> response = controllerFactory.update(documentBusiness, request, FunctionalityEnum.UPDATE_DOCUMENT);
        log.info("end method /Document/update");
        return response;
    }

    @RequestMapping(value="",method=RequestMethod.DELETE,consumes = {"application/json"},produces={"application/json"})
    public Response<DocumentDto> delete(@RequestBody Request<DocumentDto> request) {
        log.info("start method /Document/delete");
        Response<DocumentDto> response = controllerFactory.delete(documentBusiness, request, FunctionalityEnum.DELETE_DOCUMENT);
        log.info("end method /Document/delete");
        return response;
    }

    @RequestMapping(value="/forceDelete",method=RequestMethod.DELETE,consumes = {"application/json"},produces={"application/json"})
    public Response<DocumentDto> forceDelete(@RequestBody Request<DocumentDto> request) {
        log.info("start method /Document/forceDelete");
        Response<DocumentDto> response = controllerFactory.forceDelete(documentBusiness, request, FunctionalityEnum.DELETE_DOCUMENT);
        log.info("end method /Document/forceDelete");
        return response;
    }

    @RequestMapping(value="/getByCriteria",method=RequestMethod.POST,consumes = {"application/json"},produces={"application/json"})
    public Response<DocumentDto> getByCriteria(@RequestBody Request<DocumentDto> request) {
        log.info("start method /Document/getByCriteria");
        Response<DocumentDto> response = controllerFactory.getByCriteria(documentBusiness, request, FunctionalityEnum.VIEW_DOCUMENT);
        log.info("end method /Document/getByCriteria");
        return response;
    }
}
